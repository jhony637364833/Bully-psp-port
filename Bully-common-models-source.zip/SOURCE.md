<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:4eb8dc52a864cdec6e91c307327fc1845b83f887d3f021120da2ce5bdb178ee2 -->

<!-- coderabbit-ai-generated-section:v1:4183dad0db7e061b9cb0fb33546b7ab694024c2cbd904934f3d2c062525961c1 -->

# Bully common model patch source

These are reproducible patch sources for the exact supplied R4 EBOOT, not the unavailable complete R4 engine source. Based on PS2RC by SandstoneDev; retain the original distribution notices. No user disc data, RAM snapshots or saves are included.

Run with Python 3 from the extracted source directory:

```sh
python3 tools/bully/rigid_models.py /path/to/original-R4/EBOOT.PBP /path/to/new/EBOOT.PBP
```

The original R4 input must have SHA256 f84408a1f8d3956e085a95be29537aa6d99755fb2fb9fae490ec3ff134ecfa5f. The patcher itself verifies the correct complete input identity; the exact identity in the patcher is authoritative. It composes the previous CPU, original texture quality, quiet-log and skin material-flag patches. It does not accept an already patched EBOOT.

The flag trampoline clears bit 0x08 only after the original static-format branch, where bit 0x40 was already normalized, then performs the existing equality check. Unknown remaining flags still reject. Stream validation, complete object commit, mesh vertex counts, triangle counts and palette limits are preserved. This expands the formerly restricted geometry flag contract; it does not implement all RenderWare pipelines or original character lighting.

Assembly can be reproduced using the PSP toolchain:

```sh
psp-as -march=allegrex tools/bully/rigid_models.S -o /tmp/rigid.o
psp-ld -Ttext=0x099144b0 -e _start /tmp/rigid.o -o /tmp/rigid.elf
psp-objcopy -O binary -j .text /tmp/rigid.elf /tmp/rigid.bin
```

The resulting bytes must equal CAVE in rigid_models.py. Only the guarded flag-check and callback-filter jumps, ELF final LOAD sizes, PBP length and appended payload change relative to the preceding item-visibility build. A second trampoline admits exactly callback 0x0025ec80 in addition to the three existing setup callbacks. The original guest setup still executes exactly once before native drawing. Other callbacks and invalid pointers retain their rejection behavior. The complete appended payload is 72 bytes, including alignment between the two trampolines. No complete renderer replacement or additional permanent model buffers are introduced.

Private fixture tests require gcc, pyelftools and Unicorn. Fixtures are excluded from this archive:

```sh
python3 tests/bully/check_rigid_models.py ORIGINAL_EBOOT PRIVATE_BOTTLE_RAM 0x1bd3ad0
python3 tests/bully/check_skin_flag.py ORIGINAL_EBOOT PRIVATE_SKATEBOARD_RAM rigid
python3 tests/bully/check_render_filter.py ORIGINAL_EBOOT
```

The C reference under tests is an independent host oracle; it is not compiled into the EBOOT. Actual MIPS tests compare R4 batches against independently extracted positions, UVs, normals and ADC strip flags. Thirty-two captured atomics and nine malformed input checks passed. A separate actual-hook test checks callback eligibility, original setup side effects/order and register preservation; these are not a full-game or Android test. Previous CPU differential results are retained because the relevant patch bytes are unchanged.


<!-- /coderabbit-ai-generated:v1 -->

Desktop PPSSPP 1.20.4 coldboot with the supplied normal save visibly displays the green STINKBOMB chemical bottle in Jimmy’s hand after this callback repair. The original R4 comparison has the same selected flask icon and an empty hand. This verifies one flask in one scene; other chemical bottles, NPCs, vehicles, ground pickups and Android behavior are not established by that result.


<!-- /coderabbit-ai-generated:v1 -->