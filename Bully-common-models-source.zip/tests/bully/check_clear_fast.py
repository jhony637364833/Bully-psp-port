#!/usr/bin/env python3
"""Differentially execute the actual original/patched MIPS function."""
from pathlib import Path
import sys,struct,io,random
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'tools/bully'))
import clear_fast
from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.mips_const import *
base=Path(sys.argv[1]).read_bytes();patched=clear_fast.patch(base)
def run(pbp,count,guestsp,mask,objects):
 u=Uc(UC_ARCH_MIPS,UC_MODE_MIPS32|UC_MODE_LITTLE_ENDIAN)
 start,end=struct.unpack_from('<II',pbp,32)
 e=ELFFile(io.BytesIO(pbp[start:end]));segments=[s for s in e.iter_segments() if s['p_type']=='PT_LOAD']
 lo=min(s['p_vaddr'] for s in segments)&~4095; hi=(max(s['p_vaddr']+s['p_memsz'] for s in segments)+4095)&~4095
 u.mem_map(lo,hi-lo)
 for s in segments:u.mem_write(s['p_vaddr'],s.data())
 for addr,size in [(0xa000000,0x20000),(0xb000000,0x1000),(0xc000000,0x10000),(0x7000000,4096)]:u.mem_map(addr,size)
 def put(a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
 def get(a):return struct.unpack('<I',u.mem_read(a,4))[0]
 ctx=0xb000000;ram=0xa000000;sp=0xc008000
 u.mem_write(ram,bytes([0xa5])*0x20000);u.mem_write(ctx,bytes((i*73+11)%256 for i in range(4096)))
 put(ctx+0x1d0,guestsp);put(ctx+0x40,0x400);put(ctx+0x2ac,ram);put(ctx+0x2b0,mask)
 put(ram+0x498,objects)
 for i in range(objects):
  put(ram+0x490+i*4,0x1000+16*i);put(ram+0x1000+16*i+2,0xfefefeff)
 put(0x098ad570,count);put(0x098ad560,0xdeadbeef)
 u.reg_write(UC_MIPS_REG_A0,ctx);u.reg_write(UC_MIPS_REG_SP,sp);u.reg_write(UC_MIPS_REG_RA,0x7000000)
 calls=[];steps=0
 def hook(u,a,size,data):
  nonlocal steps
  steps+=1
  if a in (0x97469d0,0x8d14250):
   calls.append((a,bytes(u.mem_read(ctx,704)),bytes(u.mem_read(ram,0x20000)),get(0x098ad570),get(0x098ad560)))
   if a==0x97469d0:put(0x098ad570,0) # deterministic scheduler return
   u.reg_write(UC_MIPS_REG_PC,u.reg_read(UC_MIPS_REG_RA))
 u.hook_add(UC_HOOK_CODE,hook)
 u.emu_start(0x88a984c,0x7000000,count=100000)
 assert u.reg_read(UC_MIPS_REG_PC)==0x7000000
 return (bytes(u.mem_read(ctx,704)),bytes(u.mem_read(ram,0x20000)),get(0x098ad570),get(0x098ad560),calls),steps
cases=[(count,sp,mask,n) for count in (0,1008,1009,1022,1023,1024,0xfffffffe,0xffffffff) for sp,mask in ((0x8000,0x1ffff),(0x8001,0x1ffff),(8,0x1ffff),(16,0x1ffff),(0x10,7)) for n in (0,2)]
# Small-mask fixtures alias object storage: use no objects and avoid arbitrary callbacks.
cases=[c for c in cases if c[2]>=0x1000 or c[3]==0]
rng=random.Random(21269)
cases += [(rng.randrange(1025), rng.choice((0,0xffff8000,0x8000,0x8003,8)),0x1ffff,rng.choice((0,1,2))) for _ in range(48)]
fast_steps=[]
for c in cases:
 old,oldsteps=run(base,*c);new,newsteps=run(patched,*c)
 assert old==new,c
 if c[0]==0 and c[1]==0x8000 and c[3]==0:fast_steps=[oldsteps,newsteps]
for bad in (patched,base[:-1],b''):
 try:clear_fast.patch(bad)
 except ValueError:pass
 else:raise AssertionError('accepted invalid input')
print('PASS',len(cases),'MIPS differential cases: full context/RAM/callbacks/checkpoint sequence; instructions',fast_steps)
