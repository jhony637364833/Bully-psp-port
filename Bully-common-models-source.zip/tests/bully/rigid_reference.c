/* Independent host reference for observed rigid VIF(3,1) streams.
 * Test oracle only; this is not injected into the EBOOT.
 * No guest memory is modified. Strip ADC markers accompany each batch.
 */
#include <stdint.h>
#include <stddef.h>

typedef struct {
    float position[3], uv[2];
    uint8_t color[4], secondary[4];
    int8_t normal[3];
} Vertex;
typedef struct { uint32_t stream,bytes,vertices,material,compressed; } Mesh;
typedef struct {
    float view[4][3],near_plane,far_plane;
    uint32_t triangles,meshes,palette,bones;
    Mesh mesh[64];
} Object;
typedef void (*Visit)(const Vertex *,const uint8_t *,size_t,void *);

static uint32_t word(const uint8_t *p) {
    return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static float scalar(const uint8_t *p) {
    union { uint32_t u; float f; } v={.u=word(p)};return v.f;
}
static int finite_float(float f) {
    union { uint32_t u; float f; } v={.f=f};
    return (v.u&0x7f800000u)!=0x7f800000u;
}
static int range(size_t bytes,uint32_t at,size_t n) {
    return at>=4 && !(at&3) && at<=bytes && n<=bytes-at;
}
static int equal(const uint8_t *a,const uint8_t *b,size_t n) {
    for(size_t i=0;i<n;i++)if(a[i]!=b[i])return 0;
    return 1;
}

/* Exact observed inline RET, V4 positions including ADC, V2 UV and V3 normals.
 * Validate the entire mesh without a visitor before drawing its batches.
 * Failure leaves the reported counts zero. No arbitrary VU commands accepted.
 */
int rigid_chain(const uint8_t *ram,size_t bytes,uint32_t chain,Vertex *scratch,
                Visit visit,void *context,size_t *count,size_t *used,size_t *triangles) {
    const uint8_t *attrs[3]={0},*previous[3]={0};
    const unsigned widths[3]={16,8,3};
    size_t n=0,previous_n=0,total=0,tris=0;
    unsigned seen=0,cycle=0,mode=0,closed=0,batches=0;
    uint8_t skip[256];
    if(!count || !used || !triangles)return 0;
    *count=*used=*triangles=0;
    if(!ram || !scratch || (chain&15) || !range(bytes,chain,16))return 0;
    uint32_t tag=word(ram+chain);
    size_t payload=(tag&65535)*16u;
    if((tag&0xffff0000u)!=0x60000000u || word(ram+chain+4) ||
       payload>bytes-chain-16)return 0;
    size_t at=chain+8,end=chain+16+payload;
    while(at<end) {
        uint32_t code=word(ram+at);at+=4;
        unsigned cmd=code>>24,num=(code>>16)&255,imm=code&65535;
        if(cmd==0 || cmd==0x11) {if(num || imm)return 0;}
        else if(cmd==1) {if(num || imm!=0x103 || closed)return 0;cycle=1;}
        else if(cmd==5) {if(num || imm || closed)return 0;mode=1;}
        else if(cmd==4) {
            if(num || seen!=7 || closed || imm!=n)return 0;
            closed=1;
        } else if(cmd==0x15 || cmd==0x17) {
            if(num || imm || !closed || batches>=2048 || n<3 ||
               (cmd==0x15 ? batches!=0 : batches==0))return 0;
            if(batches)for(unsigned k=0;k<3;k++)
                if(!equal(previous[k]+(previous_n-2)*widths[k],attrs[k],2*widths[k]))return 0;
            for(size_t i=0;i<n;i++) {
                uint32_t adc=word(attrs[0]+i*16+12);
                if(adc&~0x8000u)return 0;
                skip[i]=adc!=0;
                if(i>=2 && !skip[i])tris++;
                for(unsigned k=0;k<3;k++)if(!finite_float(scalar(attrs[0]+i*16+k*4)))return 0;
                for(unsigned k=0;k<2;k++)if(!finite_float(scalar(attrs[1]+i*8+k*4)))return 0;
                if(visit) {
                    Vertex *v=scratch+i;
                    for(unsigned k=0;k<sizeof(*v);k++)((uint8_t *)v)[k]=0;
                    for(unsigned k=0;k<3;k++) {
                        v->position[k]=scalar(attrs[0]+i*16+k*4);
                        v->normal[k]=(int8_t)attrs[2][i*3+k];
                    }
                    for(unsigned k=0;k<2;k++)v->uv[k]=scalar(attrs[1]+i*8+k*4);
                    for(unsigned k=0;k<4;k++)v->color[k]=128;
                }
            }
            if(visit)visit(scratch,skip,n,context);
            total+=n-(batches?2:0);batches++;
            for(unsigned k=0;k<3;k++){previous[k]=attrs[k];attrs[k]=0;}
            previous_n=n;seen=cycle=mode=closed=0;n=0;
        } else {
            unsigned k=cmd==0x6c && imm==0x8000 ? 0 :
                       cmd==0x64 && imm==0x8001 ? 1 :
                       cmd==0x6a && imm==0x8002 ? 2 : 3;
            if(k==3 || !cycle || !mode || closed || (seen&(1u<<k)))return 0;
            size_t items=num?num:256,length=(items*widths[k]+3)&~(size_t)3;
            if((n && n!=items) || length>end-at)return 0;
            n=items;attrs[k]=ram+at;at+=length;seen|=1u<<k;
        }
    }
    if(!batches || seen || closed)return 0;
    *count=total;*used=end-chain;*triangles=tris;return 1;
}

int rigid_object(const uint8_t *ram,size_t bytes,uint32_t object,uint32_t camera,
                 Vertex *scratch,Object *out) {
    Object candidate={0};
    if(!ram || !scratch || !out || !range(bytes,object,128) ||
       !range(bytes,camera,136) || ram[object]!=1 || word(ram+camera)!=4 ||
       word(ram+camera+20)!=1)return 0;
    uint32_t frame=word(ram+object+4),geo=word(ram+object+24);
    if(!range(bytes,frame,144) || !range(bytes,geo,104))return 0;
    uint32_t flags=word(ram+geo+8)&~0x40u;
    if((flags!=0x01000037u && flags!=0x0100003fu) ||
       word(ram+geo+24)!=1)return 0;
    /* Rigid objects have no skin or hierarchy; do not reinterpret broken skin. */
    if(!range(bytes,0x58a5f4,8))return 0;
    uint32_t ao=word(ram+0x58a5f4),go=word(ram+0x58a5f8);
    if(ao>bytes-object || go>bytes-geo || !range(bytes,object+ao,4) ||
       !range(bytes,geo+go,4) || word(ram+object+ao) || word(ram+geo+go))return 0;
    uint32_t header=word(ram+geo+84),cache=word(ram+geo+96);
    if(!range(bytes,header,16) || !range(bytes,cache,4))return 0;
    unsigned meshes=word(ram+header+4)&65535;
    if(!meshes || meshes>64 || word(ram+header)!=1 || word(ram+cache)!=meshes ||
       !range(bytes,header,16+meshes*12) || !range(bytes,cache,4+meshes*4))return 0;
    for(unsigned i=0;i<4;i++)for(unsigned k=0;k<3;k++) {
        float sum=i==3?scalar(ram+camera+80+k*4):0;
        for(unsigned j=0;j<3;j++) {
            float a=scalar(ram+frame+80+i*16+j*4),b=scalar(ram+camera+32+j*16+k*4);
            if(!finite_float(a) || !finite_float(b))return 0;
            sum+=a*b;
        }
        if(!finite_float(sum))return 0;
        candidate.view[i][k]=sum;
    }
    candidate.near_plane=scalar(ram+camera+128);candidate.far_plane=scalar(ram+camera+132);
    if(!finite_float(candidate.near_plane) || !finite_float(candidate.far_plane) ||
       candidate.near_plane<=0 || candidate.near_plane>=candidate.far_plane)return 0;
    size_t total=0,tris=0;
    for(unsigned i=0;i<meshes;i++) {
        uint32_t entry=word(ram+cache+4+i*4);
        if(!range(bytes,entry,36))return 0;
        Mesh *m=candidate.mesh+i;size_t decoded=0,used=0,t=0;
        m->stream=word(ram+entry+32);
        if(!rigid_chain(ram,bytes,m->stream,scratch,0,0,&decoded,&used,&t) ||
           decoded!=word(ram+header+20+i*12))return 0;
        m->bytes=used;m->vertices=decoded;m->material=word(ram+header+24+i*12);
        /* Existing draw path2 passes ADC markers to its triangle visitor. */
        m->compressed=2;total+=decoded;tris+=t;
    }
    if(total!=word(ram+header+8) || tris!=word(ram+geo+16))return 0;
    candidate.triangles=tris;candidate.meshes=meshes;*out=candidate;return 1;
}

