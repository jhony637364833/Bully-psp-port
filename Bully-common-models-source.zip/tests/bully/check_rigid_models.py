"""Private fixture checks: original R4 PBP, captured 32MiB RAM, candidate atomic.

No game data is embedded. Requires gcc, pyelftools and Unicorn. PSP assembler verifies the separate source.
"""
from pathlib import Path
import ctypes
import io
import json
import re
import struct
import subprocess
import sys
import tempfile

from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_MIPS, UC_MODE_MIPS32, UC_MODE_LITTLE_ENDIAN, UC_HOOK_CODE
from unicorn.mips_const import *

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools/bully'))
import rigid_models
import skin_flag

original = Path(sys.argv[1]).read_bytes()
ram = Path(sys.argv[2]).read_bytes()
assert len(ram) == 0x2000000
candidate = int(sys.argv[3], 0)
patched = rigid_models.patch(original)
previous = skin_flag.patch(original)


def word(data, at):
    return struct.unpack_from('<I', data, at)[0]


def reference(data, chain):
    """Decode the observed fixture independently into batches and ADC flags."""
    end = chain + 16 + (word(data, chain) & 65535) * 16
    at, attrs, batches = chain + 8, {}, []
    while at < end:
        code = word(data, at)
        at += 4
        cmd, n, imm = code >> 24, (code >> 16) & 255, code & 65535
        if cmd in (0x6c, 0x64, 0x6a):
            width = {0x6c: 16, 0x64: 8, 0x6a: 3}[cmd]
            n = n or 256
            attrs[imm] = data[at:at+n*width]
            at += (n*width+3) & ~3
        elif cmd in (0x15, 0x17):
            n = len(attrs[0x8000]) // 16
            vertices, skip = bytearray(), bytearray()
            for i in range(n):
                vertices += (attrs[0x8000][i*16:i*16+12] + attrs[0x8001][i*8:i*8+8]
                             + b'\x80'*4 + b'\0'*4 + attrs[0x8002][i*3:i*3+3] + b'\0')
                skip.append(word(attrs[0x8000], i*16+12) != 0)
            batches.append((bytes(vertices), bytes(skip)))
            attrs = {}
    return batches


def machine(pbp, image, obj, visit=False, caches=False):
    u = Uc(UC_ARCH_MIPS, UC_MODE_MIPS32 | UC_MODE_LITTLE_ENDIAN)
    start, end = struct.unpack_from('<II', pbp, 32)
    elf = ELFFile(io.BytesIO(pbp[start:end]))
    segs = [s for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD']
    lo = min(s['p_vaddr'] for s in segs) & ~4095
    hi = (max(s['p_vaddr']+s['p_memsz'] for s in segs)+4095) & ~4095
    u.mem_map(lo, hi-lo)
    for s in segs:
        u.mem_write(s['p_vaddr'], s.data())
    u.mem_map(0xa000000, 0x2000000)
    u.mem_write(0xa000000, image)
    for a, n in ((0xc000000, 0x100000), (0xd000000, 0x100000), (0x7000000, 4096)):
        u.mem_map(a, n)
    u.mem_write(0xc010000, b'\xa5'*1352)
    for reg, value in ((UC_MIPS_REG_A0, 0xa000000), (UC_MIPS_REG_A1, len(image)),
                       (UC_MIPS_REG_A2, obj), (UC_MIPS_REG_A3, 0x18b1a60),
                       (UC_MIPS_REG_T0, 0xc000000), (UC_MIPS_REG_T1, 0xc010000),
                       (UC_MIPS_REG_T2, 0xc020000 if caches else 0),
                       (UC_MIPS_REG_T3, 0xc060000 if caches else 0),
                       (UC_MIPS_REG_SP, 0xd080000), (UC_MIPS_REG_RA, 0x7000000)):
        u.reg_write(reg, value)
    u.emu_start(0x9752ff0, 0x7000000, count=10000000)
    assert u.reg_read(UC_MIPS_REG_PC) == 0x7000000
    ok = u.reg_read(UC_MIPS_REG_V0)
    output = bytes(u.mem_read(0xc010000, 1352))
    if caches:
        assert word(bytes(u.mem_read(0xc020000, 4)), 0) == 0
        assert word(bytes(u.mem_read(0xc060000, 4)), 0) == 0
    observed = []
    if ok and visit:
        def capture(uc, address, size, context):
            n = uc.reg_read(UC_MIPS_REG_A2)
            observed.append((bytes(uc.mem_read(uc.reg_read(UC_MIPS_REG_A0), n*32)),
                             bytes(uc.mem_read(uc.reg_read(UC_MIPS_REG_A1), n))))
            uc.reg_write(UC_MIPS_REG_PC, uc.reg_read(UC_MIPS_REG_RA))
        u.hook_add(UC_HOOK_CODE, capture, begin=0x7000100, end=0x7000100)
        for i in range(word(output, 60)):
            chain, size, vertices, material, kind = struct.unpack_from('<5I', output, 72+i*20)
            assert kind == 2
            expected = reference(image, chain)
            before = len(observed)
            for reg, value in ((UC_MIPS_REG_A0, 0xa000000), (UC_MIPS_REG_A1, chain+size),
                               (UC_MIPS_REG_A2, chain), (UC_MIPS_REG_A3, 0),
                               (UC_MIPS_REG_T0, 0), (UC_MIPS_REG_T1, 0xc000000),
                               (UC_MIPS_REG_T2, 0x7000100), (UC_MIPS_REG_T3, 0),
                               (UC_MIPS_REG_SP, 0xd080000), (UC_MIPS_REG_RA, 0x7000000)):
                u.reg_write(reg, value)
            u.mem_write(0xd080000, struct.pack('<3I', 0xc080000, 0xc080004, 0xc080008))
            u.emu_start(0x9756444, 0x7000000, count=10000000)
            assert u.reg_read(UC_MIPS_REG_PC) == 0x7000000
            assert u.reg_read(UC_MIPS_REG_V0) == 1
            assert observed[before:] == expected, 'MIPS batches differ from independent reference'
            counts = struct.unpack('<3I', bytes(u.mem_read(0xc080000, 12)))
            assert counts[0] == vertices and counts[1] == size
            assert counts[2] == sum(sum(x==0 for x in flags[2:]) for _,flags in expected)
    return ok, output, observed


with tempfile.TemporaryDirectory(prefix='bully-rigid-test-') as tmp:
    lib = Path(tmp) / 'rigid.so'
    subprocess.run(['gcc', '-shared', '-fPIC', '-O2', '-Wall', '-Wextra', '-Werror',
                    str(ROOT/'tests/bully/rigid_reference.c'), '-o', str(lib)], check=True)
    host = ctypes.CDLL(str(lib)).rigid_object
    image = ctypes.create_string_buffer(ram)
    scratch = ctypes.create_string_buffer(8192)
    accepted = []
    for m in re.finditer(b'\x01', ram):
        obj = m.start()
        if obj % 4 or obj+128 > len(ram):
            continue
        geo = word(ram, obj+24)
        if not (4 <= geo < len(ram)-104 and geo % 4 == 0):
            continue
        if word(ram, geo+8) not in (0x1000037, 0x100003f, 0x1000077, 0x100007f):
            continue
        out = ctypes.create_string_buffer(b'\xa5'*1352, 1352)
        if host(image, len(ram), obj, 0x18b1a60, scratch, out):
            accepted.append(obj)
        else:
            assert out.raw == b'\xa5'*1352
    assert candidate in accepted
    picks = [candidate]
    for flag in (0x1000037, 0x100003f, 0x1000077, 0x100007f):
        picks += [a for a in accepted if word(ram,word(ram,a+24)+8)==flag][:10]
    picks = list(dict.fromkeys(picks))
    for obj in picks:
        prior_ok, prior_out, _ = machine(previous, ram, obj)
        if prior_ok:
            assert machine(patched, ram, obj)[1] == prior_out
        else:
            normalized = bytearray(ram)
            geo_at = word(ram,obj+24)
            struct.pack_into('<I',normalized,geo_at+8,word(ram,geo_at+8)&~0x48)
            assert machine(previous,bytes(normalized),obj)[0] == 1
        ok, out, batches = machine(patched, ram, obj, visit=True, caches=True)
        assert ok == 1 and batches
        expected = ctypes.create_string_buffer(1352)
        assert host(image, len(ram), obj, 0x18b1a60, scratch, expected)
        assert out == expected.raw
    target = next(a for a in accepted if word(ram,word(ram,a+24)+8)==0x100003f)
    geo = word(ram, target+24)
    header, cache = word(ram, geo+84), word(ram, geo+96)
    chain = word(ram, word(ram, cache+4)+32)
    corruptions = [(geo+8, 0x010000f7), (geo+16, word(ram, geo+16)+1),
                   (target+4, 0), (geo+96, len(ram)-4), (chain, 0x10000000),
                   (chain+4, 16), (header+8, word(ram, header+8)+1),
                   (chain+8, 0x05000001), (chain+12, 0x10000000)]
    for at, value in corruptions:
        broken = bytearray(ram)
        struct.pack_into('<I', broken, at, value)
        ok, out, batches = machine(patched, bytes(broken), target)
        assert ok == 0 and out == b'\xa5'*1352
    print(json.dumps({'host_rigid_atomics': len(accepted), 'MIPS_objects_and_batches': len(picks),
                      'malformed_rejections': len(corruptions), 'candidate': hex(candidate)}))
