from pathlib import Path
import sys,struct,io
from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.mips_const import *
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'tools/bully'))
import skin_flag,clear_fast
import rigid_models
base=Path(sys.argv[1]).read_bytes();prior=clear_fast.patch(base)
expanded=len(sys.argv)>3 and sys.argv[3]=='rigid'
patched=rigid_models.patch(base) if expanded else skin_flag.patch(base)
if not expanded:assert sum(a!=b for a,b in zip(prior,patched))==1
ram=Path(sys.argv[2]).read_bytes(); geo=0x7964a0;obj=0x1f3cc20
def run(pbp,flag,tri=328):
 u=Uc(UC_ARCH_MIPS,UC_MODE_MIPS32|UC_MODE_LITTLE_ENDIAN);start,end=struct.unpack_from('<II',pbp,32);e=ELFFile(io.BytesIO(pbp[start:end]));segs=[s for s in e.iter_segments() if s['p_type']=='PT_LOAD'];lo=min(s['p_vaddr'] for s in segs)&~4095;hi=(max(s['p_vaddr']+s['p_memsz'] for s in segs)+4095)&~4095;u.mem_map(lo,hi-lo)
 for s in segs:u.mem_write(s['p_vaddr'],s.data())
 u.mem_map(0xa000000,0x2000000);u.mem_write(0xa000000,ram);u.mem_write(0xa000000+geo+8,struct.pack('<I',flag));u.mem_write(0xa000000+geo+16,struct.pack('<I',tri))
 for a,n in [(0xc000000,0x100000),(0xd000000,0x100000),(0x7000000,4096)]:u.mem_map(a,n)
 for r,v in [(UC_MIPS_REG_A0,0xa000000),(UC_MIPS_REG_A1,0x2000000),(UC_MIPS_REG_A2,obj),(UC_MIPS_REG_A3,0x18b1a60),(UC_MIPS_REG_T0,0xc000000),(UC_MIPS_REG_T1,0xc010000),(UC_MIPS_REG_T2,0),(UC_MIPS_REG_T3,0),(UC_MIPS_REG_SP,0xd080000),(UC_MIPS_REG_RA,0x7000000)]:u.reg_write(r,v)
 u.emu_start(0x9752ff0,0x7000000,count=10000000)
 assert u.reg_read(UC_MIPS_REG_PC)==0x7000000
 return u.reg_read(UC_MIPS_REG_V0),bytes(u.mem_read(0xc010000,1368)),bytes(u.mem_read(0xc000000,8192))
a=run(prior,0x1000037);b=run(patched,0x1000077);assert a[0]==b[0]==1
assert a[1:]==b[1:], 'output or final scratch differs'
assert run(prior,0x1000077)[0]==0
assert run(patched,0x1000037)==a
if expanded:
 assert run(patched,0x100003f)==a
 assert run(patched,0x100007f)==a
for flag in (0x1000076,0x10000f7,0x1000137,0x1000067,0x1000017):assert run(patched,flag)[0]==0,hex(flag)
assert run(patched,0x1000077,329)[0]==0
print('expanded rigid flags:',expanded)
print('PASS captured skateboard: baseline37 vs patched77 outputs/scratch match; original77 rejected; five unknown flags and triangle mismatch rejected')
