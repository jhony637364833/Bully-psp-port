"""Execute the real R4 render hook with synthetic guest setup/draw boundaries."""
from pathlib import Path
import io
import struct
import sys

from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_MIPS, UC_MODE_MIPS32, UC_MODE_LITTLE_ENDIAN, UC_HOOK_CODE
from unicorn.mips_const import *

sys.path.insert(0, str(Path(__file__).resolve().parents[2]/'tools/bully'))
import rigid_models
import skin_flag

base = Path(sys.argv[1]).read_bytes()
prior, patched = skin_flag.patch(base), rigid_models.patch(base)


def run(pbp, method, node=0x1000, param=0x3000):
    u = Uc(UC_ARCH_MIPS, UC_MODE_MIPS32 | UC_MODE_LITTLE_ENDIAN)
    start, end = struct.unpack_from('<II', pbp, 32)
    e = ELFFile(io.BytesIO(pbp[start:end]))
    loads = [s for s in e.iter_segments() if s['p_type'] == 'PT_LOAD']
    lo = min(s['p_vaddr'] for s in loads)&~4095
    hi = (max(s['p_vaddr']+s['p_memsz'] for s in loads)+4095)&~4095
    u.mem_map(lo, hi-lo)
    for s in loads:
        u.mem_write(s['p_vaddr'], s.data())
    for at, size in ((0xa000000, 0x2000000), (0xc000000, 0x100000), (0x7000000, 4096)):
        u.mem_map(at, size)

    def put(address, value):
        u.mem_write(address, struct.pack('<I', value))
    put(0x9857360, 0xa000000)
    put(0x983fb3c, 0x2000000)
    put(0xa001014, 0x2000)
    put(0xa002010, method)
    put(0xa003000, 0x4000)
    put(0xa6cf898, 0x5000)
    put(0xc010040, node)
    put(0xc010050, param)
    put(0xc0101c0, 0x5e77f0)
    u.reg_write(UC_MIPS_REG_A0, 0xc010000)
    u.reg_write(UC_MIPS_REG_SP, 0xc0f0000)
    u.reg_write(UC_MIPS_REG_RA, 0x7000000)
    saved = [UC_MIPS_REG_S0, UC_MIPS_REG_S1, UC_MIPS_REG_S2, UC_MIPS_REG_S3,
             UC_MIPS_REG_S4, UC_MIPS_REG_S5, UC_MIPS_REG_S6, UC_MIPS_REG_S7]
    for i, reg in enumerate(saved):
        u.reg_write(reg, 0xabc00000+i)
    calls = []
    stubs = {0x9759d38: 'sample', 0x97c10d4: 'begin', 0x8d52250: 'guest',
             0x97c1050: 'capture', 0x97c1a80: 'draw'}

    def boundary(uc, address, size, data):
        name = stubs.get(address)
        if not name:
            return
        a, b = (uc.reg_read(r) for r in (UC_MIPS_REG_A0, UC_MIPS_REG_A1))
        calls.append((name, a, b))
        if name == 'guest':
            assert a == 0xc010000
            put(a+32, 0x12345678)
            put(0xa006000, 0x87654321)
        uc.reg_write(UC_MIPS_REG_PC, uc.reg_read(UC_MIPS_REG_RA))
    u.hook_add(UC_HOOK_CODE, boundary)
    u.emu_start(0x9759ee4, 0x7000000, count=100000)
    assert u.reg_read(UC_MIPS_REG_PC) == 0x7000000
    assert u.reg_read(UC_MIPS_REG_SP) == 0xc0f0000
    for i, reg in enumerate(saved):
        assert u.reg_read(reg) == 0xabc00000+i
    assert [x[0] for x in calls].count('guest') == 1
    assert bytes(u.mem_read(0xc010020, 4)) == struct.pack('<I', 0x12345678)
    assert bytes(u.mem_read(0xa006000, 4)) == struct.pack('<I', 0x87654321)
    draws = [x for x in calls if x[0] == 'draw']
    if draws:
        assert draws == [('draw', 0x4000, 0x5000)]
        names = [x[0] for x in calls]
        assert names.index('guest') < names.index('capture') < names.index('draw')
    return draws


for method in (0x16ce40, 0x29ccc0, 0x25f118):
    assert run(prior, method) == run(patched, method) == [('draw', 0x4000, 0x5000)]
assert run(prior, 0x25ec80) == []
assert run(patched, 0x25ec80) == [('draw', 0x4000, 0x5000)]
for method in (0, 0x25ec81, 0x25f11c, 0x29cccc):
    assert run(prior, method) == run(patched, method) == []
for node, param in ((0, 0x3000), (0x1001, 0x3000), (0x1000, 0), (0x1000, 0x3001)):
    assert run(patched, 0x25ec80, node, param) == []
print('PASS actual R4 hook: rigid callback admitted; three existing callbacks unchanged;'
      ' unknown callbacks/invalid pointers rejected; guest called once before draw; saved registers intact')
