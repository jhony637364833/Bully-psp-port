#!/usr/bin/env python3
"""Optional, exact-revision Bully diagnostic-only patch; no FPS guarantee.

The supplied source fragment is:
    if (rejected++ < 8) LOG("WORLD: unsupported object=...");
    return;
Change its logging threshold to zero. Preserve the increment/store, branch,
stack restoration, all draw rejection behavior, and all other executable bytes.
This suppresses useful object diagnostics; restore the original for debugging.
"""
import argparse
import hashlib
from pathlib import Path
import struct

BASE_SHA256 = 'f84408a1f8d3956e085a95be29537aa6d99755fb2fb9fae490ec3ff134ecfa5f'
ADDRESS = 0x097c235c
OLD = 0x2c420008  # sltiu v0,v0,8
NEW = 0x2c420000  # sltiu v0,v0,0 (always false, including wrapped counters)


def patch(data):
    if hashlib.sha256(data).hexdigest() != BASE_SHA256:
        raise ValueError('Unsupported EBOOT revision; input must be the supplied R4 repair')
    header = struct.unpack_from('<10I', data)
    if header[0] != 0x50425000:
        raise ValueError('Invalid PBP magic')
    start, end = header[8:10]
    elf = data[start:end]
    if elf[:7] != b'\x7fELF\x01\x01\x01':
        raise ValueError('Expected unencrypted ELF32 little-endian DATA.PSP')
    phoff = struct.unpack_from('<I', elf, 28)[0]
    phsize, phnum = struct.unpack_from('<HH', elf, 42)
    offset = None
    for i in range(phnum):
        kind, pos, va, _, size = struct.unpack_from('<5I', elf, phoff + phsize*i)
        if kind == 1 and va <= ADDRESS and ADDRESS+4 <= va+size:
            if offset is not None:
                raise ValueError('Ambiguous instruction mapping')
            offset = start + pos + ADDRESS-va
    if offset is None:
        raise ValueError('Instruction not mapped')
    # Verify the counter load, increment, compare, branch and delay-slot store.
    expected = (0x3c030991, 0x8c62a9b8, 0x24440001, OLD, 0x1040ffe2, 0xac64a9b8)
    if struct.unpack_from('<6I', data, offset-12) != expected:
        raise ValueError('Rejection/logging sequence differs')
    out = bytearray(data)
    struct.pack_into('<I', out, offset, NEW)
    return bytes(out), offset


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    if args.input.resolve() == args.output.resolve():
        parser.error('Use a separate output path; retain the original EBOOT')
    result, offset = patch(args.input.read_bytes())
    with args.output.open('xb') as f:
        f.write(result)
    print(f'Patched logging threshold at PBP offset 0x{offset:x}')
    print('SHA256 ' + hashlib.sha256(result).hexdigest())
    print('Rendering unchanged; FPS/stability and Android gameplay unverified.')


if __name__ == '__main__':
    main()
