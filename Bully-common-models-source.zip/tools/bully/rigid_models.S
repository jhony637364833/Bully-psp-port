.set noreorder
.set noat
.text
.globl _start
_start:
 ins $10,$0,3,1
 bne $10,$4,reject
 nop
 j 0x09912b84
 nop
reject:
 j 0x09912a1c
 move $3,$0
.org 32
.globl hook_filter
hook_filter:
 beq $2,$3,accept
 nop
 lui $3,0x25
 ori $3,$3,0xec80
 beq $2,$3,accept
 nop
 j 0x09759f4c
 nop
accept:
 j 0x0975a0e0
 nop
