#!/usr/bin/env python3
"""Route verified rigid 3f/7f geometry through R4's existing bounded decoder.

Includes the observed rigid setup callback 0x0025ec80 in native submission.
Material/prelight flags do not change the observed VIF(3,1) vertex layout.
Composes previous original-quality, CPU and material-flag fixes. Only the exact
supplied R4 is accepted; all existing geometry and topology checks remain active.
"""
import argparse
import hashlib
from pathlib import Path
import struct
import skin_flag

BASE = 0x099144B0
CAVE = bytes.fromhex('c4180a7c0300441500000000e14a640a00000000874a640a251800000000000007004310000000002500033c80ec63340300431000000000d3675d0a0000000038685d0a00000000')


def patch(data, payload=CAVE):
    if payload != CAVE:
        raise ValueError('Unexpected flag-check payload')
    result = bytearray(skin_flag.patch(data))
    start, end = struct.unpack_from('<II', result, 32)
    if end != len(result):
        raise ValueError('Unexpected PBP length')
    phoff = struct.unpack_from('<I', result, start + 28)[0]
    phsize, phnum = struct.unpack_from('<HH', result, start + 42)
    loads = []
    for i in range(phnum):
        at = start + phoff + i * phsize
        kind, pos, va, _, size, mem = struct.unpack_from('<6I', result, at)
        if kind == 1:
            loads.append((at, start + pos, va, size, mem))
    addresses = [pos + skin_flag.ADDRESS - va for _, pos, va, size, _ in loads
                 if va <= skin_flag.ADDRESS and skin_flag.ADDRESS + 8 <= va + size]
    if len(addresses) != 1:
        raise ValueError('Unexpected hook layout')
    at = addresses[0]
    if struct.unpack_from('<2I', result, at) != (skin_flag.NEW, 0x00001825):
        raise ValueError('Unexpected flag-check instructions')
    struct.pack_into('<2I', result, at, 0x08000000 | (BASE >> 2), 0)
    hook = 0x0975a0d8
    offsets = [pos + hook - va for _, pos, va, size, _ in loads
               if va <= hook and hook + 8 <= va + size]
    if len(offsets) != 1 or struct.unpack_from('<2I', result, offsets[0]) != (0x1443ff9c, 0):
        raise ValueError('Unexpected object callback filter')
    struct.pack_into('<2I', result, offsets[0], 0x08000000 | ((BASE + 32) >> 2), 0)
    ph, pos, va, size, mem = loads[-1]
    if pos + size != len(result) or mem != size:
        raise ValueError('Unexpected final LOAD layout')
    padding = BASE - (va + size)
    if not 0 <= padding < 16:
        raise ValueError('Unexpected appended code layout')
    result.extend(b'\0' * padding)
    result.extend(payload)
    struct.pack_into('<II', result, ph + 16, len(result) - pos, len(result) - pos)
    struct.pack_into('<I', result, 36, len(result))
    return bytes(result)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    data = patch(args.input.read_bytes())
    with args.output.open('xb') as f:
        f.write(data)
    print(hashlib.sha256(data).hexdigest())
