#!/usr/bin/env python3
"""Accept the observed material bit on skinned geometry in the supplied R4.

Preserves the existing decoder validation, including the triangle-count guard.
"""
import argparse
import hashlib
from pathlib import Path
import struct
import clear_fast

ADDRESS = 0x09912b7c
OLD = 0x55e4ffa7  # bnel t7,a0 (raw geometry flags)
NEW = 0x5544ffa7  # bnel t2,a0 (bit 0x40 already cleared)


def patch(data):
    result = bytearray(clear_fast.patch(data))
    start, end = struct.unpack_from('<II', result, 32)
    phoff = struct.unpack_from('<I', result, start + 28)[0]
    phsize, phnum = struct.unpack_from('<HH', result, start + 42)
    offsets = []
    for i in range(phnum):
        kind, pos, va, _, size = struct.unpack_from('<5I', result, start + phoff + i*phsize)
        if kind == 1 and va <= ADDRESS and ADDRESS + 4 <= va + size:
            offsets.append(start + pos + ADDRESS - va)
    if len(offsets) != 1: raise ValueError('Unexpected program layout')
    off = offsets[0]
    expected = (0x7c0a3184, 0x114701ee, 0x24840037, OLD, 0x00001825)
    if struct.unpack_from('<5I', result, off - 12) != expected:
        raise ValueError('Unexpected flag-validation instructions')
    struct.pack_into('<I', result, off, NEW)
    return bytes(result)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    data = patch(args.input.read_bytes())
    with args.output.open('xb') as f: f.write(data)
    print(hashlib.sha256(data).hexdigest())
