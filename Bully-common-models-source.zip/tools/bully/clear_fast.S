.set noreorder
.text
.globl _start
_start:
  lui $t0,0x098b
  lw $t1,-10896($t0)
  sltiu $v0,$t1,1009
  beqz $v0,fallback
  nop
  sltiu $v0,$s6,15
  bnez $v0,fallback
  and $v0,$s6,$s1
  andi $v1,$v0,3
  bnez $v1,fallback
  addiu $t2,$s6,-15
  sltu $v1,$t2,$v0
  bnez $v1,fallback
  addu $v0,$s5,$v0
  sw $zero,0($v0)
  sw $zero,4($v0)
  sw $zero,8($v0)
  sw $zero,12($v0)
  addiu $t1,$t1,15
  sw $t1,-10896($t0)
  j 0x088a990c
  nop
fallback:
  and $v0,$s6,$s1
  j 0x088a989c
  addu $v0,$s5,$v0
