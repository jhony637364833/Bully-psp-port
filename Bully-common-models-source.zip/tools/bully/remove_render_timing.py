#!/usr/bin/env python3
"""Remove per-object render timing from the exact supplied Bully R4 EBOOT.

Four clock reads are disabled. The common instrumentation tail branches to the
original return epilogue, skipping the third read, accumulators, and timing log.
Guest setup, object capture/draw, and saved-register restoration are retained.
The RENDER_TIME diagnostics are deliberately removed; use the original EBOOT to
profile or troubleshoot. This is not a measured FPS or stability fix.
"""
import argparse
import hashlib
from pathlib import Path
import struct

BASE_SHA256 = 'f84408a1f8d3956e085a95be29537aa6d99755fb2fb9fae490ec3ff134ecfa5f'
# Addresses and words refer only to this pinned, unencrypted ELF32 EBOOT.
CHANGES = {
    0x09759f54: (0x0e5fa029, 0),  # guest start clock, invalid-object path
    0x09759f6c: (0x0e5fa029, 0),  # native start clock, invalid-object path
    0x0975a0f0: (0x0e5fa029, 0),  # guest start clock, valid-object path
    0x0975a108: (0x0e5fa029, 0),  # native start clock, valid-object path
    0x09759f80: (0x8e63fd50, 0x1000001f),  # branch to existing epilogue
    0x09759f84: (0x8e64fd54, 0),  # safe delay slot
}

def patch(data):
    if hashlib.sha256(data).hexdigest() != BASE_SHA256:
        raise ValueError('Unsupported EBOOT revision')
    head=struct.unpack_from('<10I', data)
    if head[0]!=0x50425000:
        raise ValueError('Invalid PBP')
    start,end=head[8:10]; elf=data[start:end]
    if elf[:7]!=b'\x7fELF\x01\x01\x01':
        raise ValueError('Expected unencrypted little-endian ELF32')
    phoff=struct.unpack_from('<I',elf,28)[0]; phsize,phnum=struct.unpack_from('<HH',elf,42)
    changes=[]
    for addr,(old,new) in CHANGES.items():
        offsets=[]
        for i in range(phnum):
            kind,pos,va,_,size=struct.unpack_from('<5I',elf,phoff+phsize*i)
            if kind==1 and va<=addr and addr+4<=va+size:offsets.append(start+pos+addr-va)
        if len(offsets)!=1:raise ValueError('Ambiguous instruction mapping')
        off=offsets[0]
        if struct.unpack_from('<I',data,off)[0]!=old:raise ValueError('Unexpected instruction')
        changes.append((off,new))
    result=bytearray(data)
    for off,new in changes:struct.pack_into('<I',result,off,new)
    return bytes(result), [off for off,_ in changes]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args()
    if args.input.resolve()==args.output.resolve():parser.error('Keep the original EBOOT')
    result,_=patch(args.input.read_bytes())
    with args.output.open('xb') as f:f.write(result)
    print('SHA256',hashlib.sha256(result).hexdigest())
    print('Render timing diagnostics removed; FPS/stability unverified.')
if __name__=='__main__':main()
