#!/usr/bin/env python3
"""Exact R4 fast path for a 16-byte translated clear; original texture quality.

Retains all 15 backedge counts. Falls back if a scheduler boundary can occur,
if the span wraps guest RAM, or if unaligned. No callback or graphics bypass.
"""
import argparse
import hashlib
from pathlib import Path
import struct
import original_quality

CAVE = bytes.fromhex('8b09083c70d5098df103222d12004010000000000f00c22e0f0040142410d102030043300c006014f1ffca262b184201090060142110a202000040ac040040ac080040ac0c0040ac0f00292570d509ad43a6220a000000002410d10227a6220a2110a202')
CAVE_VA = 0x09914440


def patch(data):
    base = original_quality.patch(data)
    start, end = struct.unpack_from('<II', base, 32)
    elf = bytearray(base[start:end])
    if len(elf) != 0x111043c or end != len(base):
        raise ValueError('Unexpected ELF layout')
    at = 0x100 + 0x088a9894 - 0x08804000
    if struct.unpack_from('<2I', elf, at) != (0x02d11024, 0x02a21021):
        raise ValueError('Unexpected clear loop entry')
    struct.pack_into('<2I', elf, at, 0x08000000 | ((CAVE_VA >> 2) & 0x3ffffff), 0)
    elf.extend(b'\0' * 4)
    elf.extend(CAVE)
    phoff = struct.unpack_from('<I', elf, 28)[0]
    phsize, phnum = struct.unpack_from('<HH', elf, 42)
    segments = []
    for i in range(phnum):
        ph = phoff + phsize*i
        kind, pos, va, _, size, mem = struct.unpack_from('<6I', elf, ph)
        if kind == 1:
            segments.append((ph,pos,va,size,mem))
    ph,pos,va,size,mem = segments[-1]
    if (pos,va,size,mem) != (0x103ba24,0x0983fa24,0xd4494,0xd4494):
        raise ValueError('Unexpected final load segment')
    assert va + 0x1110440 - pos == CAVE_VA
    struct.pack_into('<II', elf, ph+16, len(elf)-pos, len(elf)-pos)
    result = bytearray(base[:start]) + elf
    struct.pack_into('<I', result, 36, len(result))
    return bytes(result)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = patch(args.input.read_bytes())
    with args.output.open('xb') as f:
        f.write(result)
    print(hashlib.sha256(result).hexdigest())
