#!/usr/bin/env python3
"""Restore original R4 texture quality, retaining timing/logging changes.

Input must be the original supplied R4 EBOOT. Audio and geometry repairs in that
binary are preserved. This is a quality rollback, not a verified FPS repair.
"""
import argparse
import hashlib
from pathlib import Path

import quiet_object_log
import remove_render_timing


def patch(data):
    timing, _ = remove_render_timing.patch(data)
    quiet, offset = quiet_object_log.patch(data)
    if timing[offset:offset + 4] != data[offset:offset + 4]:
        raise ValueError('Unexpected overlap between diagnostic patches')
    result = bytearray(timing)
    result[offset:offset + 4] = quiet[offset:offset + 4]
    return bytes(result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = patch(args.input.read_bytes())
    with args.output.open('xb') as stream:
        stream.write(result)
    print('SHA256', hashlib.sha256(result).hexdigest())


if __name__ == '__main__':
    main()
