<!-- coderabbit-ai-generated:v1 -->

# Bully PSP R2 packet decoder update

## Install

1. Close PPSSPP. Back up your Bully game folder and its `memcard` folder.
2. Copy `EBOOT.PBP` into the game folder. If you are updating the older full-game ZIP, also copy `disc/SCRIPTS/SCRIPTS.IMG` into the matching folder and use the included `ps2rc_exc.prx`, `ps2rc.cfg`, and `ps2rc_dev.cfg`. The supplied R4 scripts are unchanged. If your R2 installation already uses these files, keep your existing settings.
3. Keep the rest of your disc data, movies, and memory card. The included PPSSPP profile in `PSP/SYSTEM` is optional and unchanged from the previous replacement.
4. Start the new EBOOT from the game list. Load your normal **in-game save**. An old PPSSPP save state restores old executable code.

To roll back, close PPSSPP, restore the files you backed up, and restart the game.

## What changed

The graphics packet decoder reads aligned commands directly, processes consecutive no-op commands together, and sends vertex unpack commands straight to the original handler. The decoder still uses the previous code for unaligned data and retains the existing graphics, texture, and rendering order rules. This package keeps the previous clipping, lighting, and automatic pickup repairs. The new change does not edit pickup logic, save data, scripts, or emulator settings.

## What was tested

| Scene | Previous decoder | New decoder |
|---|---:|---:|
| Schoolyard | 5.87 rendered FPS | 6.11 rendered FPS |
| Busy route | 3.59 rendered FPS | 3.64 rendered FPS |

These are medians from two 48-frame runs per mode in desktop PPSSPP 1.20.4, using software Vulkan, a 333 MHz emulated PSP clock, and no frame skip. Each mode started from the same checkpoint. Rates are newly rendered game frames, and do not count emulator refreshes. Game time stayed within about 4% of elapsed wall time in these runs. Android and physical PSP FPS, including sustained 60 FPS, are unverified.

The production EBOOT matched 3,860 original compiled packet parser cases. Separate image tests with identical clock inputs produced pixel-identical final frames in the schoolyard and busy route. The production EBOOT booted into the bedroom from the existing normal save; the save file checksum remained unchanged. The automatic pickup code and supporting files are byte-identical to the previous replacement. This test did not replay every pickup or mission.

## Rebuild

With PSPDEV v20261001:

```sh
python3 source/build_pickup.py ORIGINAL-R2.PBP PREVIOUS.PBP --pspdev /path/to/pspdev --renderer
python3 source/build_renderer.py PREVIOUS.PBP BASELINE.PBP --pspdev /path/to/pspdev
python3 source/build_vif.py BASELINE.PBP EBOOT.PBP /path/to/pspdev
sha256sum -c SHA256SUMS.txt
```

`ORIGINAL-R2.PBP` must have SHA-256 `2eb7bf559bf2fec1d678ebccafabb99f320155b5ec2420f88a6da3aad9b0848c`. The **previous renderer update** EBOOT may be used as `BASELINE.PBP` if its SHA-256 is `9c1036d0991e9977c17bf55f8786a9cd851fe0015e853d8a550317182ae8c285`. The new EBOOT has SHA-256 `275226e48494841eba9d6390fa09943253fb7f495ec3ae638f67631a160da60e`.

To check the VIF patch from the package directory:

```sh
python3 tests/verify_vif_image.py BASELINE.PBP EBOOT.PBP
uv run --with unicorn==2.1.4 python tests/check_vif_dispatch.py BASELINE.PBP EBOOT.PBP
```

Based on PS2RC by SandstoneDev. The engine license and notices are included.
