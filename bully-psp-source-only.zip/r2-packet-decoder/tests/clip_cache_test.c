#include "clip_cache.h"
#include <assert.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

unsigned clip_attempted;
void *clip_storage;
ClipMemo clip_memo;
static unsigned total, largest, allocs, frees, live, reject_at, fragment_at;
static unsigned char arena[CLIP_SET_BYTES * CLIP_MAX_SETS + 1];

unsigned clip_total_free(void) { return total; }
unsigned clip_largest_free(void)
{
    if (!live)
        return largest;
    return live >= fragment_at || largest < CLIP_HUD_BYTES ? CLIP_HUD_BYTES - 1 : CLIP_HUD_BYTES;
}
int clip_allocate(int partition, const char *name, int type, unsigned bytes, void *address)
{
    assert(partition == 2 && strcmp(name, "world_clip") == 0 && type == 1 && !address);
    assert(!live && bytes <= total - CLIP_RESERVE_BYTES && bytes <= largest);
    ++allocs;
    if (bytes >= reject_at)
        return -1;
    live = bytes;
    total -= bytes;
    return 5;
}
void *clip_get_block(int id) { assert(id == 5 && live); return arena; }
int clip_release(int id) { assert(id == 5 && live); ++frees; total += live; live = 0; return 0; }
void clip_log(const char *format, ...) { (void)format; }
uint32_t clip_fpu_read(void) { return 0; }
void clip_fpu_write(uint32_t value) { (void)value; }

static void fixture(unsigned available, unsigned largest_block, unsigned reject, unsigned fragment,
                    unsigned expected_sets, unsigned expected_allocs, unsigned expected_frees)
{
    clip_attempted = 0;
    clip_storage = NULL;
    clip_memo = (ClipMemo){0};
    memset(arena, 0xcd, sizeof arena);
    total = available;
    largest = largest_block;
    reject_at = reject;
    fragment_at = fragment;
    live = allocs = frees = 0;

    try_clip_cache();
    try_clip_cache(); /* no extra allocations once the camera has tried */
    assert(clip_attempted && allocs == expected_allocs && frees == expected_frees);
    assert(clip_memo.sets == expected_sets);
    if (!expected_sets) {
        assert(!clip_memo.set && !clip_storage && !live && total == available);
        return;
    }

    size_t bytes = (size_t)expected_sets * CLIP_SET_BYTES;
    assert(clip_storage == arena && clip_memo.set == arena && live == bytes);
    assert(total >= CLIP_RESERVE_BYTES && clip_largest_free() >= CLIP_HUD_BYTES);
    assert(clip_memo.epoch == 1 && clip_memo.bypass_mask == 0x20f80u &&
           clip_memo.read_fpu == clip_fpu_read && clip_memo.write_fpu == clip_fpu_write);
    assert(!(clip_memo.hits || clip_memo.misses || clip_memo.bypasses || clip_memo.admissions));
    for (size_t i = 0; i < bytes; ++i)
        assert(arena[i] == 0);
    assert(arena[bytes] == 0xcd);
}

int main(void)
{
    const unsigned full = CLIP_MAX_SETS * CLIP_SET_BYTES;
    const unsigned min = CLIP_MIN_SETS * CLIP_SET_BYTES;
    const unsigned reserve = CLIP_RESERVE_BYTES;
    const unsigned unlimited = (unsigned)-1;
    fixture(reserve + full, full, unlimited, unlimited, 2048, 1, 0);
    fixture(reserve + full - 1, full, unlimited, unlimited, 1024, 1, 0);
    fixture(reserve + full, full / 2, unlimited, unlimited, 1024, 1, 0);
    fixture(reserve + min, min, unlimited, unlimited, 0, 1, 1); /* HUD still needs a larger block */
    fixture(reserve + min, CLIP_HUD_BYTES, unlimited, unlimited, 128, 1, 0);
    fixture(reserve + min - 1, full, unlimited, unlimited, 0, 0, 0);
    fixture(0, full, unlimited, unlimited, 0, 0, 0);
    fixture(reserve + full, full, full, unlimited, 1024, 2, 0);
    fixture(reserve + full, full, unlimited, full, 1024, 2, 1);
    fixture(reserve + full, full, 0, unlimited, 0, 5, 0);
    fixture(reserve + full, full, unlimited, 0, 0, 5, 5);
    puts("11 clipping cache allocation cases passed");
}
