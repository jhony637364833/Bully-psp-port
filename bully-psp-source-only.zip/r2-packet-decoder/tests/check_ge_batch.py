#!/usr/bin/env python3
"""Compare the compiled R2 and updated mixed-alpha GE loops under Unicorn."""

import random
import struct
import sys
from pathlib import Path

from unicorn import UC_ARCH_MIPS, UC_HOOK_CODE, UC_MODE_MIPS32, Uc
from unicorn import mips_const as mips


def register(name):
    return getattr(mips, "UC_MIPS_REG_" + name.upper())


def words(*values):
    return struct.pack(f"<{len(values)}I", *values)


class Renderer:
    def __init__(self, eboot):
        data = Path(eboot).read_bytes()
        start, end = struct.unpack_from("<II", data, 32)
        elf = data[start:end]
        phoff = struct.unpack_from("<I", elf, 28)[0]
        phsize, phnum = struct.unpack_from("<HH", elf, 42)

        self.cpu = Uc(UC_ARCH_MIPS, UC_MODE_MIPS32)
        self.cpu.mem_map(0x08800000, 0x01300000)
        self.cpu.mem_map(0x0A000000, 0x20000)
        for offset in range(phoff, phoff + phsize * phnum, phsize):
            kind, loc, address, _, size, *_ = struct.unpack_from("<8I", elf, offset)
            if kind == 1:
                self.cpu.mem_write(address, elf[loc:loc + size])
        self.cpu.hook_add(UC_HOOK_CODE, self.count)

    def count(self, *_):
        self.instructions += 1

    def run(self, hook, continuation, values, triangles, command_count, counter):
        cpu = self.cpu
        for name, value in values.items():
            cpu.reg_write(register(name), value)
        ctx, cursor = values["t0"], values["t1"]
        counter_at = values["s8"] + 27040
        cpu.mem_write(ctx, words(0xABCDEF00, cursor, 0xFADE2478))
        cpu.mem_write(counter_at, words(counter))
        cpu.mem_write(values["s3"] + 27044, words(values["s7"] + triangles * 3))
        size = 4 * command_count * triangles
        cpu.mem_write(cursor - 4, words(values["t2"] | (values["s1"] & 0xFFFFFF))
                      + b"\xA5" * (size + 4))
        self.instructions = 0
        cpu.emu_start(hook, continuation, count=20000)
        assert cpu.reg_read(register("pc")) == continuation
        assert cpu.mem_read(ctx, 12) == words(0xABCDEF00, cursor + size, 0xFADE2478)
        assert cpu.mem_read(counter_at, 4) == words((counter + 2 * triangles) & 0xFFFFFFFF)
        vertex, commands = values["s1"], []
        for _ in range(triangles):
            address = values["t2"] | (vertex & 0xFFFFFF)
            if command_count == 8:
                commands.append(address)
            commands.extend(values[key] for key in ("t9", "t8", "t6"))
            commands.append(address)
            commands.extend(values[key] for key in ("t9", "t7", "t5"))
            vertex += 72
        assert cpu.mem_read(cursor - 4, size + 8) == (
            words(values["t2"] | (values["s1"] & 0xFFFFFF), *commands) + b"\xA5" * 4)
        registers = tuple(cpu.reg_read(register(name)) for name in ("v0", "v1", *values))
        return registers, self.instructions


def main(old_path, new_path):
    base, updated = Renderer(old_path), Renderer(new_path)
    rng = random.Random(19948)
    for hook, continuation, command_count in (
        (0x09914774, 0x099147FC, 8),
        (0x0991499C, 0x09914A18, 7),
    ):
        sizes = [1, 2, 3, 507, 508] + [rng.randint(1, 508) for _ in range(123)]
        before = after = 0
        for i, triangles in enumerate(sizes):
            s1 = (0x09FFFFD0, 0xFFFFFFFC, 0x099AA000 + i * 72)[i % 3]
            values = dict(t0=0x0A000100, t1=0x0A001000 + 4 * i,
                          t2=0x01000000, t5=0xE7000000 | i % 2,
                          t6=0xE7000001, t7=0xDBFF0001 | i << 8,
                          t8=0xDBFF0002 | i << 8, t9=0x04030003,
                          s1=s1, s3=0x0A00B000, s8=0x0A00B000,
                          s7=3 * rng.randint(0, 508 - triangles), a0=0x55555555)
            counter = rng.getrandbits(32) if i % 2 else 0xFFFFFFFF - i
            arguments = (hook, continuation, values, triangles, command_count, counter)
            expected, old_count = base.run(*arguments)
            actual, new_count = updated.run(*arguments)
            assert actual == expected and new_count < old_count, (hook, i)
            before += old_count
            after += new_count
        print(f"{command_count} commands/triangle: {len(sizes)} batches match; "
              f"instruction slots {before:,} -> {after:,} ({1 - after / before:.1%} fewer)")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(f"usage: {sys.argv[0]} BASELINE.PBP UPDATED.PBP")
    main(*sys.argv[1:])
