"""Verify the replacement changes only the VIF hook and appended code."""
from hashlib import sha256
from pathlib import Path
import struct
import sys

BASE='9c1036d0991e9977c17bf55f8786a9cd851fe0015e853d8a550317182ae8c285'
CANDIDATE='275226e48494841eba9d6390fa09943253fb7f495ec3ae638f67631a160da60e'
HOOK=0x0992c87c

def layout(data):
    assert data[:4]==b'\0PBP'
    elf,tail=struct.unpack_from('<II',data,32)
    assert tail==len(data) and data[elf:elf+6]==b'\x7fELF\x01\x01'
    pht=elf+struct.unpack_from('<I',data,elf+28)[0]
    step,count=struct.unpack_from('<HH',data,elf+42)
    assert step==32 and count==3
    result=[]
    for i in range(count):
        at=pht+i*step
        row=struct.unpack_from('<8I',data,at)
        if row[0]==1:
            result.append((at,row))
    assert len(result)==2
    return elf,result

def verify(old,new):
    assert sha256(old).hexdigest()==BASE and sha256(new).hexdigest()==CANDIDATE
    elf,a=layout(old)
    elf2,b=layout(new)
    assert elf==elf2 and a[0]==b[0] and a[1][0]==b[1][0]
    head,before=a[1]
    _,after=b[1]
    assert before[:4]+before[6:]==after[:4]+after[6:]
    _,off,load,_,filesz,memsz,flags,_=before
    size_delta=len(new)-len(old)
    assert filesz==memsz and flags==7 and after[4]==after[5]==filesz+size_delta
    assert 0<size_delta<=4096 and elf+off+filesz==len(old)
    at=elf+off+HOOK-load
    assert struct.unpack_from('<II',old,at)==(0x24060004,0x02402825)
    op,delay=struct.unpack_from('<II',new,at)
    assert op>>26==2 and delay==0
    dest=((HOOK+4)&0xf0000000)|((op&0x03ffffff)<<2)
    assert dest==(load+filesz+63)&~63
    prefix=bytearray(new[:len(old)])
    for i,n in ((36,4),(head+16,8),(at,8)):
        prefix[i:i+n]=old[i:i+n]
    assert bytes(prefix)==old
    # Pickup and its translated callers remain in their original mappings.
    print(f'Exact released baseline outside VIF hook {HOOK:#x} and size fields; appended {size_delta} bytes; jump {dest:#x}.')

if __name__=='__main__':
    verify(*(Path(f).read_bytes() for f in sys.argv[1:]))
