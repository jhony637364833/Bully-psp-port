"""Differential tests for the compiled PSP VIF prefix and untouched native parser."""
import random, struct, sys
from pathlib import Path
from check_ge_batch import Renderer, register, words
from unicorn import UC_HOOK_CODE

old,new=map(Renderer,sys.argv[1:3])
prior=Renderer(sys.argv[3]) if len(sys.argv)==4 else None
entry,end=0x09757560,0x0a018000
state,gif,data,sp=0x0a006000,0x0a007000,0x0a008000,0x0a01a000
external=(0x0975146c,0x0992c224)
preserved='s0 s1 s2 s3 s4 s5 s6 s7 s8 gp fcsr f0 sp hi lo'.split()
rng=random.Random(2810945)

def runner(r):
    cpu=r.cpu
    assert_addr=end-8
    cpu.mem_write(assert_addr,words(0x0c000000|(entry>>2)&0x03ffffff,0))
    calls=[]
    fail=False
    def visit(c,pc,sz,ctx):
        args=tuple(c.reg_read(register(k)) for k in ('a0','a1','a2','a3'))
        if pc==external[0]:
            g,d,n,addr=args
            assert n<=1024,(pc,n)
            calls.append((pc,g,addr,bytes(c.mem_read(d,n))))
            c.reg_write(register('v0'),not fail)
        else:
            calls.append((pc,tuple(args),bytes(c.mem_read(state,64))))
            c.reg_write(register('v0'),1)
    for pc in external:
        cpu.mem_write(pc,words(0x03e00008,0))
        cpu.hook_add(UC_HOOK_CODE,visit,begin=pc,end=pc)
    ctx=cpu.context_save()
    def run(buf,pointer,addr,init,mode,length=None,callback_fail=False):
        nonlocal fail
        n=len(buf) if length is None else length
        fail=callback_fail
        calls.clear()
        cpu.context_restore(ctx)
        cpu.mem_write(gif,b'\x65'*80)
        cpu.mem_write(data,bytes(8192))
        cpu.mem_write(data if pointer in (0,state) else pointer,buf)
        cpu.mem_write(state,init)
        values={k:0x25200006+i for i,k in enumerate(preserved)}
        values.update(a0=state,a1=pointer,a2=n,a3=addr,sp=sp,fcsr=0)
        for k,v in values.items():cpu.reg_write(register(k),v)
        r.instructions=0
        cpu.emu_start(assert_addr,end,count=15000)
        assert cpu.reg_read(register('pc'))==end,(hex(cpu.reg_read(register('pc'))),hex(pointer),n,hex(addr),struct.unpack('<16I',init),r.instructions)
        ret=cpu.reg_read(register('v0'))
        return ((ret,tuple(calls),bytes(cpu.mem_read(state,64)),bytes(cpu.mem_read(gif,80)),
                 bytes(cpu.mem_read(data,8192)), tuple(cpu.reg_read(register(k)) for k in preserved)),
                r.instructions)
    return run

ref,opt=runner(old),runner(new)
inline=runner(prior) if prior else None
equiv=before=after=old_inline=0
def check(buf,addr=0x164,direct=0,skip=0,cl=1,wl=1,used=0,
          pointer=data,length=None,gifaddr=gif,wrapped=False,bench=False,fail=False):
    global equiv,before,after,old_inline
    ct=0xffffffff if wrapped else 6
    init=words(gifaddr,direct,skip,cl,wl,used,1)+bytes(range(16))+words(0x162,ct,0x9b654231,0xffffffff,0x10)
    args=buf,pointer,addr,init
    expected,a=ref(*args,0,length,fail)
    for mode in (2,):
        actual,b=opt(*args,mode,length,fail)
        assert actual==expected,(mode,addr,direct,skip,cl,wl,used,pointer,length,buf[:120].hex(),
                                 [i for i,(a,b) in enumerate(zip(expected,actual)) if a!=b],
                                 expected[5],actual[5])
        if mode==2 and bench:
            if inline:
                c,d=inline(*args,0,length,fail)
                assert c==expected
                old_inline+=d
            before+=a;after+=b
        equiv+=1

def encode(k,num=0,imm=0,irq=0):
    return words(((k|irq<<7)<<24)|(num<<16)|imm)

# Every opcode, with IRQ, differing command starts, and pass-through after a long prefix.
for k in range(128):
    for irq in (0,1):
        for cl,wl in ((1,1),(1,4),(4,1),(0,1),(256,256)):
            cmd=encode(k,9,0x8001,irq)
            check(cmd+bytes(48),cl=cl,wl=wl,wrapped=True)
            check(bytes(8)+cmd+bytes(48),cl=cl,wl=wl)

# Randomized compound streams mix unpack forms, STCYCL, skip lengths and boundaries.
for i in range(600):
    cl,wl=rng.randrange(1,257),rng.randrange(1,257)
    buf=bytearray()
    for j in range(rng.randrange(2,24)):
        op=rng.choice([0,0x02,0x04,0x06,0x07,0x10,0x20,0x30,0x31,0x4a,0x50,0x51,0x08,*range(0x60,0x80)])
        n=rng.choice([0,1,3,9,32,255])
        v=rng.getrandbits(16)
        if op in (0x50,0x51):v%=3
        buf+=encode(op,n,v,rng.getrandbits(1))
        buf+=rng.randbytes(rng.randrange(13)*4)
    check(bytes(buf),addr=0x100+(i%31),skip=(i%7)*4,cl=cl,wl=wl,wrapped=not i%2,fail=not i%5)
# Buffer boundaries, null inputs, unsupported input and truncated skips.
for i,n in enumerate((0,1,3,4,7,8,12,16,128,592)):
    for addr in (0x180,0xfffffff0):
        for ptr in (data,data+1,0,state):
            for skip in (0,4,8,n+4):
                check(bytes(1024),addr,skip=skip,pointer=ptr,length=n)
                check(bytes(1024),addr,direct=20,skip=skip,pointer=ptr,length=n,used=4)
check(bytes(3)+encode(8)+bytes(5),skip=3)
check(bytes(64),pointer=sp-192)
check(bytes(240),pointer=sp-460)
for n in (8,12,16,32,64,128,256):
    check(bytes(n),bench=True)
    check(encode(1,imm=0x0401)+encode(0x6e,8)+bytes(n),bench=True)
    check(bytes(n)+encode(0x50,imm=1)+bytes(32),bench=True)
    check(bytes(n),gifaddr=0)
    check(bytes(n),pointer=data+1)
    check(bytes(n),pointer=data+2)
    check(bytes(n),pointer=data+3)
# Nonword skip causes the original byte parser to reject this next opcode.
for skew in (1,2,3):
    for pointer in (data,data+skew):
        check(bytes(skew)+encode(8)+bytes(8-skew),addr=0x164,skip=skew,pointer=pointer)
# Two existing stack aliases plus a zero span adjacent to future counters.
check(bytes(64),pointer=state+44)
check(bytes(64),pointer=sp-64)
assert before>after
if inline: assert before>old_inline>after
print(f'{equiv:,} exact original parser comparisons. Instruction slots in selected skip/mixed streams: {before:,} -> {after:,}.')
