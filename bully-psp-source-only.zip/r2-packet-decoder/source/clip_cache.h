#ifndef BULLY_CLIP_CACHE_H
#define BULLY_CLIP_CACHE_H

#include <stdint.h>

/* Layout of the exact R2 build's clip memo (see clip_memo.h in source 106).
 * The existing renderer owns the cache and continues to perform all lookups. */
typedef struct {
    void *set;
    unsigned sets, epoch, bypass_mask;
    uint32_t (*read_fpu)(void);
    void (*write_fpu)(uint32_t);
    unsigned hits, misses, bypasses, admissions;
} ClipMemo;

enum {
    CLIP_SET_BYTES = 320,
    CLIP_HUD_BYTES = 264 * 1024,
    CLIP_RESERVE_BYTES = 1024 * 1024 + CLIP_HUD_BYTES,
    CLIP_MAX_SETS = 2048,
    CLIP_MIN_SETS = 128
};

extern unsigned clip_attempted;
extern void *clip_storage;
extern ClipMemo clip_memo;

unsigned clip_total_free(void);
unsigned clip_largest_free(void);
int clip_allocate(int partition, const char *name, int type, unsigned bytes, void *address);
void *clip_get_block(int id);
int clip_release(int id);
void clip_log(const char *format, ...);
uint32_t clip_fpu_read(void);
void clip_fpu_write(uint32_t value);
void try_clip_cache(void);

#endif
