#!/usr/bin/env python3
"""Apply verified geometry renderer changes to the published R2 replacement."""
import argparse
import hashlib
import os
from pathlib import Path
import struct
import subprocess
import tempfile

BASELINE = "621e9b22e6e1ebdaba6d5743d0cb6d2069246309586c09b8cf6108da70abcf07"
HOOK = 0x097C2850
BEFORE = (0x24030001, 0x0E5F9FFB, 0xAC432520)
GE_HOOKS = (
    (0x09914774, (0x7E24B800, 0x008A2025), "ge_batch_full"),
    (0x0991499C, (0x25290004, 0xAD090004), "ge_batch_sequential"),
)
SYMBOLS = {
    "clip_continue": 0x097C1C04,
    "clip_attempted": 0x09902520,
    "clip_storage": 0x09902524,
    "clip_memo": 0x09902528,
    "clip_total_free": 0x097E7FEC,
    "clip_largest_free": 0x097E7FE4,
    "clip_allocate": 0x097E7FF4,
    "clip_get_block": 0x097E8004,
    "clip_release": 0x097E7FFC,
    "clip_log": 0x09721254,
    "clip_fpu_read": 0x097BBD30,
    "clip_fpu_write": 0x097BBD3C,
    "memset": 0x097D531C,
    "ge_full_continue": 0x099147FC,
    "ge_sequential_continue": 0x09914A18,
}


def payload(sdk, address):
    source = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        layout = tmp / "renderer.ld"
        layout.write_text(
            "".join(f"{name} = {value:#x};\n" for name, value in SYMBOLS.items())
            + f"SECTIONS {{ . = {address:#x}; "
              ".text : { *(.text) *(.text.*) } "
              ".rodata : { *(.rodata*) } "
              ".data : { *(.data*) *(.sdata*) } "
              ".bss : { *(.bss*) *(.sbss*) *(COMMON) } "
              "/DISCARD/ : { *(.pdr) *(.comment) *(.reginfo) *(.MIPS.abiflags) *(.gnu.attributes) } "
              'ASSERT(SIZEOF(.data) == 0 && SIZEOF(.bss) == 0, "payload must have no writable state") }\n'
        )
        for program, args in (
            ("as", [source / "clip_cache_entry.S", "-o", tmp / "entry.o"]),
            ("gcc", ["-O2", "-G0", "-ffreestanding", "-fno-pic", "-mno-abicalls",
                     "-Wall", "-Wextra", "-Werror", "-c", source / "clip_cache.c", "-o", tmp / "cache.o"]),
            ("as", [source / "ge_batch.S", "-o", tmp / "ge.o"]),
            ("ld", ["-T", layout, "-o", tmp / "clip.elf", tmp / "entry.o", tmp / "cache.o", tmp / "ge.o"]),
            ("objcopy", ["-O", "binary", tmp / "clip.elf", tmp / "clip.bin"]),
        ):
            subprocess.run([sdk / "bin" / f"psp-{program}", *args], check=True)
        syms = subprocess.check_output([sdk / "bin" / "psp-nm", "-n", tmp / "clip.elf"], text=True)
        symbols = {parts[2]: int(parts[0], 16) for line in syms.splitlines()
                   if len(parts := line.split()) == 3}
        return (tmp / "clip.bin").read_bytes(), symbols


def patch(pbp, sdk):
    if hashlib.sha256(pbp).hexdigest() != BASELINE:
        raise ValueError("use EBOOT.PBP from the last Bully-R2-replacements.zip")
    if pbp[:4] != b"\0PBP":
        raise ValueError("invalid PBP signature")
    start, end = struct.unpack_from("<II", pbp, 32)
    if end != len(pbp) or pbp[start:start + 7] != b"\x7fELF\x01\x01\x01":
        raise ValueError("unexpected PBP program layout")
    elf = bytearray(pbp[start:end])
    phoff = struct.unpack_from("<I", elf, 28)[0]
    phsize, phnum = struct.unpack_from("<HH", elf, 42)
    if phsize != 32:
        raise ValueError("unexpected program header layout")
    loads = [(i, struct.unpack_from("<8I", elf, i))
             for i in range(phoff, phoff + phsize * phnum, phsize)
             if struct.unpack_from("<I", elf, i)[0] == 1]
    if len(loads) != 2:
        raise ValueError("unexpected load segments")
    _, (_, code_off, code_addr, _, code_size, _, code_flags, _) = loads[0]
    ph, (_, tail_off, tail_addr, _, file_size, mem_size, flags, _) = loads[1]
    if code_flags != 5 or not code_addr <= HOOK <= code_addr + code_size - 12:
        raise ValueError("cache hook is outside the mapped executable")
    at = code_off + HOOK - code_addr
    if struct.unpack_from("<III", elf, at) != BEFORE:
        raise ValueError("unexpected clipping allocator instructions")
    if flags != 7 or file_size != mem_size or tail_off + file_size != len(elf):
        raise ValueError("the final executable segment must cover the ELF tail")
    padding = -(tail_addr + file_size) % 16
    address = tail_addr + file_size + padding
    if address >> 28 != (HOOK + 4) >> 28:
        raise ValueError("cache payload is outside native jump range")
    code, symbols = payload(sdk, address)
    if not 0 < len(code) <= 2048:
        raise ValueError("unexpected cache payload size")
    def redirect(location, from_addr, symbol):
        target = symbols.get(symbol, 0)
        if not address <= target < address + len(code) or target % 4 or target >> 28 != (from_addr + 4) >> 28:
            raise ValueError(f"invalid renderer entry {symbol}")
        struct.pack_into("<II", elf, location, 0x08000000 | ((target >> 2) & 0x03FFFFFF), 0)

    redirect(at, HOOK, "clip_cache_entry")
    for hook, expected, entry in GE_HOOKS:
        if not tail_addr <= hook <= tail_addr + file_size - 8:
            raise ValueError("GE loop hook is outside the mapped executable")
        location = tail_off + hook - tail_addr
        if struct.unpack_from("<II", elf, location) != expected:
            raise ValueError(f"unexpected GE loop instructions at {hook:#x}")
        redirect(location, hook, entry)
    elf.extend(bytes(padding))
    elf.extend(code)
    new_size = len(elf) - tail_off
    struct.pack_into("<II", elf, ph + 16, new_size, new_size)
    result = bytearray(pbp[:start]) + elf
    struct.pack_into("<I", result, 36, len(result))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--pspdev", type=Path, default=os.environ.get("PSPDEV"), required=not os.environ.get("PSPDEV"))
    args = parser.parse_args()
    try:
        result = patch(args.baseline.read_bytes(), args.pspdev)
        with args.output.open("xb") as output:
            output.write(result)
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        parser.exit(1, f"{exc}\n")
    print(f"{hashlib.sha256(result).hexdigest()}  {args.output}")


if __name__ == "__main__":
    main()
