/* R2 already defers the GE stall update in these mixed-alpha loops.
 * Write the same commands in order, and publish the list cursor once before
 * returning to the original finish path. There are no calls within the loop.
 */
.set noreorder
.text

/* Both loops update the original counters and leave the same live registers. */
.macro advance count
    addiu $s7, $s7, 3
    addiu $s1, $s1, 72
    addiu $t1, $t1, \count
    lw    $v1, 27040($s8)
    lw    $v0, 27044($s3)
    addiu $v1, $v1, 2
    sltu  $v0, $s7, $v0
    sw    $v1, 27040($s8)
.endm

.globl ge_batch_full
.ent ge_batch_full
ge_batch_full:
1:
    ext   $a0, $s1, 0, 24
    or    $a0, $a0, $t2
    sw    $a0,  0($t1)   /* pass: vertex address, draw */
    sw    $t9,  4($t1)
    sw    $t8,  8($t1)   /* fail: inverted alpha, disable depth writes */
    sw    $t6, 12($t1)
    sw    $a0, 16($t1)   /* visit the same triangle again */
    sw    $t9, 20($t1)
    sw    $t7, 24($t1)   /* restore normal alpha and depth state */
    sw    $t5, 28($t1)
    advance 32
    bnez  $v0, 1b
     nop
    j     ge_full_continue
     sw   $t1, 4($t0)
.end ge_batch_full

.globl ge_batch_sequential
.ent ge_batch_sequential
ge_batch_sequential:
1:
    /* The current pass vertex address is already set or auto advanced. */
    sw    $t9,  0($t1)
    sw    $t8,  4($t1)
    sw    $t6,  8($t1)
    ext   $a0, $s1, 0, 24
    or    $a0, $a0, $t2
    sw    $a0, 12($t1)
    sw    $t9, 16($t1)
    sw    $t7, 20($t1)
    sw    $t5, 24($t1)
    advance 28
    bnez  $v0, 1b
     nop
    j     ge_sequential_continue
     sw   $t1, 4($t0)
.end ge_batch_sequential
