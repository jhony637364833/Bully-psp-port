/* Allegrex continuation of R2's auto-pickup health check.
 * a2 = host pointer to the player ped, a3 = checked health word.
 * This runs after the original player and item eligibility checks.
 */
.set noreorder
.set noat
.text
.globl pickup_guard
.ent pickup_guard
pickup_guard:
    bc1f    positive_health
     nop
    /* Only exact, positive zero can enter the inconsistent-state path. */
    bnez    $a3, blocked
     lw     $at, 0x1a08($a2)
    bnez    $at, blocked
     lbu    $at, 0x19e8($a2)
    /* PedIsDead reads this byte. Leave all marked deaths alone. */
    bnez    $at, blocked
     lw     $at, 0x1230($a2)
    xori    $at, $at, 13
    bnez    $at, blocked
     lw     $at, 0x1248($a2)
    /* Restrict recovery to the on-foot player. */
    bnez    $at, blocked
     lw     $at, 0x1a0c($a2)
    /* Require a positive, finite previous health value. */
    blez    $at, blocked
     srl    $at, $at, 23
    xori    $at, $at, 255
    beqz    $at, blocked
     nop
positive_health:
    j       pickup_nearby
     nop
blocked:
    j       pickup_original_blocked
     sw     $t8, 64($a0)
.end pickup_guard
