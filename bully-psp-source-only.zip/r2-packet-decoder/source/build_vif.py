"""Build an R2 EBOOT with fused aligned literal NOP and UNPACK dispatch."""
from hashlib import sha256
from pathlib import Path
import argparse,struct,subprocess,tempfile
BASE = '9c1036d0991e9977c17bf55f8786a9cd851fe0015e853d8a550317182ae8c285'

def offset(data, pc, count):
    elf, end = struct.unpack_from('<II', data, 32)
    if data[:4] != b'\x00PBP' or end != len(data) or data[elf:elf+4] != b'\x7fELF':
        raise ValueError('unexpected executable layout')
    phoff, = struct.unpack_from('<I', data, elf+28)
    entsize, num = struct.unpack_from('<HH', data, elf+42)
    if entsize != 32:
        raise ValueError('unexpected segment descriptor')
    for idx in range(num):
        kind, off, vaddr, _, used, _, flags, _ = struct.unpack_from('<8I', data, elf+phoff+idx*entsize)
        if kind == 1 and (flags & 1) and vaddr <= pc and pc+count <= vaddr+used:
            return elf+off+pc-vaddr
    raise ValueError('hook not in executable storage')


HOOK=0x0992c87c
BEFORE=(0x24060004,0x02402825,0x0e64b0e2,0x03a02025,0x8e020030,0x8e040034,0x8fa30000)
SYMBOLS=dict(original_copy_call=0x0992c884, original_dispatch=0x0992c88c,
             original_success=0x0992c830, original_unpack=0x0992c9b8)
def build(raw,sdk):
    if sha256(raw).hexdigest()!=BASE:
        raise ValueError('use the exact Bully-R2-renderer-update.zip EBOOT')
    elf,end=struct.unpack_from('<II',raw,32)
    phoff=elf+struct.unpack_from('<I',raw,elf+28)[0]
    entsize,num=struct.unpack_from('<HH',raw,elf+42)
    loads=[(i,h) for j in range(num)
           if (h:=struct.unpack_from('<8I',raw,i:=phoff+j*entsize))[0]==1]
    if entsize!=32 or len(loads)!=2:
        raise ValueError('unexpected segment layout')
    header,(_,tail,addr,_,size,mem,flags,_)=loads[-1]
    if size!=mem or flags!=7 or end!=elf+tail+size:
        raise ValueError('unexpected patch segment')
    pad=-(addr+size)%64
    base=addr+size+pad
    p=Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp)
        (d/'layout.ld').write_text(''.join(f'{k} = {v:#x};\n' for k,v in SYMBOLS.items())+
            f'SECTIONS {{ . = {base:#x}; .text : {{ *(.text*) }} .rodata : {{ *(.rodata*) }} '
            '.data : { *(.data*) *(.sdata*) } .bss : { *(.bss*) *(.sbss*) *(COMMON) } '
            '/DISCARD/ : { *(.pdr) *(.reginfo) *(.MIPS.abiflags) *(.gnu.attributes) *(.comment) } '
            'ASSERT(SIZEOF(.bss) == 0, "counter payload must be file backed") }')
        def tool(name,*args):
            return subprocess.check_output([sdk/'bin'/f'psp-{name}',*args],text=True)
        tool('as',p/'vif_dispatch.S','-o',d/'entry.o')
        tool('ld','-T',d/'layout.ld','-o',d/'prog.elf',d/'entry.o')
        tool('objcopy','-O','binary',d/'prog.elf',d/'prog.bin')
        payload=(d/'prog.bin').read_bytes()
        syms={q[2]:int(q[0],16) for row in tool('nm','-n',d/'prog.elf').splitlines()
              if len(q:=row.split())==3}
    if not 0<len(payload)<=4096:
        raise ValueError('unexpected payload length')
    out=bytearray(raw)
    at=offset(raw,HOOK,4*len(BEFORE))
    if struct.unpack_from('<7I',raw,at)!=BEFORE:
        raise ValueError('unexpected VIF command block')
    entry=syms['fused_command']
    if entry!=base or entry%4:
        raise ValueError('unexpected fused entry placement')
    struct.pack_into('<II',out,at,0x08000000|((entry>>2)&0x03ffffff),0)
    out.extend(bytes(pad)+payload)
    struct.pack_into('<I',out,36,len(out))
    struct.pack_into('<II',out,header+16,size+pad+len(payload),size+pad+len(payload))
    return out,syms

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    for arg in ('eboot','output','pspdev'):
        cli.add_argument(arg,type=Path)
    opt=cli.parse_args()
    try:
        out,syms=build(opt.eboot.read_bytes(),opt.pspdev)
        with opt.output.open('xb') as f: f.write(out)
    except (ValueError,OSError,subprocess.SubprocessError) as exc:
        cli.exit(1,f'{exc}\n')
    print(sha256(out).hexdigest())
    print(hex(syms['fused_command']))
