/* The cache math, FPU contract and lifecycle are unchanged. Allocate the
 * largest viable power of two, keeping the original HUD and free RAM gates. */
#include "clip_cache.h"
#include <stddef.h>
#include <string.h>

#if defined(__PSP__)
_Static_assert(sizeof(ClipMemo) == 40 && offsetof(ClipMemo, sets) == 4 &&
               offsetof(ClipMemo, read_fpu) == 16 && offsetof(ClipMemo, hits) == 24,
               "unexpected clip memo layout");
#endif

void try_clip_cache(void)
{
    if (clip_attempted)
        return;
    clip_attempted = 1;
    for (unsigned sets = CLIP_MAX_SETS; sets >= CLIP_MIN_SETS; sets >>= 1) {
        const unsigned bytes = sets * CLIP_SET_BYTES;
        if (clip_total_free() < CLIP_RESERVE_BYTES + bytes || clip_largest_free() < bytes)
            continue;

        int id = clip_allocate(2, "world_clip", 1, bytes, NULL);
        if (id < 0)
            continue;
        void *storage = clip_get_block(id);
        if (!storage || clip_total_free() < CLIP_RESERVE_BYTES ||
            clip_largest_free() < CLIP_HUD_BYTES) {
            if (clip_release(id) < 0)
                break;
            continue;
        }

        memset(storage, 0, bytes);
        clip_storage = storage;
        clip_memo = (ClipMemo){
            .set = storage, .sets = sets, .epoch = 1, .bypass_mask = 0x00020f80u,
            .read_fpu = clip_fpu_read, .write_fpu = clip_fpu_write,
        };
        clip_log("WORLD: optional clip memo %u bytes; remaining user memory %u bytes\n",
                 bytes, clip_total_free());
        return;
    }
    clip_log("WORLD: optional clip memo unavailable; normal clipping\n");
}
