/* Enter where the known original VIF loop has provided its state and
 * found an idle DIRECT/skip slot. No transitions are moved across GIF. */
.set noreorder
.set noat
.text
.globl fused_command
fused_command:
    andi  $a2,$s2,3
    bnez  $a2,.Lbyte
     andi $a2,$s1,3
    bnez  $a2,.Lbyte
     nop
    lw    $v1,0($s2)
    sw    $v1,0($sp)
    bnez  $v1,.Lnonzero
     nop
.Lnop:
    lw    $a0,48($s0)
    lw    $a1,52($s0)
    addiu $v0,$a0,1
    sltu  $a0,$v0,$a0
    addu  $a1,$a1,$a0
    sw    $v0,48($s0)
    sw    $a1,52($s0)
    addiu $s2,$s2,4
    addiu $s3,$s3,4
    addiu $s1,$s1,-4
    beqz  $s1,.Ldone
     nop
    lw    $v1,0($s2)
    beqz  $v1,.Lnop
     sw   $v1,0($sp)
.Lnonzero:
    srl   $t1,$v1,24
    andi  $a1,$t1,0x7f
    sltiu $a2,$a1,0x60
    bnez  $a2,.Lgeneric
     nop
    /* Class table maps all 0x60..0x7f to the original UNPACK handler.
     * Preserve its exact count and operands, including the raw high byte. */
    lw    $a0,48($s0)
    lw    $a3,52($s0)
    addiu $v0,$a0,1
    sltu  $a0,$v0,$a0
    addu  $a3,$a3,$a0
    sw    $v0,48($s0)
    sw    $a3,52($s0)
    srl   $a2,$v1,16
    andi  $a2,$a2,255
    j     original_unpack
     andi $t0,$v1,65535
.Ldone:
    j     original_success
     addiu $v0,$zero,1
.Lgeneric:
    j     original_dispatch
     nop
.Lbyte:
    addiu $a2,$zero,4
    j     original_copy_call
     move $a1,$s2
