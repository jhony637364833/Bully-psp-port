#!/usr/bin/env python3
"""Build the pickup replacement from the exact supplied Bully R2 EBOOT."""
import argparse
import hashlib
import os
from pathlib import Path
import struct
import subprocess
import tempfile

R2_SHA256 = "2eb7bf559bf2fec1d678ebccafabb99f320155b5ec2420f88a6da3aad9b0848c"
HOOK = 0x08BD4094
NEARBY = 0x08BD409C
BLOCKED = 0x08BD4240
ORIGINAL = (0x4503006A, 0xAC980040)
RGB = 0x09914588
RGB_ORIGINAL = (0xC4443338, 0x24840014)


def read_r2(pbp):
    if hashlib.sha256(pbp).hexdigest() != R2_SHA256:
        raise ValueError("input is not the supplied R2 EBOOT")
    if pbp[:4] != b"\0PBP":
        raise ValueError("invalid PBP")
    elf_start, psar = struct.unpack_from("<II", pbp, 32)
    if psar != len(pbp) or pbp[elf_start:elf_start + 7] != b"\x7fELF\x01\x01\x01":
        raise ValueError("expected an unencrypted ELF and no trailing PSAR")
    elf = bytearray(pbp[elf_start:psar])
    phoff = struct.unpack_from("<I", elf, 28)[0]
    phsize, phnum = struct.unpack_from("<HH", elf, 42)
    if phsize != 32:
        raise ValueError("invalid ELF program header size")
    loads = [(off, struct.unpack_from("<8I", elf, off))
             for off in range(phoff, phoff + phsize * phnum, phsize)
             if struct.unpack_from("<I", elf, off)[0] == 1]
    if len(loads) != 2:
        raise ValueError("unexpected ELF load segments")
    return elf_start, elf, loads


def assemble(sdk, address, source):
    src = Path(__file__).with_name(source)
    with tempfile.TemporaryDirectory() as build:
        build = Path(build)
        link = build / "pickup.ld"
        link.write_text(
            f"pickup_nearby = {NEARBY:#x};\n"
            f"pickup_original_blocked = {BLOCKED:#x};\n"
            f"SECTIONS {{ . = {address:#x}; .text : {{ *(.text) }} }}\n"
        )
        obj, elf, raw = (build / name for name in ("pickup.o", "pickup.elf", "pickup.bin"))
        for tool, args in (
            ("as", ["-o", obj, src]),
            ("ld", ["-T", link, "-o", elf, obj]),
            ("objcopy", ["-j", ".text", "-O", "binary", elf, raw]),
        ):
            subprocess.run([sdk / "bin" / f"psp-{tool}", *args], check=True)
        return raw.read_bytes()


def patch(pbp, sdk, renderer=False):
    elf_start, elf, loads = read_r2(pbp)
    _, (_, text_offset, text_address, _, text_size, _, text_flags, _) = loads[0]
    if text_flags != 5 or not text_address <= HOOK <= text_address + text_size - 8:
        raise ValueError("pickup branch is outside the code segment")
    hook_offset = text_offset + HOOK - text_address
    if struct.unpack_from("<II", elf, hook_offset) != ORIGINAL:
        raise ValueError("pickup branch does not match R2")
    ph, (_, last_offset, last_address, _, file_size, mem_size, flags, _) = loads[-1]
    if last_offset + file_size != len(elf) or file_size != mem_size or flags != 7:
        raise ValueError("ELF tail must be fully mapped and executable")
    padding = -(last_address + file_size) % 16
    payload_address = last_address + file_size + padding
    if payload_address >> 28 != (HOOK + 4) >> 28:
        raise ValueError("pickup payload is outside jump range")
    payload = assemble(sdk, payload_address, "pickup_guard.S")
    if not 0 < len(payload) <= 256 or len(payload) % 4:
        raise ValueError("unexpected pickup payload size")
    struct.pack_into("<II", elf, hook_offset, 0x08000000 | ((payload_address >> 2) & 0x03FFFFFF), 0)
    elf.extend(bytes(padding))
    elf.extend(payload)
    if renderer:
        rgb_offset = last_offset + RGB - last_address
        if not last_address <= RGB <= last_address + file_size - 8 or struct.unpack_from("<II", elf, rgb_offset) != RGB_ORIGINAL:
            raise ValueError("RGB lighting entry does not match R2")
        align = -(payload_address + len(payload)) % 16
        rgb_address = payload_address + len(payload) + align
        rgb_code = assemble(sdk, rgb_address, "rgb_light.S")
        if not 0 < len(rgb_code) <= 512 or len(rgb_code) % 4:
            raise ValueError("unexpected RGB lighting payload size")
        struct.pack_into("<II", elf, rgb_offset, 0x08000000 | ((rgb_address >> 2) & 0x03FFFFFF), 0)
        elf.extend(bytes(align))
        elf.extend(rgb_code)
    new_size = len(elf) - last_offset
    struct.pack_into("<II", elf, ph + 16, new_size, new_size)
    result = bytearray(pbp[:elf_start]) + elf
    struct.pack_into("<I", result, 36, len(result))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("r2", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--pspdev", type=Path, default=os.environ.get("PSPDEV"), required=not os.environ.get("PSPDEV"))
    parser.add_argument("--renderer", action="store_true", help="also unroll the RGB lighting path")
    args = parser.parse_args()
    try:
        result = patch(args.r2.read_bytes(), args.pspdev, args.renderer)
        with args.output.open("xb") as output:
            output.write(result)
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        parser.exit(1, f"{exc}\n")
    print(f"{hashlib.sha256(result).hexdigest()}  {args.output}")


if __name__ == "__main__":
    main()
