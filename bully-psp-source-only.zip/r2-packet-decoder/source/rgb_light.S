/* R2's RGB-only lighting path, unrolled for three channels.
 * Keep the original per-channel load order, operations, clamp and stores.
 * v0 is already the high half of the original 255.0 constant address.
 */
.set noreorder
.text
.globl rgb_light
.ent rgb_light
rgb_light:
    lwc1    $f4, 0x3338($v0)
    .macro channel slot
    lbu     $a3, 20+\slot($a0)
    lbu     $v1, 24+\slot($a0)
    lwc1    $f3, 8($a1)
    mtc1    $a3, $f1
    lwc1    $f2, 12+4*\slot($a1)
    cvt.s.w $f1, $f1
    mtc1    $v1, $f0
    nop
    cvt.s.w $f0, $f0
    sub.s   $f0, $f0, $f1
    mul.s   $f0, $f0, $f3
    add.s   $f0, $f0, $f1
    mul.s   $f0, $f0, $f2
    c.lt.s  $f0, $f4
    nop
    bc1t    1f
     lwc1   $f1, 24+4*\slot($a1)
    mov.s   $f0, $f4
1:
    mul.s   $f0, $f0, $f1
    add.s   $f0, $f0, $f0
    swc1    $f0, 4*\slot($a2)
    .endm
    channel 0
    channel 1
    channel 2
    jr      $ra
     nop
.end rgb_light
