/* Continue the exact R2 world renderer after the optional cache decision. */
.set noreorder
.text
.globl clip_cache_entry
.ent clip_cache_entry
clip_cache_entry:
    addiu $sp, $sp, -32
    sw    $ra, 28($sp)
    jal   try_clip_cache
     nop
    lw    $ra, 28($sp)
    addiu $sp, $sp, 32
    j     clip_continue
     lw   $s2, 48($s0)
.end clip_cache_entry
