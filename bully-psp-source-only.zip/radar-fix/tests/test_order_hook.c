/* CodeRabbit generated: exercise temporary replacement of the R4 records. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/mman.h>

typedef struct {uint32_t addr,bytes,serial;} Upload;
static Upload *const uploads=(Upload*)0x098cf6b4;
static uint64_t transfer;
static unsigned next_serial, expected_serial, phase, flushes;
void order_feed(unsigned,const void*,unsigned,uint32_t);
void order_upload(void*,uint64_t,uint32_t,uint32_t);
void order_reg(void*,unsigned,uint64_t);
void *order_texture(uint64_t);
void replay_pair(void);

void orig_reg(void *o,unsigned reg,uint64_t value){
 (void)o;
 if(reg==0x50)transfer=value;
 if(reg==0x53 && (value&3)!=1 && (value&3)!=3)uploads[(transfer>>32)&16383]=(Upload){0};
}
void orig_upload(void *o,uint64_t b,uint32_t addr,uint32_t n){
 (void)o;uploads[(b>>32)&16383]=(Upload){addr,n,++next_serial};
}
void orig_flush(void){flushes++;}
void *orig_texture(uint64_t t){
 (void)t;assert(uploads[100].serial==expected_serial);assert(uploads[120].serial==expected_serial+1);
 return (void*)0x1234;
}
static void upload(unsigned slot,unsigned n){
 uint64_t b=(uint64_t)slot<<32;
 order_reg(0,0x50,b);order_reg(0,0x51,0);order_reg(0,0x52,1);order_reg(0,0x53,0);
 order_upload(0,b,1000+next_serial,n);
}
void orig_feed(unsigned ch,const void*p,unsigned n,uint32_t addr){
 (void)p;(void)n;(void)addr;
 if(ch==2){upload(100,8272);upload(120,176);upload(100,8272);upload(120,176);}
 if(ch==1){
  const uint64_t t=((uint64_t)120<<37)|((uint64_t)20<<20)|100;
  replay_pair();expected_serial=1;assert(order_texture(t)==(void*)0x1234);
  assert(uploads[100].serial==3 && uploads[120].serial==4);
  replay_pair();expected_serial=3;assert(order_texture(t)==(void*)0x1234);
  assert(uploads[100].serial==3 && uploads[120].serial==4);phase++;
 }
}
int main(void){
 void *mem=mmap((void*)0x098cf000,0x31000,PROT_READ|PROT_WRITE,
                MAP_PRIVATE|MAP_ANONYMOUS|MAP_FIXED_NOREPLACE,-1,0);
 assert(mem==(void*)0x098cf000);
 order_feed(2,0,0,0);order_feed(1,0,0,0);
 assert(phase==1 && flushes==2);
 assert(munmap(mem,0x31000)==0);
 puts("PASS texture serial selection and restoration of current records");
}
