#!/usr/bin/env python3
"""CodeRabbit-generated: verify R4 patch isolation and input guards."""
import argparse
import importlib.util
from pathlib import Path
import struct
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('radar_patch', ROOT / 'patch_r4.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('base', type=Path)
    p.add_argument('candidate', type=Path)
    args = p.parse_args()
    source = args.base.read_bytes()
    result = args.candidate.read_bytes()
    payload = (ROOT / 'native/radar_fan.bin').read_bytes()
    order = (ROOT / 'native/radar_order.bin').read_bytes()
    assert result == mod.patch(source, payload, order)
    start = struct.unpack_from('<I', source, 32)[0]
    old_elf = source[start:]
    new_elf = result[start:]
    phoff = struct.unpack_from('<I', old_elf, 28)[0]
    header = phoff + 64
    site = mod.SITE - 0x08803f00
    new_seg_size = struct.unpack_from('<I', new_elf, header + 16)[0]
    assert new_seg_size == struct.unpack_from('<I', new_elf, header + 20)[0]
    assert len(new_elf) == mod.EXPECTED_SEGMENT[1] + new_seg_size
    assert struct.unpack_from('<I', result, 36)[0] == len(result)
    assert struct.unpack_from('<II', new_elf, site) == (0x08000000 | ((mod.ENTRY >> 2) & 0x03ffffff), 0)
    ignored = [(36, 40), (start + header + 16, start + header + 24), (start + site, start + site + 8)]
    for address, destination, _ in mod.ORDER_SITES:
        off = address - 0x08803f00
        assert struct.unpack_from('<II', new_elf, off) == (0x08000000 | ((destination >> 2) & 0x03ffffff), 0)
        ignored.append((start + off, start + off + 8))
    previous = 0
    for first, last in sorted(ignored):
        assert source[previous:first] == result[previous:first]
        previous = last
    assert source[previous:] == result[previous:len(source)]
    offset = mod.EXPECTED_SEGMENT[1] + mod.ENTRY - mod.EXPECTED_SEGMENT[2]
    assert new_elf[len(old_elf):offset] == bytes(offset - len(old_elf))
    order_offset = mod.EXPECTED_SEGMENT[1] + mod.ORDER_ENTRY - mod.EXPECTED_SEGMENT[2]
    assert new_elf[offset:offset + len(payload)] == payload
    assert new_elf[offset + len(payload):order_offset] == bytes(order_offset - offset - len(payload))
    assert new_elf[order_offset:] == order
    for bad_source, bad_payload, bad_order in ((source[:-1] + bytes([source[-1] ^ 1]), payload, order), (source, payload[:-1] + bytes([payload[-1] ^ 1]), order), (source, payload, order[:-1] + bytes([order[-1] ^ 1]))):
        try:
            mod.patch(bad_source, bad_payload, bad_order)
        except ValueError:
            pass
        else:
            raise AssertionError('modified input was accepted')
    with tempfile.TemporaryDirectory() as d:
        out = Path(d) / 'existing.pbp'
        out.write_bytes(b'keep')
        r = subprocess.run([sys.executable, str(ROOT / 'patch_r4.py'), str(args.base), str(out)], capture_output=True)
        assert r.returncode != 0 and out.read_bytes() == b'keep'
    print('PASS exact input/payload guards, overwrite protection, and byte isolation')


if __name__ == '__main__':
    main()
