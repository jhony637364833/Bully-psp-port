/* CodeRabbit-generated tests for the minimap mask and clipped UVs. */
#include "radar_clip.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#define PI 3.14159265358979323846f
static unsigned calls, unchanged;
static float area;
static void forward(void *o,unsigned prim,const BullyOverlayContext *s,const BullyOverlayVertex *v,unsigned n) {
 (void)o;if(prim==6 || prim==3){return;}assert(n==3);calls++;
 if(s->test==0x5140b){unchanged++;return;}
 assert(s->test==0x3140b);
 for(unsigned j=0;j<n;j++) {
  assert(v[j].x>=510.99f && v[j].x<=595.01f && v[j].y>=35.49f && v[j].y<=113.89f);
  assert(fabsf(v[j].u-(v[j].x-511)*2)<0.001f);
  assert(fabsf(v[j].v-(v[j].y-35.5f)*3)<0.001f);
  assert(v[j].color==0x7f7f7f7f && v[j].z==65535);
 }
 area+=fabsf((v[1].x-v[0].x)*(v[2].y-v[0].y)-(v[1].y-v[0].y)*(v[2].x-v[0].x))*0.5f;
}
static BullyOverlayVertex pt(float x,float y,float z) {return (BullyOverlayVertex){0,0,0,x,y,z};}
static BullyOverlayVertex ellipse(float angle,float z) {return pt(553+42*cosf(angle),74.6875f+39.1875f*sinf(angle),z);}
int main(void) {
 BullyOverlayContext m={0},r={0},clear={0};
 m.alpha=0x4a;m.test=0x3140a;m.frame=UINT64_C(0xff000000000a008c);m.zbuf=0x1000118;m.scissor=UINT64_C(0x1bf0000027f0000);
 r.alpha=0x44;r.test=0x5140b;r.frame=m.frame;r.zbuf=UINT64_C(0x101000118);r.clamp=5;
 BullyOverlayVertex rect[2]={pt(0,0,0),pt(32,448,0)};
 clear.test=0x3140a;clear.zbuf=0x1000118;clear.frame=UINT64_C(0xffffffff000a008c);
 BullyOverlayVertex tri[3]={{0,0,0x7f7f7f7f,511,35.5f,65535},{168,0,0x7f7f7f7f,595,35.5f,65535},{168,235.125f,0x7f7f7f7f,595,113.875f,65535}};
 BullyOverlayVertex tri2[3]={{0,0,0x7f7f7f7f,511,35.5f,65535},{168,235.125f,0x7f7f7f7f,595,113.875f,65535},{0,235.125f,0x7f7f7f7f,511,113.875f,65535}};
 bully_radar_draw(0,0x155,&r,tri,3,forward);assert(unchanged==1);
 BullyOverlayVertex q[3]={pt(553,74.6875f,0),ellipse(0,0),ellipse(2*PI/30,0)};
 for(unsigned i=0;i<30;i++) {
  q[1]=i? q[2]:ellipse(0,0);q[2]=i==29?ellipse(0,0):ellipse((i+1)*2*PI/30,0);
  bully_radar_draw(0,0x45,&m,q,3,forward);
 }
 bully_radar_draw(0,0x155,&r,tri,3,forward);assert(unchanged==2);
 const float cx[]={595,595,511,511},cy[]={113.875f,35.5f,35.5f,113.875f};
 const float start[]={0,0,PI,PI},step[]={1,-1,1,-1};
 for(unsigned k=0;k<4;k++) {
  q[0]=pt(cx[k],cy[k],16777215);q[1]=ellipse(start[k],16777215);
  for(unsigned i=0;i<6;i++) {
   q[2]=ellipse(start[k]+step[k]*(i+1)*PI/12,16777215);
   bully_radar_draw(0,0x45,&m,q,3,forward);q[1]=q[2];
  }
 }
 bully_radar_draw(0,0x155,&r,tri,3,forward);
 bully_radar_draw(0,0x155,&r,tri2,3,forward);
 assert(calls>10 && unchanged==2 && area>4900 && area<5200);
 bully_radar_draw(0,6,&clear,rect,2,forward);
 bully_radar_draw(0,0x155,&r,tri,3,forward);assert(unchanged==3);
 m.frame=r.frame=UINT64_C(0xff000000000a0000);
 q[0]=pt(553,74.6875f,0);q[2]=ellipse(0,0);
 for(unsigned i=0;i<30;i++) {
  q[1]=q[2];q[2]=i==29?ellipse(0,0):ellipse((i+1)*2*PI/30,0);
  bully_radar_draw(0,0x45,&m,q,3,forward);
 }
 for(unsigned k=0;k<4;k++) {
  q[0]=pt(cx[k],cy[k],16777215);q[1]=ellipse(start[k],16777215);
  for(unsigned i=0;i<6;i++) {
   q[2]=ellipse(start[k]+step[k]*(i+1)*PI/12,16777215);
   bully_radar_draw(0,0x45,&m,q,3,forward);q[1]=q[2];
  }
 }
 unsigned before=calls;
 bully_radar_draw(0,0x155,&r,tri,3,forward);assert(unchanged==3 && calls>before);
 r.frame=UINT64_C(0xff000000000a008c);
 bully_radar_draw(0,0x155,&r,tri,3,forward);assert(unchanged==4);
 r.frame=m.frame;
 BullyOverlayVertex outside[3]={tri[0],tri[1],tri[2]};outside[0].x=500;
 bully_radar_draw(0,0x155,&r,outside,3,forward);assert(unchanged==5);
 puts("PASS both framebuffers, mask isolation, bounds, clipping, UVs and frame reset");
 return 0;
}
