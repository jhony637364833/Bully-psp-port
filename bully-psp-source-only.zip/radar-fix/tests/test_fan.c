/* CodeRabbit-generated regression checks for PS2 triangle fans. */
#include "overlay_geometry.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef struct { unsigned n; BullyOverlayVertex triangles[16][3]; } Capture;
static void draw(void *opaque, unsigned prim, const BullyOverlayContext *ctx,
                 const BullyOverlayVertex *v, unsigned n) {
    Capture *c = opaque;
    (void)ctx;
    assert((prim & 7u) == 5u && n == 3 && c->n < 16);
    memcpy(c->triangles[c->n++], v, 3 * sizeof(*v));
}
static void vertex(BullyOverlayGeometry *g, unsigned x, unsigned color, unsigned reg) {
    bully_overlay_geometry_reg(g, 1, color);
    bully_overlay_geometry_reg(g, 3, ((uint64_t)(x * 16u)) | ((uint64_t)(x * 32u) << 16));
    bully_overlay_geometry_reg(g, reg, ((uint64_t)(x * 16u)) | ((uint64_t)(x * 48u) << 16));
}
static void check(const Capture *c, unsigned i, unsigned a, unsigned b, unsigned d) {
    const unsigned x[] = { a, b, d };
    for (unsigned j = 0; j < 3; ++j) {
        assert(c->triangles[i][j].x == (float)x[j]);
        assert(c->triangles[i][j].y == (float)(3 * x[j]));
        assert(c->triangles[i][j].u == (float)x[j]);
        assert(c->triangles[i][j].v == (float)(2 * x[j]));
    }
}
int main(void) {
    BullyOverlayGeometry g; Capture c = {0};
    bully_overlay_geometry_init(&g, NULL, draw, &c);
    bully_overlay_geometry_reg(&g, 0, 0x15du); /* textured, interpolated fan */
    vertex(&g, 1, 0x11, 5); vertex(&g, 2, 0x22, 5);
    assert(c.n == 0);
    vertex(&g, 3, 0x33, 5); vertex(&g, 4, 0x44, 5); vertex(&g, 5, 0x55, 5);
    assert(c.n == 3); check(&c, 0, 1, 2, 3); check(&c, 1, 1, 3, 4); check(&c, 2, 1, 4, 5);
    assert(c.triangles[2][0].color == 0x11 && c.triangles[2][1].color == 0x44 && c.triangles[2][2].color == 0x55);
    /* A new primitive restarts the fan. XYZ3 advances its edge without drawing. */
    bully_overlay_geometry_reg(&g, 0, 0x155u); /* flat color */
    vertex(&g, 6, 0x66, 5); vertex(&g, 7, 0x77, 5); vertex(&g, 8, 0x88, 13);
    assert(c.n == 3);
    vertex(&g, 9, 0x99, 5);
    assert(c.n == 4); check(&c, 3, 6, 8, 9);
    for (unsigned j = 0; j < 3; ++j) assert(c.triangles[3][j].color == 0x99);
    /* Switching away and back must discard the previous fan. */
    bully_overlay_geometry_reg(&g, 0, 3); bully_overlay_geometry_reg(&g, 0, 0x155u);
    vertex(&g, 10, 0xaa, 5); vertex(&g, 11, 0xbb, 5); assert(c.n == 4);
    vertex(&g, 12, 0xcc, 5); assert(c.n == 5); check(&c, 4, 10, 11, 12);
    puts("PASS triangle fan order, shading, XYZ3 and primitive reset");
    return 0;
}
