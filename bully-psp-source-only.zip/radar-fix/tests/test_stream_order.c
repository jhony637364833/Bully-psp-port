/* CodeRabbit generated: exercise upload ordering and conservative rejection. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "stream_order.h"

static BullyStreamOrder s;
static uint64_t bitblt(unsigned dest){return (uint64_t)dest<<32;}
static uint64_t tex(unsigned p,unsigned c){return ((uint64_t)c<<37)|((uint64_t)20<<20)|p;}
static void transfer(unsigned dest,unsigned addr,unsigned n,unsigned serial){
 bully_stream_reg(&s,0x50,bitblt(dest));
 bully_stream_reg(&s,0x51,0);
 bully_stream_reg(&s,0x52,1);
 bully_stream_reg(&s,0x53,0);
 bully_stream_upload(&s,bitblt(dest),addr,n,serial,1);
}
static void pair(unsigned p,unsigned c,unsigned serial){
 transfer(p,1000+serial,8272,serial);
 transfer(c,2000+serial,176,serial+1);
}
int main(void){
 BullyStreamUpload out[2];
 bully_stream_begin(&s);pair(100,120,1);pair(200,220,3);pair(100,120,5);
 assert(!bully_stream_select(&s,tex(100,120),out));
 assert(bully_stream_unmask(&s));assert(bully_stream_unmask(&s));
 assert(bully_stream_select(&s,tex(100,120),out) && out[0].serial==1 && out[1].serial==2);
 assert(bully_stream_unmask(&s));
 assert(bully_stream_select(&s,tex(200,220),out) && out[0].serial==3);
 assert(bully_stream_select(&s,tex(100,120),out) && out[0].serial==5);
 assert(!bully_stream_select(&s,tex(100,120),out));
 assert(!bully_stream_unmask(&s));

 bully_stream_begin(&s);transfer(1,100,208,1);bully_stream_reg(&s,5,9);transfer(2,200,176,2);
 assert(bully_stream_unmask(&s));assert(!bully_stream_select(&s,tex(1,2),out));
 bully_stream_begin(&s);pair(1,2,1);assert(bully_stream_unmask(&s));
 assert(!bully_stream_select(&s,tex(1,3),out));
 assert(!bully_stream_select(&s,tex(1,1),out));
 assert(!bully_stream_select(&s,((uint64_t)19<<20)|((uint64_t)2<<37)|1,out));
 assert(bully_stream_select(&s,tex(1,2),out));

 bully_stream_begin(&s);pair(1,2,1);bully_stream_reg(&s,0x53,2);
 assert(!bully_stream_unmask(&s));assert(!bully_stream_select(&s,tex(1,2),out));
 bully_stream_begin(&s);bully_stream_reg(&s,0x51,1);bully_stream_reg(&s,0x53,0);
 bully_stream_upload(&s,bitblt(1),100,208,1,1);assert(!s.valid);
 bully_stream_begin(&s);bully_stream_reg(&s,0x53,0);bully_stream_reg(&s,0x50,bitblt(2));assert(!s.valid);
 bully_stream_begin(&s);bully_stream_reg(&s,0x53,0);bully_stream_upload(&s,bitblt(1),100,208,0,0);assert(!s.valid);
 bully_stream_begin(&s);for(unsigned i=0;i<BULLY_STREAM_CAPACITY/2;i++)pair(1,2,1);
 assert(s.valid && s.length==BULLY_STREAM_CAPACITY);transfer(3,100,208,1);assert(!s.valid && s.length==BULLY_STREAM_CAPACITY);
 puts("PASS transfer order, lagged selection, reuse, invalidation and bounds");
}
