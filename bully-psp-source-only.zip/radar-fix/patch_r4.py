#!/usr/bin/env python3
"""Add the experimental radar fix to the exact Bully R4 fix-kit executable.

CodeRabbit-generated. The input game program is never embedded in this tool.
"""
import argparse
import hashlib
from pathlib import Path
import struct

INPUT_SHA256 = '3ab5d5af58b683294bb3f713badf31d0a3578305b371ccab4182a9cacf203d70'
ORDER_SHA256 = 'eb5fa115a40c1a72b6e9d1a3aff1fc5626a9507350aa9fe7e07cfacb6950a207'
ORDER_ENTRY = 0x0992c000
ORDER_SITES = (
    (0x0975942c, 0x0992c000, '8409023c3cfb428c'),
    (0x097596b4, 0x0992c0d8, '9009023cc4f6428c'),
    (0x09759544, 0x0992c194, '500002241f00a210'),
    (0x09758094, 0x0992c250, '002d827cedff4224'),
    (0x09757560, 0x0992c6ec, '9800801000000000'),
)
PAYLOAD_SHA256 = 'dfc75b2ab9d4459d8bb5afe05e05a6ab2908b9631c7bc71bb988f89ba17fda50'
SITE = 0x09757968
ENTRY = 0x09928100
ORIGINAL_SITE = bytes.fromhex('010002245700a210')
EXPECTED_SEGMENT = (1, 0x103ba24, 0x0983fa24, 0x0983fa24, 0xe8611, 0xe8611, 7, 0x80)


def patch(data, payload, order):
    if hashlib.sha256(data).hexdigest() != INPUT_SHA256:
        raise ValueError('Expected the EBOOT.PBP from the Bully R4 fix kit')
    if hashlib.sha256(payload).hexdigest() != PAYLOAD_SHA256:
        raise ValueError('Radar payload does not match the tested build')
    if hashlib.sha256(order).hexdigest() != ORDER_SHA256:
        raise ValueError('Texture ordering payload does not match the tested build')
    if data[:4] != b'\0PBP' or len(data) < 40:
        raise ValueError('Invalid PBP header')
    offsets = struct.unpack_from('<8I', data, 8)
    start, end = offsets[6:8]
    if start >= end or end != len(data):
        raise ValueError('Unexpected PBP data offsets')
    elf = bytearray(data[start:end])
    if elf[:7] != b'\x7fELF\x01\x01\x01' or struct.unpack_from('<HH', elf, 42) != (32, 3):
        raise ValueError('Unexpected ELF32 layout')
    phoff, = struct.unpack_from('<I', elf, 28)
    header = phoff + 64
    segment = struct.unpack_from('<8I', elf, header)
    if segment != EXPECTED_SEGMENT or len(elf) != segment[1] + segment[4]:
        raise ValueError('Unexpected R4 load segment')
    site = SITE - 0x08803f00
    if elf[site:site + 8] != ORIGINAL_SITE:
        raise ValueError('Overlay function signature mismatch')
    target = segment[1] + ENTRY - segment[2]
    order_target = segment[1] + ORDER_ENTRY - segment[2]
    if target < len(elf) or target + len(payload) > order_target or ORDER_ENTRY + len(order) >= 0x099f7d00:
        raise ValueError('Patch payload overlaps existing code or guest RAM')
    if (SITE + 4) >> 28 != ENTRY >> 28 or ENTRY & 3:
        raise ValueError('Radar payload is outside the MIPS jump region')
    for address, destination, expected in ((SITE, ENTRY, ORIGINAL_SITE.hex()), *ORDER_SITES):
        offset = address - 0x08803f00
        if elf[offset:offset + 8] != bytes.fromhex(expected) or (address + 4) >> 28 != destination >> 28 or destination & 3:
            raise ValueError('Unexpected overlay hook or destination')
        struct.pack_into('<II', elf, offset, 0x08000000 | ((destination >> 2) & 0x03ffffff), 0)
    elf.extend(bytes(target - len(elf)))
    elf.extend(payload)
    elf.extend(bytes(order_target - len(elf)))
    elf.extend(order)
    new_size = len(elf) - segment[1]
    struct.pack_into('<II', elf, header + 16, new_size, new_size)
    result = bytearray(data[:start]) + elf
    struct.pack_into('<I', result, 36, len(result))
    return bytes(result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input_pbp', type=Path)
    parser.add_argument('output_pbp', type=Path)
    args = parser.parse_args()
    payload = (Path(__file__).parent / 'native' / 'radar_fan.bin').read_bytes()
    order = (Path(__file__).parent / 'native' / 'radar_order.bin').read_bytes()
    result = patch(args.input_pbp.read_bytes(), payload, order)
    with args.output_pbp.open('xb') as f:
        f.write(result)
    print('Created', args.output_pbp, 'SHA-256', hashlib.sha256(result).hexdigest())


if __name__ == '__main__':
    main()
