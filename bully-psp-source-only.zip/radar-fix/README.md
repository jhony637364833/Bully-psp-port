<!-- coderabbit-ai-generated:v1 -->

<!-- coderabbit-ai-generated-section:v1:93c3a71a43d88d64db0cfd73a163cad6796502825fc3a2c6c3a1aed901d5d78b -->

# Bully R4 map patch

This patch targets the exact EBOOT.PBP in the supplied R4 fix kit. It adds triangle fan decoding, clips the observed minimap against its circular mask, and resolves the captured map texture transfers in their draw order. The R4 timing, audio, and script changes are retained.

## Apply

1. Back up the game folder and saves. Install the supplied R4 fix kit replacement files in the complete Bully PSP folder.
2. With Python 3, run:

   ```sh
   python3 radar-fix/patch_r4.py /path/to/r4/EBOOT.PBP /path/to/patched/EBOOT.PBP
   ```

   The destination must not already exist. The script checks the input EBOOT and both payloads.
3. Copy the resulting EBOOT.PBP beside `SLUS_212.69` and `discmap.txt`. Keep the R4 kit's script and other replacement files in place. Cold boot the game; do not load an old emulator save state.

The map fix is limited to the observed R4 framebuffers, minimap mask and transfer sequence. Desktop PPSSPP checks cover the bedroom, dorm hallway, school grounds and the zoomed map. Android, physical PSP and all game locations have not been tested. FPS improvements are still under investigation.

## Rebuild and test

Build with pspdev v20261001: `make -C radar-fix/native PSPDEV=/path/to/pspdev`. The resulting payload hashes must match `patch_r4.py`. The host tests are `tests/test_fan.c`, `tests/test_clip.c`, `tests/test_stream_order.c` and `tests/test_order_hook.c`. Run `python3 radar-fix/tests/test_patch.py /path/to/r4/EBOOT.PBP /path/to/patched/EBOOT.PBP` to verify the exact input and patch boundaries.

Based on PS2RC by SandstoneDev  
https://github.com/SandstoneDev/PS2RC  
Community: https://discord.gg/wV8x46ZTDu

See `third-party/PS2RC-LICENSE` and `third-party/PS2RC-NOTICE.md`.


<!-- /coderabbit-ai-generated:v1 -->