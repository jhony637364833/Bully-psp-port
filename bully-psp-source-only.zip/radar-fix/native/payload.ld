/* CodeRabbit generated: payload sits after the R4 fix kit's bounds repair. */
ENTRY(bully_overlay_geometry_reg)
SECTIONS {
  . = 0x09928100;
  .text : { *(.text.bully_overlay_geometry_reg) *(.text*) }
  .rodata : { *(.rodata*) }
  .payload : { *(.data*) *(.bss*) *(COMMON) BYTE(0) }
  /DISCARD/ : { *(.comment) *(.pdr) *(.mdebug*) *(.reginfo) *(.MIPS.abiflags) *(.gnu.attributes) }
}
