/* CodeRabbit generated: track the supported R4 GIF/VIF texture sequence. */
#ifndef BULLY_STREAM_ORDER_H
#define BULLY_STREAM_ORDER_H
#include <stdint.h>
#define BULLY_STREAM_CAPACITY 2048

typedef struct {
 uint64_t bitblt;
 uint32_t addr, bytes, serial, epoch;
} BullyStreamUpload;

typedef struct {
 BullyStreamUpload upload[BULLY_STREAM_CAPACITY];
 uint32_t length, unmasked, search, epoch;
 uint64_t transfer_pos;
 unsigned valid, awaiting;
} BullyStreamOrder;

void bully_stream_begin(BullyStreamOrder *s);
void bully_stream_reg(BullyStreamOrder *s, unsigned reg, uint64_t value);
void bully_stream_upload(BullyStreamOrder *s, uint64_t bitblt,
                         uint32_t addr, uint32_t bytes, uint32_t serial,
                         int accepted);
int bully_stream_unmask(BullyStreamOrder *s);
int bully_stream_select(BullyStreamOrder *s, uint64_t tex0,
                        BullyStreamUpload out[2]);
#endif
