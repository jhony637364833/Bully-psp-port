ENTRY(order_feed)
SECTIONS {
 . = 0x0992c000;
 .text : { *(.text*) }
 .rodata : { *(.rodata*) }
 .data : { *(.data*) *(.bss*) *(COMMON) BYTE(0) }
 /DISCARD/ : { *(.comment) *(.pdr) *(.mdebug*) *(.reginfo) *(.MIPS.abiflags) *(.gnu.attributes) }
}
bully_gif_feed = 0x0975146c;
orig_flush = 0x09758618;
