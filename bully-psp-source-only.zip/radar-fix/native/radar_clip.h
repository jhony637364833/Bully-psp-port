#ifndef BULLY_RADAR_CLIP_H
#define BULLY_RADAR_CLIP_H
#include "overlay_geometry.h"
typedef void (*BullyDraw)(void *, unsigned, const BullyOverlayContext *, const BullyOverlayVertex *, unsigned);
void bully_radar_before_state(void);
void bully_radar_draw(void *, unsigned, const BullyOverlayContext *, const BullyOverlayVertex *, unsigned, BullyDraw);
#endif
