/* CodeRabbit-generated clipping for the observed R4 radar depth mask. */
#include "radar_clip.h"
#define INNER_EDGES 30
#define OUTER_EDGES 24
#define MAX_EDGES (INNER_EDGES + OUTER_EDGES)
#define MAX_VERTICES 64

typedef struct { float x0,y0,x1,y1,sign; } Edge;
static Edge edges[MAX_EDGES];
static BullyOverlayVertex work[2][MAX_VERTICES];
static unsigned inner,outer,valid;
static uint64_t mask_frame;
static float center_x,center_y,first_x,first_y,prev_x,prev_y;

void bully_radar_before_state(void) { /* Ordinary GS state changes do not change the mask. */ }
static void reset(void) {inner=outer=valid=0;}
static int radar_frame(uint64_t frame) {
 return frame==UINT64_C(0xff000000000a008c) || frame==UINT64_C(0xff000000000a0000);
}
static int mask_state(unsigned prim, const BullyOverlayContext *s,
                      const BullyOverlayVertex *v, unsigned n) {
 if (prim != 0x45 || n != 3 || s->alpha != 0x4a || s->test != 0x3140a ||
     !radar_frame(s->frame) || s->zbuf != 0x1000118 ||
     s->scissor != UINT64_C(0x1bf0000027f0000)) return 0;
 for (unsigned i=0;i<n;i++)
  if (v[i].color || (v[i].z != 0 && v[i].z != 16777215.0f) ||
      v[i].z != v[0].z || v[i].x < 510 || v[i].x > 596 ||
      v[i].y < 34 || v[i].y > 115) return 0;
 return 1;
}
static int edge_add(unsigned i,const BullyOverlayVertex *a,const BullyOverlayVertex *b) {
 float d=(b->x-a->x)*(center_y-a->y)-(b->y-a->y)*(center_x-a->x);
 if (d==0) return 0;
 edges[i]=(Edge){a->x,a->y,b->x,b->y,d>0 ? 1.0f : -1.0f};
 return 1;
}
static void mask_collect(const BullyOverlayVertex *v,uint64_t frame) {
 if (v[0].z == 0) {
  if (outer || inner==INNER_EDGES) reset();
  if (!inner) {mask_frame=frame;center_x=v[0].x;center_y=v[0].y;first_x=v[1].x;first_y=v[1].y;}
  else if(frame!=mask_frame || v[0].x!=center_x || v[0].y!=center_y || v[1].x!=prev_x || v[1].y!=prev_y) {reset();return;}
  if (center_x!=553 || center_y!=74.6875f || !edge_add(inner,&v[1],&v[2])) {reset();return;}
  prev_x=v[2].x;prev_y=v[2].y;inner++;
  if (inner==INNER_EDGES && (prev_x!=first_x || prev_y!=first_y)) reset();
 } else {
  if (frame!=mask_frame || inner!=INNER_EDGES || outer>=OUTER_EDGES) {reset();return;}
  static const float x[4]={595,595,511,511},y[4]={113.875f,35.5f,35.5f,113.875f};
  unsigned quadrant=outer/6;
  if (v[0].x!=x[quadrant] || v[0].y!=y[quadrant] ||
      (outer%6 && (v[1].x!=prev_x || v[1].y!=prev_y)) ||
      !edge_add(INNER_EDGES+outer,&v[1],&v[2])) {reset();return;}
  prev_x=v[2].x;prev_y=v[2].y;outer++;
  if (outer==OUTER_EDGES) valid=1;
 }
}
static float distance(const Edge *e,const BullyOverlayVertex *v) {
 return e->sign*((e->x1-e->x0)*(v->y-e->y0)-(e->y1-e->y0)*(v->x-e->x0));
}
static BullyOverlayVertex intersect(BullyOverlayVertex a,BullyOverlayVertex b,float da,float db) {
 float t=da/(da-db);
 a.u += (b.u-a.u)*t; a.v += (b.v-a.v)*t;
 a.x += (b.x-a.x)*t; a.y += (b.y-a.y)*t;
 return a; /* These flat-shaded radar triangles have a single color and Z. */
}
static void clipped(void *o,unsigned prim,const BullyOverlayContext *s,
                    const BullyOverlayVertex *v,BullyDraw draw) {
 unsigned count=3,src=0;
 for(unsigned i=0;i<3;i++)work[0][i]=v[i];
 for(unsigned e=0;e<MAX_EDGES && count;e++) {
  unsigned next=0,dst=src^1; BullyOverlayVertex a=work[src][count-1];float da=distance(&edges[e],&a);
  for(unsigned i=0;i<count;i++) {
   BullyOverlayVertex b=work[src][i];float db=distance(&edges[e],&b);
   if ((da>=0)!=(db>=0)) {
    if(next>=MAX_VERTICES)return;
    work[dst][next++]=intersect(a,b,da,db);
   }
   if(db>=0) {if(next>=MAX_VERTICES)return;work[dst][next++]=b;}
   a=b;da=db;
  }
  src=dst;count=next;
 }
 BullyOverlayContext copy=*s;
 copy.test=(copy.test & ~(UINT64_C(3)<<17)) | (UINT64_C(1)<<17);
 for(unsigned i=1;i+1<count;i++) {
  BullyOverlayVertex tri[3]={work[src][0],work[src][i],work[src][i+1]};
  draw(o,prim,&copy,tri,3);
 }
}
void bully_radar_draw(void *o,unsigned prim,const BullyOverlayContext *s,
                      const BullyOverlayVertex *v,unsigned n,BullyDraw draw) {
 if(mask_state(prim,s,v,n)) {mask_collect(v,s->frame);return;}
 if (prim == 6 && n == 2 && s->test == 0x3140a && s->zbuf == 0x1000118 &&
     (s->frame >> 32) == 0xffffffffu && v[0].x == 0 && v[0].y == 0 &&
     v[1].x == 32 && v[1].y == 448 && v[0].z == 0 && v[1].z == 0) reset();
 else if ((s->test & (1u<<16)) && !(s->zbuf & (UINT64_C(1)<<32))) reset();
 if (valid && prim==0x155 && n==3 && s->test==0x5140b && s->alpha==0x44 &&
     s->zbuf==UINT64_C(0x101000118) && radar_frame(s->frame) &&
     s->frame==mask_frame &&
     s->clamp==5 && v[0].z==65535 && v[1].z==65535 && v[2].z==65535 &&
     v[0].color==v[1].color && v[1].color==v[2].color) {
  for(unsigned i=0;i<3;i++)
   if(v[i].x<511 || v[i].x>595 || v[i].y<35.5f || v[i].y>113.875f) {draw(o,prim,s,v,n);return;}
  clipped(o,prim,s,v,draw);
 } else draw(o,prim,s,v,n);
}
