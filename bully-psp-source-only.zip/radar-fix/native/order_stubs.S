.set noreorder
.globl orig_upload
orig_upload:
.word 0x3c020984
.word 0x8c42fb3c
j 0x09759434
nop
.globl orig_feed
orig_feed:
.word 0x3c020990
.word 0x8c42f6c4
j 0x097596bc
nop
.globl orig_reg
orig_reg:
li $v0,0x50
beq $a1,$v0,reg_50
nop
j 0x0975954c
li $v0,0x53
reg_50:
j 0x097595c8
li $v0,0x53
.globl orig_texture
orig_texture:
.word 0x7c822d00
.word 0x2442ffed
j 0x0975809c
nop
