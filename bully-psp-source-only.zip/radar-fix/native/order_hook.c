/* CodeRabbit generated for the exact supplied R4 executable. */
#include <stdint.h>
#include <stddef.h>
#include "stream_order.h"

typedef struct {uint32_t addr,bytes,serial;} R4Upload;
static R4Upload *const uploads=(R4Upload*)0x098cf6b4;
static BullyStreamOrder stream;
static unsigned last_ch,inside_ch2;
void orig_upload(void *,uint64_t,uint32_t,uint32_t);
void orig_feed(unsigned,const void*,unsigned,uint32_t);
void orig_reg(void *,unsigned,uint64_t);
void *orig_texture(uint64_t);
void orig_flush(void);

void order_upload(void *o,uint64_t b,uint32_t a,uint32_t n){
 unsigned slot=(b>>32)&16383;
 uint32_t old=uploads[slot].serial;
 orig_upload(o,b,a,n);
 if(inside_ch2){
  R4Upload v=uploads[slot];
  bully_stream_upload(&stream,b,a,n,v.serial,
                      v.addr==a && v.bytes==n && v.serial && v.serial!=old);
 }
}
void order_feed(unsigned ch,const void*p,unsigned n,uint32_t addr){
 if(ch==2 && last_ch!=2)bully_stream_begin(&stream);
 last_ch=ch;inside_ch2=(ch==2);
 orig_feed(ch,p,n,addr);
 inside_ch2=0;
}
void order_reg(void *o,unsigned reg,uint64_t value){
 if(inside_ch2)bully_stream_reg(&stream,reg,value);
 orig_reg(o,reg,value);
}
/* A VIF unmask marks the next two transfers in the observed game stream.
 * Flush the previous batch so its texture is resolved at that boundary. */
void replay_pair(void){if(bully_stream_unmask(&stream))orig_flush();}
void *order_texture(uint64_t t){
 BullyStreamUpload pair[2];
 if(!inside_ch2 && bully_stream_select(&stream,t,pair)){
  unsigned pix=t&16383,pal=(t>>37)&16383;
  R4Upload oldp=uploads[pix],oldc=uploads[pal];
  uploads[pix]=(R4Upload){pair[0].addr,pair[0].bytes,pair[0].serial};
  uploads[pal]=(R4Upload){pair[1].addr,pair[1].bytes,pair[1].serial};
  void *result=orig_texture(t);
  uploads[pix]=oldp;uploads[pal]=oldc;
  return result;
 }
 return orig_texture(t);
}
/* The standalone patch does not link the game's C library. */
void *memcpy(void *dst,const void *src,size_t n){
 unsigned char*d=dst;const unsigned char*s=src;
 while(n--)*d++=*s++;
 return dst;
}
