/* CodeRabbit generated. Reject unexpected transfers rather than reuse stale data. */
#include "stream_order.h"

void bully_stream_begin(BullyStreamOrder *s){
 s->length=s->unmasked=s->search=s->epoch=0;
 s->transfer_pos=0;s->valid=1;s->awaiting=0;
}
void bully_stream_reg(BullyStreamOrder *s,unsigned reg,uint64_t value){
 if(reg==0x51)s->transfer_pos=value;
 if(reg==0x50 && s->awaiting)s->valid=0;
 if(reg==0x53){
  if(value || s->transfer_pos || s->awaiting)s->valid=0;
  s->awaiting=1;
 }
 /* Other GIF writes make texture pairs spanning them ineligible. */
 if((reg<0x50 || reg>0x53) && reg!=0x7f)s->epoch++;
}
void bully_stream_upload(BullyStreamOrder *s,uint64_t b,uint32_t a,uint32_t n,uint32_t serial,int accepted){
 if(!s->awaiting || n<80 || !serial || !accepted)s->valid=0;
 s->awaiting=0;
 if(s->length>=BULLY_STREAM_CAPACITY){s->valid=0;return;}
 s->upload[s->length++]=(BullyStreamUpload){b,a,n,serial,s->epoch};
}
int bully_stream_unmask(BullyStreamOrder *s){
 if(!s->valid || s->awaiting || s->unmasked+1>=s->length)return 0;
 s->unmasked+=2;return 1;
}
int bully_stream_select(BullyStreamOrder *s,uint64_t t,BullyStreamUpload out[2]){
 if(!s->valid || s->awaiting || ((t>>20)&63)!=20)return 0;
 unsigned pix=t&16383,pal=(t>>37)&16383;
 if(pix==pal)return 0;
 for(uint32_t i=s->search;i+1<s->unmasked;i+=2){
  BullyStreamUpload a=s->upload[i],b=s->upload[i+1];
  if(b.bytes==176 && a.serial && b.serial && a.epoch==b.epoch &&
     ((a.bitblt>>32)&16383)==pix && ((b.bitblt>>32)&16383)==pal){
   s->search=i+2;out[0]=a;out[1]=b;return 1;
  }
 }
 return 0;
}
