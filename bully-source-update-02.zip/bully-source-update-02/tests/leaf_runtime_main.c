#include "r5900_rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully leaf preservation",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
PSP_HEAP_SIZE_KB(1024);
static void mode(unsigned i){uint32_t f=(1u<<24)|i;__asm__ volatile("ctc1 %0,$31"::"r"(f));}
#else
#include <fenv.h>
static void mode(unsigned i){static const int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(modes[i]);}
#endif
#include "reference.decl"
#include "candidate.decl"
static const struct {void(*ref)(R5900Ctx*);void(*cand)(R5900Ctx*);const char*name;} cases[]={
#include "table.inc"
};
static uint32_t seed=0x629173ab;
static uint32_t rnd(void){seed=seed*1664525u+1013904223u;return seed;}
static uint32_t hash(const void*p,size_t n){uint32_t x=2166136261u;const unsigned char*s=p;while(n--)x=(x^*s++)*16777619u;return x;}
static R5900Ctx a,b,initial;
static unsigned char ram_a[65536] __attribute__((aligned(16))),ram_b[65536] __attribute__((aligned(16)));
static uint32_t state_hash;
static unsigned errors;
static FILE*logfile;
static void error(const char*what,unsigned which,unsigned iter,unsigned rounding){fprintf(logfile,"ERROR %s case=%s iter=%u mode=%u\n",what,cases[which].name,iter,rounding);fflush(logfile);errors++;}
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);logfile=fopen("leaf-test.log","w");
#else
 logfile=stdout;
#endif
 if(!logfile)return 2;
 _Static_assert(_Alignof(R5900Ctx)>=16,"context alignment");
 unsigned total=0;
 for(unsigned rounding=0;rounding<4;rounding++){
  mode(rounding);
  for(unsigned k=0;k<sizeof(cases)/sizeof(cases[0]);k++)for(unsigned it=0;it<1000;it++){
   // Naturally aligned pointer data also exercises arbitrary normal floats,
   // signs, exponents, MMI upper words and wrapped guest address regions.
   memset(&initial,0,sizeof(initial));
   for(unsigned j=0;j<32;j++)for(unsigned lane=0;lane<4;lane++)initial.r[j].w[lane]=(rnd()&0xffff0000u)|(0x1000u+((rnd()%0xe00u)<<4));
   for(unsigned j=0;j<32;j++)initial.fpr[j].u=rnd();
   for(unsigned j=0;j<32;j++)for(unsigned lane=0;lane<4;lane++)initial.vu0.vf[j].w[lane]=rnd();
   for(unsigned j=0;j<32;j++)initial.vu0.vi[j]=rnd();
   for(unsigned j=0;j<4;j++)initial.vu0.acc.w[j]=rnd();
   initial.acc.u=rnd();initial.fcr31=rnd();initial.ram_mask=sizeof(ram_a)-1;initial.r[29].w[0]=0x8000;
   for(unsigned j=0;j<sizeof(ram_a);j+=4){uint32_t v=(rnd()&0xffff0000u)|(0x1000u+((rnd()%0xe00u)<<4));memcpy(ram_a+j,&v,4);}
   memcpy(ram_b,ram_a,sizeof(ram_a));a=initial;b=initial;a.ram=ram_a;b.ram=ram_b;
   cases[k].ref(&a);cases[k].cand(&b);
   // The executable intentionally uses independent memory windows. Normalize
   // only their host addresses before comparing every context and RAM byte.
   a.ram=NULL;b.ram=NULL;
   if(memcmp(&a,&b,sizeof(a)))error("context",k,it,rounding);
   if(memcmp(ram_a,ram_b,sizeof(ram_a)))error("RAM",k,it,rounding);
   for(unsigned j=16;j<=23;j++)if(memcmp(&b.r[j],&initial.r[j],sizeof(R5900Reg128)))error("saved GPR",k,it,rounding);
   if(memcmp(&b.r[30],&initial.r[30],sizeof(R5900Reg128)))error("saved FP",k,it,rounding);
   for(unsigned j=20;j<32;j++)if(b.fpr[j].u!=initial.fpr[j].u)error("saved FPR",k,it,rounding);
   state_hash^=hash(&b,sizeof(b));state_hash^=hash(ram_b,sizeof(ram_b));total++;
   if(errors)goto done;
  }
  fprintf(logfile,"mode=%u comparisons=%u errors=%u hash=%08x\n",rounding,total,errors,(unsigned)state_hash);fflush(logfile);
 }
 done:
 fprintf(logfile,"COMPLETE comparisons=%u errors=%u hash=%08x\n",total,errors,(unsigned)state_hash);fflush(logfile);
#ifdef __PSP__
 fclose(logfile);sceKernelExitGame();
#endif
 return errors?1:0;
}
