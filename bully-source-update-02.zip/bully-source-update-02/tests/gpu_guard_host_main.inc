
static unsigned seed=4242001;
static float randf(void){seed=seed*1664525u+1013904223u;return (seed>>8)*(1.0f/16777216);}
int main(void){
 const int rounding[4]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};
 for(unsigned rm=0;rm<4;rm++){
  assert(!fesetround(rounding[rm]));
  for(unsigned test=0;test<3200;test++){
   BullyNativeVertex v[3],saved[3];uint8_t skip[3]={0,0,0};unsigned kind=test%8;
   memset(v,0,sizeof v);memset(&object_view,0,sizeof object_view);
   for(int k=0;k<3;k++)object_view.view[k][k]=1;
   object_view.near_plane=1;object_view.far_plane=100;material_light=0;
   for(unsigned i=0;i<3;i++){
    float z=5+randf()*40;
    float x=i==0?.15f:i==1?.8f:.45f,y=i==2?.85f:.15f+randf()*.15f;
    if(kind==1 && !i)z=.5f;
    if(kind==2 && !i)z=150;
    if(kind==3 && !i)x=-4;
    if(kind==4 || kind==6 || kind==7){
     unsigned side=(test/8)%4;
     if(side==0)x-=.3f;if(side==1)x+=.3f;if(side==2)y-=.3f;if(side==3)y+=.3f;
    }
    if(kind==6){if(test%16)object_view.near_plane=0.00000001f;else object_view.far_plane=1e30f;}
    v[i].position[0]=x*z;v[i].position[1]=y*z;v[i].position[2]=z;
    for(unsigned k=0;k<3;k++)v[i].color[k]=(unsigned)(randf()*127);
    for(unsigned k=0;k<2;k++)v[i].uv[k]=randf()*2;
   }
   if(kind==5)v[0].position[0]=NAN;
   if(test%11==0)skip[2]=1;
   memcpy(saved,v,sizeof v);recorded=queued=triangles=0;
   draw_skin_batch(v,skip,3,0);flush_vertices();
   assert(!memcmp(v,saved,sizeof v));assert(fegetround()==rounding[rm]);
#ifdef CANDIDATE
   if(recorded && (kind==4 || kind==7)){
    assert(recorded==3);
    for(unsigned i=0;i<3;i++){
     assert(!memcmp(&record[i].x,saved[i].position,12));
     assert(record[i].u==saved[i].uv[0] && record[i].v==saved[i].uv[1]);
     assert(record[i].color==(0xff000000u|saved[i].color[0]*2u|(saved[i].color[1]*2u<<8)|(saved[i].color[2]*2u<<16)));
     double sx=480.0*(double)record[i].x/record[i].z+1808.0,sy=272.0*(double)record[i].y/record[i].z+1912.0;
     assert(sx>0 && sx<4095 && sy>0 && sy<4095);
    }
   }
#endif
   unsigned hdr[4]={rm,test,recorded,triangles};assert(fwrite(hdr,sizeof hdr,1,stdout)==1);
   assert(fwrite(record,sizeof(*record),recorded,stdout)==recorded);
  }
 }
 return 0;
}
