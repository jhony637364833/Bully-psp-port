#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bully_test_dir=$(mktemp -d)
trap 'rm -rf "$bully_test_dir"' EXIT
bully_src=app/games/SLUS-21269_v1.02/src
${CC:-cc} -std=c11 -Wall -Wextra -Werror -O1 -g -fsanitize=address,undefined -I"$bully_src" tests/native_state_test.c "$bully_src/native_state.c" -o "$bully_test_dir/test"
"$bully_test_dir/test"
