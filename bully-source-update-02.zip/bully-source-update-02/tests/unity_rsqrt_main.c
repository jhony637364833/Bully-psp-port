#include "candidate/r5900_rt.h"
#include <stdio.h>
#include <stdlib.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully exact unity rsqrt",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
PSP_HEAP_SIZE_KB(1024);
static void mode(unsigned i){uint32_t f=(1u<<24)|i;__asm__ volatile("ctc1 %0,$31"::"r"(f));}
#else
#include <fenv.h>
static void mode(unsigned i){static const int m[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(m[i]);}
#endif
uint32_t reference_one(uint32_t),candidate_one(uint32_t),reference_generic(uint32_t,uint32_t),candidate_generic(uint32_t,uint32_t);
void reference_normalizer(R5900Ctx*),candidate_normalizer(R5900Ctx*);
static uint32_t seed=0x629173ab;
static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static R5900Ctx a,b,initial;
static unsigned char ra[65536] __attribute__((aligned(16))),rb[65536] __attribute__((aligned(16)));
static const uint32_t mant[]={0,1,2,0x3fffff,0x400000,0x7ffffd,0x7ffffe,0x7fffff};
static unsigned scalars,vectors;
static FILE*f;
static int scalar(uint32_t t){uint32_t x=reference_one(t),y=candidate_one(t),s=rnd();if(x!=y||reference_generic(s,t)!=candidate_generic(s,t)){fprintf(f,"ERROR scalar t=%08x ref=%08x cand=%08x\n",t,x,y);return 1;}scalars++;return 0;}
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);f=fopen("rsqrt-test.log","w");
#else
 f=stdout;
#endif
 if(!f)return 2;
 for(unsigned m=0;m<4;m++){
  mode(m);
  for(unsigned sign=0;sign<2;sign++)for(unsigned e=0;e<256;e++)for(unsigned j=0;j<8;j++)if(scalar((sign<<31)|(e<<23)|mant[j]))goto fail;
  for(unsigned i=0;i<1000000;i++)if(scalar(rnd()))goto fail;
  for(unsigned i=0;i<10000;i++){
   unsigned char*q=(void*)&initial;for(unsigned j=0;j<sizeof(initial);j++)q[j]=(unsigned char)rnd();
   for(unsigned j=0;j<sizeof(ra);j++)ra[j]=(unsigned char)(j*37+i);
   uint32_t base=(rnd()&0xffff0000u)|((rnd()%16382u)*4u);
   for(unsigned j=0;j<3;j++){uint32_t t=i<4096?(((i>>11)<<31)|(((i>>3)&255)<<23)|mant[i&7]):rnd();memcpy(ra+((base+4*j)&65535),&t,4);}
   initial.r[4].d[0]=(uint64_t)(int64_t)(int32_t)base;initial.ram_mask=65535;
   memcpy(rb,ra,sizeof(ra));a=initial;b=initial;a.ram=ra;b.ram=rb;
   reference_normalizer(&a);candidate_normalizer(&b);a.ram=NULL;b.ram=NULL;
   if(memcmp(&a,&b,sizeof(a))||memcmp(ra,rb,sizeof(ra))){fprintf(f,"ERROR vector mode=%u i=%u\n",m,i);goto fail;}
   vectors++;
  }
  fprintf(f,"mode=%u scalars=%u vectors=%u errors=0\n",m,scalars,vectors);fflush(f);
 }
 fprintf(f,"COMPLETE scalars=%u vectors=%u errors=0\n",scalars,vectors);fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
 fail:fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 1;
}
