/* Bounded static-geometry path. Native textures and vertex colors, bounded CPU skinning.
 * GPU screen-edge clipping inside a conservative guard band; CPU clipping
 * handles near/far crossings and large geometry. GPU perspective-correct UVs.
 * Unsupported objects retain guest execution and are counted, never fabricated.
 * Small synchronous lists keep geometry memory bounded on the 64MB target.
 */
#include "hle.h"
#include "native_object.h"
#include "native_skin.h"
#include "native_light.h"
#include "native_state.h"
#include "native_texture.h"
#include "native_texture_alpha.h"
#include "world_clip.h"
#include "clip_memo.h"
#include "native_memory.h"
#include "world_projection.h"
#include <pspgu.h>
#include <pspge.h>
#include <pspdisplay.h>
#include <pspkernel.h>
#include <math.h>

extern int hle_ge_on;
static int enabled, active,clear_pending,underlay_active;
#define OVERLAY_FB (512u*272u*4u)
#define OVERLAY_DEPTH (512u*272u*2u)
#define OVERLAY_BG (2u*OVERLAY_FB+OVERLAY_DEPTH)
static unsigned overlay_draw_offset;
static int overlay_background,overlay_world_new,overlay_started,overlay_defer_world;
void bully_overlay_flush(void);


static uint64_t frame;
static uint32_t scene_camera;
/* Completed camera throughput, measured in wall time. Multiple cameras may
 * belong to one gameplay frame, so this is deliberately not an FPS counter. */
static uint32_t perf_camera;
static uint64_t camera_start_us,perf_start_us,perf_camera_us,perf_max_us;
static unsigned perf_passes;
static unsigned objects, triangles, rejected, reports, skinned_objects;
static unsigned list[4096] __attribute__((aligned(16)));
static void copy_background(unsigned from,unsigned to) {
    sceGuStart(GU_DIRECT,list);
    sceGuCopyImage(GU_PSM_8888,0,0,480,272,512,(void *)(uintptr_t)(0x04000000u+from),
                   0,0,512,(void *)(uintptr_t)(0x04000000u+to));
    sceGuFinish();sceGuSync(0,0);
}
typedef struct { float u,v; unsigned color; float x,y,z; } GeVertex;
#define WORLD_BATCH_VERTICES 384
/* SDK 20261001: each non-indexed draw emits 4 words, each alpha/depth
 * update 1. Two ordered draws plus four updates = 12 words/triangle.
 * Reserve 16 plus 64 words for list setup/termination. */
_Static_assert((WORLD_BATCH_VERTICES/3)*16+64 <= sizeof(list)/sizeof(*list),
               "world command list must hold the worst-case ordered batch");
static unsigned queued, draw_calls;
static int gpu_vertex_space,gpu_model_active;
static GeVertex verts[WORLD_BATCH_VERTICES] __attribute__((aligned(16)));
/* Allocate after the movie, from the runtime arena. Keep the boot reserve. */
static BullyNativeVertex *mesh;
static BullyNativeSkinCache *skin_cache;
static int skin_cache_attempted;
/* Optional storage must not use hle_plat_big_alloc: that allocator exits on
 * failure. Allocate once, after the first valid skin object, leaving 1 MiB of
 * user memory free. The current object and all failures retain normal decode. */
static void allocate_skin_cache(void) {
    if(skin_cache_attempted)return;
    skin_cache_attempted=1;
    unsigned bytes=(unsigned)sizeof(*skin_cache);
    if(sceKernelTotalFreeMemSize()<bytes+1024u*1024u ||
       sceKernelMaxFreeMemSize()<bytes) {
        LOG("WORLD: optional skin cache unavailable; normal decode\n");return;
    }
    SceUID id=sceKernelAllocPartitionMemory(2,"world_skin",PSP_SMEM_High,bytes,0);
    if(id<0) {LOG("WORLD: optional skin cache allocation failed; normal decode\n");return;}
    skin_cache=sceKernelGetBlockHeadAddr(id);
    if(!skin_cache) {sceKernelFreePartitionMemory(id);return;}
    skin_cache->complete=0;
    LOG("WORLD: optional skin cache %u bytes; remaining user memory %u bytes\n",
        bytes,(unsigned)sceKernelTotalFreeMemSize());
}
/* Optional persistent intersections: 640 KiB, never required for rendering.
 * Keep one MiB free for other runtime needs and preserve normal clipping when
 * partition allocation is unavailable. Moving cameras bypass the memo. */
#define WORLD_CLIP_MEMO_SETS 2048
/* The existing overlay arena may initialize later. Its allocation must still
 * leave its own one-MiB reserve, even on a fragmented PSP memory partition. */
#define WORLD_CLIP_MEMORY_RESERVE (1024u*1024u+BULLY_OVERLAY_ARENA_BYTES)
static BullyClipMemo clip_memo;
static BullyClipMemoSet *clip_memo_storage;
static int clip_memo_attempted,clip_memo_enabled;
static uint32_t clip_camera,clip_camera_key[18];
static unsigned clip_camera_stable;
static __attribute__((noinline)) uint32_t clip_fpu_read(void) {
    uint32_t x;__asm__ volatile("cfc1 %0,$31":"=r"(x)::"memory");return x;
}
static __attribute__((noinline)) void clip_fpu_write(uint32_t x) {
    __asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(x):"memory");
}
static void allocate_clip_memo(void) {
    if(clip_memo_attempted)return;
    clip_memo_attempted=1;
    unsigned bytes=WORLD_CLIP_MEMO_SETS*(unsigned)sizeof(*clip_memo_storage);
    if(sceKernelTotalFreeMemSize()<bytes+WORLD_CLIP_MEMORY_RESERVE || sceKernelMaxFreeMemSize()<bytes) {
        LOG("WORLD: optional clip memo unavailable; normal clipping\n");return;
    }
    SceUID id=sceKernelAllocPartitionMemory(2,"world_clip",PSP_SMEM_High,bytes,0);
    if(id<0){LOG("WORLD: optional clip memo allocation failed; normal clipping\n");return;}
    clip_memo_storage=sceKernelGetBlockHeadAddr(id);
    if(!clip_memo_storage || sceKernelTotalFreeMemSize()<WORLD_CLIP_MEMORY_RESERVE ||
       sceKernelMaxFreeMemSize()<BULLY_OVERLAY_ARENA_BYTES) {
        sceKernelFreePartitionMemory(id);clip_memo_storage=0;return;
    }
    if(!bully_clip_memo_init(&clip_memo,clip_memo_storage,WORLD_CLIP_MEMO_SETS,
                            clip_fpu_read,clip_fpu_write,0x00020f80u)) {
        sceKernelFreePartitionMemory(id);clip_memo_storage=0;return;
    }
    LOG("WORLD: optional clip memo %u bytes; remaining user memory %u bytes\n",
        bytes,(unsigned)sceKernelTotalFreeMemSize());
}
static void clip_camera_begin(uint32_t camera) {
    clip_memo_enabled=0;
    if(!hle_ram || hle_ram_end<136 || camera<4 || (camera&3) || camera>hle_ram_end-136) {
        clip_camera=clip_camera_stable=0;bully_clip_memo_reset(&clip_memo);return;
    }
    uint32_t key[18];memcpy(key,hle_ram+camera+32,64);memcpy(key+16,hle_ram+camera+128,8);
    if(camera==clip_camera && !memcmp(key,clip_camera_key,sizeof(key))) {
        if(clip_camera_stable<3)clip_camera_stable++;
    } else {
        clip_camera=camera;memcpy(clip_camera_key,key,sizeof(key));clip_camera_stable=0;
        bully_clip_memo_reset(&clip_memo);
    }
    clip_memo_enabled=clip_camera_stable>=3;
}
static BullyNativeObject object_view;
#define WORLD_TEXTURE_BYTES 65536
static uint8_t *texels;
static BullyNativeTexture texture;
static unsigned textured, texture_misses, texture_reports;
static int has_texture;
static unsigned texture_alpha_minimum,texture_alpha_minimum_valid;
static BullyNativeLight lights[BULLY_NATIVE_MAX_MESHES];
static unsigned light_count, lit_meshes;
static int collecting_lights;
static const BullyNativeLight *material_light;
static BullyNativeState states[BULLY_NATIVE_MAX_MESHES];
static unsigned state_count;
static const BullyNativeState *material_state;
static BullyNativeState float_sky_state;
static uint32_t float_sky_object;
void bully_world_capture_float_state(uint32_t object,uint32_t gp) {
    float_sky_object=0;
    if(bully_native_state_shadow(hle_ram,hle_ram_end,gp,&float_sky_state) &&
       float_sky_state.zmask && (float_sky_state.test&0x3000)==0x1000)
        float_sky_object=object;
}
/* The observed float sky atomics have constant material/depth behavior across
 * these three textures. Their original object setup supplies the GS state.
 * Keep all other float/skin pipelines on their existing adapter path. */
static int float_sky_material(uint32_t material) {
    if(!hle_ram || hle_ram_end<84 || material<4 || (material&3) || material>hle_ram_end-4)return 0;
    uint32_t tex=gw(material);
    if(tex<4 || (tex&3) || tex>hle_ram_end-84)return 0;
    const unsigned char *name=hle_ram+tex+16;
    return !memcmp(name,"SKY_high",9) || !memcmp(name,"SKY_tile",9) || !memcmp(name,"SKY_bot",8);
}
static const int alpha_functions[8]={GU_NEVER,GU_ALWAYS,GU_LESS,GU_LEQUAL,
                                    GU_EQUAL,GU_GEQUAL,GU_GREATER,GU_NOTEQUAL};
static const unsigned inverse_alpha[8]={1,0,5,6,7,2,3,4};
static unsigned alpha_reference(const BullyNativeState *s) {
    unsigned a=(s->test>>4)&255;return a<128?a*2:255;
}
static void apply_state(void) {
    const BullyNativeState *s=material_state;
    if(!s) {
        sceGuDisable(GU_BLEND);sceGuDepthMask(GU_FALSE);
        sceGuEnable(GU_DEPTH_TEST);sceGuDepthFunc(GU_LEQUAL);
        if(has_texture){sceGuEnable(GU_ALPHA_TEST);sceGuAlphaFunc(GU_GREATER,0,255);}
        else sceGuDisable(GU_ALPHA_TEST);
        return;
    }
    if(s->blend) {
        sceGuEnable(GU_BLEND);
        /* GS (Cs-0)*FIX/128 + Cd, FIX=128: additive, including destination. */
        if(s->alpha==0x68)sceGuBlendFunc(GU_ADD,GU_FIX,GU_FIX,0xffffff,0xffffff);
        else sceGuBlendFunc(GU_ADD,GU_SRC_ALPHA,s->alpha==0x44?GU_ONE_MINUS_SRC_ALPHA:GU_FIX,0,0);
    } else sceGuDisable(GU_BLEND);
    sceGuDepthMask(s->zmask?GU_TRUE:GU_FALSE);
    if(s->test&(1u<<16)) {
        static const int depth[4]={GU_NEVER,GU_ALWAYS,GU_LEQUAL,GU_LESS};
        sceGuEnable(GU_DEPTH_TEST);sceGuDepthFunc(depth[(s->test>>17)&3]);
    } else sceGuDisable(GU_DEPTH_TEST);
    if((s->test&1) && !(s->zmask && ((s->test>>12)&3)==1)) {
        sceGuEnable(GU_ALPHA_TEST);
        sceGuAlphaFunc(alpha_functions[(s->test>>1)&7],alpha_reference(s),255);
    } else sceGuDisable(GU_ALPHA_TEST);
}
/* With Z already masked, both AFAIL=FB_ONLY branches do exactly the same
 * work. With constant opaque alpha and a passing comparison, no fail branch
 * can run. Keep the ordered two-pass path for genuinely mixed fragments. */
static int needs_alpha_fail_pass(void) {
    const BullyNativeState *s=material_state;
    if(!s || !(s->test&1) || ((s->test>>12)&3)!=1 || s->zmask)return 0;
    unsigned fn=(s->test>>1)&7;
    if(fn==1)return 0;
    if(fn!=5 && fn!=6 && fn!=7)return 1;
    unsigned minimum=255,reference=alpha_reference(s);
    for(unsigned i=0;i<queued;i++) {
        unsigned alpha=verts[i].color>>24;
        if(alpha<minimum)minimum=alpha;
    }
    unsigned lower=minimum;
    if(has_texture && texture.texture.alpha_class!=TC_ALPHA_OPAQUE) {
        if(!texture_alpha_minimum_valid) {
            texture_alpha_minimum=bully_texture_alpha_minimum(&texture,texels,WORLD_TEXTURE_BYTES);
            texture_alpha_minimum_valid=1;
        }
        /* Opaque modulation preserves vertex alpha. Otherwise divide by256
         * for a conservative lower bound under either normalized convention. */
        if(texture_alpha_minimum!=255)lower=(minimum*texture_alpha_minimum)>>8;
    }
    if((fn==5 && lower>=reference) ||
       ((fn==6 || fn==7) && lower>reference))return 0;
    return 1;
}
/* Texture alpha modulation cannot increase the vertex alpha bound. Only
 * these comparisons are certified; unknown/mixed batches keep ordered draws. */
static int all_alpha_fail(void) {
    const BullyNativeState *s=material_state;
    if(!s || !(s->test&1) || ((s->test>>12)&3)!=1 || s->zmask || !queued)return 0;
    unsigned fn=(s->test>>1)&7;
    if(fn==0)return 1;
    if(fn!=5 && fn!=6)return 0;
    unsigned maximum=0,reference=alpha_reference(s);
    for(unsigned i=0;i<queued;i++) {
        unsigned alpha=verts[i].color>>24;
        if(alpha>maximum)maximum=alpha;
    }
    return fn==5 ? maximum<reference : maximum<=reference;
}
void bully_world_begin(void) { light_count=state_count=0;collecting_lights=1; }
void bully_world_capture_state(uint32_t pipe,uint32_t gp) {
    if(collecting_lights && state_count<BULLY_NATIVE_MAX_MESHES &&
       bully_native_state(hle_ram,hle_ram_end,pipe,gp,&states[state_count]))state_count++;
}
void bully_world_capture_light(uint32_t pipe,uint32_t gp) {
    if(collecting_lights && light_count<BULLY_NATIVE_MAX_MESHES &&
       bully_native_light(hle_ram,hle_ram_end,pipe,gp,&lights[light_count]))light_count++;
}


void bully_world_enable(void) { enabled=1; }
void bully_world_shutdown(void) {
    bully_overlay_flush();
    enabled=0;scene_camera=0;collecting_lights=0;gpu_vertex_space=gpu_model_active=0;
    clip_camera=clip_camera_stable=0;clip_memo_enabled=0;bully_clip_memo_reset(&clip_memo);
    overlay_background=overlay_world_new=overlay_started=overlay_defer_world=0;
    if(!active)return;
    sceGuSync(0,0);sceGuDisplay(GU_FALSE);sceGuTerm();
    active=0;hle_ge_on=0;
}
/* Keep projection/material commands in the first geometry list. CPU-only
 * preparation may run while the list is open; it never mutates a texture or
 * submitted vertex buffer. Every flush still waits before buffer reuse, and
 * the mesh boundary also finishes empty/fully rejected strips. */
static int command_open;
static void start(void) {
    if(!command_open){sceGuStart(GU_DIRECT,list);command_open=1;}
}
static void finish(void) {
    if(command_open){sceGuFinish();sceGuSync(0,0);command_open=0;}
}
/* All queued vertices share material state. Complete GPU reads before reusing
 * the bounded buffer or converting the next texture. Preserve triangle order. */
/* Queued vertices have one coordinate space. Model state is restored at the
 * object boundary so overlays and other GU users retain the original contract. */
static void select_vertex_space(void) {
    if(gpu_vertex_space && !gpu_model_active) {
        ScePspFMatrix4 model;float m[16]={0};
        for(unsigned r=0;r<4;r++)for(unsigned k=0;k<3;k++)m[r*4+k]=object_view.view[r][k];
        m[15]=1;memcpy(&model,m,sizeof(model));sceGuSetMatrix(GU_MODEL,&model);gpu_model_active=1;
    } else if(!gpu_vertex_space && gpu_model_active) {
        const ScePspFMatrix4 identity={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
        sceGuSetMatrix(GU_MODEL,&identity);gpu_model_active=0;
    }
}
static void flush_vertices(void) {
    if(!queued)return;
    sceKernelDcacheWritebackRange(verts,queued*sizeof(*verts));start();select_vertex_space();
    unsigned type=GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D;
    if(all_alpha_fail()) {
        sceGuAlphaFunc(alpha_functions[inverse_alpha[(material_state->test>>1)&7]],alpha_reference(material_state),255);
        sceGuDepthMask(GU_TRUE);
        sceGuDrawArray(GU_TRIANGLES,type,queued,0,verts);draw_calls++;
        sceGuAlphaFunc(alpha_functions[(material_state->test>>1)&7],alpha_reference(material_state),255);
        sceGuDepthMask(material_state->zmask?GU_TRUE:GU_FALSE);
    } else if(needs_alpha_fail_pass()) {
        /* Preserve primitive order for AFAIL=FB_ONLY, including overlapping
         * triangles: pass writes Z, fail writes only color. The entire
         * bounded vertex batch fits the command list; wait only before reuse. */
        for(unsigned i=0;i<queued;i+=3) {
            sceGuDrawArray(GU_TRIANGLES,type,3,0,verts+i);
            sceGuAlphaFunc(alpha_functions[inverse_alpha[(material_state->test>>1)&7]],alpha_reference(material_state),255);
            sceGuDepthMask(GU_TRUE);
            sceGuDrawArray(GU_TRIANGLES,type,3,0,verts+i);
            sceGuAlphaFunc(alpha_functions[(material_state->test>>1)&7],alpha_reference(material_state),255);
            sceGuDepthMask(material_state->zmask?GU_TRUE:GU_FALSE);
            draw_calls+=2;
        }
    } else {
        sceGuDrawArray(GU_TRIANGLES,type,queued,0,verts);draw_calls++;
    }
    finish();queued=0;
}
static int init(void) {
    const unsigned fb=512*272*4,depth=512*272*2;
    if(hle_ge_on || sceGeEdramGetSize()<3*fb+depth) return 0;
    if(sceGuInit()<0)return 0;
    start();
    sceGuDrawBuffer(GU_PSM_8888,(void *)0,512);
    sceGuDispBuffer(480,272,(void *)(uintptr_t)fb,512);
    sceGuDepthBuffer((void *)(uintptr_t)(2*fb),512);
    sceGuOffset(2048-240,2048-136);sceGuViewport(2048,2048,480,272);
    sceGuScissor(0,0,480,272);sceGuEnable(GU_SCISSOR_TEST);
    sceGuDepthRange(0,65535);sceGuDepthFunc(GU_LEQUAL);sceGuDepthMask(GU_FALSE);
    sceGuEnable(GU_DEPTH_TEST);sceGuDisable(GU_TEXTURE_2D);sceGuDisable(GU_CULL_FACE);
    sceGuDisable(GU_BLEND);sceGuDisable(GU_LIGHTING);sceGuDisable(GU_ALPHA_TEST);
    const ScePspFMatrix4 identity={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
    sceGuSetMatrix(GU_MODEL,&identity);sceGuSetMatrix(GU_VIEW,&identity);
    sceGuEnable(GU_CLIP_PLANES);
    sceGuShadeModel(GU_SMOOTH);sceGuClearColor(0xff101010);sceGuClearDepth(65535);
    sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);finish();
    if(sceDisplaySetMode(0,480,272)<0) { sceGuTerm();return 0; }
    sceGuDisplay(GU_TRUE);
    active=1;hle_ge_on=1;frame=hle_frame;gpu_vertex_space=gpu_model_active=0;
    overlay_draw_offset=0;overlay_background=overlay_world_new=overlay_started=overlay_defer_world=0;
    LOG("WORLD: live static geometry with native textures enabled\n");return 1;
}
/* The guest submits the preceding camera's HUD DMA before starting its
 * next camera. Present that completed composition before its buffer is
 * cleared. A world-only guest flip then retains the new camera for the next
 * HUD; pause/UI-only updates continue to present at the guest flip. */
static void present_composition(void) {
    overlay_draw_offset=(unsigned)(uintptr_t)sceGuSwapBuffers();
    overlay_world_new=overlay_started=0;
}
/* A virtual vblank can occur in the middle of rendering one camera. Only
 * the guest camera update boundary owns clearing/presentation of this scene. */
void bully_world_camera_begin(uint32_t camera) {
    bully_overlay_flush();
    if(!scene_camera && overlay_started) {
        present_composition();overlay_defer_world=1;
    }
    scene_camera=camera;
    camera_start_us=sceKernelGetSystemTimeWide();
    clip_camera_begin(camera);
    if(perf_camera!=camera || !perf_start_us) {
        perf_camera=camera;perf_start_us=camera_start_us;
        perf_camera_us=perf_max_us=0;perf_passes=0;
    }
    objects=triangles=rejected=textured=texture_misses=skinned_objects=draw_calls=lit_meshes=0;
    underlay_active=0;
    clear_pending=1; /* A paused UI camera contains no native world objects. */
}
void bully_world_camera_end(uint32_t camera) {
    if(!scene_camera || camera!=scene_camera)return;
    void bully_overlay_underlay_flush(void);
    bully_overlay_underlay_flush();
    scene_camera=0;
    collecting_lights=0;
    if(!active || (!objects && !underlay_active))return;
    copy_background(overlay_draw_offset,OVERLAY_BG);
    overlay_background=overlay_world_new=1;
    uint64_t now=sceKernelGetSystemTimeWide(),elapsed=now-camera_start_us;
    perf_camera_us+=elapsed;perf_passes++;
    if(elapsed>perf_max_us)perf_max_us=elapsed;
    if(now-perf_start_us>=5000000ull) {
        LOG("WORLD_PERF: camera=%08x passes=%u wall_us=%llu camera_us=%llu max_camera_us=%llu\n",
            camera,perf_passes,(unsigned long long)(now-perf_start_us),
            (unsigned long long)perf_camera_us,(unsigned long long)perf_max_us);
        if(clip_memo_storage)LOG("WORLD_CLIP_MEMO: hits=%u misses=%u bypasses=%u admissions=%u stable=%u epoch=%u\n",
            clip_memo.hits,clip_memo.misses,clip_memo.bypasses,clip_memo.admissions,clip_camera_stable,(unsigned)clip_memo.epoch);
        perf_start_us=now;perf_camera_us=perf_max_us=0;perf_passes=0;
    }
    frame=hle_frame;
    if(reports++<8 || !(reports%120))LOG("WORLD_COMPLETE: camera=%08x frame=%u objects=%u triangles=%u rejected=%u textured_meshes=%u texture_misses=%u skinned_objects=%u draw_calls=%u lit_meshes=%u\n",camera,(unsigned)frame,objects,triangles,rejected,textured,texture_misses,skinned_objects,draw_calls,lit_meshes);
}
static void bind_material(uint32_t material) {
    texture_alpha_minimum_valid=0;
    has_texture=bully_native_texture(hle_ram,hle_ram_end,material,texels,WORLD_TEXTURE_BYTES,&texture);
    start();
    if(!has_texture) {
        sceGuDisable(GU_TEXTURE_2D);sceGuDisable(GU_ALPHA_TEST);
        texture_misses++;apply_state();return;
    }
    TcPspTex *p=&texture.texture;
    sceKernelDcacheWritebackRange(texels,p->total_bytes);
    sceGuTexMode(p->psm,0,0,p->swizzled);
    sceGuTexImage(0,p->level[0].width,p->level[0].height,p->level[0].bufw,texels+p->level[0].offset);
    if(p->clut_entries) {
        sceGuClutMode(p->clut_psm,0,p->clut_entries-1,0);
        sceGuClutLoad(p->clut_bytes/32,texels+p->clut_offset);
    }
    sceGuTexFlush();
    sceGuTexFunc(GU_TFX_MODULATE,GU_TCC_RGBA);
    int filter=texture.filter==1?GU_NEAREST:GU_LINEAR;
    sceGuTexFilter(filter,filter);
    sceGuTexWrap(texture.wrap_u==3?GU_CLAMP:GU_REPEAT,texture.wrap_v==3?GU_CLAMP:GU_REPEAT);
    sceGuTexScale(1,1);sceGuTexOffset(0,0);
    sceGuEnable(GU_TEXTURE_2D);
    sceGuAlphaFunc(GU_GREATER,0,255);sceGuEnable(GU_ALPHA_TEST);
    apply_state();textured++;
    if(texture_reports++<3)LOG("WORLD: texture material=%08x size=%ux%u bytes=%u\n",material,p->level[0].width,p->level[0].height,p->total_bytes);
}
static unsigned channel(float f) { return f<=0?0:f>=255?255:(unsigned)f; }
/* Positive screen coordinates need only the upper clamp. Retain the original
 * library path for zero, negative, NaN and flushed subnormal comparisons. */
static inline float screen_clamp(float value,float maximum) {
    if(value>0.0f)return value<maximum?value:maximum;
    return fminf(maximum,fmaxf(0.0f,value));
}

/* A strip shares two vertices with its next triangle. Transform and shade
 * each decoded vertex once; a three-entry stack ring also handles skin skips. */
static void prepare_vertex(const BullyNativeVertex *src,BullyClipVertex *out) {
    for(int k=0;k<3;k++) {
        float p=object_view.view[3][k];
        for(int j=0;j<3;j++)p+=src->position[j]*object_view.view[j][k];
        out->p[k]=p;out->color[k]=src->color[k]*2.0f;
    }
    out->alpha=255;
    if(material_light) {
        bully_light_color(src,material_light,out->color);
        out->alpha=bully_light_alpha(src,material_light);
    }
    for(int k=0;k<2;k++)out->uv[k]=src->uv[k];
}
static void triangle(const BullyClipVertex *a,const BullyClipVertex *b,const BullyClipVertex *c,BullyClipCache *cache,const int codes[3]) {
    BullyClipVertex in[3]={*a,*b,*c},out[10];
    BullyClipMemo *memo=clip_memo_enabled && clip_memo_storage && !object_view.bones ? &clip_memo:0;
    int n=bully_clip_triangle_classified(in,object_view.near_plane,object_view.far_plane,codes,out,cache,memo);
    if(!n)return;
    /* A clipped polygon is triangulated as a fan. Prepare each polygon
     * vertex once, keeping screen coordinates separate from GE positions.
     * All UV validation still finishes before any triangle is submitted. */
    GeVertex projected[10],clipped[24];
    float screen_x[10],screen_y[10];
    for(int j=0;j<n;j++) {
        const BullyClipVertex *v=&out[j];
        projected[j].u=v->uv[0];projected[j].v=v->uv[1];
        if(!isfinite(projected[j].u) || !isfinite(projected[j].v))return;
        screen_x[j]=screen_clamp(480*v->p[0]/v->p[2],480);
        screen_y[j]=screen_clamp(272*v->p[1]/v->p[2],272);
        projected[j].color=(channel(v->alpha)<<24)|channel(v->color[0])|(channel(v->color[1])<<8)|(channel(v->color[2])<<16);
        projected[j].x=v->p[0];projected[j].y=v->p[1];projected[j].z=v->p[2];
    }
    int count=0;
    for(int i=1;i<n-1;i++) {
        float area=(screen_x[i]-screen_x[0])*(screen_y[i+1]-screen_y[0])-
                   (screen_x[i+1]-screen_x[0])*(screen_y[i]-screen_y[0]);
        if(fabsf(area)<0.001f)continue;
        clipped[count++]=projected[0];
        clipped[count++]=projected[i];
        clipped[count++]=projected[i+1];
    }
    if(!count)return;
    if(queued+(unsigned)count>WORLD_BATCH_VERTICES)flush_vertices();
    for(int i=0;i<count;i++)verts[queued++]=clipped[i];
    triangles+=count/3;
}
/* Visibility and projection belong to each shared vertex. Safe screen-edge
 * crossings use GE interpolation; near/far and guard-band crossings retain
 * the reference CPU clipper. Edge color/UV rounding may differ from software. */
typedef struct {
    BullyClipVertex vertex;
    GeVertex draw;
    float screen_x,screen_y;
    int code,guard_safe;
} PreparedVertex;
static void prepare_cached(const BullyNativeVertex *src,PreparedVertex *out) {
    prepare_vertex(src,&out->vertex);
    out->code=bully_clip_vertex_code(&out->vertex,object_view.near_plane,object_view.far_plane);
    out->guard_safe=0;
    if(out->code<0 || (out->code&3))return;
    const BullyClipVertex *v=&out->vertex;
    if(!out->code) {
        out->screen_x=screen_clamp(480*v->p[0]/v->p[2],480);
        out->screen_y=screen_clamp(272*v->p[1]/v->p[2],272);
        out->guard_safe=1;
    } else {
        /* GE's 12-bit screen coordinates include the viewport offset.
         * Keep a wide margin from both hardware limits; unusual geometry
         * retains the original six-plane double-precision CPU clipper. */
        out->screen_x=480*v->p[0]/v->p[2];
        out->screen_y=272*v->p[1]/v->p[2];
        out->guard_safe=out->screen_x>=-480 && out->screen_x<=960 &&
                        out->screen_y>=-272 && out->screen_y<=544;
    }
    out->draw.u=v->uv[0];out->draw.v=v->uv[1];
    out->draw.color=(channel(v->alpha)<<24)|channel(v->color[0])|(channel(v->color[1])<<8)|(channel(v->color[2])<<16);
    out->draw.x=v->p[0];out->draw.y=v->p[1];out->draw.z=v->p[2];
}
static void triangle_cached(const PreparedVertex *a,const PreparedVertex *b,const PreparedVertex *c,BullyClipCache *cache) {
    if(a->code<0 || b->code<0 || c->code<0)return;
    if(a->code & b->code & c->code)return;
    if((a->code | b->code | c->code) && !(a->guard_safe && b->guard_safe && c->guard_safe &&
        object_view.near_plane>=0.0001f && object_view.far_plane<=65536.0f)) {
        int codes[3]={a->code,b->code,c->code};
        triangle(&a->vertex,&b->vertex,&c->vertex,cache,codes);return;
    }
    float area=(b->screen_x-a->screen_x)*(c->screen_y-a->screen_y)-
               (b->screen_y-a->screen_y)*(c->screen_x-a->screen_x);
    if(fabsf(area)<0.001f)return;
    if(queued+3>WORLD_BATCH_VERTICES)flush_vertices();
    verts[queued++]=a->draw;verts[queued++]=b->draw;verts[queued++]=c->draw;
    triangles++;
}
/* Compare consumed input words without a library call in the vertex loop.
 * memcpy keeps integer bit comparisons valid under strict aliasing. */
static inline int same_vertex_inputs(const BullyNativeVertex *a,const BullyNativeVertex *b) {
    _Static_assert(offsetof(BullyNativeVertex,normal)==28,"vertex input layout");
    for(unsigned k=0;k<7;k++) {
        uint32_t x,y;
        memcpy(&x,(const uint8_t *)a+k*4,4);
        memcpy(&y,(const uint8_t *)b+k*4,4);
        if(x!=y)return 0;
    }
    return 1;
}
static void draw_strip(const BullyNativeVertex *v,const uint8_t *skip,size_t n) {
    PreparedVertex ring[3];BullyClipCache cache;bully_clip_cache_reset(&cache);
    PreparedVertex *a=&ring[1],*b=&ring[2],*current=&ring[0];
    int previous_same=0;
    uint32_t saved_before=0,saved_after=0;
    for(size_t i=0;i<n;i++) {
        /* Strip inputs and material/view state stay immutable during this
         * synchronous draw. Normals/padding are not consumed by preparation.
         * Look ahead so unique vertices pay no FPU-state save/restore cost. */
        int next_same=i+1<n && same_vertex_inputs(&v[i],&v[i+1]);
        uint32_t before=0,after=0;
        if(previous_same || next_same)before=clip_fpu_read();
        if(previous_same && before==saved_before && !(before&0x00020f80u)) {
            current->vertex=b->vertex;current->code=b->code;
            current->guard_safe=b->guard_safe;
            /* Near/far and invalid inputs leave these fields untouched in
             * prepare_cached. Preserve the destination ring's unused bytes. */
            if(b->code>=0 && !(b->code&3)) {
                current->draw=b->draw;
                current->screen_x=b->screen_x;current->screen_y=b->screen_y;
            }
            clip_fpu_write(saved_after);after=saved_after;
        } else {
            prepare_cached(&v[i],current);
            if(next_same)after=clip_fpu_read();
        }
        previous_same=next_same && !(before&0x00020f80u);
        saved_before=before;saved_after=after;
        if(i>=2 && (!skip || !skip[i]))triangle_cached(a,b,current,&cache);
        PreparedVertex *next=a;a=b;b=current;current=next;
    }
}
static void draw_batch(const BullyNativeVertex *v,size_t n,void *context) {
    (void)context;draw_strip(v,0,n);
}
static void draw_skin_batch(const BullyNativeVertex *v,const uint8_t *skip,size_t n,void *context) {
    (void)context;draw_strip(v,skip,n);
}
/* GPU strip dispatch. CPU helpers above retain their exact baseline contract. */
/* Experimental: private strip path. Bounds use a padded camera-space box;
 * the GU transforms boxes within the existing [-1,2] screen guard range.
 * The existing CPU path handles all uncertain/crossing cases. */
static int gpu_strip_bounds(const BullyNativeVertex *v,size_t n) {
    float lo[3],hi[3],clo[3]={0},chi[3]={0},error[3];
    for(unsigned k=0;k<3;k++)lo[k]=hi[k]=v[0].position[k];
    for(size_t i=0;i<n;i++)for(unsigned k=0;k<3;k++) {
        float x=v[i].position[k];if(!isfinite(x))return 0;
        if(x<lo[k])lo[k]=x;
        if(x>hi[k])hi[k]=x;
    }
    if(!isfinite(object_view.near_plane) || !isfinite(object_view.far_plane) ||
       object_view.near_plane<=0 || object_view.far_plane<=object_view.near_plane)return 0;
    for(unsigned k=0;k<3;k++) {
        float magnitude=fabsf(object_view.view[3][k]);
        for(unsigned j=0;j<3;j++) {
            float extent=fabsf(lo[j])>fabsf(hi[j])?fabsf(lo[j]):fabsf(hi[j]);
            magnitude+=extent*fabsf(object_view.view[j][k]);
        }
        error[k]=(magnitude+1.0f)*0.0001f;
        if(!isfinite(error[k]))return 0;
    }
    float center[3],extent[3];
    for(unsigned j=0;j<3;j++) {
        center[j]=lo[j]*0.5f+hi[j]*0.5f;
        extent[j]=hi[j]*0.5f-lo[j]*0.5f;
    }
    for(unsigned k=0;k<3;k++) {
        float c=object_view.view[3][k],e=0;
        for(unsigned j=0;j<3;j++) {
            c+=center[j]*object_view.view[j][k];
            e+=extent[j]*fabsf(object_view.view[j][k]);
        }
        clo[k]=c-e;chi[k]=c+e;
        if(!isfinite(clo[k]) || !isfinite(chi[k]))return 0;
    }
    if(chi[2]<object_view.near_plane-error[2] || clo[2]>object_view.far_plane+error[2] ||
       chi[0]<-error[0] || chi[1]<-error[1] ||
       clo[0]>chi[2]+error[0]+error[2] || clo[1]>chi[2]+error[1]+error[2])return -1;
    if(clo[2]>object_view.near_plane+error[2] && chi[2]<object_view.far_plane-error[2] &&
       object_view.near_plane>=0.0001f && object_view.far_plane<=65536.0f &&
       clo[0]>-clo[2]+error[0]+error[2] && clo[1]>-clo[2]+error[1]+error[2] &&
       chi[0]<2*clo[2]-error[0]-2*error[2] && chi[1]<2*clo[2]-error[1]-2*error[2])return 1;
    return 0;
}
static inline int gpu_same_position(const BullyNativeVertex *a,const BullyNativeVertex *b) {
    for(unsigned k=0;k<3;k++) {
        uint32_t x,y;memcpy(&x,&a->position[k],4);memcpy(&y,&b->position[k],4);
        if(x!=y)return 0;
    }
    return 1;
}
/* On the GPU path FP traps are disabled and entry FCR is restored at exit.
 * Lighting consumes only these two color banks and the immutable material.
 * Reuse the already packed result without extra FCR reads or cache storage. */
static inline int gpu_same_colors(const BullyNativeVertex *a,const BullyNativeVertex *b) {
    uint32_t a0,a1,b0,b1;
    memcpy(&a0,a->color,4);memcpy(&b0,b->color,4);
    memcpy(&a1,a->color_secondary,4);memcpy(&b1,b->color_secondary,4);
    return a0==b0 && a1==b1;
}
static int draw_gpu_strip(const BullyNativeVertex *v,const uint8_t *skip,size_t n) {
    if(n<12 || n>256)return 0;
    uint32_t saved=clip_fpu_read();if(saved&0x00020f80u)return 0;
    int bounds=gpu_strip_bounds(v,n);
    if(bounds<=0){clip_fpu_write(saved);return bounds<0;}
    GeVertex prepared[256];
    for(size_t i=0;i<n;i++) {
        if(!isfinite(v[i].uv[0]) || !isfinite(v[i].uv[1])){clip_fpu_write(saved);return 0;}
        unsigned color=0xff000000u;
        if(material_light && i && gpu_same_colors(&v[i-1],&v[i])) {
            color=prepared[i-1].color;
        } else if(material_light) {
            float rgb[3],alpha;bully_light_color(&v[i],material_light,rgb);alpha=bully_light_alpha(&v[i],material_light);
            if(!isfinite(alpha) || !isfinite(rgb[0]) || !isfinite(rgb[1]) || !isfinite(rgb[2])){clip_fpu_write(saved);return 0;}
            color=(channel(alpha)<<24)|channel(rgb[0])|(channel(rgb[1])<<8)|(channel(rgb[2])<<16);
        } else {
            /* Exact integer form of the default byte*2 then channel clamp. */
            for(unsigned k=0;k<3;k++){unsigned x=(unsigned)v[i].color[k]*2;if(x>255)x=255;color|=x<<(k*8);}
        }
        prepared[i]=(GeVertex){v[i].uv[0],v[i].uv[1],color,v[i].position[0],v[i].position[1],v[i].position[2]};
    }
    int selected=0;
    for(size_t i=2;i<n;i++) {
        if(skip && skip[i])continue;
        if(gpu_same_position(&v[i-2],&v[i-1]) || gpu_same_position(&v[i-1],&v[i]) || gpu_same_position(&v[i-2],&v[i]))continue;
        if(!selected){if(!gpu_vertex_space){flush_vertices();gpu_vertex_space=1;}selected=1;}
        if(queued+3>WORLD_BATCH_VERTICES)flush_vertices();
        verts[queued++]=prepared[i-2];verts[queued++]=prepared[i-1];verts[queued++]=prepared[i];triangles++;
    }
    clip_fpu_write(saved);return 1;
}


static void draw_accelerated_strip(const BullyNativeVertex *v,const uint8_t *skip,size_t n) {
    if(draw_gpu_strip(v,skip,n))return;
    if(gpu_vertex_space){flush_vertices();gpu_vertex_space=0;}
    draw_strip(v,skip,n);
}
static void draw_accelerated_batch(const BullyNativeVertex *v,size_t n,void *context) {
    (void)context;draw_accelerated_strip(v,0,n);
}
static void draw_accelerated_skin_batch(const BullyNativeVertex *v,const uint8_t *skip,size_t n,void *context) {
    (void)context;draw_accelerated_strip(v,skip,n);
}
void bully_world_draw(uint32_t object,uint32_t camera) {
    bully_overlay_flush();
    collecting_lights=0;
    if(!enabled || !scene_camera || camera!=scene_camera)return;
    if(!mesh)mesh=hle_plat_big_alloc(256*sizeof(*mesh));
    if(!texels)texels=hle_plat_big_alloc(WORLD_TEXTURE_BYTES);
    if(!bully_native_object_cached(hle_ram,hle_ram_end,object,camera,mesh,&object_view,skin_cache)) {
        if(rejected++<8)LOG("WORLD: unsupported object=%08x camera=%08x\n",object,camera);
        return;
    }
    if(!active && !init())return;
    underlay_active=0;
    if(clear_pending){start();sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);finish();clear_pending=0;}
    if(object_view.bones)allocate_skin_cache();
    else if(clip_memo_enabled)allocate_clip_memo();
    ScePspFMatrix4 projection;
    float matrix[16];
    if(!bully_projection_matrix(object_view.near_plane,object_view.far_plane,matrix))return;
    memcpy(&projection,matrix,sizeof(projection));
    start();sceGuSetMatrix(GU_PROJECTION,&projection);
    objects++;
    if(object_view.bones)skinned_objects++;
    for(unsigned m=0;m<object_view.meshes;m++) {
        BullyNativeMeshView *v=&object_view.mesh[m];size_t n=0;
        material_light=0;
        if(v->compressed==1)for(unsigned l=0;l<light_count;l++)
            if(lights[l].stream==v->stream && lights[l].material_id==v->material) { material_light=&lights[l];break; }
        if(material_light)lit_meshes++;
        material_state=0;
        for(unsigned j=0;j<state_count;j++)
            if(states[j].stream==v->stream && states[j].material==v->material) { material_state=&states[j];break; }
        if(!material_state && !v->compressed && float_sky_object==object && float_sky_material(v->material))
            material_state=&float_sky_state;
        bind_material(v->material);
        if(v->compressed==2) {
            size_t used=0,tris=0;
            /* No guest execution or RAM mutation occurs between validation
             * and these synchronous draws. Reuse only the fully validated
             * object's complete batches; overflow/allocation failure decodes. */
            if(!bully_native_skin_replay(skin_cache,m,draw_accelerated_skin_batch,0))
                bully_skin_chain(hle_ram,hle_ram_end,v->stream,object_view.palette,object_view.bones,
                                 mesh,draw_accelerated_skin_batch,0,&n,&used,&tris);
        } else if(v->compressed) {
            size_t used=0;
            /* Adapter validated every mesh before any draws. Guest RAM is not
             * executed or mutated while these synchronous batches are submitted. */
            bully_compressed_chain(hle_ram,(size_t)v->stream+v->bytes,v->stream,
                                   mesh,draw_accelerated_batch,0,&n,&used);
        } else if(bully_native_decode(hle_ram+v->stream,v->bytes,mesh,256,&n))
            draw_accelerated_batch(mesh,n,0);
        flush_vertices();
        finish(); /* Also close a material that emitted no vertices. */
    }
    finish(); /* Keep the object boundary closed even for an empty object. */
    gpu_vertex_space=0;
    if(gpu_model_active){start();select_vertex_space();finish();}
}

/* A far-plane, untextured GS sky triangle is valid before world geometry.
 * Its Z=0 write leaves the cleared far depth unchanged. Clear once here so
 * the first native object preserves the original sky instead of erasing it.
 * Paused UI retains the normal completed-background composition path. */
int bully_world_overlay_begin(void);
int bully_world_underlay_begin(void) {
    if(!scene_camera)return bully_world_overlay_begin();
    if(!active && !init())return 0;
    if(clear_pending){start();sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);finish();clear_pending=0;}
    underlay_active=1;return 1;
}
/* Compose overlays after the world camera, present at the guest flip. */
int bully_world_overlay_begin(void) {
    if(!active || !overlay_background)return 0;
    if(!overlay_started && !overlay_world_new)copy_background(OVERLAY_BG,overlay_draw_offset);
    overlay_started=1;return 1;
}
void bully_world_overlay_present(void) {
    if(!active)return;
    if(overlay_defer_world) {
        overlay_defer_world=0;
        if(!overlay_started)return;
    }
    if(!overlay_world_new && !overlay_started)return;
    present_composition();
}
