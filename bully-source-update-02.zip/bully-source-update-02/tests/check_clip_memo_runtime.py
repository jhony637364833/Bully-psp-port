"""Exercise actual optional allocator and camera guards without PSP hardware."""
from pathlib import Path
import subprocess,argparse,tempfile
repo=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--output',type=Path,required=True);args=a.parse_args();b=args.output.resolve();b.mkdir(parents=True,exist_ok=True)
g=repo/'app/games/SLUS-21269_v1.02/src'
s=(g/'psp/world_display.c').read_text();s=s[s.index('#define WORLD_CLIP_MEMO_SETS'):s.index('static BullyNativeObject object_view;')]
a=s.index('static __attribute__((noinline)) uint32_t clip_fpu_read');z=s.index('static void allocate_clip_memo')
s=s[:a]+'static uint32_t clip_fpu_read(void){return 0;}\nstatic void clip_fpu_write(uint32_t value){(void)value;}\n'+s[z:]
head=r'''
#include "clip_memo.h"
#include "native_memory.h"
#include <assert.h>
#include <stdio.h>
#define LOG(...) ((void)0)
#define PSP_SMEM_High 2
typedef int SceUID;
static uint8_t ram[256],*hle_ram=ram;static uint32_t hle_ram_end=sizeof(ram);
static unsigned total_free,max_free,allocations,frees,mode;
static BullyClipMemoSet storage[2048];
static unsigned sceKernelTotalFreeMemSize(void){return total_free;}
static unsigned sceKernelMaxFreeMemSize(void){return max_free;}
static SceUID sceKernelAllocPartitionMemory(int p,const char*n,int type,unsigned bytes,void*at){assert(p==2&&!strcmp(n,"world_clip")&&type==2&&bytes==sizeof(storage)&&!at);allocations++;if(mode==1)return -1;total_free-=bytes;max_free=1024u*1024u+BULLY_OVERLAY_ARENA_BYTES;
 if(mode==3)total_free=1024u*1024u+BULLY_OVERLAY_ARENA_BYTES-1;
 if(mode==4)max_free=BULLY_OVERLAY_ARENA_BYTES-1;
 return 7;}
static void*sceKernelGetBlockHeadAddr(SceUID id){assert(id==7);return mode==2?0:storage;}
static int sceKernelFreePartitionMemory(SceUID id){assert(id==7);frees++;total_free+=sizeof(storage);return 0;}
'''
main=r'''
int main(void){
 for(unsigned test=0;test<7;test++){
  clip_memo=(BullyClipMemo){0};clip_memo_storage=0;clip_memo_attempted=0;allocations=frees=mode=0;
  total_free=(unsigned)sizeof(storage)+1024u*1024u+BULLY_OVERLAY_ARENA_BYTES;max_free=sizeof(storage);
  if(test==0)total_free--;
  if(test==1)max_free--;
  if(test==2)mode=1;
  if(test==3)mode=2;
  if(test==4)mode=3;
  if(test==5)mode=4;
  allocate_clip_memo();allocate_clip_memo();assert(clip_memo_attempted);
  assert(allocations==(test>=2));assert(frees==(test>=3 && test<=5));
  assert((clip_memo_storage!=0)==(test==6));
 }
 assert(clip_memo.set==storage&&clip_memo.sets==2048);
 assert(total_free>=1024u*1024u+BULLY_OVERLAY_ARENA_BYTES && max_free>=BULLY_OVERLAY_ARENA_BYTES);
 clip_camera=clip_camera_stable=0;
 for(unsigned i=0;i<4;i++){clip_camera_begin(4);assert((clip_memo_enabled!=0)==(i==3));}
 unsigned epoch=clip_memo.epoch;storage[0].entry[0].hash=123;ram[36]^=1;
 clip_camera_begin(4);assert(!clip_memo_enabled&&clip_camera_stable==0&&clip_memo.epoch==epoch+1&&storage[0].entry[0].hash==123);
 for(unsigned i=0;i<3;i++)clip_camera_begin(4);assert(clip_memo_enabled);
 unsigned bad[]={0,1,3,5,128,256,0xffffffffu};
 for(unsigned i=0;i<sizeof bad/sizeof(*bad);i++){clip_camera_begin(bad[i]);assert(!clip_memo_enabled&&!clip_camera);}
 hle_ram_end=8;clip_camera_begin(4);assert(!clip_memo_enabled);hle_ram_end=256;
 hle_ram=0;clip_camera_begin(4);assert(!clip_memo_enabled);
 puts("COMPLETE actual_runtime allocation_cases=7 lowtotal/fragmentation/allocationfail/nullhead/posttotal/postfragmentation/success HUD_reserve=preserved repeatedallocation=bounded camera_bounds/stability/change/epoch=exact ASanUBSan errors=0");return 0;
}
'''

(b/'runtime-test.c').write_text(head+s+main)
subprocess.run(['gcc','-O2','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(g),str(b/'runtime-test.c'),'-o',str(b/'runtime-test')],check=True)
subprocess.run([str(b/'runtime-test')],check=True)
