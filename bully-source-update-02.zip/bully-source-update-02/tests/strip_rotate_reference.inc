static void draw_strip(const BullyNativeVertex *v,const uint8_t *skip,size_t n) {
    PreparedVertex ring[3];BullyClipCache cache;bully_clip_cache_reset(&cache);
    for(size_t i=0;i<n;i++) {
        prepare_cached(&v[i],&ring[i%3]);
        if(i>=2 && (!skip || !skip[i]))
            triangle_cached(&ring[(i-2)%3],&ring[(i-1)%3],&ring[i%3],&cache);
    }
}
