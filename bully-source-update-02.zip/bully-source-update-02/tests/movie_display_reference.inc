/* Native movie presentation only. This does not implement Bully's gameplay renderer.
 * Two buffers in PSP VRAM; CPU copy from the firmware decoder's 512-pixel stride.
 */
#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspge.h>
#include <pspdebug.h>
#include "hle.h"

#define STRIDE 512u
#define WIDTH 480u
#define HEIGHT 272u
#define FB_BYTES (STRIDE * HEIGHT * 4u)
int hle_ge_on;
static unsigned front, pictures;

static uint8_t *buffer(unsigned n)
{
    return (uint8_t *)((uintptr_t)sceGeEdramGetAddr() | 0x40000000u) + n * FB_BYTES;
}

int bully_movie_display_init(void)
{
    void bully_world_shutdown(void);
    bully_world_shutdown();
    if (hle_ge_on) return 1;
    if (sceGeEdramGetSize() < 2 * FB_BYTES || sceDisplaySetMode(0, WIDTH, HEIGHT) < 0) return 0;
    memset(buffer(0), 0, 2 * FB_BYTES);
    front = pictures = 0;
    if (sceDisplaySetFrameBuf(buffer(0), STRIDE, PSP_DISPLAY_PIXEL_FORMAT_8888, PSP_DISPLAY_SETBUF_IMMEDIATE) < 0)
        return 0;
    hle_ge_on = 1;
    return 1;
}

int hle_ge_movie_begin(void) { return hle_ge_on; }

void hle_ge_movie_frame(const void *pic, int rgba8888, uint32_t dump)
{
    (void)dump; /* Frame dumps are a developer option of the full GE backend. */
    if (!hle_ge_on) return;
    unsigned back = front ^ 1u;
    uint32_t *dst = (uint32_t *)buffer(back);
    if (!pic) memset(dst, 0, FB_BYTES);
    else {
        /* Firmware decoding writes RAM through DMA: invalidate cached CPU views before reading. */
        sceKernelDcacheInvalidateRange(pic, STRIDE * HEIGHT * (rgba8888 ? 4u : 2u));
        if (rgba8888) {
            for (unsigned y = 0; y < HEIGHT; y++)
                memcpy(dst + y * STRIDE, (const uint32_t *)pic + y * STRIDE, WIDTH * 4u);
        } else {
            const uint16_t *src = pic;
            for (unsigned y = 0; y < HEIGHT; y++) for (unsigned x = 0; x < WIDTH; x++) {
                unsigned p = src[y * STRIDE + x];
                unsigned r = (p & 31u) * 255u / 31u;
                unsigned g = ((p >> 5) & 63u) * 255u / 63u;
                unsigned b = (p >> 11) * 255u / 31u;
                dst[y * STRIDE + x] = r | g << 8 | b << 16 | 0xff000000u;
            }
        }
        pictures++;
    }
    sceDisplaySetFrameBuf(dst, STRIDE, PSP_DISPLAY_PIXEL_FORMAT_8888, PSP_DISPLAY_SETBUF_NEXTFRAME);
    sceDisplayWaitVblankStart();
    front = back;
}

void hle_ge_movie_end(void) { hle_ge_movie_frame(NULL, 1, 0); }

void bully_movie_display_shutdown(void)
{
    if (!hle_ge_on) return;
    hle_ge_on = 0;
    pspDebugScreenInit();
    LOG("Bully movie display: %u pictures presented; gameplay rendering is not implemented\n", pictures);
}
