.DEFAULT_GOAL := all
TARGET = movie_display_test
OBJS = main.o
INCDIR = .
CFLAGS = -O2 -G0 -Wall -Wextra -Werror
BUILD_PRX = 1
LIBS = -lpspgu -lpspge -lpspdisplay -lm
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully movie display test
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
main.o: movie_display.c hle.h
