#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include "native_object.h"
#include "native_light.h"
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("GPU light reuse check",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
#endif
#include <stdint.h>
#ifdef __PSP__
static __attribute__((noinline)) uint32_t clip_fpu_read(void) {
    uint32_t x;__asm__ volatile("cfc1 %0,$31":"=r"(x)::"memory");return x;
}
static __attribute__((noinline)) void clip_fpu_write(uint32_t x) {
    __asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(x):"memory");
}
#else
#include <fenv.h>
/* Host adapter: preserve rounding and exception flags. PSP fixtures also
 * compare the hardware's comparison-condition and cause bits. */
static uint32_t clip_fpu_read(void) {
    return ((uint32_t)fegetround()<<16)|(unsigned)fetestexcept(FE_ALL_EXCEPT);
}
static void clip_fpu_write(uint32_t x) {
    fesetround((int)(x>>16));feclearexcept(FE_ALL_EXCEPT);
    feraiseexcept((int)(x&0xffff));
}
#endif

#define WORLD_BATCH_VERTICES 384
static BullyNativeObject object_view;
static const BullyNativeLight *material_light;
typedef struct {float u,v;uint32_t color;float x,y,z;} GeVertex;
static GeVertex verts[384],captured[1024];
static unsigned queued,triangles,captured_count,flushes;
static int gpu_vertex_space;
static void flush_vertices(void){assert(captured_count+queued<=1024);memcpy(captured+captured_count,verts,queued*sizeof(*verts));captured_count+=queued;queued=0;flushes++;}
static unsigned channel(float f){return f<=0?0:f>=255?255:(unsigned)f;}
