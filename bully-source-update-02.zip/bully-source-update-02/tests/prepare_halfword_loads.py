"""Generate exhaustive host/PSP halfword-load and compressed-parser checks."""
from pathlib import Path
import argparse
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();here=Path(__file__).parent;d=a.output;d.mkdir(parents=True,exist_ok=True)
g=a.app/'games/SLUS-21269_v1.02/src'
(d/'native_mesh.h').write_bytes((g/'native_mesh.h').read_bytes())
for name in ['baseline','candidate']:
 s=((here/'halfword_reference.inc') if name=='baseline' else (g/'native_mesh.c')).read_text()
 if name=='baseline':s='#define bully_compressed_chain baseline_bully_compressed_chain\n#define bully_native_decode baseline_bully_native_decode\n'+s
 s+='\nfloat '+name+'_fixed(const uint8_t*p){return fixed128(p); }\nunsigned '+name+'_half(const uint8_t*p){return half(p); }\n'
 s=s.replace('p); }','p);}')
 if name=='candidate':
  s=s.replace('return fixed128(p);','return ((uintptr_t)p&1u)?fixed128(p):fixed128_aligned(p);').replace('return half(p);','return ((uintptr_t)p&1u)?half(p):half_aligned(p);')
 (d/(name+'.c')).write_text(s)
for src,dst in [('halfword_main.c','main.c'),('halfword_Makefile.inc','Makefile'),('halfword_parser_cases.inc','original.inc')]:
 (d/dst).write_bytes((here/src).read_bytes())
print('Expected COMPLETE values=2097152 parser=80000 sideeffects=1024 errors=0')
