#include "native_light.h"
void bully_test106_light_color(const BullyNativeVertex *v,const BullyNativeLight *light,float rgb[3]) {
    for(unsigned k=0;k<3;k++) {
        float a=v->color[light->monochrome?0:k];
        float b=v->color_secondary[light->monochrome?0:k];
        if(light->monochrome) { a+=12; b+=12; }
        /* Clamp before material modulation, as the original VU shader does. */
        float lit=(a+(b-a)*light->blend)*light->gain[k];
        /* The other fmin operand is the positive finite constant255.
         * A NaN comparison selects255, exactly as fminf does here; signed
         * zeros and finite/subnormal values retain their original bits. */
        rgb[k]=(lit<255.0f?lit:255.0f)*light->material[k]*2.0f;
    }
}
