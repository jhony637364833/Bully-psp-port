#include "r5900_rt.h"
#include "context_copy_reference.inc"
#include "candidate.h"
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully context raw copy",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
PSP_MAIN_THREAD_STACK_SIZE_KB(128);
#include "context_copy_vfpu_load.h"
#include "context_copy_vfpu_store.h"
static void mode(unsigned m,unsigned p){uint32_t f=0x01000000u|m|((p&1)?0x800000u:0)|((p&2)?0x7cu:0);__asm__ volatile("ctc1 %0,$31"::"r"(f):"memory");}
static uint32_t status(void){uint32_t f;__asm__ volatile("cfc1 %0,$31":"=r"(f)::"memory");return f;}
static void controls_load(const uint32_t *p) {
 __asm__ volatile("mtvc %0, $128\n\tmtvc %1, $129\n\tmtvc %2, $130\n\tmtvc %3, $131\n\tmtvc %4, $136" :: "r"(p[0]),"r"(p[1]),"r"(p[2]),"r"(p[3]),"r"(p[4]):"memory");
}
static void controls_store(uint32_t *p) {
 __asm__ volatile("mfvc %0, $128\n\tmfvc %1, $129\n\tmfvc %2, $130\n\tmfvc %3, $131\n\tmfvc %4, $136" : "=r"(p[0]),"=r"(p[1]),"=r"(p[2]),"=r"(p[3]),"=r"(p[4]) ::"memory");
}
#else
#include <fenv.h>
static void mode(unsigned m,unsigned p){static const int r[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(r[m]);feclearexcept(FE_ALL_EXCEPT);if(p&2)feraiseexcept(FE_ALL_EXCEPT);}
static uint32_t status(void){return fetestexcept(FE_ALL_EXCEPT);}
static void vfpu_load(void*p){(void)p;}
static void vfpu_store(void*p){(void)p;}
static void controls_load(const uint32_t*p){(void)p;}
static void controls_store(uint32_t*p){(void)p;}
#endif
static R5900Ctx original,a,b;
struct Guarded {R5900Reg128 before[2];R5900CSave data;R5900Reg128 after[2];};
static struct Guarded x,y;
static uint32_t vregs[128] __attribute__((aligned(16))),actual[128] __attribute__((aligned(16)));
static uint32_t seed=0x76893ad7;
static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static void fill(void*p,size_t n){unsigned char*q=p;for(size_t i=0;i<n;i++)q[i]=(unsigned char)rnd();}
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);FILE*f=fopen("context-vfpu.log","w");
#else
 FILE*f=stdout;
#endif
 if(!f)return 2;
 _Static_assert(sizeof(R5900CSave)==192,"snapshot layout");
 _Static_assert(offsetof(R5900Ctx,fpr[20])%16==4,"FPR must stay word copy");
 unsigned total=0;
 for(unsigned enabled=0;enabled<2;enabled++)for(unsigned m=0;m<4;m++)for(unsigned it=0;it<2000;it++){
  candidate_enable(enabled);
  fill(&original,sizeof original);a=b=original;fill(&x,sizeof x);y=x;
  fill(vregs,sizeof vregs);memcpy(actual,vregs,sizeof actual);
  // Include exponent255/subnormal/zero payloads in both copied and scratch state.
  static const uint32_t edge[]={0,0x80000000,1,0x80000001,0x7fffff,0x807fffff,0x7f800000,0xff800000,0x7f800001,0x7fc00001,0x7fffffff,0xffffffff};
  for(unsigned j=0;j<4;j++){vregs[j]=edge[(it+j)%12];a.r[16].w[j]=b.r[16].w[j]=edge[(it+j+4)%12];}
  memcpy(actual,vregs,sizeof actual);
  uint32_t ctrl[5]={rnd()&0xfffff,rnd()&0xfffff,rnd()&0xfff,rnd()&0x3f,rnd()},before[5]={0},after[5]={0};
  controls_load(ctrl);controls_store(before);vfpu_load(vregs);
  mode(m,it&3);uint32_t fp0=status();reference_save(&a,&x.data);uint32_t fp1=status();candidate_save(&b,&y.data);uint32_t fp2=status();
  vfpu_store(actual);controls_store(after);
  if(memcmp(&a,&b,sizeof a)||memcmp(&x,&y,sizeof x)||memcmp(actual,vregs,sizeof actual)||memcmp(before,after,sizeof before)||fp0!=fp1||fp1!=fp2){fprintf(f,"ERROR save m=%u it=%u ctx=%d snap=%d regs=%d ctrl=%d fcr=%08lx/%08lx/%08lx\n",m,it,memcmp(&a,&b,sizeof a),memcmp(&x,&y,sizeof x),memcmp(actual,vregs,sizeof actual),memcmp(before,after,sizeof before),(unsigned long)fp0,(unsigned long)fp1,(unsigned long)fp2);fflush(f);return 1;}
  fill(&original,sizeof original);a=b=original;
  controls_load(ctrl);controls_store(before);vfpu_load(vregs);mode(m,it&3);fp0=status();
  reference_restore(&a,&x.data);fp1=status();candidate_restore(&b,&y.data);fp2=status();vfpu_store(actual);controls_store(after);
  if(memcmp(&a,&b,sizeof a)||memcmp(&x,&y,sizeof x)||memcmp(actual,vregs,sizeof actual)||memcmp(before,after,sizeof before)||fp0!=fp1||fp1!=fp2){fprintf(f,"ERROR restore m=%u it=%u\n",m,it);fflush(f);return 1;}
  total++;
  if(it==1999){fprintf(f,"mode=%u comparisons=%u errors=0\n",m,total);fflush(f);}
 }
 fprintf(f,"COMPLETE comparisons=%u errors=0\n",total);fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
}
