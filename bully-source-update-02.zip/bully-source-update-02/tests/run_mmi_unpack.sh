#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bully_mmi_tmp=$(mktemp -d)
trap 'rm -rf "$bully_mmi_tmp"' EXIT
"${CC:-cc}" -O2 -Wall -Wextra -Werror -fsanitize=address,undefined \
 -Iapp/runtime tests/mmi_unpack_test.c -o "$bully_mmi_tmp/mmi_unpack_test"
"$bully_mmi_tmp/mmi_unpack_test"
