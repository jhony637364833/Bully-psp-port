static int pass(unsigned fn,unsigned a,unsigned r){switch(fn){case 0:return 0;case 1:return 1;case 2:return a<r;case 3:return a<=r;case 4:return a==r;case 5:return a>=r;case 6:return a>r;default:return a!=r;}}
int main(void){
 BullyNativeState state={0};material_state=&state;state.zmask=0;queued=3;unsigned long checks=0;
 for(unsigned fn=0;fn<8;fn++)for(unsigned ref=0;ref<128;ref++)for(unsigned maximum=0;maximum<256;maximum++){
  state.test=1|(fn<<1)|(ref<<4)|(1<<12);for(unsigned i=0;i<3;i++)verts[i].color=maximum<<24;
  if(all_alpha_fail()){
   for(unsigned a=0;a<=maximum;a++){assert(!pass(fn,a,ref*2));checks++;}
  }
 }
 /* Bound of modulated unsigned alpha, for truncating and nearest division.
  * Raster interpolation bounds require separate actual-GPU verification. */
 for(unsigned a=0;a<256;a++)for(unsigned tex=0;tex<256;tex++){
  assert(a*tex/255<=a);assert((a*tex+127)/255<=a);checks+=2;
 }
 state.test=1|(5<<1)|(64<<4)|(1<<12);verts[0].color=127u<<24;verts[1].color=126u<<24;verts[2].color=0;
 assert(all_alpha_fail());verts[2].color=128u<<24;assert(!all_alpha_fail());
 state.zmask=1;assert(!all_alpha_fail());state.zmask=0;state.test&=~1u;assert(!all_alpha_fail());
 material_state=0;assert(!all_alpha_fail());material_state=&state;queued=0;assert(!all_alpha_fail());
 printf("%lu exhaustive bound checks PASS; pixel/depth equivalence still required\n",checks);return 0;
}
