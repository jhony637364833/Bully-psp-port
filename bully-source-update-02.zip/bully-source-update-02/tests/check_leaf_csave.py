"""Asset-free tests of conservative preservation removal and retained fallbacks."""
import importlib.util
from pathlib import Path
import sys
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]/'app/ps2rc/pipeline/leaf_csave.py'
spec=importlib.util.spec_from_file_location('leaf_csave',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
def fn(name,body):return 'void '+name+'(R5900Ctx *c)\n{\n'+body+'\n}\n'
wrapper='{ R5900CSave cs_; rt_cs_save(c, &cs_); fn_00000001(c); rt_cs_restore(c, &cs_); }'
caller=fn('fn_00000002',wrapper+'\n{ RC_BACKEDGE_AT(c, 0x1234u); goto L_1234; }')
safe=['c->acc.u = f_in5(fpu_rsqrt5(0, fpu_sqrt_c(0)));', 'c->r[3].d[0] = 42;', 'c->r[3] = mmi_pextlw(c->r[4], c->r[5]);', 'c->fpr[19].u = c->fpr[0].u;', 'vu0_ctc2(c, 16, 0); c->r[3].d[0] = vu0_cfc2(c, 16);', 'const R5900Mem m_ = {c->ram, c->ram_mask}; rmb_sw(m_, 0, 4, 123);']
unsafe=[f'c->r[{i}].w[0] = 42;' for i in [16,17,18,19,20,21,22,23,30]]
unsafe += ['c->acc.u_extra = 1;', 'c->acc.u.w[0] = 1;', 'void *p = &c->acc.u;', 'c->acc.other = 1;', 'c->acc.u = unknown();']
unsafe += [f'c->fpr[{i}].u = 42;' for i in range(20,32)]
unsafe += ['c->acc.u_extra = 1;', 'c->acc.u.w[0] = 1;', 'void *p = &c->acc.u;', 'c->acc.other = 1;', 'c->acc.u = unknown();', 'c->r[i].w[0] = 42;', 'fn_00000003(c);', 'callback(c);', 'callback();', 'vu0_ctc2(c, 17, 0);', 'RC_BACKEDGE_AT(c, 0x1234u);', 'R5900Ctx *alias = c;', 'void *p = &c->r[3];', 'void *p = & ( c->r[3]);', 'c->r[15].w[4] = 42;', 'c->r[15] .w[4] = 42;', 'c->fpr[19].u_extra = 42;', 'c->ram = p;', 'c->vu0.vi[i] = 42;', 'rmbx_sw(c, m_, 0, 42);']
for body in safe+unsafe:
 units={'caller.c':caller,'callee.c':fn('fn_00000001',body),'other.c':fn('fn_00000004',wrapper)}
 result,count=mod.optimize_units(units,['fn_00000002'])
 if body in safe:
  assert result['caller.c']==caller.replace(wrapper,'fn_00000001(c);')
  assert count=={('fn_00000002','fn_00000001'):1}
 else:assert result==units and not count,body
 assert result['other.c']==units['other.c']
 again,counts=mod.optimize_units(result,['fn_00000002']);assert again==result and not counts
# Missing definition, hook renaming, duplicate definitions, and indirect calls
# cannot establish the selected callee's exact implementation.
for extra in ['',fn('fn_00000001__guest',safe[0]),fn('fn_00000001',safe[0])*2]:
 units={'caller.c':caller,'callee.c':extra};result,count=mod.optimize_units(units,['fn_00000002']);assert result==units and not count
for callers in [['bad'],['fn_00000009']]:
 try:mod.optimize_units({'caller.c':caller},callers)
 except ValueError:pass
 else:raise AssertionError(callers)
print('PASS: asset-free positive/unsafe cases, full saved-register set, unchanged other callers/backedges, missing/hooked/duplicate/indirect fallbacks, idempotence and malformed configuration')
