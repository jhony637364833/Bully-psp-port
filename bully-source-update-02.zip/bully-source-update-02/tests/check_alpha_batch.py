"""Exercise the actual renderer's conservative alpha-pass batch selection."""
from pathlib import Path
import subprocess,tempfile,os
repo=Path(__file__).resolve().parents[1]
src=repo/'app/games/SLUS-21269_v1.02/src'
s=(src/'psp/world_display.c').read_text()
body=s[s.index('static unsigned alpha_reference'):s.index('static void apply_state')]
body+=s[s.index('static int needs_alpha_fail_pass'):s.index('void bully_world_begin')]
head='''#include "native_state.h"
#include "native_texture.h"
#include "native_texture_alpha.h"
#include <assert.h>
#include <stdio.h>
static const BullyNativeState *material_state;
static BullyNativeTexture texture;
static int has_texture;
#define WORLD_TEXTURE_BYTES 65536
static unsigned char texels[WORLD_TEXTURE_BYTES];
static const unsigned char *material_texels=texels;
static unsigned texture_alpha_minimum,texture_alpha_minimum_valid;
static unsigned queued;
static struct { unsigned color; } verts[3];
'''
main='''
int main(void) {
 BullyNativeState state={0};material_state=&state;has_texture=1;queued=3;
 texture.texture.alpha_class=TC_ALPHA_OPAQUE;
 state.test=1|(5<<1)|(64<<4)|(1<<12); /* GEQUAL128, FB_ONLY */
 for(unsigned i=0;i<3;i++)verts[i].color=128u<<24;
 assert(!needs_alpha_fail_pass()); /* inclusive boundary */
 verts[1].color=127u<<24;assert(needs_alpha_fail_pass());
 verts[1].color=255u<<24;assert(!needs_alpha_fail_pass()); /* variable but bounded */
 state.test=1|(6<<1)|(64<<4)|(1<<12);assert(needs_alpha_fail_pass());
 for(unsigned i=0;i<3;i++)verts[i].color=129u<<24;
 assert(!needs_alpha_fail_pass()); /* strict boundary */
 state.test=1|(7<<1)|(64<<4)|(1<<12);
 assert(!needs_alpha_fail_pass());
 verts[0].color=127u<<24;assert(needs_alpha_fail_pass()); /* interval spans equality */
 for(unsigned i=0;i<3;i++)verts[i].color=255u<<24;
 texture.texture.alpha_class=TC_ALPHA_BLEND;assert(needs_alpha_fail_pass());
 state.zmask=1;assert(!needs_alpha_fail_pass());
 state.zmask=0;state.test=1|(0<<1)|(64<<4)|(1<<12);assert(needs_alpha_fail_pass());
 puts("10 alpha batch boundary assertions PASS");return 0;
}
'''
with tempfile.TemporaryDirectory(prefix='bully-alpha-batch-') as tmp:
 p=Path(tmp);(p/'test.c').write_text(head+body+main)
 subprocess.run([os.environ.get('CC','cc'),'-O2','-fsanitize=address,undefined','-I'+str(src),str(p/'test.c'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
