from pathlib import Path
from array import array
import json
import argparse
a=argparse.ArgumentParser();a.add_argument('fixtures',type=Path);args=a.parse_args();b=args.fixtures.resolve();rows=[]
a=(b/'gpu-reference/pixels.bin').read_bytes();c=(b/'gpu-candidate/pixels.bin').read_bytes();assert len(a)==len(c)==65*2*480*272*4
for k in range(65):
 row={'case':128 if k==64 else k,'mode':((128 if k==64 else k)//4)%8}
 for j,kind in enumerate(['color','witness']):
  start=(k*2+j)*480*272*4;end=start+480*272*4
  aa=array('I');aa.frombytes(a[start:end]);cc=array('I');cc.frombytes(c[start:end]);n=big=maximum=total=0
  for x,y in zip(aa,cc):
   if x==y:continue
   n+=1;d=[abs(((x>>s)&255)-((y>>s)&255)) for s in (0,8,16)];m=max(d);maximum=max(maximum,m);big+=m>8;total+=sum(d)
  row[kind]={'different_pixels':n,'different_percent':100*n/(480*272),'max_rgb_channel_error':maximum,'pixels_error_over8':big,'mean_rgb_absolute_error':total/(480*272*3)}
 rows.append(row)
# Numerical GE clipping is intentionally different. These bounded fixture
# checks detect dropped geometry/large errors; inspect game visuals separately.
for row in rows:
 if row['mode'] in (0,7):assert row['color']['different_pixels']==row['witness']['different_pixels']==0,row
 assert row['color']['mean_rgb_absolute_error']<=0.5,row
 assert row['color']['pixels_error_over8']<=16,row
(b/'pixel-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
print('DIFFERENT cases',sum(x['color']['different_pixels']>0 for x in rows),'of65')
for mode in range(8):
 items=[x for x in rows if x['mode']==mode];print('mode',mode,'color_different',sum(x['color']['different_pixels'] for x in items),'over8',sum(x['color']['pixels_error_over8'] for x in items),'max',max(x['color']['max_rgb_channel_error'] for x in items),'witness_different',sum(x['witness']['different_pixels'] for x in items))
