"""Verify the specialization against a prepared baseline (before --native)."""
import sys,re
from pathlib import Path
repo=Path(__file__).resolve().parents[1]
original=Path(sys.argv[1]).read_text()
start='void fn_0024d848__ynguest(' if 'void fn_0024d848__ynguest(' in original else 'void fn_0024d848('
body=original[original.index(start):original.index('void fn_0024dd68(')].replace(start,'void fn_0024d848(',1)
actual=(repo/'app/games/SLUS-21269_v1.02/src/texture_cache_fast.c').read_text()
actual=actual[actual.index('void y_nat_0024d848('):].replace('void y_nat_0024d848(', 'void fn_0024d848(',1)
body=body.replace('{\n','{\n    R5900Reg128 r[32];\n    memcpy(r,c->r,sizeof r);\n',1).replace('c->r[','r[')
body=re.sub(r'fn_[0-9a-f]+\(c\)',lambda m:'CACHE_CALL('+m[0]+')',body)
body=body.replace('RC_BACKEDGE_AT(c,','CACHE_EDGE(').replace('return;', 'memcpy(c->r,r,sizeof r); return;')
assert actual==body
assert actual.count('CACHE_EDGE')==7
print('Cache specialization matches the register-local rewrite, including all seven safe points')
