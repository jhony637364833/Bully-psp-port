"""Generate exact unity-rsqrt host/PSP comparison against the pre-change helper."""
import argparse
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();d=a.output;d.mkdir(parents=True,exist_ok=True)
    here=Path(__file__).parent
    header=(a.app/'runtime/r5900_rt.h').read_text()
    start=header.index('    /* For numerator 1,')
    end=header.index('    return f_out(f2u(F5(s)',start)
    reference=header[:start]+header[end:]
    for n,h in [('reference',reference),('candidate',header)]:
        (d/n).mkdir(exist_ok=True);(d/n/'r5900_rt.h').write_text(h)
        body=(here/'unity_rsqrt_normalizer.inc').read_text().replace('NORMALIZER',n+'_normalizer')
        (d/(n+'.c')).write_text('#include "'+n+'/r5900_rt.h"\nuint32_t '+n+'_one(uint32_t t){return fpu_rsqrt5(0x3f800000u,t);}\nuint32_t '+n+'_generic(uint32_t s,uint32_t t){return fpu_rsqrt5(s,t);}\n'+body)
    (d/'main.c').write_bytes((here/'unity_rsqrt_main.c').read_bytes())
    (d/'Makefile').write_bytes((here/'unity_rsqrt_Makefile.inc').read_bytes())
    print('Expected COMPLETE scalars=4016384 vectors=40000 errors=0')

if __name__=='__main__':main()
