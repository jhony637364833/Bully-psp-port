#include "overlay_geometry.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static int active,clear_pending,underlay_active,scene_camera,allow_init=1,clears,starts,finishes;
#define GU_COLOR_BUFFER_BIT 1
#define GU_DEPTH_BUFFER_BIT 2
static int bully_world_overlay_begin(void){return 0;}
static int init(void){if(!allow_init)return 0;active=1;return 1;}
static void start(void){starts++;}static void finish(void){finishes++;}
static void sceGuClear(unsigned x){assert(x==3);clears++;}
