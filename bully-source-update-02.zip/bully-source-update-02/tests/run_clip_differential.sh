#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bully_test_dir=$(mktemp -d)
trap 'rm -rf "$bully_test_dir"' EXIT
bully_src=app/games/SLUS-21269_v1.02/src
${CC:-cc} -O2 -fsanitize=address,undefined -I"$bully_src" \
 -Dbully_clip_triangle=baseline_clip -c tests/clip_reference.c -o "$bully_test_dir/before.o"
${CC:-cc} -O2 -fsanitize=address,undefined -I"$bully_src" \
 tests/clip_differential.c "$bully_test_dir/before.o" "$bully_src/world_clip.c" -lm -o "$bully_test_dir/test"
"$bully_test_dir/test"
${CC:-cc} -O2 -fsanitize=address,undefined -I"$bully_src" \
 tests/clip_order_test.c -lm -o "$bully_test_dir/order"
"$bully_test_dir/order"
