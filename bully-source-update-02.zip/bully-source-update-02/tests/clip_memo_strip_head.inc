#include "native_object.h"
#include "native_light.h"
#include "world_clip.h"
#include "clip_memo.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully strip rotate check",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
static unsigned getcsr(void){unsigned x;__asm__ volatile("cfc1 %0,$31":"=r"(x));return x;}
static void setcsr(unsigned x){__asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(x));}
#else
#include <fenv.h>
static unsigned getcsr(void){return fetestexcept(FE_ALL_EXCEPT);}
static void setcsr(unsigned x){int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(modes[x&3]);feclearexcept(FE_ALL_EXCEPT);}
#endif
typedef struct {float u,v;unsigned color;float x,y,z;} GeVertex;
#define WORLD_BATCH_VERTICES 384
static GeVertex verts[384],record[30000],expected[30000];
static unsigned queued,triangles,recorded,flushes;
static unsigned flush_sizes[512],expected_sizes[512];
static BullyNativeObject object_view;
static const BullyNativeLight *material_light;
static void flush_vertices(void){assert(recorded+queued<30000);memcpy(record+recorded,verts,queued*sizeof(*verts));recorded+=queued;assert(flushes<512);flush_sizes[flushes]=queued;queued=0;flushes++;}

static BullyClipMemo clip_memo;
static BullyClipMemoSet clip_storage[2048];
static BullyClipMemoSet *clip_memo_storage=clip_storage;
static int clip_memo_enabled=1;
static uint32_t memo_read(void){
#ifdef __PSP__
return getcsr();
#else
return ((uint32_t)fegetround()<<16)|(uint32_t)fetestexcept(FE_ALL_EXCEPT);
#endif
}
static void memo_write(uint32_t x){
#ifdef __PSP__
setcsr((unsigned)x);
#else
fesetround((int)(x>>16));feclearexcept(FE_ALL_EXCEPT);feraiseexcept((int)(x&0xffff));
#endif
}
