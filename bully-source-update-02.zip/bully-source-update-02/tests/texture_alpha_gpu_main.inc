static unsigned read_list[64] __attribute__((aligned(16)));
static uint32_t pixels[480*272] __attribute__((aligned(16))),previous[480*272] __attribute__((aligned(16)));
static uint32_t witness[480*272] __attribute__((aligned(16))),previous_witness[480*272] __attribute__((aligned(16)));
static unsigned draw_fb;
static void read_pixels(uint32_t*dst){
 sceGuStart(GU_DIRECT,read_list);
 sceGuCopyImage(GU_PSM_8888,0,0,480,272,512,(uint8_t*)sceGeEdramGetAddr()+draw_fb*512*272*4,0,0,480,dst);
 sceGuFinish();sceGuSync(0,0);sceKernelDcacheInvalidateRange(dst,480*272*4);
}
static void draw_witness(float z,unsigned color){
 GeVertex quad[6] __attribute__((aligned(16)))={{0,0,color,0,0,z},{0,0,color,z,0,z},{0,0,color,z,z,z},{0,0,color,0,0,z},{0,0,color,z,z,z},{0,0,color,0,z,z}};
 static unsigned witness_list[128] __attribute__((aligned(16)));
 sceKernelDcacheWritebackRange(quad,sizeof quad);sceGuStart(GU_DIRECT,witness_list);
 sceGuDisable(GU_TEXTURE_2D);sceGuDisable(GU_BLEND);sceGuDisable(GU_ALPHA_TEST);
 sceGuEnable(GU_DEPTH_TEST);sceGuDepthFunc(GU_LEQUAL);sceGuDepthMask(GU_FALSE);
 sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,6,0,quad);
 sceGuFinish();sceGuSync(0,0);
}
int main(void){
 freopen("submission.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
 FILE*file=fopen("pixels.bin","wb");if(!file){puts("ERROR pixel output");return 1;}
 for(unsigned iteration=0;iteration<65;iteration++){
  unsigned test=iteration==64?128:iteration;
  for(unsigned repeat=0;repeat<2;repeat++){
   run_fixture(test);assert(!gpu_open);
   read_pixels(pixels);draw_witness(99.9f,0xff55ee33u);read_pixels(witness);
   if(!repeat){memcpy(previous,pixels,sizeof pixels);memcpy(previous_witness,witness,sizeof witness);
    assert(fwrite(pixels,1,sizeof pixels,file)==sizeof pixels);assert(fwrite(witness,1,sizeof witness,file)==sizeof witness);
   }else if(memcmp(previous,pixels,sizeof pixels)||memcmp(previous_witness,witness,sizeof witness)){
    printf("ERROR self comparison case=%u\n",test);return 2;
   }
   if(test==128){
    unsigned changed=0;for(unsigned i=0;i<480*272;i++)if((witness[i]&0xffffffu)!=0x55ee33u){printf("ERROR nonuniform depth witness pixel=%u value=%08x\n",i,(unsigned)witness[i]);return 4;}
    draw_witness(5,0xffaa3399u);draw_witness(99.9f,0xff55ee33u);read_pixels(witness);
    for(unsigned i=0;i<480*272;i++)changed+=(witness[i]&0xffffffu)!=0x55ee33u;
    if(!changed){puts("ERROR insensitive depth witness");return 3;}
    printf("depth positive_control_pixels=%u\n",changed);
   }
   bully_world_camera_end(2);bully_world_camera_end(1);draw_fb^=1;bully_world_camera_end(1);
  }
  printf("case=%u self=pass draws=%u max_list_bytes=%u starts=%u syncs=%u\n",test,draw_calls,gpu_max_bytes,gpu_starts,gpu_syncs);
 }
 assert(!fclose(file));bully_world_shutdown();assert(!gpu_open);
 printf("COMPLETE cases=65 self=65 depth_witness=2 positive_controls=2 max_list_bytes=%u starts=%u syncs=%u errors=0\n",gpu_max_bytes,gpu_starts,gpu_syncs);
 sceKernelExitGame();return 0;
}
