#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bully_lerp_tmp=$(mktemp -d)
trap 'rm -rf "$bully_lerp_tmp"' EXIT
"${CC:-cc}" -O2 -ffp-contract=off -Wall -Wextra -Werror -fsanitize=address,undefined \
 -Iapp/games/SLUS-21269_v1.02/src tests/clip_lerp_test.c -o "$bully_lerp_tmp/clip_lerp_test"
"$bully_lerp_tmp/clip_lerp_test"
