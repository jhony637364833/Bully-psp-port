# CPU fallback helper fixture. Accelerated rendering is tested separately by the full GPU fixtures.
"""Generate asset-free host/PSP exact memo comparisons against frozen build38."""
from pathlib import Path
import argparse,re
repo=Path(__file__).resolve().parents[1];t=repo/'tests';g=repo/'app/games/SLUS-21269_v1.02/src'
a=argparse.ArgumentParser();a.add_argument('output',type=Path);args=a.parse_args();base=args.output.resolve()
for kind in ['math','renderer']:
 p=base/kind;p.mkdir(parents=True,exist_ok=True)
 for name in ['world_clip.c','world_clip.h','clip_memo.h','clip_lerp.h']:(p/name).write_bytes((g/name).read_bytes())
 if kind=='math':
  (p/'main.c').write_bytes((t/'clip_memo_main.c').read_bytes())
  ref=(t/'clip_memo_reference_38.inc').read_text().replace('bully_clip_triangle_cached','reference_clip').replace('bully_clip_triangle','reference_plain').replace('bully_clip_vertex_code','reference_code').replace('bully_clip_cache_reset','reference_reset');(p/'reference.c').write_text(ref)
 else:
  candidate=(g/'psp/world_display.c').read_text();candidate=candidate[candidate.index('static unsigned channel'):candidate.index('void bully_world_draw')].split('/* GPU strip dispatch.',1)[0]
  parts=[]
  for label,body in [('reference',(t/'clip_memo_strip_reference.inc').read_text()),('candidate',candidate)]:
   for symbol in ['channel','screen_clamp','prepare_vertex','triangle','PreparedVertex','prepare_cached','same_vertex_inputs','triangle_cached','draw_strip','draw_batch','draw_skin_batch']:body=re.sub(r'\b'+symbol+r'\b',label+'_'+symbol,body)
   parts.append(body)
  (p/'main.c').write_text((t/'clip_memo_strip_head.inc').read_text()+(t/'renderer_fpu_test.inc').read_text()+'\n'.join(parts)+(t/'clip_memo_strip_main.inc').read_text())
 objects='main.o world_clip.o '+('reference.o' if kind=='math' else 'native_light.o')
 make='.DEFAULT_GOAL := all\nTARGET = clip_memo\nOBJS = '+objects+'\nINCDIR = . '+str(g)+'\nVPATH = '+str(g)+'\nCFLAGS = -O2 -G0 -Wall -Wextra -Werror -Wno-unused-function -Wno-misleading-indentation -fno-fast-math -frounding-math -ffp-contract=off\nBUILD_PRX = 1\nLIBS = -lm\nEXTRA_TARGETS = EBOOT.PBP\nPSP_EBOOT_TITLE = Bully exact clipping memo\nPSPSDK = $(shell psp-config --pspsdk-path)\ninclude $(PSPSDK)/lib/build.mak\n'
 (p/'Makefile').write_text(make+'\n$(OBJS): world_clip.h clip_memo.h clip_lerp.h\n')
print('Prepared math2048*3 and renderer256*3 comparisons; make either folder with PSPDEV or run check_clip_memo.py')
