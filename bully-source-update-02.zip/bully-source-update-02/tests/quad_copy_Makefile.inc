TARGET = bully_quad_copy
OBJS = main.o leaves.o reference.o candidate.o
INCDIR = .
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -Wno-unused-label -Wno-unused-variable -Wno-unused-but-set-variable -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fno-strict-aliasing
BUILD_PRX = 1
LIBS = -lm -lpsppower
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully quad copy test
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
main.o leaves.o reference.o candidate.o: r5900_rt.h candidate_psp.h candidate_host.h
