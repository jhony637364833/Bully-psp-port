static unsigned build(unsigned bones,unsigned n,unsigned inf,unsigned batches,unsigned variant){
 
 for(unsigned b=0;b<bones;b++)for(unsigned r=0;r<4;r++)for(unsigned k=0;k<3;k++){
  float v=r<3?(r==k?1.0f:0.0f):(float)((int)((b*13+k*7)%31)-15)/8.0f;
  if(variant&1)v=(float)((int)(rnd()%129)-64)/32.0f;
  real(original+PAL+b*64+r*16+k*4,v);
 }
 unsigned at=65536+mesh_index*32768;
 for(unsigned batch=0;batch<batches;batch++){
  unsigned widths[4]={16,8,3,16};memset(attrs,0,sizeof(attrs));
  for(unsigned i=0;i<n;i++){
   for(unsigned k=0;k<3;k++)real(attrs[0]+i*16+k*4,(float)((int)(rnd()%257)-128)/16.0f);
   put(attrs[0]+i*16+12,(i%11==7)?0x8000u:0);
   for(unsigned k=0;k<2;k++)real(attrs[1]+i*8+k*4,(float)((int)(rnd()%257)-128)/32.0f);
   for(unsigned k=0;k<3;k++)attrs[2][i*3+k]=(uint8_t)rnd();
   for(unsigned k=0;k<inf;k++){
    unsigned bone=(i*7+k*11+batch*5)%bones;
    uint32_t v=raw(inf==1?1.0f:inf==2?.5f:inf==3?(k==2?.5f:.25f):.25f);
    put(attrs[3]+i*16+k*4,v|((bone+1)*4u));
   }
  }
  if(batch)for(unsigned k=0;k<4;k++)memcpy(attrs[k],previous[k]+(n-2)*widths[k],2*widths[k]);
  unsigned weights=0x240000+mesh_index*12288+batch*4096;memcpy(original+weights,attrs[3],n*16);
  put(original+at,0x30000000u+n);put(original+at+4,weights);put(original+at+8,0x01000104u);put(original+at+12,0x6c008003u|((n&255)<<16));at+=16;
  unsigned tag=at,cursor=at+8;
  put(original+cursor,0x01000104u);cursor+=4;put(original+cursor,0x05000000u);cursor+=4;
  for(unsigned k=0;k<3;k++){
   unsigned cmd=k==0?0x6c:k==1?0x64:0x6a;
   put(original+cursor,(cmd<<24)|((n&255)<<16)|0x8000u|k);cursor+=4;
   unsigned length=(n*widths[k]+3)&~3u;memcpy(original+cursor,attrs[k],n*widths[k]);cursor+=length;
  }
  put(original+cursor,0x04000000u|n);cursor+=4;put(original+cursor,batch?0x17000000u:0x15000000u);cursor+=4;
  unsigned end=(cursor+15)&~15u;put(original+tag,0x10000000u+(end-tag-16)/16);at=end;
  memcpy(previous,attrs,sizeof(attrs));
 }
 put(original+at,0x60000000u);at+=16;return at;
}
