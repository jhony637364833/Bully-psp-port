void candidate_enable(int);
void candidate_save(const R5900Ctx*,R5900CSave*);
void candidate_restore(R5900Ctx*,const R5900CSave*);
