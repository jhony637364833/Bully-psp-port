"""Check actual all-fail bounds and command/state restoration against build05."""
from pathlib import Path
import tempfile,subprocess,os
repo=Path(__file__).resolve().parents[1]
game=repo/'app/games/SLUS-21269_v1.02/src'
s=(game/'psp/world_display.c').read_text()
alpha=s[s.index('static unsigned alpha_reference'):s.index('static void apply_state')]
helper=s[s.index('static int all_alpha_fail'):s.index('void bully_world_begin')]
head='#include "native_state.h"\n#include <assert.h>\n#include <stdio.h>\nstatic const BullyNativeState *material_state;\nstatic unsigned queued;\nstatic struct {unsigned color;} verts[384];\n'
with tempfile.TemporaryDirectory(prefix='bully-alpha-fail-') as tmp:
 p=Path(tmp);(p/'bounds.c').write_text(head+alpha+helper+(repo/'tests/alpha_fail_bounds_main.inc').read_text())
 subprocess.run([os.environ.get('CC','cc'),'-O2','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+str(game),str(p/'bounds.c'),'-o',str(p/'bounds')],check=True)
 subprocess.run([str(p/'bounds')],check=True)
 constants=s[s.index('static const int alpha_functions'):s.index('static void apply_state')]
 needs=s[s.index('static int needs_alpha_fail_pass'):s.index('void bully_world_begin')]
 flush=s[s.index('static void flush_vertices'):s.index('static int init')]
 source=(repo/'tests/alpha_fail_command_head.inc').read_text()+constants+needs+(repo/'tests/alpha_flush_test05_reference.inc').read_text()+flush+(repo/'tests/alpha_fail_command_main.inc').read_text()
 (p/'commands.c').write_text(source)
 subprocess.run([os.environ.get('CC','cc'),'-O2','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+str(game),str(p/'commands.c'),'-o',str(p/'commands')],check=True)
 subprocess.run([str(p/'commands')],check=True)
