from pathlib import Path
import argparse,shutil
r=Path(__file__).resolve().parents[1];t=r/'tests';g=r/'app/games/SLUS-21269_v1.02/src'
a=argparse.ArgumentParser();a.add_argument('output',type=Path);d=a.parse_args().output.resolve()
for n in ['gpu','parser']:(d/n).mkdir(parents=True,exist_ok=True)
s=(g/'psp/world_display.c').read_text();raw=s[s.index('static inline int raw_short'):s.index('static void draw_accelerated_strip')]
(d/'gpu/main.c').write_text((t/'gpu_raw_head.inc').read_text()+(t/'gpu_raw_reference_92.inc').read_text()+raw+'\n'+(t/'gpu_raw_main.inc').read_text())
(d/'gpu/Makefile').write_text('TARGET = gpu_raw\nOBJS = main.o native_light.o\nINCDIR = '+str(g)+'\nVPATH = '+str(g)+'\nCFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -fno-fast-math -frounding-math -ffp-contract=off\nBUILD_PRX = 1\nLIBS = -lm\nEXTRA_TARGETS = EBOOT.PBP\nPSPSDK = $(shell psp-config --pspsdk-path)\ninclude $(PSPSDK)/lib/build.mak\n')
for src,dst in [('compressed_raw_main.c','main.c'),('compressed_raw_reference_92.inc','baseline.c'),('compressed_raw_cases.inc','original.inc')]:shutil.copy2(t/src,d/'parser'/dst)
shutil.copy2(g/'native_mesh.h',d/'parser/native_mesh.h')
s=(g/'native_mesh.c').read_text();s+='\nfloat candidate_fixed(const uint8_t*p){return ((uintptr_t)p&1u)?fixed128(p):fixed128_aligned(p);}\nunsigned candidate_half(const uint8_t*p){return ((uintptr_t)p&1u)?half(p):half_aligned(p);}\n';(d/'parser/candidate.c').write_text(s)
(d/'parser/Makefile').write_text('.DEFAULT_GOAL := all\nTARGET = compressed_raw\nOBJS = main.o baseline.o candidate.o\nINCDIR = .\nCFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off\nBUILD_PRX = 1\nLIBS = -lm -lpsppower\nEXTRA_TARGETS = EBOOT.PBP\nPSPSDK = $(shell psp-config --pspsdk-path)\ninclude $(PSPSDK)/lib/build.mak\n$(OBJS): native_mesh.h\nmain.o: original.inc\n')
