#include "native_mesh.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Halfword loads",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
PSP_MAIN_THREAD_STACK_SIZE_KB(128);
static void mode(unsigned m,unsigned fs){unsigned x=m|(fs<<24)|0x80007c;__asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(x):"memory");}
static unsigned status(void){unsigned x;__asm__ volatile("cfc1 %0,$31":"=r"(x)::"memory");return x;}
#else
#include <fenv.h>
static void mode(unsigned m,unsigned fs){(void)fs;int r[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(r[m]);feclearexcept(FE_ALL_EXCEPT);}
static unsigned status(void){return fetestexcept(FE_ALL_EXCEPT);}
#endif
#include "original.inc"
static uint8_t ram[65536];
struct Seen {uint64_t hash;unsigned calls,vertices;};
static void see(const BullyNativeVertex*v,size_t n,void*ctx){
 struct Seen*s=ctx;const unsigned char*p=(const unsigned char*)v;
 s->hash=(s->hash^n)*1099511628211ull;
 for(size_t j=0;j<n*sizeof(*v);j++)s->hash=(s->hash^p[j])*1099511628211ull;
 s->calls++;s->vertices+=(unsigned)n;
}
static size_t chain(unsigned at,unsigned n,unsigned batches){
 for(unsigned j=0;j<batches;j++){
  unsigned p=at+8;put(ram,p,0x01000104);p+=4;put(ram,p,0x05000000);p+=4;
  const unsigned cmd[]={0x69,0x65,0x6f,0x6f},imm[]={0x8000,0x8001,0xc002,0xc003},width[]={6,4,2,2};
  for(unsigned k=0;k<4;k++){
   put(ram,p,(cmd[k]<<24)|((n&255)<<16)|imm[k]);p+=4;
   /* Each batch repeats equal vertices; cover the entire signed16 range. */
   unsigned value=random_word();
   for(unsigned i=0;i<n*width[k];i++)ram[p+i]=(uint8_t)(value>>(8*(i%width[k]%4)));
   p+=(n*width[k]+3)&~3u;
  }
  put(ram,p,0x04000000|n);p+=4;put(ram,p,j?0x17000000:0x15000000);p+=4;p=(p+15)&~15u;
  put(ram,at,0x10000000|((p-at-16)/16));
  if(j){unsigned prev=at-(p-at);memcpy(ram+at+16,ram+prev+16,p-at-16);put(ram,p-4,0); /* rebuild launch below */
   unsigned q=at+16;for(unsigned k=0;k<4;k++)q+=4+((n*width[k]+3)&~3u);put(ram,q,0x04000000|n);put(ram,q+4,0x17000000);
  }
  at=p;
 }
 put(ram,at,0x60000000);put(ram,at+12,0x11000000);return at+16;
}
static uint8_t side_a[65536],side_b[65536];
struct Mutate {struct Seen seen;uint8_t *ram;unsigned mutate;};
static void mutate_visit(const BullyNativeVertex*v,size_t n,void*ctx){
 struct Mutate *m=ctx;see(v,n,&m->seen);
 if(m->mutate && m->seen.calls==1)m->ram[32]^=0x80;
}
static void side_effects(unsigned m,unsigned fs){
 for(unsigned t=0;t<128;t++){
  memset(ram,0,sizeof ram);size_t bytes=chain(16,3+t%12,3);
  memcpy(side_a,ram,sizeof ram);memcpy(side_b,ram,sizeof ram);
  struct Mutate sa={{0},side_a,t%2},sb={{0},side_b,t%2};size_t ac=99,au=99,bc=99,bu=99;
  unsigned offset=t%3==0?16:t%3==1?64:4096;
  mode(m,fs);int ar=baseline_bully_compressed_chain(side_a,bytes,16,(BullyNativeVertex*)(side_a+offset),mutate_visit,&sa,&ac,&au);unsigned af=status();
  mode(m,fs);int br=bully_compressed_chain(side_b,bytes,16,(BullyNativeVertex*)(side_b+offset),mutate_visit,&sb,&bc,&bu);unsigned bf=status();
  assert(ar==br&&ac==bc&&au==bu&&af==bf&&!memcmp(&sa.seen,&sb.seen,sizeof sa.seen)&&!memcmp(side_a,side_b,sizeof side_a));
 }
}
float baseline_fixed(const uint8_t*);float candidate_fixed(const uint8_t*);
unsigned baseline_half(const uint8_t*);unsigned candidate_half(const uint8_t*);
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);freopen("halfword.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
#endif
 unsigned cases=0;uint8_t buf[8];
 for(unsigned m=0;m<4;m++)for(unsigned fs=0;fs<2;fs++){
  for(unsigned at=0;at<4;at++)for(unsigned v=0;v<65536;v++){
   memset(buf,0x97,sizeof buf);buf[at]=(uint8_t)v;buf[at+1]=(uint8_t)(v>>8);
   mode(m,fs);float a=baseline_fixed(buf+at);unsigned af=status();
   mode(m,fs);float b=candidate_fixed(buf+at);unsigned bf=status();
   if(memcmp(&a,&b,4)||af!=bf||baseline_half(buf+at)!=candidate_half(buf+at)){printf("ERROR half value=%u offset=%u mode=%u fs=%u fcr=%08x/%08x\n",v,at,m,fs,af,bf);return 1;}
   cases++;
  }
  mode(m,fs);original_checks();side_effects(m,fs);printf("mode=%u fs=%u pass\n",m,fs);
 }
 printf("COMPLETE values=%u parser=80000 sideeffects=1024 errors=0\n",cases);fflush(stdout);
#ifdef __PSP__
 fclose(stdout);sceKernelExitGame();
#endif
 return 0;
}
