"""Reproduce palette-reuse differential checks against the frozen build22 decoder."""
from pathlib import Path
import argparse

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
 p.add_argument('--output',type=Path,required=True)
 a=p.parse_args();here=Path(__file__).parent;d=a.output;d.mkdir(parents=True,exist_ok=True)
 for name in ['reference','candidate']:
  sub=d/name;sub.mkdir(exist_ok=True)
  for header in ['native_skin.h','native_mesh.h']:(sub/header).write_bytes((a.app/'games/SLUS-21269_v1.02/src'/header).read_bytes())
  source=here/'skin_palette_reference.inc' if name=='reference' else a.app/'games/SLUS-21269_v1.02/src/native_skin.c'
  (sub/'native_skin.c').write_bytes(source.read_bytes())
  (d/(name+'.c')).write_text('#define bully_skin_chain '+name+'_skin_chain\n#include "'+name+'/native_skin.c"\n')
 for src,dst in [('skin_palette_main.c','main.c'),('skin_palette_Makefile.inc','Makefile')]:(d/dst).write_bytes((here/src).read_bytes())
 print('Expected COMPLETE cases=26896 ... errors=0; success totals differ across host/PSP FTZ.')

if __name__=='__main__':main()
