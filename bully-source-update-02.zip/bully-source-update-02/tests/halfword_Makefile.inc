.DEFAULT_GOAL := all
TARGET = halfword_loads
OBJS = main.o baseline.o candidate.o
INCDIR = .
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off
BUILD_PRX = 1
LIBS = -lm -lpsppower
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Compressed parse plans
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
$(OBJS): native_mesh.h
main.o: original.inc
