.DEFAULT_GOAL := all
TARGET = texture_cache
OBJS = main.o reference.o texconv.o
BULLY_SRC = @SOURCE@
INCDIR = . $(BULLY_SRC)
VPATH = $(BULLY_SRC)
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -fno-fast-math
reference.o: reference.c
	$(CC) $(CFLAGS) $(addprefix -I,$(INCDIR)) -Dbully_native_texture=reference_texture -c $< -o $@
BUILD_PRX = 1
LIBS = -lm
EXTRA_TARGETS = EBOOT.PBP
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
