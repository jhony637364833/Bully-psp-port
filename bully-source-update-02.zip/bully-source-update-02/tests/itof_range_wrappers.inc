#include "LABEL/r5900_rt.h"
void fn_00129480(R5900Ctx*);
void fn_001294e0(R5900Ctx*);
void fn_0012c010(R5900Ctx*);
void fn_001313d0(R5900Ctx*);
uint32_t LABEL_byte(uint32_t x){return vu0_itof1(x&255,0);}
uint32_t LABEL_generic(uint32_t x,unsigned s){return vu0_itof1(x,s);}
uint32_t LABEL_known24(uint32_t x){return vu0_itof1(x&0xffffffu,0);}
void LABEL_prefix(R5900Ctx *c)
{
    uint64_t r1 = c->r[1].d[0], r3 = c->r[3].d[0], r4 = c->r[4].d[0], r5 = c->r[5].d[0], r6 = c->r[6].d[0], r7 = c->r[7].d[0], r17 = c->r[17].d[0];
    int32_t r2 = (int32_t)c->r[2].d[0], r8 = (int32_t)c->r[8].d[0], r16 = (int32_t)c->r[16].d[0], r28 = (int32_t)c->r[28].w[0], r29 = (int32_t)c->r[29].w[0], r31 = (int32_t)c->r[31].d[0];
    uint32_t f0 = c->fpr[0].u, f1 = c->fpr[1].u, f2 = c->fpr[2].u, f3 = c->fpr[3].u, f20 = c->fpr[20].u;
    const R5900Mem m_ = {c->ram, c->ram_mask};
    r29 = (int32_t)(SX32((uint32_t)((uint64_t)(int64_t)r29) + (uint32_t)-272));
    rm_sd(m_, (uint32_t)(((uint64_t)(int64_t)r29) + 48), ((uint64_t)(int64_t)r31));
    { c->r[29].w[0] = (uint32_t)r29; rm_sq(m_, (uint32_t)(c->r[29].d[0] + 32), &c->r[17]);  }
    {  rm_sq(m_, (uint32_t)(c->r[29].d[0] + 16), &c->r[16]);  }
    r17 = (r6 + 0ull);
    rm_sw(m_, (uint32_t)(((uint64_t)(int64_t)r29) + 0), f20);
    r6 = (r17 & 0xffffull);
    {  rm_lq(m_, (uint32_t)(c->r[4].d[0] + 0), &c->r[3]); r3 = c->r[3].d[0]; }
    r7 = SX32(rm_lw(m_, (uint32_t)(((uint64_t)(int64_t)r28) + -5176)));
    r4 = SX32((uint32_t)r6 << 1);
    r4 = SX32((uint32_t)r4 + (uint32_t)r6);
    r6 = SX32((uint32_t)r4 << 2);
    r4 = SX32(rm_lw(m_, (uint32_t)(r7 + 36)));
    {  rm_sq(m_, (uint32_t)(c->r[29].d[0] + 192), &c->r[3]);  }
    r6 = SX32((uint32_t)r4 + (uint32_t)r6);
    {  rm_lq(m_, (uint32_t)(c->r[5].d[0] + 0), &c->r[3]); r3 = c->r[3].d[0]; }
    {  rm_sq(m_, (uint32_t)(c->r[29].d[0] + 208), &c->r[3]);  }
    r4 = SX32(rm_lw(m_, (uint32_t)(r6 + 0)));
    r3 = SX32(rm_lw(m_, (uint32_t)(r6 + 4)));
    { c->r[4].d[0] = r4; c->r[4] = mmi_pextlb((R5900Reg128){{0, 0}}, c->r[4]); r4 = c->r[4].d[0]; }
    { c->r[3].d[0] = r3; c->r[3] = mmi_pextlb((R5900Reg128){{0, 0}}, c->r[3]); r3 = c->r[3].d[0]; }
    {  c->r[4] = mmi_pextlb((R5900Reg128){{0, 0}}, c->r[4]); r4 = c->r[4].d[0]; }
    {  c->r[3] = mmi_pextlb((R5900Reg128){{0, 0}}, c->r[3]); r3 = c->r[3].d[0]; }
    {  c->vu0.vf[6] = c->r[4];  }
    vu0_itof(c, 0xe, 6, 6, 0);
    {  c->vu0.vf[7] = c->r[3];  }
    vu0_itof(c, 0xe, 7, 7, 0);
 c->r[1].d[0] = r1; c->r[3].d[0] = r3; c->r[4].d[0] = r4; c->r[5].d[0] = r5; c->r[6].d[0] = r6; c->r[7].d[0] = r7; c->r[17].d[0] = r17; c->r[2].d[0] = (uint64_t)(int64_t)r2; c->r[8].d[0] = (uint64_t)(int64_t)r8; c->r[16].d[0] = (uint64_t)(int64_t)r16; c->r[28].d[0] = (uint64_t)(int64_t)r28; c->r[29].d[0] = (uint64_t)(int64_t)r29; c->r[31].d[0] = (uint64_t)(int64_t)r31; c->fpr[0].u = f0; c->fpr[1].u = f1; c->fpr[2].u = f2; c->fpr[3].u = f3; c->fpr[20].u = f20;
}
void LABEL_vu(R5900Ctx*c,unsigned dest,int t,int s,unsigned shift){vu0_itof(c,dest,t,s,shift);}
