#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "r5900_rt.h"
static unsigned char ram[0x100000];
static int exists, cwd, fail, calls[32], ncall, checks;
#define MAN 0x10000u
#define GP 0x20000u
static void check(int yes){++checks;if(!yes){fprintf(stderr,"FAIL check %d fail=%d exists=%d cwd=%d calls=%d\n",checks,fail,exists,cwd,ncall);exit(1);}}
static void result(R5900Ctx*c,int op,int value){calls[ncall++]=op;c->r[2].d[0]=(unsigned)value;}
void fn_00433c50(R5900Ctx*c){result(c,1,1);}
void fn_00435380(R5900Ctx*c){int root=c->r[5].w[0]!=0x5b2a30;result(c,root?2:5,fail==(root?2:5)?0:1);if(c->r[2].w[0])cwd=!root;}
void fn_004353f0(R5900Ctx*c){result(c,3,exists);}
void fn_00435310(R5900Ctx*c){result(c,4,fail==4?0:1);if(c->r[2].w[0])exists=1;}
void fn_004341d0(R5900Ctx*c){check(cwd==1);result(c,6,fail==6?0:1);}
void fn_00434d60(R5900Ctx*c){result(c,7,0);}
void fn_00435680(R5900Ctx*c){check(cwd==1);result(c,8,fail==8?0:1);}
void fn_004349a0(R5900Ctx*c){check(cwd==1);result(c,9,fail==9?0:1);}
void fn_00434cd0(R5900Ctx*c){check(cwd==1);result(c,10,fail==10?0:1);}
void fn_00435810(R5900Ctx*c){check(cwd==1);result(c,11,fail==11?0:1);}
void fn_00434c30(R5900Ctx*c){result(c,12,0);}
#include "folder-base.inc"
#include "folder-candidate.inc"
static R5900Ctx init(int state,int free_space,int full){
 memset(ram,0,sizeof ram);R5900Ctx c={0};c.ram=ram;c.ram_mask=sizeof ram-1;c.r[4].d[0]=MAN;c.r[5].d[0]=full;c.r[28].d[0]=GP;c.r[29].d[0]=0xf0000;
 R5900Mem m={ram,sizeof ram-1};rmb_sw(m,MAN,1664,state);rmb_sw(m,MAN,1672,free_space);rmb_sw(m,GP,-2740,MAN);rmb_sw(m,GP,-19232,0x12345);exists=0;cwd=0;ncall=0;return c;
}
int main(void){
 for(int full=0;full<2;++full)for(int f=0;f<=11;++f){
  fail=f;R5900Ctx c=init(4,173,full);candidate_folder(&c);
  check(c.r[29].w[0]==0xf0000);
  if(f==0||f==1||f==3||f==7){check(c.r[2].w[0]==1);check(cwd==1);check(ncall>=11);}
  else check(c.r[2].w[0]==0);
 }
 /* Existing-directory behavior must remain byte-for-byte identical. */
 for(int full=0;full<2;++full)for(int f=0;f<=11;++f){
  unsigned char saved[sizeof ram];int saved_calls[32];fail=f;
  R5900Ctx a=init(6,200,full);exists=1;baseline_folder(&a);memcpy(saved,ram,sizeof ram);memcpy(saved_calls,calls,sizeof calls);int nc=ncall,cd=cwd;
  R5900Ctx b=init(6,200,full);exists=1;candidate_folder(&b);
  check(a.r[2].d[0]==b.r[2].d[0]);check(!memcmp(saved,ram,sizeof ram));check(nc==ncall&&cd==cwd);check(!memcmp(saved_calls,calls,nc*sizeof(int)));
 }
 for(int state=0;state<40;++state)for(int space=172;space<=173;++space){
  fail=0;R5900Ctx c=init(state,space,1);candidate_folder(&c);
  if((state==4||state==6)&&space>=173)check(c.r[2].w[0]==1&&cwd==1);
  else check(c.r[2].w[0]==0&&cwd==0);
 }
 puts("PASS folder setup: new/existing directories, state/space boundaries, injected failures, complete RAM and operation-order comparisons");printf("checks=%d\n",checks);return 0;
}
