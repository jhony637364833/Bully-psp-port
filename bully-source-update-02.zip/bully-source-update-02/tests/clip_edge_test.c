/* Compare complete polygons with the supplied immediately preceding clipper.
 * Synthetic fixtures only; no game data. Run on host and PSP. */
#include "world_clip.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully clip edge test",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
#define CASES 3000
#else
#define CASES 100000
#endif
int edge_reference_clip(const BullyClipVertex*,float,float,BullyClipVertex*);
static uint32_t seed=0x6bc917u;
static uint32_t random_word(void){seed=seed*1664525u+1013904223u;return seed;}
static float random_float(void){return (random_word()>>8)*(1.0f/16777216.0f);}
static unsigned checks,errors;
static void compare(const BullyClipVertex in[3],float near,float far) {
    BullyClipVertex a[10],b[10];
    int na=edge_reference_clip(in,near,far,a),nb=bully_clip_triangle(in,near,far,b);
    checks++;
    if(na!=nb || (na && memcmp(a,b,(size_t)na*sizeof(*a))))errors++;
}
static uint64_t now(void) {
#ifdef __PSP__
    return sceKernelGetSystemTimeWide();
#else
    return (uint64_t)clock()*1000000/CLOCKS_PER_SEC;
#endif
}
static void bench(FILE *log,const char *name,const BullyClipVertex in[3]) {
    BullyClipVertex out[10];unsigned vertices=0;
    uint64_t start=now();
    for(int i=0;i<10000;i++)vertices+=(unsigned)edge_reference_clip(in,1,100,out);
    uint64_t middle=now();
    for(int i=0;i<10000;i++)vertices+=(unsigned)bully_clip_triangle(in,1,100,out);
    uint64_t end=now();
    fprintf(log,"%s: before_us=%llu after_us=%llu vertices=%u\n",name,
            (unsigned long long)(middle-start),(unsigned long long)(end-middle),vertices);
}
int main(void) {
    const uint32_t edge[]={0,0x80000000u,1,0x80000001u,0x007fffffu,
        0x807fffffu,0x00800000u,0x80800000u,0x3f7fffffu,0x3f800000u,
        0x3f800001u,0xbf800000u,0x7f7fffffu,0xff7fffffu};
    for(unsigned n=0;n<CASES;n++) {
        BullyClipVertex in[3];
        for(int i=0;i<3;i++) {
            for(int k=0;k<3;k++){in[i].p[k]=random_float()*150-25;in[i].color[k]=random_float()*255;}
            for(int k=0;k<2;k++)in[i].uv[k]=random_float()*4-2;
            in[i].alpha=random_float()*255;
        }
        if(n%4==0)for(int i=0;i<3;i++) {
            in[i].p[2]=2+random_float()*97;
            in[i].p[0]=random_float()*in[i].p[2];in[i].p[1]=random_float()*in[i].p[2];
        }
        compare(in,1,100);
        /* Exact plane boundaries, signed zeros, subnormals and finite extremes. */
        if(n<sizeof(edge)/sizeof(*edge))for(int lane=0;lane<3;lane++)for(int v=0;v<3;v++) {
            BullyClipVertex special[3];memcpy(special,in,sizeof special);
            memcpy(&special[v].p[lane],&edge[n],sizeof(float));compare(special,1,100);
        }
        if(n%97==0) {in[0].alpha=NAN;compare(in,1,100);}
        if(n%101==0) {in[1].p[2]=INFINITY;compare(in,1,100);}
        if(n%103==0) {compare(in,0,100);compare(in,1,1);compare(in,NAN,100);}
    }
#ifdef __PSP__
    FILE *log=fopen("clip-edge.log","w");
#else
    FILE *log=stdout;
#endif
    if(!log)return 2;
    fprintf(log,"clip-edge checks=%u errors=%u\n",checks,errors);
    BullyClipVertex in[3]={{{1,1,2},{12,34,56},{0,0},37},
        {{2,1,3},{78,90,12},{1,0},129},{{1,3,4},{34,56,78},{0,1},255}};
    bench(log,"visible",in);
    in[0].p[0]=-1;bench(log,"side crossing",in);
    in[1].p[1]=5;in[2].p[2]=101;bench(log,"multiple planes",in);
#ifdef __PSP__
    fclose(log);sceKernelExitGame();
#endif
    return errors?1:0;
}
