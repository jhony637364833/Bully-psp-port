# CPU fallback helper fixture. Accelerated rendering is tested separately by the full GPU fixtures.
from pathlib import Path
import subprocess,struct,json
import argparse,tempfile
r=Path(__file__).resolve().parents[1];t=r/'tests';a=argparse.ArgumentParser();a.add_argument('--output',type=Path);args=a.parse_args();scratch=tempfile.TemporaryDirectory(prefix='bully-ge-clip-');b=args.output.resolve() if args.output else Path(scratch.name);b.mkdir(parents=True,exist_ok=True);g=r/'app/games/SLUS-21269_v1.02/src'
s=(r/'tests/renderer_differential.py').read_text();head=s.split("head='''",1)[1].split("'''",1)[0].replace('#include <stdio.h>','#include <stdio.h>\n#include <fenv.h>')
head+=(t/'renderer_fpu_test.inc').read_text()
main=(t/'gpu_guard_host_main.inc').read_text()
results={}
for name in ['reference','candidate']:
 body=((t/'gpu_guard_reference.inc') if name=='reference' else (g/'psp/world_display.c')).read_text();body=body[body.index('static unsigned channel'):body.index('void bully_world_draw')].split('/* GPU strip dispatch.',1)[0]
 source=b/('host-'+name+'.c');source.write_text(head+body+main)
 cmd=['gcc','-O2','-std=gnu11','-Wall','-Wextra','-Wno-misleading-indentation','-fno-fast-math','-fno-math-errno','-frounding-math','-ffp-contract=off','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(g),str(source),str(g/'native_light.c'),str(g/'world_clip.c'),'-lm','-o',str(b/('host-'+name))]
 if name=='candidate':cmd.insert(1,'-DCANDIDATE')
 (b/('host-'+name+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n');subprocess.run(cmd,check=True)
 with (b/('host-'+name+'.bin')).open('wb') as output:subprocess.run([str(b/('host-'+name))],stdout=output,check=True)
 data=(b/('host-'+name+'.bin')).read_bytes();offset=0;rows=[]
 while offset<len(data):
  rm,test,count,triangles=struct.unpack_from('4I',data,offset);offset+=16;rows.append((rm,test,count,triangles,data[offset:offset+count*24]));offset+=count*24
 results[name]=rows
assert len(results['reference'])==len(results['candidate'])==12800
exact=changed=0
for before,after in zip(results['reference'],results['candidate']):
 assert before[:2]==after[:2]
 if before[1]%8 in (0,1,2,3,5,6):assert before==after,(before[:4],after[:4]);exact+=1
 else:changed+=before!=after
print('PASS12800cases/all4rounding:9600inside/near/far/large/invalid/extreme-plane outputs exact;3200GEcases safety/input/UV/color/order checks; changed',changed,'ASanUBSan')
