.DEFAULT_GOAL := all
TARGET = strip_rotate
OBJS = main.o native_light.o world_clip.o
BULLY_SRC = /home/vercel-sandbox/workspace/repos/github.com/jhonmarston1973-cpu/bully-psp/app/games/SLUS-21269_v1.02/src
INCDIR = . $(BULLY_SRC)
VPATH = $(BULLY_SRC)
CFLAGS = -O2 -G0 -Wall -fno-fast-math -frounding-math -ffp-contract=off
BUILD_PRX = 1
LIBS = -lm
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully strip rotate check
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
