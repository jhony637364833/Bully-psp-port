#include "native_texture_alpha.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
static uint32_t seed=0x410972;
static uint32_t next(void){seed=seed*1664525u+1013904223u;return seed;}
static size_t swz(size_t x,size_t y,size_t pitch){return(y/8)*(pitch*8)+(y%8)*16+(x/16)*128+x%16;}
int main(void){
 uint8_t raw[65536];unsigned exact=0,conservative=0,opaque_witnesses=0,partial_witnesses=0;
 for(unsigned test=0;test<30000;test++){
  BullyNativeTexture tex={0};TcPspTex*t=&tex.texture;TcPspLevel*l=&t->level[0];
  unsigned p4=test&1;size_t entries=p4?16:256;
  t->psm=p4?TC_GU_T4:TC_GU_T8;t->nlevels=1;t->clut_entries=entries;t->clut_psm=TC_GU_8888;t->swizzled=(test>>1)&1;
  l->width=1u<<(4+next()%4);l->height=1u<<(3+next()%4);l->bufw=l->width+(test%5==0?16:0);l->rows=l->height+(test%7==0?8:0);
  size_t pitch=l->bufw/(p4?2:1);if(t->swizzled && pitch%16){l->bufw+=16;pitch=l->bufw/(p4?2:1);}
  l->offset=16;l->bytes=pitch*l->rows;t->clut_offset=l->offset+l->bytes+16;t->clut_bytes=entries*4;t->total_bytes=t->clut_offset+t->clut_bytes;
  assert(t->total_bytes<=sizeof raw);memset(raw,0x00,sizeof raw);
  for(unsigned i=0;i<entries;i++)raw[t->clut_offset+i*4+3]=test%3==0?(i?255:0):test%3==1?(i?160+i%32:0):(next()>>24);
  unsigned image_min=255;
  for(unsigned y=0;y<l->height;y++)for(unsigned x=0;x<l->width;x++){
   unsigned index=test%3<2?1+next()%(entries-1):next()%entries;
   unsigned alpha=raw[t->clut_offset+index*4+3];if(alpha<image_min)image_min=alpha;
   size_t xb=p4?x/2:x,at=l->offset+(t->swizzled?swz(xb,y,pitch):y*pitch+xb);
   if(p4){unsigned shift=(x&1)*4;raw[at]=(uint8_t)((raw[at]&~(15u<<shift))|(index<<shift));}else raw[at]=index;
  }
  unsigned lower=bully_texture_alpha_minimum(&tex,raw,sizeof raw);
  assert(lower<=image_min);
  if(l->width==l->bufw && l->height==l->rows){assert(lower==image_min);exact++;if(image_min==255)opaque_witnesses++;if(image_min>=160&&image_min<255)partial_witnesses++;}
  else conservative++;
  // Hostile lengths and offsets must fail before any out-of-range read.
  BullyNativeTexture invalid=tex;invalid.texture.clut_offset=UINT32_MAX;assert(!bully_texture_alpha_minimum(&invalid,raw,sizeof raw));
  invalid=tex;invalid.texture.level[0].offset=UINT32_MAX;assert(!bully_texture_alpha_minimum(&invalid,raw,sizeof raw));
  invalid=tex;invalid.texture.level[0].bytes=UINT32_MAX;assert(!bully_texture_alpha_minimum(&invalid,raw,sizeof raw));
  invalid=tex;invalid.texture.clut_bytes=0;assert(!bully_texture_alpha_minimum(&invalid,raw,sizeof raw));
  invalid=tex;invalid.texture.nlevels=2;assert(!bully_texture_alpha_minimum(&invalid,raw,sizeof raw));
  invalid=tex;invalid.texture.psm=TC_GU_8888;assert(!bully_texture_alpha_minimum(&invalid,raw,sizeof raw));
  assert(!bully_texture_alpha_minimum(&tex,raw,t->total_bytes-1));
 }
 assert(opaque_witnesses&&partial_witnesses);
 unsigned pairs=0;
 for(unsigned a=0;a<256;a++)for(unsigned b=0;b<256;b++){
  unsigned lower=b==255?a:(a*b)>>8;
  // Opaque 255 modulation preserves vertex alpha; both other common integer
  // normalization conventions are bounded by division by256.
  unsigned divide256=b==255?a:(a*b)/256,divide255=(a*b)/255;
  assert(lower<=divide256&&lower<=divide255);pairs++;
 }
 printf("PASS textures=30000 exact=%u padded_conservative=%u opaque_witnesses=%u partial_witnesses=%u malformed=210000 modulation_pairs=%u\n",exact,conservative,opaque_witnesses,partial_witnesses,pairs);
 return 0;
}
