"""Generate exact 24-bit VITOF0 range checks against the original helper.

The frozen geometry prefix is the original fn_0037eeb0 through both VITOF0s.
Only local scalar flushes are added at its test boundary. Valid memory windows
satisfy the runtime's existing naturally aligned guest-access contract.
"""
from pathlib import Path
import argparse

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();d=a.output;d.mkdir(parents=True,exist_ok=True)
    here=Path(__file__).parent;header=(a.app/'runtime/r5900_rt.h').read_text()
    i=header.index('    /* Every nonnegative 24-bit integer')
    j=header.index('    uint32_t sign = x',i)
    reference=header[:i]+header[j:]
    i=reference.index('    /* Keep the architectural x/y/z/w order,')
    j=reference.index('\n}',i)
    reference=reference[:i]+'''    for (int i = 0; i < 4; i++)
        if (dest & (8u >> i)) c->vu0.vf[t].w[i] = vu0_itof1(vu0_lane(c, s, i), shift);'''+reference[j:]
    for label,text in [('reference',reference),('candidate',header)]:
        (d/label).mkdir(exist_ok=True);(d/label/'r5900_rt.h').write_text(text)
        (d/(label+'_test.c')).write_text((here/'itof_range_wrappers.inc').read_text().replace('LABEL',label))
    (d/'main.c').write_bytes((here/'itof_range_main.c').read_bytes())
    (d/'Makefile').write_bytes((here/'itof_range_Makefile.inc').read_bytes())
    print('Expected COMPLETE scalars=67108864 vectors=40000 lanes=278528 errors=0')

if __name__=='__main__':main()
