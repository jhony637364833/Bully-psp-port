static unsigned seed=1241;
static float randf(void){seed=seed*1664525u+1013904223u;return (seed>>8)*(1.0f/16777216);}
int main(void){
#ifdef __PSP__
 freopen("strip-memo.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
#endif
 BullyNativeVertex v[256],before[256];uint8_t skip[256];BullyNativeLight light={0};
 for(int k=0;k<3;k++){object_view.view[k][k]=1;light.gain[k]=.8f;light.material[k]=.5f;}
 object_view.near_plane=1;object_view.far_plane=100;light.blend=.35f;light.material_alpha=.5f;
 assert(bully_clip_memo_init(&clip_memo,clip_storage,2048,memo_read,memo_write,
#ifdef __PSP__
0x00020f80u
#else
0
#endif
));
 for(unsigned mode=0;mode<4;mode++)for(unsigned fs=0;fs<2;fs++)for(unsigned test=0;test<160;test++){
  setcsr(0);material_light=test%2?&light:0;size_t n=test==31?256:(test*2)%257;object_view.bones=test%3==0;clip_memo_enabled=test%11!=0;clip_memo_storage=test%13?clip_storage:0;
  for(size_t i=0;i<n;i++){
   memset(&v[i],0,sizeof(v[i]));v[i].color[3]=v[i].color_secondary[3]=128;
   for(int k=0;k<3;k++){v[i].position[k]=randf()*120-10;v[i].color[k]=randf()*255;v[i].color_secondary[k]=randf()*255;}
   if(test%4==0){v[i].position[2]=2+randf()*97;v[i].position[0]=randf()*v[i].position[2];v[i].position[1]=randf()*v[i].position[2];}
   if(test%17==0)v[i].position[0]=-200-randf()*10;
   if(test%19==0 && i==2)v[i].position[1]=NAN;
   if(test%23==0 && i==3)v[i].uv[0]=INFINITY;else v[i].uv[0]=randf()*2;
   v[i].uv[1]=randf()*2;
   skip[i]=test%7==0?1:test%7==1?0:(i%5==0);
  }
  memcpy(before,v,n*sizeof(*v));
  unsigned csr=mode|(fs?(1u<<24):0)|((test&2)?0x80007cu:0);
  setcsr(csr);recorded=queued=triangles=flushes=0;
  if(test%3)reference_draw_batch(v,n,0);else reference_draw_skin_batch(v,skip,n,0);
  flush_vertices();unsigned refcsr=getcsr(),refcount=recorded,reftri=triangles,refflush=flushes;
  memcpy(expected_sizes,flush_sizes,flushes*sizeof(*flush_sizes));
  memcpy(expected,record,recorded*sizeof(*record));assert(!memcmp(before,v,n*sizeof(*v)));
  for(unsigned repeat=0;repeat<3;repeat++){
  memset(record,0xa5,sizeof record);setcsr(csr);recorded=queued=triangles=flushes=0;
  if(test%3)candidate_draw_batch(v,n,0);else candidate_draw_skin_batch(v,skip,n,0);
  flush_vertices();unsigned candcsr=getcsr();
  if(memcmp(expected_sizes,flush_sizes,flushes*sizeof(*flush_sizes))||refcount!=recorded||reftri!=triangles||refflush!=flushes||refcsr!=candcsr||memcmp(record,expected,recorded*sizeof(*record))||memcmp(before,v,n*sizeof(*v))){
   printf("ERROR mode=%u case=%u n=%u count=%u/%u tri=%u/%u flush=%u/%u csr=%08x/%08x\n",mode,test,(unsigned)n,refcount,recorded,reftri,triangles,refflush,flushes,refcsr,candcsr);return 1;
  }
 }
 }
 assert(clip_memo.hits>1000);printf("MEMO hits=%u misses=%u\n",clip_memo.hits,clip_memo.misses);
 puts("COMPLETE cases=1280 cached_repeats=3 FS_modes=2 all_modes=4 vertex_bytes=exact triangles=exact flushes=exact source=unchanged fcr31=exact errors=0");
#ifdef __PSP__
 sceKernelExitGame();
#endif
 return 0;
}
