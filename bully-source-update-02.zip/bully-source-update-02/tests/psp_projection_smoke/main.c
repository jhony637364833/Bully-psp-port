#include <pspkernel.h>
#include <pspdisplay.h>
#include <string.h>
#include "native_object.h"
#include "native_skin.h"
#include "native_texture.h"
PSP_MODULE_INFO("Bully projection test",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER | THREAD_ATTR_VFPU);
int hle_ge_on;uint8_t *hle_ram;uint32_t hle_ram_end;uint64_t hle_frame;
void bully_world_enable(void);
void bully_world_camera_begin(uint32_t);
void bully_world_camera_end(uint32_t);
void bully_world_overlay_present(void);
void bully_world_draw(uint32_t,uint32_t);
int bully_native_object(const uint8_t *r,size_t b,uint32_t o,uint32_t c,BullyNativeVertex *s,BullyNativeObject *out) {
 (void)r;(void)b;(void)o;(void)c;(void)s;memset(out,0,sizeof(*out));
 for(int k=0;k<3;k++)out->view[k][k]=1;
 out->near_plane=1;out->far_plane=100;out->meshes=1;
 out->mesh[0].compressed=1;out->mesh[0].material=1;return 1;
}
int bully_native_texture(const uint8_t *r,size_t b,uint32_t m,void *dst,size_t cap,BullyNativeTexture *out) {
 (void)r;(void)b;(void)m;if(cap<4096)return 0;memset(out,0,sizeof(*out));
 out->texture.psm=3;out->texture.total_bytes=4096;
 out->texture.level[0].width=out->texture.level[0].height=out->texture.level[0].bufw=32;
 out->filter=2;out->wrap_u=out->wrap_v=3;
 for(int y=0;y<32;y++)for(int x=0;x<32;x++)((uint32_t*)dst)[y*32+x]=0xff000000u|(x*255/31);
 return 1;
}
int bully_compressed_chain(const uint8_t *r,size_t b,uint32_t a,BullyNativeVertex *s,BullyNativeVisit visit,void *ctx,size_t *n,size_t *used) {
 (void)r;(void)b;(void)a;memset(s,0,4*sizeof(*s));
 for(int i=0;i<4;i++) {
  float z=i<2?1:4;
  s[i].position[0]=(i<2?.1f:.9f)*z;
  s[i].position[1]=(i%2?.8f:.2f)*z;s[i].position[2]=z;
  s[i].uv[0]=i<2?0:1;s[i].uv[1]=i%2;
  memset(s[i].color,128,4);
 }
 *n=4;*used=0;if(visit)visit(s,4,ctx);return 1;
}
int bully_native_decode(const uint8_t *r,size_t b,BullyNativeVertex *v,size_t cap,size_t *n) {return 0;}
int bully_skin_chain(const uint8_t *r,size_t b,uint32_t a,uint32_t p,unsigned bones,BullyNativeVertex *s,BullySkinVisit f,void *ctx,size_t *n,size_t *used,size_t *tris) {return 0;}
int main(void) {
 bully_world_enable();
 for(hle_frame=0;hle_frame<600;hle_frame++) {bully_world_camera_begin(1);bully_world_draw(1,1);bully_world_camera_end(1);bully_world_overlay_present();sceDisplayWaitVblankStart();}
 sceKernelExitGame();return 0;
}

#include "../texture_cache_unavailable.inc"

/* These fixtures synthesize expanded vertices rather than packed DMA data.
 * Keep using their original visitor; the raw bridge has its own differential
 * tests in prepare_raw_mesh.py. */
int bully_compressed_chain_raw(const uint8_t*r,size_t b,uint32_t a,
    BullyNativeVertex*s,BullyNativeVisit visit,BullyNativeRawVisit raw,
    void*ctx,size_t*n,size_t*used) {
    (void)raw;return bully_compressed_chain(r,b,a,s,visit,ctx,n,used);
}

void bully_overlay_flush(void){}
void bully_overlay_underlay_flush(void){}
int bully_native_object_cached(const uint8_t*r,size_t b,uint32_t o,uint32_t c,BullyNativeVertex*s,BullyNativeObject*out,BullyNativeSkinCache*cache){(void)cache;return bully_native_object(r,b,o,c,s,out);}
int bully_native_skin_replay(const BullyNativeSkinCache*c,unsigned mesh,BullySkinVisit visit,void*ctx){(void)c;(void)mesh;(void)visit;(void)ctx;return 0;}
