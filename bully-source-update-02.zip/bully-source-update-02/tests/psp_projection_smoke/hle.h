#include <stdint.h>
#include <stdio.h>
#include <string.h>
extern int hle_ge_on;
extern uint8_t *hle_ram;
extern uint32_t hle_ram_end;
extern uint64_t hle_frame;
#define LOG(...) ((void)0)

#include <stdlib.h>
static inline void *hle_plat_big_alloc(size_t n) { void *p=calloc(1,n); if(!p)abort();return p; }

static inline uint32_t gw(uint32_t a){uint32_t v;memcpy(&v,hle_ram+a,4);return v;}
