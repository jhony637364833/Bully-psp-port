#include "native_light.h"
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <float.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully lighting exact clamp",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
#define CASES 25000
#else
#include <fenv.h>
#define CASES 250000
#endif
void bully_test04_light_color(const BullyNativeVertex*,const BullyNativeLight*,float[3]);
float bully_test04_light_alpha(const BullyNativeVertex*,const BullyNativeLight*);
static unsigned seed=0x7ac34920;static unsigned rnd(void){seed=seed*1664525u+1013904223u;return seed;}
static float finite_value(void){uint32_t b=rnd();if((b&0x7f800000u)==0x7f800000u)b^=0x00800000u;float f;memcpy(&f,&b,4);return f;}
int main(void){unsigned checks=0;
#ifdef __PSP__
 freopen("light-compare.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
#else
 const int modes[]={FE_TONEAREST,FE_DOWNWARD,FE_UPWARD,FE_TOWARDZERO};
#endif
 for(unsigned mode=0;mode<4;mode++){
#ifdef __PSP__
 unsigned control=0x01000000u|mode;__asm__ volatile("ctc1 %0,$31"::"r"(control));
#else
 fesetround(modes[mode]);
#endif
 for(unsigned i=0;i<CASES;i++){
 BullyNativeVertex v={0};BullyNativeLight l={0};l.blend=finite_value();l.material_alpha=finite_value();l.monochrome=rnd()&1;
 for(unsigned k=0;k<4;k++){v.color[k]=rnd()>>24;v.color_secondary[k]=rnd()>>24;}
 for(unsigned k=0;k<3;k++){l.gain[k]=finite_value();l.material[k]=finite_value();}
 /* Exercise exact saturation boundaries, signed zero, subnormal gains,
  * finite blend overflow and zero-gain NaN intermediates deliberately. */
 if(i<4096){
  static const float gains[]={0.0f,-0.0f,1.0f,0x1p-149f,FLT_MIN,FLT_MAX};
  static const float blends[]={0,1,.5f,-3,FLT_MAX,-FLT_MAX};
  l.blend=blends[(i/256)%6];l.monochrome=(i/1536)&1;l.material_alpha=.5f;
  for(unsigned k=0;k<4;k++){v.color[k]=i&255;v.color_secondary[k]=255-(i&255);}
  for(unsigned k=0;k<3;k++){l.gain[k]=gains[(i/16+k)%6];l.material[k]=.5f;}
 }
 float a[3],b[3],aa,bb;bully_test04_light_color(&v,&l,a);bully_light_color(&v,&l,b);aa=bully_test04_light_alpha(&v,&l);bb=bully_light_alpha(&v,&l);
 for(unsigned k=0;k<3;k++)if(memcmp(a+k,b+k,4)){printf("color mismatch mode=%u case=%u channel=%u\n",mode,i,k);return 1;}
 if(memcmp(&aa,&bb,4)){printf("alpha mismatch mode=%u case=%u\n",mode,i);return 1;}checks++;
 }
 /* All byte pairs, both signed-zero blends, both color modes. */
 for(unsigned mono=0;mono<2;mono++)for(unsigned sign=0;sign<2;sign++)
 for(unsigned pair=0;pair<65536;pair++) {
  BullyNativeVertex v={0};BullyNativeLight l={0};float a[3],b[3];
  l.blend=sign?-0.0f:0.0f;l.monochrome=mono;
  for(unsigned k=0;k<3;k++) {
   v.color[k]=pair>>8;v.color_secondary[k]=pair&255;
   l.gain[k]=k==0?1.0f:k==1?-1.0f:0x1p-149f;
   l.material[k]=.5f;
  }
  bully_test04_light_color(&v,&l,a);bully_light_color(&v,&l,b);
  if(memcmp(a,b,sizeof(a))) {
   printf("zero blend mismatch mode=%u mono=%u sign=%u pair=%u\n",mode,mono,sign,pair);
   return 1;
  }
  checks++;
 }
 }printf("%u lighting comparisons, including exhaustive signed-zero blends, four rounding modes PASS\n",checks);
#ifdef __PSP__
 sceKernelExitGame();
#endif
 return 0;
}
