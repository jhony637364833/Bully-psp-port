#ifdef __PSP__
#include "r5900_rt.h"
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully sphere flags",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
PSP_MAIN_THREAD_STACK_SIZE_KB(128);
static void mode(unsigned m,unsigned fs){unsigned x=m|(fs<<24)|0x80007c;__asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(x):"memory");}
static unsigned status(void){unsigned x;__asm__ volatile("cfc1 %0,$31":"=r"(x)::"memory");return x;}
#else
#include "runtime_host.h"
#include <fenv.h>
static void mode(unsigned m,unsigned fs){(void)fs;int x[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(x[m]);feclearexcept(FE_ALL_EXCEPT);}
static unsigned status(void){return fetestexcept(FE_ALL_EXCEPT);}
#endif
#include <stdio.h>
#include <stdlib.h>
void baseline_sphere(R5900Ctx*);void candidate_sphere(R5900Ctx*);
static unsigned char ra[65536] __attribute__((aligned(16))),rb[65536] __attribute__((aligned(16)));
static R5900Ctx a,b,initial;
static unsigned seed=0x10422312;
static unsigned rnd(void){seed=seed*1664525u+1013904223u;return seed;}
static void fill(void*p,size_t n){unsigned char*s=p;while(n--)*s++=rnd()>>24;}
static void put(unsigned at,unsigned x){memcpy(ra+at,&x,4);}
/* Independent scalar interpretation of each discarded guest VSUB lane.
   Clamp by exponent, then force the single precision operation at runtime. */
static unsigned input(unsigned x){unsigned e=(x>>23)&255;return e==0?(x&0x80000000u):e==255?((x&0x80000000u)|0x7f7fffffu):x;}
static unsigned sub(unsigned x,unsigned y){union{float f;unsigned u;}s,t,r;s.u=input(x);t.u=input(y);volatile float fs=s.f,ft=t.f,z=fs-ft;r.f=z;return r.u;}
int main(void){FILE*f=stdout;
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);f=fopen("sphere.log","w");
#endif
 unsigned cases=0,rejects=0,accepts=0;
 unsigned edge[]={0,0x80000000u,1,0x80000001u,0x7fffffu,0x807fffffu,0x800000u,0x80800000u,0x3f800000u,0xbf800000u,0x7f7fffffu,0xff7fffffu,0x7f800000u,0xff800000u,0x7fc12345u};
 for(unsigned m=0;m<4;m++)for(unsigned fs=0;fs<2;fs++)for(unsigned t=0;t<4096;t++){
  mode(0,0);fill(&initial,sizeof initial);fill(ra,sizeof ra);initial.ram_mask=65535;initial.r[29].d[0]=0xe800;initial.r[4].d[0]=0x1000;initial.r[5].d[0]=0x2000;initial.r[6].d[0]=0x2100;
  for(unsigned k=0;k<4;k++){
   float x=(float)(int)(rnd()%2048)-1024.0f;put(0x1000+4*k,f2u(k==3?(float)(rnd()%64):x));
   put(0x2000+4*k,f2u(x+(float)(int)(rnd()%256)-128.0f));put(0x2100+4*k,f2u(x+(float)(int)(rnd()%256)-128.0f));
  }
  if(t<1024)for(unsigned k=0;k<4;k++){put(0x1000+4*k,edge[rnd()%15]);put(0x2000+4*k,edge[rnd()%15]);put(0x2100+4*k,edge[rnd()%15]);}
  if(t==1024){for(unsigned k=0;k<3;k++){put(0x1000+4*k,0);put(0x2000+4*k,f2u(-10));put(0x2100+4*k,f2u(10));}put(0x100c,f2u(1));}
  if(t==1025){for(unsigned k=0;k<3;k++){put(0x1000+4*k,f2u(30));put(0x2000+4*k,f2u(-10));put(0x2100+4*k,f2u(10));}put(0x100c,f2u(1));}
  memcpy(rb,ra,sizeof ra);a=initial;b=initial;a.ram=ra;b.ram=rb;
  mode(m,fs);baseline_sphere(&a);unsigned sign=0;
  for(unsigned k=0;k<3;k++){sign|=sub(a.vu0.vf[4].w[k],a.vu0.vf[2].w[k]);sign|=sub(a.vu0.vf[3].w[k],a.vu0.vf[5].w[k]);}
  unsigned flags=status(),reject=sign>>31;
  if(reject){a.vu0.vi[16]|=0x80;a.r[2].d[0]=0;ra[0xe7ff]=0;rejects++;}else accepts++;
  if(t==1024&&reject){fprintf(f,"ERROR inside rejected\n");return 1;}if(t==1025&&!reject){fprintf(f,"ERROR outside accepted\n");return 1;}
  mode(m,fs);candidate_sphere(&b);unsigned actual=status();a.ram=b.ram=0;
  if(memcmp(&a,&b,sizeof a)||memcmp(ra,rb,sizeof ra)||flags!=actual){fprintf(f,"ERROR m=%u fs=%u t=%u ctx=%d ram=%d flags=%08x/%08x result=%u/%u\n",m,fs,t,memcmp(&a,&b,sizeof a),memcmp(ra,rb,sizeof ra),flags,actual,(unsigned)a.r[2].w[0],(unsigned)b.r[2].w[0]);for(unsigned i=0;i<sizeof a;i++)if(((unsigned char*)&a)[i]!=((unsigned char*)&b)[i]){fprintf(f,"first_ctx_byte=%u\n",i);break;}fflush(f);return 1;}
  cases++;
 }
 fprintf(f,"COMPLETE %u original-predicate/full-context/RAM/FPU-status cases; reject=%u accept=%u errors=0\n",cases,rejects,accepts);fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
}
