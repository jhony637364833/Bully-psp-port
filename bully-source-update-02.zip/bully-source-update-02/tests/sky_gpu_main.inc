void bully_overlay_dma_begin(void);
void bully_overlay_dma_feed(unsigned,const void*,unsigned,uint32_t);
void bully_overlay_flush(void);
static uint64_t packet[128] __attribute__((aligned(16)));static unsigned words;
static void ad(unsigned reg,uint64_t value){packet[words++]=value;packet[words++]=reg;}
static void feed_sky(uint32_t color,unsigned z,unsigned sprite){
 words=2;ad(0,sprite?6:11);ad(0x18,0);ad(0x40,((uint64_t)447<<48)|((uint64_t)639<<16));
 ad(0x4c,0);ad(0x4e,sprite?UINT64_C(0x101000118):UINT64_C(0x1000118));ad(0x47,sprite?0x30000:0x50000);ad(0x42,0x44);ad(1,color);
 unsigned xy[6][2]={{0,0},{640,0},{0,448},{0,448},{640,0},{640,448}};
 if(sprite){ad(5,0);ad(5,128|(UINT64_C(128)<<16));}
 else for(unsigned i=0;i<6;i++)ad(5,xy[i][0]*16u|((uint64_t)xy[i][1]*16<<16)|((uint64_t)z<<32));
 packet[0]=((words-2)/2)|(UINT64_C(1)<<60);packet[1]=14;
 bully_overlay_dma_begin();bully_overlay_dma_feed(2,packet,words*8,0x100000);bully_overlay_flush();
}
static uint32_t before[480*272],after[480*272] __attribute__((aligned(16)));
static unsigned read_list[64] __attribute__((aligned(16)));
static void read_pixels(uint32_t*dst){
 sceGuStart(GU_DIRECT,read_list);sceGuCopyImage(GU_PSM_8888,0,0,480,272,512,(uint8_t*)sceGeEdramGetAddr()+overlay_draw_offset,0,0,480,dst);sceGuFinish();sceGuSync(0,0);sceKernelDcacheInvalidateRange(dst,480*272*4);
}
int main(void){
 freopen("sky.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
 unsigned mode=0x01000001u;__asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(mode):"memory");
 fixture_case=0;hle_ram=fixture_ram;hle_ram_end=sizeof fixture_ram;bully_world_enable();bully_world_camera_begin(1);
 feed_sky(0x800000ff,0,0);read_pixels(before);
 printf("initial sky pixel=%08x active=%d clear=%d\n",(unsigned)before[0],active,clear_pending);
 for(unsigned i=0;i<480*272;i++)assert((before[i]&0xffffff)==0xff);
 assert(!clear_pending&&underlay_active);bully_world_begin();
 for(unsigned m=0;m<mesh_count();m++){bully_world_capture_state(m+1,1);bully_world_capture_light(m+1,1);}bully_world_draw(1,1);read_pixels(before);
 assert(!underlay_active&&!clear_pending);assert((before[0]&0xffffff)==0xff);
 feed_sky(0x8000ff00,0,0);read_pixels(after);
 unsigned near=0,far=0;
 for(unsigned y=0;y<272;y++)for(unsigned x=0;x<480;x++){
  unsigned i=y*480+x;if((before[i]&0xffffff)!=0xff){near++;assert((before[i]&0xffffff)==0xffffff);assert(before[i]==after[i]);}else{far++;assert((after[i]&0xffffff)==0xff00);}
 }
 assert(near>100&&far>100);printf("PASS far sky depth near=%u background=%u first object preserves sky\n",near,far);
 memcpy(before,after,sizeof before);feed_sky(0x80ff0000,1,0);read_pixels(after);assert(!memcmp(before,after,sizeof before));
 bully_world_camera_end(1);bully_world_overlay_present();bully_world_camera_begin(1);
 feed_sky(0x80ff0000,0,1);read_pixels(after);
 assert(clear_pending&&!underlay_active);
 for(unsigned y=16;y<272;y++)for(unsigned x=16;x<480;x++)assert(before[y*480+x]==after[y*480+x]);
 assert((after[2*480+2]&0xffffff)==0xff0000);

 const char *names[]={"SKY_high","SKY_tile","SKY_bot","OTHER"};
 fixture_sky=1;
 for(unsigned test=0;test<5;test++){
  memset(fixture_ram,0,sizeof fixture_ram);uint32_t value=0x2000;memcpy(fixture_ram+0x1000,&value,4);strcpy((char*)fixture_ram+0x2010,names[test<4?test:0]);
  unsigned gp=0x8000;value=0x513fb;memcpy(fixture_ram+gp-25152,&value,4);value=0x68;memcpy(fixture_ram+gp-25112,&value,4);value=128;memcpy(fixture_ram+gp-25108,&value,4);value=1;memcpy(fixture_ram+gp-25164,&value,4);value=0x58;memcpy(fixture_ram+gp-25096,&value,4);
  bully_world_camera_end(1);bully_world_camera_begin(1);feed_sky(0x80080808,0,0);bully_world_begin();
  bully_world_capture_float_state(test==4?2:1,gp);bully_world_draw(1,1);read_pixels(before);
  unsigned changed=0;int valid=test<3;
  for(unsigned i=0;i<480*272;i++)if((before[i]&0xffffff)!=0x080808){changed++;assert((before[i]&0xffffff)==(valid?0x282828:0x202020));}
  assert(changed>100);
  feed_sky(0x8000ff00,0,0);read_pixels(after);unsigned retained=0;
  for(unsigned i=0;i<480*272;i++)if((after[i]&0xffffff)!=0xff00){retained++;assert(!valid&&before[i]==after[i]);}
  assert(valid?retained==0:retained==changed);
  printf("PASS float sky name=%s object_match=%d additive=%d depth_mask=%d pixels=%u\n",names[test<4?test:0],test!=4,valid,valid,changed);
 }
 puts("COMPLETE sky/depth preservation, invalid-Z rejection, empty-camera UI background, actual GIF/GE path");sceKernelDelayThread(2000000);sceKernelExitGame();return 0;
}
