#include "candidate/r5900_rt.h"
#include <stdio.h>
#include <stdlib.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully exact range itof",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
PSP_HEAP_SIZE_KB(1024);
static void mode(unsigned i){uint32_t f=(1u<<24)|i;__asm__ volatile("ctc1 %0,$31"::"r"(f));}
#else
#include <fenv.h>
static void mode(unsigned i){static const int m[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(m[i]);}
#endif
uint32_t reference_known24(uint32_t),candidate_known24(uint32_t),reference_byte(uint32_t),candidate_byte(uint32_t),reference_generic(uint32_t,unsigned),candidate_generic(uint32_t,unsigned);
void reference_vu(R5900Ctx*,unsigned,int,int,unsigned),candidate_vu(R5900Ctx*,unsigned,int,int,unsigned);
void reference_prefix(R5900Ctx*),candidate_prefix(R5900Ctx*);
static uint32_t seed=0x629173ab;
static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static R5900Ctx a,b,initial;
static unsigned char ra[65536] __attribute__((aligned(16))),rb[65536] __attribute__((aligned(16)));
static unsigned scalars,vectors,lanes;
static FILE*f;
static int scalar(uint32_t x){uint32_t a=reference_known24(x),b=candidate_known24(x);if(a!=b || reference_byte(x)!=candidate_byte(x)){fprintf(f,"ERROR scalar x=%08x ref=%08x cand=%08x\n",x,a,b);return 1;}scalars++;return 0;}
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);f=fopen("itof-test.log","w");
#else
 f=stdout;
#endif
 if(!f)return 2;
 for(unsigned m=0;m<4;m++){
  mode(m);
  for(unsigned x=0;x<0x1000000u;x++)if(scalar(x))goto fail;
  for(unsigned i=0;i<1000000;i++){uint32_t x=rnd(),shift=rnd();if(reference_generic(x,shift)!=candidate_generic(x,shift)){fprintf(f,"ERROR generic\n");goto fail;}}
  for(unsigned i=0;i<10000;i++){
   unsigned char*q=(void*)&initial;for(unsigned j=0;j<sizeof(initial);j++)q[j]=(unsigned char)rnd();
   for(unsigned j=0;j<sizeof(ra);j+=4){uint32_t v=rnd();memcpy(ra+j,&v,4);}
   // The original runtime requires natural LH/LW/LD alignment. Use valid,
   // disjoint stack/global/object/table windows, with arbitrary packed data.
   // Random virtual mirror bits still exercise the guest-address mask.
   uint32_t sp=0xe000u+((i&127u)<<4),gp=0x5000u+((i&63u)<<2);
   uint32_t object=0x6000u+((i&255u)<<4),table=0x8000u;
   initial.r[29].w[0]=(rnd()&0xffff0000u)|sp;
   initial.r[28].w[0]=(rnd()&0xffff0000u)|gp;
   initial.r[4].d[0]=(uint64_t)rnd()<<32|((rnd()&0xffff0000u)|0x1000u|((i&255u)<<4));
   initial.r[5].d[0]=(uint64_t)rnd()<<32|((rnd()&0xffff0000u)|0x2000u|((i&255u)<<4));
   initial.r[6].d[0]=(initial.r[6].d[0]&~0xffffull)|(rnd()&511u);
   uint32_t ptr=(rnd()&0xffff0000u)|object;
   memcpy(ra+gp-5176,&ptr,4);
   ptr=(rnd()&0xffff0000u)|table;memcpy(ra+object+36,&ptr,4);
   initial.ram_mask=65535;
   memcpy(rb,ra,sizeof(ra));a=initial;b=initial;a.ram=ra;b.ram=rb;
   reference_prefix(&a);candidate_prefix(&b);a.ram=NULL;b.ram=NULL;
   if(memcmp(&a,&b,sizeof(a))||memcmp(ra,rb,sizeof(ra))){fprintf(f,"ERROR vector mode=%u i=%u\n",m,i);goto fail;}
   vectors++;
  }
  for(unsigned dest=0;dest<16;dest++)for(int t=0;t<32;t++)for(int src=0;src<34;src++)for(unsigned sh=0;sh<4;sh++){
   static const unsigned shifts[]={0,4,12,15};
   for(unsigned j=0;j<sizeof(initial);j+=4){uint32_t v=rnd();memcpy((unsigned char*)&initial+j,&v,4);}
   initial.ram=NULL;a=initial;b=initial;
   reference_vu(&a,dest|0x100,t,src,shifts[sh]);candidate_vu(&b,dest|0x100,t,src,shifts[sh]);
   if(memcmp(&a,&b,sizeof(a))){fprintf(f,"ERROR lanes mode=%u dest=%u t=%d s=%d shift=%u\n",m,dest,t,src,shifts[sh]);goto fail;}
   lanes++;
  }
  fprintf(f,"mode=%u scalars=%u vectors=%u lanes=%u errors=0\n",m,scalars,vectors,lanes);fflush(f);
 }
 fprintf(f,"COMPLETE scalars=%u vectors=%u lanes=%u errors=0\n",scalars,vectors,lanes);fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
 fail:fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 1;
}
