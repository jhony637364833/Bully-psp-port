#ifndef BULLY_AUDIO_TEST_HLE_H
#define BULLY_AUDIO_TEST_HLE_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
void *hle_plat_big_alloc(size_t);
void audio_test_log(const char *,...);
#define LOG(...) audio_test_log(__VA_ARGS__)
#endif
