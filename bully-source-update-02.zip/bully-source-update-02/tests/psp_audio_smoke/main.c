#include "hle.h"
#include <pspkernel.h>
#include <malloc.h>
#include <stdio.h>
#include <stdarg.h>
#include <math.h>
PSP_MODULE_INFO("Bully audio test",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER | THREAD_ATTR_VFPU);
static FILE *logfile;
void *hle_plat_big_alloc(size_t n){void *p=memalign(64,n);if(!p)sceKernelExitGame();memset(p,0,n);return p;}
void audio_test_log(const char *fmt,...){va_list ap;va_start(ap,fmt);vfprintf(logfile,fmt,ap);va_end(ap);fflush(logfile);}
int bully_audio_output_push(const int16_t *,uint32_t);
void bully_audio_output_shutdown(void);
int main(void){
 logfile=fopen("audio-smoke.log","w");if(!logfile){sceKernelExitGame();return 1;}
 int16_t pcm[256*2];unsigned sample=0;
 for(unsigned block=0;block<900;block++){
  for(unsigned i=0;i<256;i++){
   int16_t v=(int16_t)(10000*sinf(6.28318530718f*440*sample++/48000));
   pcm[2*i]=v;pcm[2*i+1]=v;
  }
  int rc=bully_audio_output_push(pcm,256);
  if(rc<0){LOG("FAIL %08x\n",(unsigned)rc);break;}
  sceKernelDelayThread(10667); /* half-speed producer */
 }
 bully_audio_output_shutdown();LOG("END\n");fclose(logfile);
 sceKernelExitGame();return 0;
}
