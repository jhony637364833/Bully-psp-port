/* Check the clipper's actual finite-value ordering against its former double
 * subtraction, including signed zero, subnormals and both finite extremes. */
#include "world_clip.c"
#include <stdio.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully clip ordering test",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
#endif
static unsigned checks, errors;
static void compare(uint32_t a, uint32_t b)
{
    float x,y;
    memcpy(&x,&a,sizeof(x));memcpy(&y,&b,sizeof(y));
    int expected=((double)x-(double)y)<0;
    int actual=order_key(x)<order_key(y);
    checks++;errors+=expected!=actual;
    BullyClipVertex v={0};
    v.p[0]=x;v.p[1]=y;v.p[2]=x;
    unsigned expected_code=0;
    for(int plane=0;plane<6;plane++) {
        expected_code|=(distance_to(&v,plane,1.0,100.0)<0)<<plane;
        checks++;
        errors+=outside(&v,plane,order_key(1.0f),order_key(100.0f))!=
                (distance_to(&v,plane,1.0,100.0)<0);
    }
    checks++;errors+=bully_clip_vertex_code(&v,1,100)!=(int)expected_code;
}
int main(void)
{
    const uint32_t edge[]={0,0x80000000u,1,0x80000001u,0x007fffffu,
        0x807fffffu,0x00800000u,0x80800000u,0x3f7fffffu,0x3f800000u,
        0x3f800001u,0xbf800000u,0x7f7fffffu,0xff7fffffu};
    for(unsigned i=0;i<sizeof(edge)/sizeof(*edge);i++)
        for(unsigned j=0;j<sizeof(edge)/sizeof(*edge);j++)compare(edge[i],edge[j]);
    BullyClipVertex v={0};
    checks++;errors+=bully_clip_vertex_code(NULL,1,100)!=-1;
    checks++;errors+=bully_clip_vertex_code(&v,0,100)!=-1;
    checks++;errors+=bully_clip_vertex_code(&v,2,1)!=-1;
    float *fields[]={&v.p[0],&v.p[1],&v.p[2],&v.color[0],&v.color[1],&v.color[2],&v.uv[0],&v.uv[1],&v.alpha};
    for(unsigned i=0;i<sizeof(fields)/sizeof(*fields);i++) {
        *fields[i]=NAN;checks++;errors+=bully_clip_vertex_code(&v,1,100)!=-1;
        *fields[i]=INFINITY;checks++;errors+=bully_clip_vertex_code(&v,1,100)!=-1;
        *fields[i]=0;
    }
    uint32_t state=0x829310u;
    for(unsigned i=0;i<1000000;i++) {
        state=state*1664525u+1013904223u;uint32_t a=state;
        state=state*1664525u+1013904223u;uint32_t b=state;
        if((a&0x7f800000u)==0x7f800000u ||
           (b&0x7f800000u)==0x7f800000u)continue;
        compare(a,b);
    }
#ifdef __PSP__
    FILE *out=fopen("clip-order.log","w");
#else
    FILE *out=stdout;
#endif
    if(!out)return 2;
    fprintf(out,"clip-order checks=%u errors=%u\n",checks,errors);
#ifdef __PSP__
    fclose(out);sceKernelExitGame();
#endif
    return errors?1:0;
}
