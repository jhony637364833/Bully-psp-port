"""Run the generated sphere rejection fixture with host sanitizers."""
from pathlib import Path
import argparse,subprocess
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fixtures',type=Path,required=True);a=p.parse_args();d=a.fixtures.resolve()
subprocess.run(['gcc','-O2','-g','-std=gnu11','-fno-fast-math','-frounding-math','-ffp-contract=off','-fsanitize=address,undefined','-fno-omit-frame-pointer','main.c','baseline-host.c','candidate-host.c','-lm','-o','check-host'],cwd=d,check=True)
subprocess.run([str(d/'check-host')],cwd=d,check=True)
