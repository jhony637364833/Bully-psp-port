#include "baseline.h"
#include <stdio.h>
#include <stdlib.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully geometry quad copy",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
PSP_MAIN_THREAD_STACK_SIZE_KB(128);
#include "vfpu_load.h"
#include "vfpu_store.h"
static void mode(unsigned m,unsigned p){uint32_t f=((p&4)?0x01000000u:0)|m|((p&1)?0x800000u:0)|((p&2)?0x7cu:0);__asm__ volatile("ctc1 %0,$31"::"r"(f):"memory");}
static uint32_t status(void){uint32_t f;__asm__ volatile("cfc1 %0,$31":"=r"(f)::"memory");return f;}
static void controls_load(const uint32_t *p) {
 __asm__ volatile("mtvc %0, $128\n\tmtvc %1, $129\n\tmtvc %2, $130\n\tmtvc %3, $131\n\tmtvc %4, $136" :: "r"(p[0]),"r"(p[1]),"r"(p[2]),"r"(p[3]),"r"(p[4]):"memory");
}
static void controls_store(uint32_t *p) {
 __asm__ volatile("mfvc %0, $128\n\tmfvc %1, $129\n\tmfvc %2, $130\n\tmfvc %3, $131\n\tmfvc %4, $136" : "=r"(p[0]),"=r"(p[1]),"=r"(p[2]),"=r"(p[3]),"=r"(p[4]) ::"memory");
}
#else
#include <fenv.h>
static void mode(unsigned m,unsigned p){static const int r[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(r[m]);feclearexcept(FE_ALL_EXCEPT);if(p&2)feraiseexcept(FE_ALL_EXCEPT);}
static uint32_t status(void){return fetestexcept(FE_ALL_EXCEPT);}
static void vfpu_load(void*p){(void)p;}
static void vfpu_store(void*p){(void)p;}
static void controls_load(const uint32_t*p){(void)p;}
static void controls_store(uint32_t*p){(void)p;}
#endif

void reference(R5900Ctx*);void candidate(R5900Ctx*);
void candidate_enable(int);
void candidate_load(R5900Mem,uint32_t,R5900Reg128*);
void candidate_store(R5900Mem,uint32_t,const R5900Reg128*);
static R5900Ctx a,b,initial;
static uint8_t ram_a[65536] __attribute__((aligned(16))),ram_b[65536] __attribute__((aligned(16)));
static uint8_t arena_a[1024] __attribute__((aligned(16))),arena_b[1024] __attribute__((aligned(16)));
static uint32_t vregs[128] __attribute__((aligned(16))),actual[128] __attribute__((aligned(16)));
static uint32_t ctrl[5],ctrl_before[5],ctrl_after[5];
static uint32_t seed=0x76893ad7;
static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static void fill(void*p,size_t n){unsigned char*q=p;for(size_t i=0;i<n;i++)q[i]=(unsigned char)rnd();}
static void put(unsigned addr,uint32_t v){memcpy(ram_a+(addr&65535),&v,4);}
static void setup_vector(void){
 fill(vregs,sizeof vregs);
 static const uint32_t edge[]={0,0x80000000,1,0x80000001,0x7fffff,0x807fffff,0x7f800000,0xff800000,0x7f800001,0x7fc00001,0x7fffffff,0xffffffff};
 for(unsigned j=0;j<4;j++)vregs[j]=edge[rnd()%12];
 ctrl[0]=rnd()&0xfffff;ctrl[1]=rnd()&0xfffff;ctrl[2]=rnd()&0xfff;ctrl[3]=rnd()&0x3f;ctrl[4]=rnd();
 memcpy(actual,vregs,sizeof actual);controls_load(ctrl);controls_store(ctrl_before);vfpu_load(vregs);
}
static int vector_changed(void){vfpu_store(actual);controls_store(ctrl_after);return memcmp(vregs,actual,sizeof vregs)||memcmp(ctrl_before,ctrl_after,sizeof ctrl_before);}
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);FILE*f=fopen("quad-copy.log","w");
#else
 FILE*f=stdout;
#endif
 if(!f)return 2;
 unsigned total=0,direct=0,wraps=0,aliases=0;
 for(unsigned enabled=0;enabled<2;enabled++)for(unsigned m=0;m<4;m++)for(unsigned it=0;it<1000;it++){
  candidate_enable(enabled);
  fill(&initial,sizeof initial);fill(ram_a,sizeof ram_a);
  initial.ram_mask=65535;initial.r[28].w[0]=0x9000;initial.r[29].w[0]=it%5?0x8000:0x40;
  initial.r[4].d[0]=0x1000;initial.r[5].d[0]=(it%8==0?0x1000:0x1100);initial.r[6].d[0]=(rnd()&0xffff0000u)|(it%128);
  put(0x9000-5176,0x2000);put(0x2000+36,0x3000);put(0x9000-5156,it%4);put(0x9000-5160,it%8);
  if(it%5==0){for(unsigned j=0;j<8;j++)put(0x1000+j*4,(j&1?0xbf800000u:0x3f800000u));}
  memcpy(ram_b,ram_a,sizeof ram_a);a=initial;b=initial;a.ram=ram_a;b.ram=ram_b;
  mode(m,it&7);reference(&a);uint32_t fa=status();
  setup_vector();mode(m,it&7);candidate(&b);uint32_t fb=status();int changed=vector_changed();
  a.ram=NULL;b.ram=NULL;total++;
  if(memcmp(&a,&b,sizeof a)||memcmp(ram_a,ram_b,sizeof ram_a)||fa!=fb||changed){fprintf(f,"ERROR function flag=%u mode=%u iter=%u ctx=%d ram=%d csr=%08lx/%08lx vector=%d\n",enabled,m,it,memcmp(&a,&b,sizeof a),memcmp(ram_a,ram_b,sizeof ram_a),(unsigned long)fa,(unsigned long)fb,changed);fflush(f);return 1;}
  for(unsigned store=0;store<2;store++){
   fill(arena_a,sizeof arena_a);memcpy(arena_b,arena_a,sizeof arena_a);
   unsigned mask=(1u<<(5+it%4))-1,addr=rnd(),index=(rnd()%28)*16;
   R5900Mem ma={arena_a,mask},mb={arena_b,mask};unsigned count=store?4:2,invalid=0;
   // All individual memcpy16 pairs are disjoint; cross-quad aliases are valid.
   for(unsigned j=0;j<count;j++)if((((addr+j*16)&~15u)&mask)==index+j*16)invalid=1;
   if(invalid)continue;
   if(((addr&~15u)&mask)+count*16>mask+1)wraps++;
   for(unsigned j=0;j<count;j++)for(unsigned k=0;k<count;k++)if(j!=k&&(((addr+j*16)&~15u)&mask)==index+k*16)aliases++;
   setup_vector();mode(m,it&7);uint32_t fp0=status();
   if(store)for(unsigned j=0;j<4;j++)rm_sq(ma,addr+j*16,((R5900Reg128*)(arena_a+index))+j);
   else for(unsigned j=0;j<2;j++)rm_lq(ma,addr+j*16,((R5900Reg128*)(arena_a+index))+j);
   uint32_t fp1=status();
   if(store)candidate_store(mb,addr,(R5900Reg128*)(arena_b+index));else candidate_load(mb,addr,(R5900Reg128*)(arena_b+index));
   uint32_t fp2=status();changed=vector_changed();direct++;
   if(memcmp(arena_a,arena_b,sizeof arena_a)||fp0!=fp1||fp1!=fp2||changed){fprintf(f,"ERROR direct flag=%u mode=%u iter=%u store=%u addr=%08x mask=%x index=%u csr=%08lx/%08lx/%08lx vector=%d\n",enabled,m,it,store,addr,mask,index,(unsigned long)fp0,(unsigned long)fp1,(unsigned long)fp2,changed);fflush(f);return 1;}
  }
  if(it==999){fprintf(f,"mode=%u flag=%u function=%u direct=%u wraps=%u aliases=%u errors=0\n",m,enabled,total,direct,wraps,aliases);fflush(f);}
 }
 if(!wraps||!aliases)return 3;
 fprintf(f,"COMPLETE function=%u direct=%u wraps=%u aliases=%u errors=0\n",total,direct,wraps,aliases);fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
}
