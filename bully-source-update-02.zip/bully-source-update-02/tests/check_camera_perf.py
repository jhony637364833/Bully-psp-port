"""Check actual camera boundary timing code with a deterministic PSP clock."""
from pathlib import Path
import os
import subprocess
import tempfile

repo = Path(__file__).resolve().parents[1]
source = (repo / 'app/games/SLUS-21269_v1.02/src/psp/world_display.c').read_text()
body = source[source.index('void bully_world_camera_begin'):source.index('static void bind_material')]
header = r'''
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdarg.h>
static uint32_t scene_camera,perf_camera;
static uint64_t camera_start_us,perf_start_us,perf_camera_us,perf_max_us;
static unsigned perf_passes,objects,triangles,rejected,textured,texture_misses;
static unsigned skinned_objects,draw_calls,lit_meshes,reports;
static unsigned swaps;
static int active=1,collecting_lights,overlay_started,overlay_defer_world;
static unsigned overlay_draw_offset,overlay_background,overlay_world_new,clear_pending,underlay_active;
static unsigned clip_camera_stable;static int clip_memo_storage;
static struct {unsigned hits,misses,bypasses,admissions,epoch;} clip_memo;
#define OVERLAY_BG 2
static void bully_overlay_flush(void){}
static void bully_overlay_underlay_flush(void){}
static void clip_camera_begin(uint32_t c){(void)c;}
static void copy_background(unsigned a,unsigned b){(void)a;(void)b;}
static void present_composition(void){swaps++;}

static uint64_t frame,hle_frame,now;
static unsigned perf_logs;
static char last_perf[256];
static uint64_t sceKernelGetSystemTimeWide(void){return now;}
static void start(void){}
static void finish(void){}
#define GU_COLOR_BUFFER_BIT 1
#define GU_DEPTH_BUFFER_BIT 2
static void sceGuClear(unsigned bits){(void)bits;}
static void sceGuSwapBuffers(void){swaps++;}
static void log_line(const char *format,...) {
    if(strncmp(format,"WORLD_PERF:",11))return;
    va_list args;va_start(args,format);
    vsnprintf(last_perf,sizeof last_perf,format,args);
    va_end(args);perf_logs++;
}
#define LOG log_line
'''
main = r'''
int main(void){
 now=100;bully_world_camera_begin(1);objects=1;
 now=1000100;bully_world_camera_end(2);assert(scene_camera==1 && swaps==0);
 bully_world_camera_end(1);assert(perf_passes==1 && perf_camera_us==1000000);
 now=2000100;bully_world_camera_begin(1);objects=1;
 now=3000100;bully_world_camera_end(1);assert(perf_passes==2 && !perf_logs);
 now=4000100;bully_world_camera_begin(1);objects=1;
 now=5000100;bully_world_camera_end(1);
 assert(perf_logs==1 && swaps==0 && perf_passes==0 && perf_camera_us==0);
 assert(strstr(last_perf,"camera=00000001 passes=3 wall_us=5000000 camera_us=3000000 max_camera_us=1000000"));
 now=6000100;bully_world_camera_begin(2);objects=1;
 assert(perf_camera==2 && perf_start_us==now);
 now=7000100;bully_world_camera_end(2);bully_world_camera_end(2);
 assert(perf_passes==1 && swaps==0 && perf_logs==1);
 now=8000100;bully_world_camera_begin(2); /* no supported objects */
 now=9000100;bully_world_camera_end(2);
 assert(perf_passes==1 && swaps==0 && perf_logs==1);
 puts("Camera timing windows, gaps, camera switches and duplicate/mismatched ends PASS");
}
'''
with tempfile.TemporaryDirectory(prefix='bully-camera-perf-') as tmp:
    root = Path(tmp)
    (root / 'test.c').write_text(header + body + main)
    subprocess.run([os.environ.get('CC', 'cc'), '-O2', '-fsanitize=address,undefined',
                    str(root / 'test.c'), '-o', str(root / 'test')], check=True)
    subprocess.run([str(root / 'test')], check=True)
