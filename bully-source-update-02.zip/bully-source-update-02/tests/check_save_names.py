"""Check the actual PSP filename adapter, including its pack and directory scope."""
from pathlib import Path
import os
import subprocess
import tempfile

root = Path(__file__).resolve().parent.parent
source = (root / 'app/hle/psp/hle_mcfs_psp.c').read_text()
start = source.index('static const char *mc_psp_entry_name(')
end = source.index('\nint hle_plat_mc_list(', start)
helper = source[start:end]
fixture = r'''
#include <assert.h>
#include <string.h>
#include <stdio.h>
%s
int main(void) {
    const char *upper[] = {"ICON.SYS", "ICON0.ICN", "ICON1.ICN", "ICON2.ICN"};
    const char *lower[] = {"icon.sys", "icon0.icn", "icon1.icn", "icon2.icn"};
    unsigned checks = 0;
    for (unsigned i = 0; i < 4; ++i) {
        assert(!strcmp(mc_psp_entry_name(upper[i], 0), TARGET ? lower[i] : upper[i])); ++checks;
        assert(mc_psp_entry_name(upper[i], 1) == upper[i]); ++checks;
        assert(mc_psp_entry_name(lower[i], 0) == lower[i]); ++checks;
    }
    const char *keep[] = {"BullyFile1", "FileTableBully", "PhotoGallery", "BASLUS-21269BULLY000",
                          "Icon.Sys", "ICON3.ICN", "ICON.SYS._ps2rc_new", "", "OTHER.SYS"};
    for (unsigned i = 0; i < sizeof keep / sizeof keep[0]; ++i) {
        assert(mc_psp_entry_name(keep[i], 0) == keep[i]); ++checks;
        assert(mc_psp_entry_name(keep[i], 1) == keep[i]); ++checks;
    }
    printf("PASS save filenames: %%u checks, target=%%d\n", checks, TARGET);
    return 0;
}
''' % helper
with tempfile.TemporaryDirectory(prefix='bully-save-names-') as work:
    work = Path(work)
    (work / 'check.c').write_text(fixture)
    for target, pack in [(1, 'SLUS-21269_v1.02'), (0, 'OTHER')]:
        subprocess.run([os.environ.get('CC', 'gcc'), '-O1', '-g', '-std=gnu11',
                        '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
                        '-Wall', '-Wextra', '-Werror', '-DTARGET=' + str(target),
                        '-DHLE_PACK_NAME="' + pack + '"', str(work / 'check.c'),
                        '-o', str(work / 'check')], check=True)
        subprocess.run([str(work / 'check')], check=True)
