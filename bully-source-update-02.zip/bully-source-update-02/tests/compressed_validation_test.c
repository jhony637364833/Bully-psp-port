#include "native_mesh.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int reference_chain(const uint8_t *,size_t,uint32_t,BullyNativeVertex *,BullyNativeVisit,void *,size_t *,size_t *);
static void put(uint8_t *r,size_t p,uint32_t w) {
    for(unsigned k=0;k<4;k++)r[p+k]=(uint8_t)(w>>(k*8));
}
static size_t fixture(uint8_t *r) {
    size_t at=16;
    for(unsigned batch=0;batch<2;batch++) {
        size_t p=at+8;
        put(r,p,0x01000104);p+=4;put(r,p,0x05000000);p+=4;
        const unsigned cmd[]={0x69,0x65,0x6f,0x6f},imm[]={0x8000,0x8001,0xc002,0xc003};
        const unsigned width[]={6,4,2,2};
        for(unsigned k=0;k<4;k++) {
            put(r,p,(cmd[k]<<24)|(5<<16)|imm[k]);p+=4;
            /* Identical vertices ensure the two seam vertices agree. */
            for(unsigned i=0;i<5*width[k];i++)r[p+i]=(uint8_t)(i%width[k]*31+k);
            p+=(5*width[k]+3)&~3u;
        }
        put(r,p,0x04000005);p+=4;
        put(r,p,batch?0x17000000:0x15000000);p+=4;
        p=(p+15)&~(size_t)15;
        put(r,at,0x10000000u|((p-at-16)/16));at=p;
    }
    put(r,at,0x60000000);put(r,at+12,0x11000000);
    return at+16;
}
struct Capture { BullyNativeVertex vertices[512];size_t n; };
static void capture(const BullyNativeVertex *v,size_t n,void *ctx) {
    struct Capture *c=ctx;assert(c->n+n<=512);
    memcpy(c->vertices+c->n,v,n*sizeof(*v));c->n+=n;
}
static unsigned seed=17;
static unsigned random_word(void) {seed=seed*1664525u+1013904223u;return seed;}
int main(void) {
    uint8_t original[512]={0},r[512];size_t length=fixture(original);
    unsigned accepted=0;
    for(unsigned i=0;i<10000;i++) {
        memcpy(r,original,sizeof(r));size_t bytes=length;
        if(i%3==1)for(unsigned j=0;j<1+i%4;j++)r[16+random_word()%(length-16)]^=(uint8_t)(1u<<(random_word()%8));
        if(i%3==2)bytes=random_word()%(length+1);
        BullyNativeVertex scratch[256],before[256];
        memset(scratch,0xa5,sizeof(scratch));memcpy(before,scratch,sizeof(before));
        size_t count=99,used=99,rcount=99,rused=99;
        int valid=bully_compressed_chain(r,bytes,16,scratch,NULL,NULL,&count,&used);
        assert(!memcmp(scratch,before,sizeof(scratch)));
        int ref=reference_chain(r,bytes,16,scratch,NULL,NULL,&rcount,&rused);
        assert(valid==ref && count==rcount && used==rused);
        if(valid)accepted++;
        struct Capture a={0},b={0};
        valid=bully_compressed_chain(r,bytes,16,scratch,capture,&a,&count,&used);
        ref=reference_chain(r,bytes,16,scratch,capture,&b,&rcount,&rused);
        assert(valid==ref && count==rcount && used==rused);
        assert(a.n==b.n && !memcmp(a.vertices,b.vertices,a.n*sizeof(*a.vertices)));
    }
    printf("10000 validation/draw differential cases passed (%u valid)\n",accepted);
}
