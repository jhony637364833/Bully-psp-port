int main(void){
 BullyOverlayContext s={0};BullyOverlayVertex v[3]={{0}};s.test=0x513fa;s.zbuf=0x1000118;s.frame=0xa0000;
 assert(sky_underlay(12,&s,v,3));scene_camera=1;clear_pending=1;
 assert(sky_underlay(12,&s,v,3));assert(sky_underlay(76,&s,v,3));
 unsigned tests=0;
 for(unsigned prim=0;prim<2048;prim++){
  int expected=!(prim&16)&&((prim&7)==3||(prim&7)==4);
  assert(sky_underlay(prim,&s,v,3)==expected);tests++;
 }
 for(unsigned bit=0;bit<64;bit++){
  BullyOverlayContext q=s;q.test^=UINT64_C(1)<<bit;
  int expected=!(q.test&0x4001)&&(q.test&(1u<<16))&&((q.test>>17)&3)==2;
  assert(sky_underlay(12,&q,v,3)==!!expected);tests++;
 }
 for(unsigned f=0;f<64;f++){BullyOverlayContext q=s;q.frame=(uint64_t)f<<24;assert(sky_underlay(12,&q,v,3)==(f==0));tests++;}
 for(unsigned f=0;f<16;f++){BullyOverlayContext q=s;q.zbuf=(uint64_t)f<<24;assert(sky_underlay(12,&q,v,3)==(f==1));tests++;}
 s.zbuf|=UINT64_C(1)<<32;assert(!sky_underlay(12,&s,v,3));s.zbuf^=UINT64_C(1)<<32;
 for(unsigned i=0;i<3;i++){v[i].z=1;assert(!sky_underlay(12,&s,v,3));v[i].z=0;}
 assert(!sky_underlay(12,&s,v,2));assert(!sky_underlay(12,&s,v,0));
 allow_init=0;assert(!bully_world_underlay_begin());assert(clear_pending&&clears==0&&!active);
 allow_init=1;assert(bully_world_underlay_begin());assert(active&&!clear_pending&&underlay_active&&clears==1);
 for(unsigned i=0;i<10;i++)assert(bully_world_underlay_begin());assert(clears==1&&starts==1&&finishes==1);
 underlay_active=0;assert(bully_world_underlay_begin());assert(clears==1);
 scene_camera=0;clear_pending=1;assert(!bully_world_underlay_begin());assert(clears==1);
 printf("PASS %u sky-policy cases, unsupported depth/format/count/texture guards, init failure, one clear, original geometry ordering, post-world depth path and outside-camera delegation\n",tests);
 return 0;
}
