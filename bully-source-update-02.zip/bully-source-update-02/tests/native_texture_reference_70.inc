#include "native_texture.h"
#include <string.h>
static uint32_t word(const uint8_t *p) {
    return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static int range(size_t bytes,uint32_t at,size_t n) {
    return at>=4 && !(at&3) && at<=bytes && n<=bytes-at;
}
int bully_native_texture(const uint8_t *ram,size_t bytes,uint32_t material,
                         void *dst,size_t capacity,BullyNativeTexture *out) {
    if(!ram || !dst || !out || bytes>UINT32_MAX || !range(bytes,material,4))return 0;
    uint32_t tex=word(ram+material);
    if(!range(bytes,tex,84))return 0;
    uint32_t raster=word(ram+tex),fa=word(ram+tex+80);
    unsigned u=(fa>>8)&15,v=(fa>>12)&15,filter=fa&255;
    if(!range(bytes,raster,36) || (u!=1 && u!=3) || (v!=1 && v!=3) || filter<1 || filter>6)return 0;
    uint32_t pix=word(ram+raster+4),pal=word(ram+raster+8);
    unsigned format=(unsigned)ram[raster+35]<<8;
    if(pix<80 || !range(bytes,pix-80,80))return 0;
    TcPs2Raster input={0};TcPs2Info info;TcPolicy policy;
    BullyNativeTexture result={0};
    input.width=(int32_t)word(ram+raster+12);input.height=(int32_t)word(ram+raster+16);
    input.depth=(int32_t)word(ram+raster+20);input.format=format;input.version=2;
    input.nlevels=(format&TC_PF_MIPMAP)?0:1;
    input.pix=ram+pix-80;input.pix_size=(uint32_t)(bytes-(pix-80));
    /* Give the converter actual bounded RAM slices rather than the historical
     * helper's assumed palette length. The parser validates every GIF upload. */
    if(format&(TC_PF_PAL4|TC_PF_PAL8)) {
        if(pal<80 || !range(bytes,pal-80,80))return 0;
        input.pal=ram+pal-80;input.pal_size=(uint32_t)(bytes-(pal-80));
        if(pal>pix)input.pix_size=pal-pix;
    }
    if(tc_ps2_inspect(&input,&info))return 0;
    tc_policy_default(&policy);policy.max_dim=256;policy.max_levels=1;
    policy.cache_bytes=0;policy.decimate=1;
    if(tc_plan(&info,&policy,&result.texture))return 0;
    if(result.texture.total_bytes>capacity) {
        policy.max_dim=128;
        if(tc_plan(&info,&policy,&result.texture) || result.texture.total_bytes>capacity)return 0;
    }
    if(tc_convert(&info,&policy,&result.texture,dst,capacity))return 0;
    result.filter=filter;result.wrap_u=u;result.wrap_v=v;*out=result;return 1;
}
