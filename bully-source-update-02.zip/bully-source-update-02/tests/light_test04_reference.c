/* Frozen test04 lighting output oracle. */
#include "native_light.h"
#include <math.h>
void bully_test04_light_color(const BullyNativeVertex *v,const BullyNativeLight *light,float rgb[3]) {
    for(unsigned k=0;k<3;k++) {
        float a=v->color[light->monochrome?0:k];
        float b=v->color_secondary[light->monochrome?0:k];
        if(light->monochrome) { a+=12; b+=12; }
        /* Clamp before material modulation, as the original VU shader does. */
        float lit=(a+(b-a)*light->blend)*light->gain[k];
        rgb[k]=fminf(255.0f,lit)*light->material[k]*2.0f;
    }
}

/* VU 0x56717c: W banks add (089), gain.W is one (06a), clamp to255
 * before material.W (0a0/0a4). GS alpha128 maps to PSP alpha255. */
float bully_test04_light_alpha(const BullyNativeVertex *v,const BullyNativeLight *light) {
    return fminf(255.0f,(float)v->color[3]+v->color_secondary[3])*
           light->material_alpha*2.0f;
}
