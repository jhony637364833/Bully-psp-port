#include "native_gif.h"
#include "native_vif.h"
#include "overlay_geometry.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static uint32_t seed=0x38a9431;
static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static BullyOverlayGeometry geom;
static void reg(void*o,unsigned r,uint64_t v){(void)o;bully_overlay_geometry_reg(&geom,r,v);}
int main(void){
 for(unsigned k=0;k<50000;k++){
  size_t n=(rnd()%129)*16;unsigned char*p=malloc(n?n:1);assert(p);
  for(size_t i=0;i<n;i++)p[i]=(unsigned char)rnd();
  /* Half the corpus has structurally valid GIF tag headers and random payload. */
  if((k&1) && n>=16){uint64_t lo=(rnd()%65)|((uint64_t)(rnd()%3)<<58)|((uint64_t)(rnd()%16)<<60);uint64_t hi=((uint64_t)rnd()<<32)|rnd();memcpy(p,&lo,8);memcpy(p+8,&hi,8);}
  BullyGif g;BullyVif v;bully_overlay_geometry_init(&geom,0,0,0);bully_gif_init(&g,reg,0,0);bully_vif_init(&v,&g);
  uint32_t addr=rnd();addr&=0x00fffff0;
  assert(!bully_gif_feed(&g,p,n+1,addr));assert(!bully_vif_feed(&v,p,n+1,addr));
  for(size_t i=0;i<n;i+=16)if(!bully_gif_feed(&g,p+i,16,addr+(uint32_t)i))break;
  bully_gif_init(&g,reg,0,0);
  for(size_t i=0;i<n;i+=4)if(!bully_vif_feed(&v,p+i,4,addr+(uint32_t)i))break;
  for(unsigned i=0;i<64;i++)bully_overlay_geometry_reg(&geom,rnd()&127,((uint64_t)rnd()<<32)|rnd());
  free(p);
 }
 puts("PASS 50000 deterministic malformed/valid-header GIF/VIF and geometry cases, exact allocation bounds, fragmented feeds");return 0;
}
