#include "native_state.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
static uint8_t ram[65536],saved[65536];static uint8_t *hle_ram=ram;static uint32_t hle_ram_end=sizeof ram;
static uint32_t gw(uint32_t a){uint32_t x;memcpy(&x,ram+a,4);return x;}
static void put(uint32_t a,uint32_t v){memcpy(ram+a,&v,4);}
