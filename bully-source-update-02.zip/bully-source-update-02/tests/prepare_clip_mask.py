"""Reproduce exact coordinate-order mask checks against the frozen build23 clipper."""
from pathlib import Path
import argparse

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
 p.add_argument('--output',type=Path,required=True)
 a=p.parse_args();here=Path(__file__).parent;d=a.output;d.mkdir(parents=True,exist_ok=True)
 for name in ['reference','candidate']:
  sub=d/name;sub.mkdir(exist_ok=True)
  for header in ['world_clip.h','clip_lerp.h','clip_memo.h']:(sub/header).write_bytes((a.app/'games/SLUS-21269_v1.02/src'/header).read_bytes())
  source=here/'clip_mask_reference.inc' if name=='reference' else a.app/'games/SLUS-21269_v1.02/src/world_clip.c'
  (sub/'world_clip.c').write_bytes(source.read_bytes())
  text=''.join('#define bully_clip_'+a+' '+name+'_'+b+'\n' for a,b in [('vertex_code','code'),('triangle','triangle'),('triangle_cached','cached'),('cache_reset','reset'),('triangle_memoized','memoized'),('triangle_classified','classified')])
  text+='#include "'+name+'/world_clip.c"\nuint32_t '+name+'_key(uint32_t bits){float f;memcpy(&f,&bits,4);return order_key(f); }\n'
  # Preserve exact executed wrapper spelling, including closing-brace spacing.
  text=text.replace('order_key(f); }','order_key(f);}')
  (d/(name+'.c')).write_text(text)
 for src,dst in [('clip_mask_main.c','main.c'),('clip_mask_Makefile.inc','Makefile')]:(d/dst).write_bytes((here/src).read_bytes())
 print('Expected COMPLETE keys=17825814 codes=160000 polygons=72064 ... errors=0')

if __name__=='__main__':main()
