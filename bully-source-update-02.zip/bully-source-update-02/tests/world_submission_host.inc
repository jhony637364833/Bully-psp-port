#include <pspgu.h>
#include <pspge.h>
#include <pspdisplay.h>
#include <pspkernel.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
static uint64_t trace_hash=1469598103934665603ull;
static unsigned syncs,starts,host_open,words,max_words;
static void hash_bytes(const void*p,size_t n){const unsigned char*b=p;for(size_t i=0;i<n;i++)trace_hash=(trace_hash^b[i])*1099511628211ull;}
static uint64_t hash_memory(const void*p,size_t n){const unsigned char*b=p;uint64_t h=1469598103934665603ull;for(size_t i=0;i<n;i++)h=(h^b[i])*1099511628211ull;return h;}
static void command(unsigned op,unsigned a,unsigned b,unsigned c,unsigned d,unsigned e){
 assert(host_open);unsigned data[6]={op,a,b,c,d,e};hash_bytes(data,sizeof(data));words+=op==7?4:op==15?18:op==23?4:op==6?3:op==12?6:(op==30||op==31)?2:(op==8||op==9)?3:1;assert(words<4096);
}
static unsigned float_bits(float f){unsigned u;memcpy(&u,&f,4);return u;}
static struct {const void*p;size_t n;uint64_t hash;} reads[2048];static unsigned read_count;
static void add_read(const void*p,size_t n){assert(read_count<2048);reads[read_count].p=p;reads[read_count].n=n;reads[read_count++].hash=hash_memory(p,n);}
#define BEFORE_TEXTURE_WRITE() assert(!read_count)
int sceGuStart(int c,void*p){(void)p;assert(c==GU_DIRECT && !host_open && !read_count);host_open=1;words=0;starts++;return 0;}
int sceGuFinish(void){assert(host_open);host_open=0;if(words>max_words)max_words=words;return (int)(words*4);}
int sceGuSync(int a,int b){assert(!a&&!b&&!host_open);for(unsigned i=0;i<read_count;i++)assert(reads[i].hash==hash_memory(reads[i].p,reads[i].n));read_count=0;syncs++;return 0;}
void sceGuEnable(int a){command(1,a,0,0,0,0);}void sceGuDisable(int a){command(2,a,0,0,0,0);}
void sceGuDepthMask(int a){command(3,a,0,0,0,0);}void sceGuDepthFunc(int a){command(4,a,0,0,0,0);}
void sceGuAlphaFunc(int a,int b,int c){command(5,a,b,c,0,0);}
void sceGuBlendFunc(int a,int b,int c,unsigned int d,unsigned int e){command(6,a,b,c,d,e);}
void sceGuDrawArray(int a,int b,int n,const void*idx,const void*p){assert(!idx);command(7,a,b,n,0,0);hash_bytes(p,(size_t)n*24);add_read(p,(size_t)n*24);}
void sceGuDrawBuffer(int a,void*b,int c){command(8,a,(unsigned)(uintptr_t)b,c,0,0);}
void sceGuDispBuffer(int a,int b,void*c,int d){command(9,a,b,(unsigned)(uintptr_t)c,d,0);}
void sceGuDepthBuffer(void*a,int b){command(10,(unsigned)(uintptr_t)a,b,0,0,0);}
void sceGuOffset(unsigned int a,unsigned int b){command(11,a,b,0,0,0);}
void sceGuViewport(int a,int b,int c,int d){command(12,a,b,c,d,0);}
void sceGuScissor(int a,int b,int c,int d){command(13,a,b,c,d,0);}
void sceGuDepthRange(int a,int b){command(14,a,b,0,0,0);}
void sceGuSetMatrix(int a,const ScePspFMatrix4*b){if(a==GU_MODEL){const float identity[16]={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};assert(!memcmp(b,identity,64));uint64_t saved_hash=trace_hash;command(15,a,0,0,0,0);trace_hash=saved_hash;}else{command(15,a,0,0,0,0);hash_bytes(b,64);}}
void sceGuShadeModel(int a){command(16,a,0,0,0,0);}
void sceGuClearColor(unsigned int a){command(17,a,0,0,0,0);}void sceGuClearDepth(unsigned int a){command(18,a,0,0,0,0);}
void sceGuClear(int a){command(19,a,0,0,0,0);}
int sceGuInit(void){assert(!host_open&&!read_count);return 0;}
void sceGuTerm(void){assert(!host_open&&!read_count);}
int sceGuDisplay(int a){assert(!host_open&&!read_count);unsigned data[2]={20,(unsigned)a};hash_bytes(data,sizeof(data));return 0;}
void*sceGuSwapBuffers(void){assert(!host_open&&!read_count);unsigned op=21;hash_bytes(&op,4);return 0;}
static unsigned texture_psm;
void sceGuTexMode(int a,int b,int c,int d){command(22,a,b,c,d,0);texture_psm=a;}
static const void*texture_pointer;
void sceGuTexImage(int a,int b,int c,int d,const void*p){command(23,a,b,c,d,0);texture_pointer=p;size_t bytes=(size_t)c*d*(texture_psm==GU_PSM_8888?4:1);hash_bytes(p,bytes);add_read(p,bytes);}
void sceGuClutMode(unsigned int a,unsigned int b,unsigned int c,unsigned int d){command(24,a,b,c,d,0);}
void sceGuClutLoad(int a,const void*p){command(25,a,0,0,0,0);hash_bytes(p,(size_t)a*32);add_read(p,(size_t)a*32);}
void sceGuTexFlush(void){command(26,0,0,0,0,0);}
void sceGuTexFunc(int a,int b){command(27,a,b,0,0,0);}void sceGuTexFilter(int a,int b){command(28,a,b,0,0,0);}
void sceGuTexWrap(int a,int b){command(29,a,b,0,0,0);}
void sceGuTexScale(float a,float b){command(30,float_bits(a),float_bits(b),0,0,0);}
void sceGuTexOffset(float a,float b){command(31,float_bits(a),float_bits(b),0,0,0);}
unsigned int sceGeEdramGetSize(void){return 2097152;}
int sceDisplaySetMode(int a,int b,int c){assert(!host_open&&!read_count);assert(a==0&&b==480&&c==272);return 0;}
SceInt64 sceKernelGetSystemTimeWide(void){return 1;}
void sceKernelDcacheWritebackRange(const void*p,unsigned int n){(void)p;(void)n;}

SceSize sceKernelTotalFreeMemSize(void){return 0;}
SceSize sceKernelMaxFreeMemSize(void){return 0;}
SceUID sceKernelAllocPartitionMemory(SceUID a,const char*b,int c,SceSize d,void*e){(void)a;(void)b;(void)c;(void)d;(void)e;return -1;}
void*sceKernelGetBlockHeadAddr(SceUID a){(void)a;return 0;}
int sceKernelFreePartitionMemory(SceUID a){(void)a;return 0;}
void bully_overlay_flush(void){assert(!host_open&&!read_count);}
void sceGuCopyImage(int p,int sx,int sy,int w,int h,int ss,void*s,int dx,int dy,int ds,void*d){
 command(32,p,sx,sy,w,h);command(33,ss,(unsigned)(uintptr_t)s,dx,dy,ds);command(34,(unsigned)(uintptr_t)d,0,0,0,0);
}
