static inline void reference_save(const R5900Ctx *c, R5900CSave *s) {
    memcpy(__builtin_assume_aligned(&s->r[0], 16), __builtin_assume_aligned(&c->r[16], 16), 8 * sizeof(R5900Reg128)); s->r[8] = c->r[30];
    memcpy(__builtin_assume_aligned(&s->f[0], 4), __builtin_assume_aligned(&c->fpr[20], 4), 12 * sizeof(uint32_t));
}
static inline void reference_restore(R5900Ctx *c, const R5900CSave *s) {
    memcpy(__builtin_assume_aligned(&c->r[16], 16), __builtin_assume_aligned(&s->r[0], 16), 8 * sizeof(R5900Reg128)); c->r[30] = s->r[8];
    memcpy(__builtin_assume_aligned(&c->fpr[20], 4), __builtin_assume_aligned(&s->f[0], 4), 12 * sizeof(uint32_t));
}

