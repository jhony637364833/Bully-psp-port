#include <pspkernel.h>
#include <pspgu.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
PSP_MODULE_INFO("Bully movie display test",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
#include "movie_display.c"
void bully_world_shutdown(void){}
static uint32_t pixels[512*512] __attribute__((aligned(16)));
static void phase(int n){FILE*f=fopen("phase.txt","w");fprintf(f,"%d",n);fclose(f);for(unsigned i=0;i<1000;i++){FILE*a=fopen("ack.txt","r");if(a){int x=-1;fscanf(a,"%d",&x);fclose(a);if(x==n)return;}sceKernelDelayThread(10000);}sceKernelExitGame();}
int main(void){
 if(!bully_movie_display_init())return 2;
 for(unsigned y=0;y<512;y++)for(unsigned x=0;x<512;x++)pixels[y*512+x]=0xff000000u|((x/32*31)&255)|(((y/32*47)&255)<<8)|((((x/64+y/64)&1)?0xd0u:0x20u)<<16);
 sceKernelDcacheWritebackRange(pixels,sizeof pixels);for(unsigned i=0;i<10;i++){hle_ge_movie_frame(pixels,1,0);sceKernelDelayThread(33000); }phase(1);
 hle_ge_movie_end();phase(2);
 uint16_t*p=(uint16_t*)pixels;for(unsigned y=0;y<512;y++)for(unsigned x=0;x<512;x++)p[y*512+x]=(x/32%32)|((y/8%64)<<5)|(((x/64+y/64)%32)<<11);
 sceKernelDcacheWritebackRange(pixels,sizeof pixels);for(unsigned i=0;i<10;i++){hle_ge_movie_frame(pixels,0,0);sceKernelDelayThread(33000); }phase(3);
 bully_movie_display_shutdown();if(!bully_movie_display_init())return 3;hle_ge_movie_end();phase(4);bully_movie_display_shutdown();
 FILE*f=fopen("result.txt","w");fputs("COMPLETE phases=4 errors=0\n",f);fclose(f);for(;;)sceKernelDelayThread(100000);
}
