# Alpha-fail GPU differential

Build with PSP GCC/SDK and Python 3:

```sh
make -C tests/psp_alpha_fail
```

Run the generated EBOOT in PPSSPP (PSP-2000/3000, OpenGL, 1×, frameskip 0).
The test writes `alpha-fail.log` next to its EBOOT and exits after `COMPLETE`.
No game assets or captured data are needed. `generated.c` is recreated from the
current renderer, the frozen build05 flush oracle and the synthetic test support.

The 108 cases include alpha comparisons, boundary values, opaque/cutout/blended
textures, absent textures, nearest/linear filtering, overlapping triangles,
blending, 384-vertex batches and the depth-mask/disabled-test/KEEP guards.
Every case compares original/candidate pixels and a repeated original rendering.

Certified all-fail cases must preserve a far-depth full-screen witness. A separate
positive control deliberately writes foreground depth and must block that witness.
These checks validate observable depth behavior. Raw emulated depth-buffer bytes
are not used as an oracle. Explicit GE transfer/readback is required for stable
color pixels; direct CPU reads of emulated VRAM can be stale.

Host bounds and command/state/fallback checks:

```sh
python3 tests/check_alpha_fail.py
python3 tests/check_alpha_batch.py
```
