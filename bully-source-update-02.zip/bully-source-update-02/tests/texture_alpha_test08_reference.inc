/* Bounded static-geometry path. Native textures and vertex colors, bounded CPU skinning.
 * CPU clipping with GPU projection for perspective-correct UV interpolation.
 * Unsupported objects retain guest execution and are counted, never fabricated.
 * Small synchronous lists keep geometry memory bounded on the 64MB target.
 */
#include "hle.h"
#include "native_object.h"
#include "native_skin.h"
#include "native_light.h"
#include "native_state.h"
#include "native_texture.h"
#include "world_clip.h"
#include "world_projection.h"
#include <pspgu.h>
#include <pspge.h>
#include <pspdisplay.h>
#include <pspkernel.h>
#include <math.h>

extern int hle_ge_on;
static int enabled, active;
static uint64_t frame;
static uint32_t scene_camera;
/* Completed camera throughput, measured in wall time. Multiple cameras may
 * belong to one gameplay frame, so this is deliberately not an FPS counter. */
static uint32_t perf_camera;
static uint64_t camera_start_us,perf_start_us,perf_camera_us,perf_max_us;
static unsigned perf_passes;
static unsigned objects, triangles, rejected, reports, skinned_objects;
static unsigned list[4096] __attribute__((aligned(16)));
typedef struct { float u,v; unsigned color; float x,y,z; } GeVertex;
#define WORLD_BATCH_VERTICES 384
/* SDK 20261001: each non-indexed draw emits 4 words, each alpha/depth
 * update 1. Two ordered draws plus four updates = 12 words/triangle.
 * Reserve 16 plus 64 words for list setup/termination. */
_Static_assert((WORLD_BATCH_VERTICES/3)*16+64 <= sizeof(list)/sizeof(*list),
               "world command list must hold the worst-case ordered batch");
static unsigned queued, draw_calls;
static GeVertex verts[WORLD_BATCH_VERTICES] __attribute__((aligned(16)));
/* Allocate after the movie, from the runtime arena. Keep the boot reserve. */
static BullyNativeVertex *mesh;
static BullyNativeObject object_view;
#define WORLD_TEXTURE_BYTES 65536
static uint8_t *texels;
static BullyNativeTexture texture;
static unsigned textured, texture_misses, texture_reports;
static int has_texture;
static BullyNativeLight lights[BULLY_NATIVE_MAX_MESHES];
static unsigned light_count, lit_meshes;
static int collecting_lights;
static const BullyNativeLight *material_light;
static BullyNativeState states[BULLY_NATIVE_MAX_MESHES];
static unsigned state_count;
static const BullyNativeState *material_state;
static const int alpha_functions[8]={GU_NEVER,GU_ALWAYS,GU_LESS,GU_LEQUAL,
                                    GU_EQUAL,GU_GEQUAL,GU_GREATER,GU_NOTEQUAL};
static const unsigned inverse_alpha[8]={1,0,5,6,7,2,3,4};
static unsigned alpha_reference(const BullyNativeState *s) {
    unsigned a=(s->test>>4)&255;return a<128?a*2:255;
}
static void apply_state(void) {
    const BullyNativeState *s=material_state;
    if(!s) {
        sceGuDisable(GU_BLEND);sceGuDepthMask(GU_FALSE);
        sceGuEnable(GU_DEPTH_TEST);sceGuDepthFunc(GU_LEQUAL);
        if(has_texture){sceGuEnable(GU_ALPHA_TEST);sceGuAlphaFunc(GU_GREATER,0,255);}
        else sceGuDisable(GU_ALPHA_TEST);
        return;
    }
    if(s->blend) {
        sceGuEnable(GU_BLEND);
        /* GS (Cs-0)*FIX/128 + Cd, FIX=128: additive, including destination. */
        if(s->alpha==0x68)sceGuBlendFunc(GU_ADD,GU_FIX,GU_FIX,0xffffff,0xffffff);
        else sceGuBlendFunc(GU_ADD,GU_SRC_ALPHA,s->alpha==0x44?GU_ONE_MINUS_SRC_ALPHA:GU_FIX,0,0);
    } else sceGuDisable(GU_BLEND);
    sceGuDepthMask(s->zmask?GU_TRUE:GU_FALSE);
    if(s->test&(1u<<16)) {
        static const int depth[4]={GU_NEVER,GU_ALWAYS,GU_LEQUAL,GU_LESS};
        sceGuEnable(GU_DEPTH_TEST);sceGuDepthFunc(depth[(s->test>>17)&3]);
    } else sceGuDisable(GU_DEPTH_TEST);
    if((s->test&1) && !(s->zmask && ((s->test>>12)&3)==1)) {
        sceGuEnable(GU_ALPHA_TEST);
        sceGuAlphaFunc(alpha_functions[(s->test>>1)&7],alpha_reference(s),255);
    } else sceGuDisable(GU_ALPHA_TEST);
}
/* With Z already masked, both AFAIL=FB_ONLY branches do exactly the same
 * work. With constant opaque alpha and a passing comparison, no fail branch
 * can run. Keep the ordered two-pass path for genuinely mixed fragments. */
static int needs_alpha_fail_pass(void) {
    const BullyNativeState *s=material_state;
    if(!s || !(s->test&1) || ((s->test>>12)&3)!=1 || s->zmask)return 0;
    if(!has_texture || texture.texture.alpha_class==TC_ALPHA_OPAQUE) {
        unsigned fn=(s->test>>1)&7;
        if(fn==1)return 0;
        /* Opaque texels preserve interpolated vertex alpha. Its minimum is
         * bounded by the submitted endpoints, including clipped vertices. */
        unsigned minimum=255,reference=alpha_reference(s);
        for(unsigned i=0;i<queued;i++) {
            unsigned alpha=verts[i].color>>24;
            if(alpha<minimum)minimum=alpha;
        }
        if((fn==5 && minimum>=reference) ||
           ((fn==6 || fn==7) && minimum>reference))return 0;
    }
    return 1;
}
/* Texture alpha modulation cannot increase the vertex alpha bound. Only
 * these comparisons are certified; unknown/mixed batches keep ordered draws. */
static int all_alpha_fail(void) {
    const BullyNativeState *s=material_state;
    if(!s || !(s->test&1) || ((s->test>>12)&3)!=1 || s->zmask || !queued)return 0;
    unsigned fn=(s->test>>1)&7;
    if(fn==0)return 1;
    if(fn!=5 && fn!=6)return 0;
    unsigned maximum=0,reference=alpha_reference(s);
    for(unsigned i=0;i<queued;i++) {
        unsigned alpha=verts[i].color>>24;
        if(alpha>maximum)maximum=alpha;
    }
    return fn==5 ? maximum<reference : maximum<=reference;
}
void bully_world_begin(void) { light_count=state_count=0;collecting_lights=1; }
void bully_world_capture_state(uint32_t pipe,uint32_t gp) {
    if(collecting_lights && state_count<BULLY_NATIVE_MAX_MESHES &&
       bully_native_state(hle_ram,hle_ram_end,pipe,gp,&states[state_count]))state_count++;
}
void bully_world_capture_light(uint32_t pipe,uint32_t gp) {
    if(collecting_lights && light_count<BULLY_NATIVE_MAX_MESHES &&
       bully_native_light(hle_ram,hle_ram_end,pipe,gp,&lights[light_count]))light_count++;
}


void bully_world_enable(void) { enabled=1; }
void bully_world_shutdown(void) {
    enabled=0;scene_camera=0;collecting_lights=0;
    if(!active)return;
    sceGuSync(0,0);sceGuDisplay(GU_FALSE);sceGuTerm();
    active=0;hle_ge_on=0;
}
static void start(void) { sceGuStart(GU_DIRECT,list); }
static void finish(void) { sceGuFinish();sceGuSync(0,0); }
/* All queued vertices share material state. Complete GPU reads before reusing
 * the bounded buffer or converting the next texture. Preserve triangle order. */
static void flush_vertices(void) {
    if(!queued)return;
    sceKernelDcacheWritebackRange(verts,queued*sizeof(*verts));start();
    unsigned type=GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D;
    if(all_alpha_fail()) {
        sceGuAlphaFunc(alpha_functions[inverse_alpha[(material_state->test>>1)&7]],alpha_reference(material_state),255);
        sceGuDepthMask(GU_TRUE);
        sceGuDrawArray(GU_TRIANGLES,type,queued,0,verts);draw_calls++;
        sceGuAlphaFunc(alpha_functions[(material_state->test>>1)&7],alpha_reference(material_state),255);
        sceGuDepthMask(material_state->zmask?GU_TRUE:GU_FALSE);
    } else if(needs_alpha_fail_pass()) {
        /* Preserve primitive order for AFAIL=FB_ONLY, including overlapping
         * triangles: pass writes Z, fail writes only color. The entire
         * bounded vertex batch fits the command list; wait only before reuse. */
        for(unsigned i=0;i<queued;i+=3) {
            sceGuDrawArray(GU_TRIANGLES,type,3,0,verts+i);
            sceGuAlphaFunc(alpha_functions[inverse_alpha[(material_state->test>>1)&7]],alpha_reference(material_state),255);
            sceGuDepthMask(GU_TRUE);
            sceGuDrawArray(GU_TRIANGLES,type,3,0,verts+i);
            sceGuAlphaFunc(alpha_functions[(material_state->test>>1)&7],alpha_reference(material_state),255);
            sceGuDepthMask(material_state->zmask?GU_TRUE:GU_FALSE);
            draw_calls+=2;
        }
    } else {
        sceGuDrawArray(GU_TRIANGLES,type,queued,0,verts);draw_calls++;
    }
    finish();queued=0;
}
static int init(void) {
    const unsigned fb=512*272*4,depth=512*272*2;
    if(hle_ge_on || sceGeEdramGetSize()<2*fb+depth) return 0;
    if(sceGuInit()<0)return 0;
    start();
    sceGuDrawBuffer(GU_PSM_8888,(void *)0,512);
    sceGuDispBuffer(480,272,(void *)(uintptr_t)fb,512);
    sceGuDepthBuffer((void *)(uintptr_t)(2*fb),512);
    sceGuOffset(2048-240,2048-136);sceGuViewport(2048,2048,480,272);
    sceGuScissor(0,0,480,272);sceGuEnable(GU_SCISSOR_TEST);
    sceGuDepthRange(0,65535);sceGuDepthFunc(GU_LEQUAL);sceGuDepthMask(GU_FALSE);
    sceGuEnable(GU_DEPTH_TEST);sceGuDisable(GU_TEXTURE_2D);sceGuDisable(GU_CULL_FACE);
    sceGuDisable(GU_BLEND);sceGuDisable(GU_LIGHTING);sceGuDisable(GU_ALPHA_TEST);
    const ScePspFMatrix4 identity={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
    sceGuSetMatrix(GU_MODEL,&identity);sceGuSetMatrix(GU_VIEW,&identity);
    sceGuEnable(GU_CLIP_PLANES);
    sceGuShadeModel(GU_SMOOTH);sceGuClearColor(0xff101010);sceGuClearDepth(65535);
    sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);finish();
    if(sceDisplaySetMode(0,480,272)<0) { sceGuTerm();return 0; }
    sceGuDisplay(GU_TRUE);
    active=1;hle_ge_on=1;frame=hle_frame;
    LOG("WORLD: live static geometry with native textures enabled\n");return 1;
}
/* A virtual vblank can occur in the middle of rendering one camera. Only
 * the guest camera update boundary owns clearing/presentation of this scene. */
void bully_world_camera_begin(uint32_t camera) {
    scene_camera=camera;
    camera_start_us=sceKernelGetSystemTimeWide();
    if(perf_camera!=camera || !perf_start_us) {
        perf_camera=camera;perf_start_us=camera_start_us;
        perf_camera_us=perf_max_us=0;perf_passes=0;
    }
    objects=triangles=rejected=textured=texture_misses=skinned_objects=draw_calls=lit_meshes=0;
    if(active) { start();sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);finish(); }
}
void bully_world_camera_end(uint32_t camera) {
    if(!scene_camera || camera!=scene_camera)return;
    scene_camera=0;
    collecting_lights=0;
    if(!active || !objects)return;
    sceGuSwapBuffers();
    uint64_t now=sceKernelGetSystemTimeWide(),elapsed=now-camera_start_us;
    perf_camera_us+=elapsed;perf_passes++;
    if(elapsed>perf_max_us)perf_max_us=elapsed;
    if(now-perf_start_us>=5000000ull) {
        LOG("WORLD_PERF: camera=%08x passes=%u wall_us=%llu camera_us=%llu max_camera_us=%llu\n",
            camera,perf_passes,(unsigned long long)(now-perf_start_us),
            (unsigned long long)perf_camera_us,(unsigned long long)perf_max_us);
        perf_start_us=now;perf_camera_us=perf_max_us=0;perf_passes=0;
    }
    frame=hle_frame;
    if(reports++<8 || !(reports%120))LOG("WORLD_COMPLETE: camera=%08x frame=%u objects=%u triangles=%u rejected=%u textured_meshes=%u texture_misses=%u skinned_objects=%u draw_calls=%u lit_meshes=%u\n",camera,(unsigned)frame,objects,triangles,rejected,textured,texture_misses,skinned_objects,draw_calls,lit_meshes);
}
static void bind_material(uint32_t material) {
    has_texture=bully_native_texture(hle_ram,hle_ram_end,material,texels,WORLD_TEXTURE_BYTES,&texture);
    start();
    if(!has_texture) {
        sceGuDisable(GU_TEXTURE_2D);sceGuDisable(GU_ALPHA_TEST);
        texture_misses++;apply_state();finish();return;
    }
    TcPspTex *p=&texture.texture;
    sceKernelDcacheWritebackRange(texels,p->total_bytes);
    sceGuTexMode(p->psm,0,0,p->swizzled);
    sceGuTexImage(0,p->level[0].width,p->level[0].height,p->level[0].bufw,texels+p->level[0].offset);
    if(p->clut_entries) {
        sceGuClutMode(p->clut_psm,0,p->clut_entries-1,0);
        sceGuClutLoad(p->clut_bytes/32,texels+p->clut_offset);
    }
    sceGuTexFlush();
    sceGuTexFunc(GU_TFX_MODULATE,GU_TCC_RGBA);
    int filter=texture.filter==1?GU_NEAREST:GU_LINEAR;
    sceGuTexFilter(filter,filter);
    sceGuTexWrap(texture.wrap_u==3?GU_CLAMP:GU_REPEAT,texture.wrap_v==3?GU_CLAMP:GU_REPEAT);
    sceGuTexScale(1,1);sceGuTexOffset(0,0);
    sceGuEnable(GU_TEXTURE_2D);
    sceGuAlphaFunc(GU_GREATER,0,255);sceGuEnable(GU_ALPHA_TEST);
    apply_state();finish();textured++;
    if(texture_reports++<3)LOG("WORLD: texture material=%08x size=%ux%u bytes=%u\n",material,p->level[0].width,p->level[0].height,p->total_bytes);
}
static unsigned channel(float f) { return f<=0?0:f>=255?255:(unsigned)f; }
/* Positive screen coordinates need only the upper clamp. Retain the original
 * library path for zero, negative, NaN and flushed subnormal comparisons. */
static inline float screen_clamp(float value,float maximum) {
    if(value>0.0f)return value<maximum?value:maximum;
    return fminf(maximum,fmaxf(0.0f,value));
}

/* A strip shares two vertices with its next triangle. Transform and shade
 * each decoded vertex once; a three-entry stack ring also handles skin skips. */
static void prepare_vertex(const BullyNativeVertex *src,BullyClipVertex *out) {
    for(int k=0;k<3;k++) {
        float p=object_view.view[3][k];
        for(int j=0;j<3;j++)p+=src->position[j]*object_view.view[j][k];
        out->p[k]=p;out->color[k]=src->color[k]*2.0f;
    }
    out->alpha=255;
    if(material_light) {
        bully_light_color(src,material_light,out->color);
        out->alpha=bully_light_alpha(src,material_light);
    }
    for(int k=0;k<2;k++)out->uv[k]=src->uv[k];
}
static void triangle(const BullyClipVertex *a,const BullyClipVertex *b,const BullyClipVertex *c,BullyClipCache *cache) {
    BullyClipVertex in[3]={*a,*b,*c},out[10];
    int n=bully_clip_triangle_cached(in,object_view.near_plane,object_view.far_plane,out,cache);
    if(!n)return;
    /* A clipped polygon is triangulated as a fan. Prepare each polygon
     * vertex once, keeping screen coordinates separate from GE positions.
     * All UV validation still finishes before any triangle is submitted. */
    GeVertex projected[10],clipped[24];
    float screen_x[10],screen_y[10];
    for(int j=0;j<n;j++) {
        const BullyClipVertex *v=&out[j];
        projected[j].u=v->uv[0];projected[j].v=v->uv[1];
        if(!isfinite(projected[j].u) || !isfinite(projected[j].v))return;
        screen_x[j]=screen_clamp(480*v->p[0]/v->p[2],480);
        screen_y[j]=screen_clamp(272*v->p[1]/v->p[2],272);
        projected[j].color=(channel(v->alpha)<<24)|channel(v->color[0])|(channel(v->color[1])<<8)|(channel(v->color[2])<<16);
        projected[j].x=v->p[0];projected[j].y=v->p[1];projected[j].z=v->p[2];
    }
    int count=0;
    for(int i=1;i<n-1;i++) {
        float area=(screen_x[i]-screen_x[0])*(screen_y[i+1]-screen_y[0])-
                   (screen_x[i+1]-screen_x[0])*(screen_y[i]-screen_y[0]);
        if(fabsf(area)<0.001f)continue;
        clipped[count++]=projected[0];
        clipped[count++]=projected[i];
        clipped[count++]=projected[i+1];
    }
    if(!count)return;
    if(queued+(unsigned)count>WORLD_BATCH_VERTICES)flush_vertices();
    for(int i=0;i<count;i++)verts[queued++]=clipped[i];
    triangles+=count/3;
}
/* Visibility and projection belong to each shared vertex. Crossing triangles
 * retain the reference clipper and its double-precision intersections. */
typedef struct {
    BullyClipVertex vertex;
    GeVertex draw;
    float screen_x,screen_y;
    int code;
} PreparedVertex;
static void prepare_cached(const BullyNativeVertex *src,PreparedVertex *out) {
    prepare_vertex(src,&out->vertex);
    out->code=bully_clip_vertex_code(&out->vertex,object_view.near_plane,object_view.far_plane);
    if(out->code)return;
    const BullyClipVertex *v=&out->vertex;
    out->screen_x=screen_clamp(480*v->p[0]/v->p[2],480);
    out->screen_y=screen_clamp(272*v->p[1]/v->p[2],272);
    out->draw.u=v->uv[0];out->draw.v=v->uv[1];
    out->draw.color=(channel(v->alpha)<<24)|channel(v->color[0])|(channel(v->color[1])<<8)|(channel(v->color[2])<<16);
    out->draw.x=v->p[0];out->draw.y=v->p[1];out->draw.z=v->p[2];
}
static void triangle_cached(const PreparedVertex *a,const PreparedVertex *b,const PreparedVertex *c,BullyClipCache *cache) {
    if(a->code<0 || b->code<0 || c->code<0)return;
    if(a->code & b->code & c->code)return;
    if(a->code | b->code | c->code) {
        triangle(&a->vertex,&b->vertex,&c->vertex,cache);return;
    }
    float area=(b->screen_x-a->screen_x)*(c->screen_y-a->screen_y)-
               (b->screen_y-a->screen_y)*(c->screen_x-a->screen_x);
    if(fabsf(area)<0.001f)return;
    if(queued+3>WORLD_BATCH_VERTICES)flush_vertices();
    verts[queued++]=a->draw;verts[queued++]=b->draw;verts[queued++]=c->draw;
    triangles++;
}
static void draw_strip(const BullyNativeVertex *v,const uint8_t *skip,size_t n) {
    PreparedVertex ring[3];BullyClipCache cache;bully_clip_cache_reset(&cache);
    for(size_t i=0;i<n;i++) {
        prepare_cached(&v[i],&ring[i%3]);
        if(i>=2 && (!skip || !skip[i]))
            triangle_cached(&ring[(i-2)%3],&ring[(i-1)%3],&ring[i%3],&cache);
    }
}
static void draw_batch(const BullyNativeVertex *v,size_t n,void *context) {
    (void)context;draw_strip(v,0,n);
}
static void draw_skin_batch(const BullyNativeVertex *v,const uint8_t *skip,size_t n,void *context) {
    (void)context;draw_strip(v,skip,n);
}
void bully_world_draw(uint32_t object,uint32_t camera) {
    collecting_lights=0;
    if(!enabled || !scene_camera || camera!=scene_camera)return;
    if(!mesh)mesh=hle_plat_big_alloc(256*sizeof(*mesh));
    if(!texels)texels=hle_plat_big_alloc(WORLD_TEXTURE_BYTES);
    if(!bully_native_object(hle_ram,hle_ram_end,object,camera,mesh,&object_view)) {
        if(rejected++<8)LOG("WORLD: unsupported object=%08x camera=%08x\n",object,camera);
        return;
    }
    if(!active && !init())return;
    ScePspFMatrix4 projection;
    float matrix[16];
    if(!bully_projection_matrix(object_view.near_plane,object_view.far_plane,matrix))return;
    memcpy(&projection,matrix,sizeof(projection));
    start();sceGuSetMatrix(GU_PROJECTION,&projection);finish();
    objects++;
    if(object_view.bones)skinned_objects++;
    for(unsigned m=0;m<object_view.meshes;m++) {
        BullyNativeMeshView *v=&object_view.mesh[m];size_t n=0;
        material_light=0;
        if(v->compressed==1)for(unsigned l=0;l<light_count;l++)
            if(lights[l].stream==v->stream && lights[l].material_id==v->material) { material_light=&lights[l];break; }
        if(material_light)lit_meshes++;
        material_state=0;
        for(unsigned j=0;j<state_count;j++)
            if(states[j].stream==v->stream && states[j].material==v->material) { material_state=&states[j];break; }
        bind_material(v->material);
        if(v->compressed==2) {
            size_t used=0,tris=0;
            bully_skin_chain(hle_ram,hle_ram_end,v->stream,object_view.palette,object_view.bones,
                             mesh,draw_skin_batch,0,&n,&used,&tris);
        } else if(v->compressed) {
            size_t used=0;
            /* Adapter validated every mesh before any draws. Guest RAM is not
             * executed or mutated while these synchronous batches are submitted. */
            bully_compressed_chain(hle_ram,(size_t)v->stream+v->bytes,v->stream,
                                   mesh,draw_batch,0,&n,&used);
        } else if(bully_native_decode(hle_ram+v->stream,v->bytes,mesh,256,&n))
            draw_batch(mesh,n,0);
        flush_vertices();
    }
}
