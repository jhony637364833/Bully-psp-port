#include "native_object.h"
#include "native_light.h"
#include "world_clip.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully vertex work",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
PSP_MAIN_THREAD_STACK_SIZE_KB(128);
static void mode(unsigned m,unsigned fs){unsigned x=m|(fs<<24)|0x80007c;__asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(x):"memory");}
static unsigned status(void){unsigned x;__asm__ volatile("cfc1 %0,$31":"=r"(x)::"memory");return x;}
#else
#include <fenv.h>
static void mode(unsigned m,unsigned fs){(void)fs;int r[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(r[m]);feclearexcept(FE_ALL_EXCEPT);}
static unsigned status(void){return fetestexcept(FE_ALL_EXCEPT);}
#endif
BullyNativeObject object_view;
const BullyNativeLight *material_light;
void baseline_prepare(const BullyNativeVertex*,BullyClipVertex*);
void candidate_prepare(const BullyNativeVertex*,BullyClipVertex*);
int candidate_compressed(const uint8_t*,size_t,uint32_t,BullyNativeVertex*,BullyNativeVisit,void*,size_t*,size_t*);
#define main compressed_checks
#define reference_chain baseline_compressed
#define bully_compressed_chain candidate_compressed
#include "compressed_checks.inc"
#undef bully_compressed_chain
#undef reference_chain
#undef main
static unsigned prep_seed=0x123f245a;
static unsigned prep_rnd(void){prep_seed=1664525u*prep_seed+1013904223u;return prep_seed;}
static void prep_fill(void*p,size_t n){unsigned char*s=p;while(n--)*s++=prep_rnd()>>24;}
static float scalar(void){float f;unsigned x=prep_rnd();memcpy(&f,&x,4);return f;}
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);if(!freopen("vertex-work.log","w",stdout))return 2;
#endif
 unsigned cases=0,clears=0;unsigned char arena[256] __attribute__((aligned(16))),expected[256];
 for(unsigned m=0;m<4;m++)for(unsigned fs=0;fs<2;fs++){
  for(unsigned t=0;t<4096;t++){
   prep_fill(arena,sizeof arena);memcpy(expected,arena,sizeof arena);unsigned at=32+4*(t%32);memset(expected+at,0,sizeof(BullyNativeVertex));mode(m,fs);unsigned before=status();bully_native_vertex_clear((BullyNativeVertex*)(arena+at));unsigned after=status();
   if(memcmp(arena,expected,sizeof arena)||before!=after){printf("ERROR raw clear m=%u fs=%u t=%u\n",m,fs,t);fflush(stdout);return 1;}clears++;
   BullyNativeVertex v;BullyNativeLight light;BullyClipVertex a,b;prep_fill(&v,sizeof v);prep_fill(&light,sizeof light);memset(&a,0x97,sizeof a);b=a;
   for(unsigned r=0;r<4;r++)for(unsigned k=0;k<3;k++)object_view.view[r][k]=t%4==0?scalar():(float)(int)(prep_rnd()%129)-64.0f;
   for(unsigned k=0;k<3;k++){v.position[k]=t%4==0?scalar():(float)(int)(prep_rnd()%129)/32.0f-2.0f;light.gain[k]=(float)(prep_rnd()%256)/128.0f;light.material[k]=(float)(prep_rnd()%256)/510.0f;}
   light.blend=(float)(prep_rnd()%256)/256.0f;light.material_alpha=(float)(prep_rnd()%256)/510.0f;light.monochrome=t%3==0;
   material_light=t&1?&light:NULL;
   mode(m,fs);baseline_prepare(&v,&a);unsigned fa=status();mode(m,fs);candidate_prepare(&v,&b);unsigned fb=status();
   if(memcmp(&a,&b,sizeof a)||fa!=fb){printf("ERROR vertex m=%u fs=%u t=%u output=%d FCR=%08x/%08x\n",m,fs,t,memcmp(&a,&b,sizeof a),fa,fb);fflush(stdout);return 1;}cases++;
  }
  mode(m,fs);int rc=compressed_checks();if(rc)return rc;
 }
 printf("COMPLETE vertex=%u clear=%u compressed=80000 allbytes/guards/FPU-status exact errors=0\n",cases,clears);fflush(stdout);
#ifdef __PSP__
 fclose(stdout);sceKernelExitGame();
#endif
 return 0;
}
