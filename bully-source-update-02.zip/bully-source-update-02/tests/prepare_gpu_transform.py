from pathlib import Path
import shutil,argparse
r=Path(__file__).resolve().parents[1];t=r/'tests';a=argparse.ArgumentParser();a.add_argument('output',type=Path);a.add_argument('--extended',action='store_true');args=a.parse_args();b=args.output.resolve();b.mkdir(parents=True,exist_ok=True);g=r/'app/games/SLUS-21269_v1.02/src'
head='''#include <pspkernel.h>
#include <pspgu.h>
#include <pspge.h>
#include <pspdisplay.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
PSP_MODULE_INFO("Bully submission check",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
static unsigned gpu_open,gpu_max_bytes,gpu_starts,gpu_syncs;
void bully_overlay_flush(void){assert(!gpu_open);}
static int tracked_start(int context,void*list){assert(!gpu_open);gpu_open=1;gpu_starts++;return sceGuStart(context,list);}
static int tracked_finish(void){assert(gpu_open);gpu_open=0;int n=sceGuFinish();assert(n>0&&n<=16384);if((unsigned)n>gpu_max_bytes)gpu_max_bytes=n;return n;}
static int tracked_sync(int a,int b){assert(!gpu_open);gpu_syncs++;return sceGuSync(a,b);}
#define sceGuStart tracked_start
#define sceGuFinish tracked_finish
#define sceGuSync tracked_sync
'''
for name in ['reference','candidate']:
 p=b/('gpu-'+name);p.mkdir(exist_ok=True)
 shutil.copy2(r/'tests/psp_state_smoke/hle.h',p/'hle.h')
 fixture=(t/'gpu_guard_fixture.inc').read_text().replace('unsigned fn=(fixture_case+mesh)%8,ref=', 'unsigned fn=fixture_case==128?0:(fixture_case+mesh)%8,ref=')
 if args.extended:
  fixture=fixture.replace('out->near_plane=1;', 'out->view[0][0]=2;out->view[1][1]=.5f;out->view[3][0]=2;out->view[3][1]=1;out->near_plane=1;')
  fixture=fixture.replace('out->mesh[m].compressed=1;', 'out->bones=1;out->mesh[m].compressed=(m%2 || fixture_case%2)?2:1;')
  fixture=fixture.replace('(void)r;(void)b;(void)a;(void)p;(void)bones;(void)s;(void)f;(void)ctx;*n=*used=*tris=0;return 0;', '(void)p;(void)bones;uint8_t skip[256]={0};int ok=bully_compressed_chain(r,b,a,s,0,ctx,n,used);*tris=0;for(size_t i=2;i<*n;i++){skip[i]=(fixture_case%4==0 || (fixture_case%4==1 && i%3==0) || (fixture_case%4==2 && i%5!=0));if(!skip[i])(*tris)++;}if(f){f(s,skip,*n,ctx);if(geometry(fixture_mesh)==3)f(s,skip,*n,ctx);}return ok;')
 s=head+((t/'gpu_transform_reference_55.inc') if name=='reference' else (g/'psp/world_display.c')).read_text()+'\n#undef sceGuStart\n#undef sceGuFinish\n#undef sceGuSync\n'+fixture+(t/'texture_cache_unavailable.inc').read_text()+(t/'gpu_guard_main.inc').read_text()
 (p/'main.c').write_text(s)
 (p/'Makefile').write_text('''.DEFAULT_GOAL := all
TARGET = submission_test
OBJS = main.o world_clip.o
BULLY_SRC = '''+str(g)+'''
INCDIR = . $(BULLY_SRC)
VPATH = $(BULLY_SRC)
CFLAGS = -O2 -G0 -Wall -fno-math-errno -fno-fast-math -frounding-math -ffp-contract=off
BUILD_PRX = 1
LIBS = -lpspgu -lpspge -lm
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully submission check
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
''')
print('Prepared original and candidate complete-renderer PSP GPU fixtures')
