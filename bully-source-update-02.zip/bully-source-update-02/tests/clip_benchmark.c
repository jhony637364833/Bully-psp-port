#include "world_clip.h"
#include <stdio.h>
#include <time.h>
int baseline_clip(const BullyClipVertex*,float,float,BullyClipVertex*);
static void bench(const char* name,int(*fn)(const BullyClipVertex*,float,float,BullyClipVertex*)) {
 BullyClipVertex in[3]={{{1,1,2},{128,128,128},{0,0}},{{2,1,3},{128,128,128},{1,0}},{{1,3,4},{128,128,128},{0,1}}},out[10];
 clock_t begin=clock();unsigned total=0;
 for(int i=0;i<2000000;i++)total+=fn(in,1,100,out);
 printf("%s: %.3f CPU seconds, %u vertices\n",name,(double)(clock()-begin)/CLOCKS_PER_SEC,total);
}
int main(void){for(int i=0;i<3;i++){bench("before",baseline_clip);bench("after",bully_clip_triangle);}return 0;}
