"""Compare generated hot bodies with prepared v0 bodies, including every safe point.

Usage: python tests/check_hot_bodies.py BUILD/gen WORK/modules/bully_hot.c
For the earlier v0 native specialization (not selected by the v5 pack).
Requires a converter build from the matching user's disc; no disc data is stored here.
"""
import re
import sys
from pathlib import Path

HOT = (0x0037EDB0, 0x0037EEB0)

def body(source, name):
    match = re.search(r"^void " + re.escape(name) + r"\(R5900Ctx \*c\)\n\{\n(.*?)^\}", source, re.M | re.S)
    if not match:
        raise AssertionError("missing function " + name)
    return match.group(1).strip()

prepared = "\n".join(p.read_text() for p in sorted(Path(sys.argv[1]).glob("*.c")))
hot = Path(sys.argv[2]).read_text()
for address in HOT:
    name = "fn_%08x" % address
    if "void " + name + "__ynguest(" in prepared:
        name += "__ynguest"
    expected = body(prepared, name)
    actual = body(hot, "y_nat_%08x" % address)
    assert actual == expected, "prepared body differs at %08x" % address
    print("%08x: identical body, %d scheduler checkpoints" % (address, actual.count("RC_BACKEDGE_AT(")))
