 /* Early original UI owns a clean background only when GU is free. */
 hle_ram=fixture_ram;hle_ram_end=sizeof fixture_ram;
 hle_ge_on=1;assert(!bully_world_overlay_begin()&&!active);hle_ge_on=0;
 feed_sky(0x800000ff,0,1);assert(active&&overlay_background&&overlay_started);read_pixels(before);
 assert((before[2*480+2]&0xffffff)==0xff);assert((before[20*480+20]&0xffffff)==0x101010);
 bully_world_overlay_present();feed_sky(0x80ff0000,0,1);read_pixels(before);
 assert((before[2*480+2]&0xffffff)==0xff0000);assert((before[20*480+20]&0xffffff)==0x101010);
 bully_world_overlay_present();bully_world_shutdown();assert(!active&&!hle_ge_on);
 puts("PASS original UI before first camera, clean repeated background, movie GU ownership");
