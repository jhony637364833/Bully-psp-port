from pathlib import Path
import argparse,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path);a=p.parse_args();s=a.source.read_text();out=a.output or Path(tempfile.mkdtemp(prefix='bully-composition-'));out.mkdir(parents=True,exist_ok=True)
def body(signature):
 start=s.index(signature);beg=s.index('{',start);depth=1;end=beg+1
 while depth:
  depth+=(s[end]=='{')-(s[end]=='}');end+=1
 return s[start:end]
head='''#include <assert.h>
#include <stdint.h>
#include <stdio.h>
static int active=1,overlay_background,overlay_world_new,overlay_started,overlay_defer_world;
static int hle_ge_on,init_calls;static uint32_t scene_camera,perf_camera;static uint64_t camera_start_us,perf_start_us,perf_camera_us,perf_max_us;static unsigned perf_passes;
static unsigned objects,triangles,rejected,textured,texture_misses,skinned_objects,draw_calls,lit_meshes,underlay_active,clear_pending;
static unsigned overlay_draw_offset,displayed=99,pixels[3],swaps,copies;
#define OVERLAY_BG 2
static void copy_background(unsigned from,unsigned to){assert(from<3&&to<3);pixels[to]=pixels[from];copies++;}
static void *sceGuSwapBuffers(void){displayed=pixels[overlay_draw_offset];swaps++;return(void*)(uintptr_t)(overlay_draw_offset^1);}
static int init(void){init_calls++;if(hle_ge_on)return 0;active=1;overlay_background=overlay_world_new=overlay_started=overlay_defer_world=0;pixels[overlay_draw_offset]=10;return 1;}
static void bully_overlay_flush(void){}
static uint64_t sceKernelGetSystemTimeWide(void){return 100;}
static void clip_camera_begin(uint32_t c){(void)c;}
'''
functions=[]
if 'static void present_composition(void)' in s:functions.append(body('static void present_composition(void)'))
functions.extend(body(x) for x in ['void bully_world_camera_begin(uint32_t camera)','int bully_world_overlay_begin(void) {','void bully_world_overlay_present(void) {'])
main='''
static void world(unsigned value){assert(clear_pending);pixels[overlay_draw_offset]=value;clear_pending=0;pixels[OVERLAY_BG]=value;scene_camera=0;overlay_background=overlay_world_new=1;}
static void hud(unsigned value){assert(bully_world_overlay_begin());pixels[overlay_draw_offset]=value;}
int main(void){
 /* Movie-owned GU and a camera under construction cannot bootstrap UI. */
 active=0;hle_ge_on=1;assert(!bully_world_overlay_begin());assert(init_calls==1&&!active);
 hle_ge_on=0;scene_camera=1;assert(!bully_world_overlay_begin());assert(init_calls==1&&!active);scene_camera=0;
 /* Original UI before the first 3D camera renders over a clean background. */
 assert(bully_world_overlay_begin());assert(active&&overlay_background&&overlay_started&&init_calls==2);
 pixels[overlay_draw_offset]=11;bully_world_overlay_present();assert(displayed==11&&swaps==1);
 assert(bully_world_overlay_begin());assert(pixels[overlay_draw_offset]==10);pixels[overlay_draw_offset]=12;
 bully_world_overlay_present();assert(displayed==12&&swaps==2);
 /* An active renderer without a complete background still refuses overlays. */
 overlay_background=0;assert(!bully_world_overlay_begin());
 active=1;overlay_background=overlay_world_new=overlay_started=overlay_defer_world=0;overlay_draw_offset=0;swaps=copies=0;displayed=99;

 /* No completed world: refuse early UI. Initial camera presents normally. */
 assert(!bully_world_overlay_begin());bully_world_camera_begin(1);world(10);bully_world_overlay_present();assert(displayed==10&&swaps==1);
 /* Observed game order: HUD DMA, next camera clear/draw/end, guest flip. */
 hud(11);bully_world_camera_begin(1);assert(displayed==11&&swaps==2);world(20);bully_world_overlay_present();assert(displayed==11&&swaps==2);
 hud(21);bully_world_camera_begin(1);assert(displayed==21&&swaps==3);world(30);bully_world_overlay_present();assert(displayed==21&&swaps==3);
 /* UI-only updates and repeated menus restore the clean world background. */
 hud(31);bully_world_overlay_present();assert(displayed==31&&swaps==4);
 assert(bully_world_overlay_begin());assert(pixels[overlay_draw_offset]==30);pixels[overlay_draw_offset]=32;bully_world_overlay_present();assert(displayed==32&&swaps==5);
 /* A HUD produced after the current camera retains ordinary flip timing. */
 bully_world_camera_begin(1);world(40);hud(41);bully_world_overlay_present();assert(displayed==41&&swaps==6);
 /* A frame with no HUD still displays its completed world. */
 bully_world_camera_begin(1);world(50);bully_world_overlay_present();assert(displayed==50&&swaps==7);
 /* Empty pause camera consumes deferral, including when flip has no work. */
 hud(51);bully_world_camera_begin(2);assert(displayed==51&&swaps==8);scene_camera=0;bully_world_overlay_present();assert(!overlay_defer_world&&swaps==8);
 bully_world_camera_begin(1);world(60);bully_world_overlay_present();assert(displayed==60&&swaps==9);
 /* A late UI after an early presentation still presents at this flip. */
 hud(61);bully_world_camera_begin(1);assert(displayed==61&&swaps==10);world(70);hud(71);bully_world_overlay_present();assert(displayed==71&&swaps==11);
 /* Nested camera starts must not swap a partially constructed camera. */
 bully_world_camera_begin(1);hud(72);bully_world_camera_begin(2);assert(swaps==11);world(80);bully_world_overlay_present();assert(displayed==80&&swaps==12);
 puts("PASS actual composition functions: early/late HUD, repeated menus, empty/nested cameras, no-HUD frames");return 0;
}
'''
(out/'check.c').write_text(head+'\n'.join(functions)+main)
subprocess.run(['gcc','-O2','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-unused-parameter','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(out/'check.c'),'-o',str(out/'check')],check=True)
subprocess.run([str(out/'check')],check=True)
