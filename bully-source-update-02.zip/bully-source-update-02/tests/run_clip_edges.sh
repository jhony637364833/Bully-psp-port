#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bully_test_dir=$(mktemp -d)
trap 'rm -rf "$bully_test_dir"' EXIT
bully_src=app/games/SLUS-21269_v1.02/src
${CC:-cc} -O2 -fno-fast-math -ffp-contract=off -fsanitize=address,undefined -I"$bully_src" \
 -Dbully_clip_triangle=edge_reference_clip \
 -Dbully_clip_vertex_code=edge_reference_code \
 -c tests/clip_edge_reference.c -o "$bully_test_dir/before.o"
${CC:-cc} -O2 -fno-fast-math -ffp-contract=off -fsanitize=address,undefined -I"$bully_src" \
 tests/clip_edge_test.c "$bully_test_dir/before.o" "$bully_src/world_clip.c" -lm -o "$bully_test_dir/test"
"$bully_test_dir/test"
