/* Legacy synthetic render fixtures exercise the allocation-failure path.
 * Actual cache mutation and borrowed-resource lifetimes have separate tests. */
#include <assert.h>
size_t bully_native_texture_cache_bytes(void){return 0x40000000u;}
void bully_native_texture_cache_init(BullyNativeTextureCache *c){(void)c;assert(0 && "cache must be unavailable in this fixture");}
int bully_native_texture_view(const uint8_t*r,size_t bytes,uint32_t m,void*dst,size_t cap,BullyNativeTexture*out,BullyNativeTextureCache*c,const void**view){
 assert(!c);int ok=bully_native_texture(r,bytes,m,dst,cap,out);if(ok)*view=dst;return ok;
}
