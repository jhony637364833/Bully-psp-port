"""Compile binary MMI with architectural $zero in either operand/destination.
Compare all output context bytes against the stored-zero baseline semantics.
"""
from pathlib import Path
from types import SimpleNamespace
import os,sys,subprocess,tempfile,argparse
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('engine',type=Path,help='PS2RC checkout with app overlay applied');args=parser.parse_args()
assert (args.engine/'ps2rc/backend_c.py').read_bytes()==(root/'app/ps2rc/backend_c.py').read_bytes()
sys.path.insert(0,str(args.engine))
from ps2rc.backend_c import stmt,_MMI3
code=['#include "r5900_rt.h"','#include <stdio.h>']
names=[]
for op in sorted(_MMI3):
 for dest,s,t in [(3,0,4),(3,4,0),(3,0,0),(4,0,4),(0,3,4),(3,4,5)]:
  i=SimpleNamespace(mnem=op,ops=[('r',dest),('r',s),('r',t)],pc=0x1000,word=0)
  name=f'test_{len(names)}';names.append(name)
  code.append(f'static int {name}(R5900Ctx *c) {{ R5900Ctx before=*c, expected=*c;')
  if dest:code.append(f'expected.r[{dest}]=mmi_{op}(before.r[{s}],before.r[{t}]);')
  code.append(stmt(i)+'return memcmp(c,&expected,sizeof expected);}')
code.append('''static unsigned seed=0x184703;static unsigned rnd(void){seed=seed*1664525u+1013904223u;return seed;}
int main(void){R5900Ctx c;unsigned checks=0;
for(unsigned n=0;n<1000;n++){
memset(&c,0,sizeof c);for(unsigned i=1;i<32;i++)for(unsigned k=0;k<4;k++)c.r[i].w[k]=rnd();''')
for name in names:code.append(f'if({name}(&c)){{puts("{name} mismatch");return 1;}} checks++;')
code.append('}printf("binary MMI codegen comparisons=%u errors=0\\n",checks);return 0;}')
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'test.c').write_text('\n'.join(code))
 subprocess.run([os.environ.get('CC','cc'),'-O2','-I'+str(root/'app/runtime'),str(p/'test.c'),'-lm','-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
