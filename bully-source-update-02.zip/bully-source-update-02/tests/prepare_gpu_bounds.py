from pathlib import Path
import argparse
r=Path(__file__).resolve().parents[1];g=r/'app/games/SLUS-21269_v1.02/src'
a=argparse.ArgumentParser();a.add_argument('output',type=Path);args=a.parse_args();d=args.output.resolve();d.mkdir(parents=True,exist_ok=True)
s=(g/'psp/world_display.c').read_text();s=s[s.index('static int gpu_strip_bounds'):s.index('static inline int gpu_same_position')]
head='''#include "native_object.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("GPU bounds proof trials",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
static void setmode(unsigned m){unsigned csr=0x01000000u|m;__asm__ volatile("ctc1 %0,$31\\n\\tnop\\n\\tnop"::"r"(csr):"memory");}
#else
#include <fenv.h>
static void setmode(unsigned m){int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(modes[m]);}
#endif
static BullyNativeObject object_view;
'''
main='''
static uint32_t seed=1234;static uint32_t rnd(void){seed=seed*1664525u+1013904223u;return seed;}
static float val(void){return ((int)(rnd()%20001)-10000)/1000.0f;}
int main(void){
#ifdef __PSP__
freopen("bounds.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
#endif
unsigned counts[3]={0},crossings=0;BullyNativeVertex v[256];
for(unsigned mode=0;mode<4;mode++)for(unsigned t=0;t<20000;t++){
 setmode(mode);unsigned n=12+rnd()%245;
 memset(&object_view,0,sizeof(object_view));object_view.near_plane=.1f;object_view.far_plane=1000;
 for(unsigned k=0;k<3;k++){object_view.view[k][k]=1;object_view.view[3][k]=k==2?50:25;}
 if(t%4==0)for(unsigned j=0;j<4;j++)for(unsigned k=0;k<3;k++)object_view.view[j][k]=val();
 if(t%8==1)object_view.view[3][0]=0;
 if(t%4==2)object_view.view[3][0]=-100;
 if(t%4==3)object_view.view[3][2]=-.01f;
 for(unsigned i=0;i<n;i++)for(unsigned k=0;k<3;k++)v[i].position[k]=val();
 if(t%17==0){uint32_t bits[]={0,0x80000000u,1,0x80000001u,0x7f7fffffu,0x7f800000u,0xff800000u,0x7fc12345u,0x7f800001u};memcpy(&v[t%n].position[t%3],&bits[(t/17)%9],4);}
 int result=gpu_strip_bounds(v,n);counts[result+1]++;
 if(result){unsigned common=63;for(unsigned i=0;i<n;i++){
  float p[3];for(unsigned k=0;k<3;k++){p[k]=object_view.view[3][k];for(unsigned j=0;j<3;j++)p[k]+=v[i].position[j]*object_view.view[j][k];}
  if(!isfinite(p[0])||!isfinite(p[1])||!isfinite(p[2])){printf("ERROR nonfinite t=%u mode=%u result=%d\\n",t,mode,result);return 1;}
  unsigned code=(p[2]<object_view.near_plane)|((p[2]>object_view.far_plane)<<1)|((p[0]<0)<<2)|((p[0]>p[2])<<3)|((p[1]<0)<<4)|((p[1]>p[2])<<5);common&=code;if(result>0 && code)crossings++;
  if(result>0 && ((code&3) || p[0]/p[2]<-1 || p[0]/p[2]>2 || p[1]/p[2]<-1 || p[1]/p[2]>2)){printf("ERROR false-inside t=%u mode=%u code=%u\\n",t,mode,code);return 1;}
 }
 if(result<0 && !common){printf("ERROR false-outside t=%u mode=%u\\n",t,mode);return 1;}}
}
assert(crossings>100);assert(counts[0]>100 && counts[1]>100 && counts[2]>100);printf("COMPLETE cases=80000 outside=%u fallback=%u inside=%u errors=0\\n",counts[0],counts[1],counts[2]);
#ifdef __PSP__
sceKernelExitGame();
#endif
return 0;}
'''
(d/'main.c').write_text(head+s+main)
(d/'Makefile').write_text('TARGET = bounds\nOBJS = main.o\nINCDIR = '+str(g)+'\nCFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -fno-fast-math -frounding-math -ffp-contract=off\nBUILD_PRX = 1\nLIBS = -lm\nEXTRA_TARGETS = EBOOT.PBP\nPSPSDK = $(shell psp-config --pspsdk-path)\ninclude $(PSPSDK)/lib/build.mak\n')
