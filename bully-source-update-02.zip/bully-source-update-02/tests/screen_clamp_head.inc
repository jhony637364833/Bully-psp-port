#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully screen clamp check",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
#else
#include <fenv.h>
#endif
