#include "main.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
uint32_t hle_ram_end=0x2000000,hle_backedge_count;
volatile uint32_t hle_where;
static uint64_t trace;static unsigned calls,hist[6];
void hle_alias_check(uint32_t a){fprintf(stderr,"alias %x\n",a);abort();}
static void boundary(R5900Ctx*c,unsigned id){
 assert(++calls<10000);hist[id]++;trace=(trace^id)*1099511628211ull;
 unsigned char*p=(unsigned char*)c->r;
 for(unsigned i=0;i<sizeof(c->r);i++)trace=(trace^p[i])*1099511628211ull;
 c->r[26].d[1]^=0xabc000ull+id;c->r[27].d[0]^=calls;c->ram[0x100]^=id;
}
void hle_backedge_slow(R5900Ctx*c){boundary(c,1);hle_backedge_count=0;}
void fn_0011e620(R5900Ctx*c){boundary(c,2);}
void fn_0011e670(R5900Ctx*c){boundary(c,3);}
void fn_002352d8(R5900Ctx*c){boundary(c,4);}
void fn_0024cf38(R5900Ctx*c){boundary(c,5);}
#include "cache_baseline.inc"
#include "../app/games/SLUS-21269_v1.02/src/texture_cache_fast.c"
int main(int argc,char**argv){
 assert(argc==3);
 uint8_t*initial=malloc(hle_ram_end),*ram=malloc(hle_ram_end),*expected=malloc(hle_ram_end);assert(initial&&ram&&expected);
 FILE*f=fopen(argv[1],"rb");assert(f);assert(fread(initial,1,hle_ram_end,f)==hle_ram_end);fclose(f);
 unsigned n=0,total_calls=0;for(unsigned mode=0;mode<16;mode++){
  R5900Ctx c={0},seed,old;
  f=fopen(argv[2],"rb");assert(f);assert(fread(&c,1,sizeof c,f)==sizeof c);fclose(f);
  c.ram=ram;seed=c;
  memcpy(ram,initial,hle_ram_end);hle_backedge_count=1023-mode;hle_where=0;trace=1469598103934665603ull;calls=0;
  cache_baseline(&c);old=c;unsigned old_count=hle_backedge_count,old_where=hle_where,old_calls=calls;uint64_t old_trace=trace;
  memcpy(expected,ram,hle_ram_end);memcpy(ram,initial,hle_ram_end);c=seed;hle_backedge_count=1023-mode;hle_where=0;trace=1469598103934665603ull;calls=0;
  y_nat_0024d848(&c);
  assert(!memcmp(&c,&old,sizeof(c)));assert(!memcmp(ram,expected,hle_ram_end));
  assert(hle_backedge_count==old_count&&hle_where==old_where&&calls==old_calls&&trace==old_trace);n++;total_calls+=calls;
 }
 printf("PASS %u cache replay cases; %u guest/scheduler boundary snapshots; exact context and 32MB RAM match\n",n,total_calls);
 for(int i=1;i<6;i++)printf("boundary %d: %u\n",i,hist[i]);free(initial);free(ram);free(expected);return 0;
}
