#include "candidate/r5900_rt.h"
#include <stdio.h>
#include <stdlib.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully normalizer reuse",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
PSP_HEAP_SIZE_KB(1024);
static void mode(unsigned i){uint32_t f=(1u<<24)|i;__asm__ volatile("ctc1 %0,$31"::"r"(f));}
#else
#include <fenv.h>
static void mode(unsigned i){static const int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(modes[i]);}
#endif
void reference_normalize(R5900Ctx*),candidate_normalize(R5900Ctx*);
static uint32_t seed=0x629173ab;
static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static R5900Ctx a,b,initial;
static unsigned char ra[65536+128] __attribute__((aligned(16))),rb[sizeof(ra)] __attribute__((aligned(16)));
static const uint32_t edge[]={
 0,0x80000000,1,0x80000001,0x007fffff,0x807fffff,
 0x00800000,0x80800000,0x00800001,0x80800001,
 0x3f800000,0xbf800000,0x3f800001,0xbf800001,
 0x5f000000,0xdf000000,0x7f7fffff,0xff7fffff,
 0x7f800000,0xff800000,0x7fc00000,0xffc00000,0x7f800001,0xff800001};
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);FILE*f=fopen("normalize-test.log","w");
#else
 FILE*f=stdout;
#endif
 if(!f)return 2;
 unsigned total=0,n=sizeof(edge)/sizeof(edge[0]),systematic=n*n*n;
 for(unsigned m=0;m<4;m++){
  mode(m);
  for(unsigned i=0;i<systematic+10000;i++){
   for(unsigned j=0;j<sizeof(initial);j+=4){uint32_t v=rnd();memcpy((unsigned char*)&initial+j,&v,4);}
   memset(ra,(unsigned char)(i*37u+17u),sizeof(ra));
   memset(ra,0xa5,64);memset(ra+64+65536,0x5a,64);
   unsigned base=(rnd()%16382u)*4u;
   for(unsigned j=0;j<3;j++){
    unsigned index=j==0?i%n:j==1?(i/n)%n:(i/n/n)%n;
    uint32_t v=i<systematic?edge[index]:rnd();memcpy(ra+64+base+4*j,&v,4);
   }
   initial.r[4].w[0]=(rnd()&0xffff0000u)|base;initial.ram_mask=65535;
   memcpy(rb,ra,sizeof(ra));a=initial;b=initial;a.ram=ra+64;b.ram=rb+64;
   reference_normalize(&a);candidate_normalize(&b);a.ram=NULL;b.ram=NULL;
   if(memcmp(&a,&b,sizeof(a))||memcmp(ra,rb,sizeof(ra))){fprintf(f,"ERROR mode=%u case=%u base=%u\n",m,i,base);goto fail;}
   for(unsigned j=0;j<64;j++)if(ra[j]!=0xa5||rb[j]!=0xa5||ra[64+65536+j]!=0x5a||rb[64+65536+j]!=0x5a){fprintf(f,"ERROR guard\n");goto fail;}
   total++;
  }
  fprintf(f,"mode=%u comparisons=%u errors=0\n",m,total);fflush(f);
 }
 fprintf(f,"COMPLETE comparisons=%u errors=0\n",total);fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
 fail:fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 1;
}
