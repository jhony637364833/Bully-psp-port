static inline uint32_t fpu_rsqrt5(uint32_t s, uint32_t t) {
    if ((t & 0x7F800000u) == 0) return (t & 0x80000000u) | F_FMAX;
    float r = __builtin_sqrtf(u2f(f_in5(t) & 0x7FFFFFFFu));
    /* For numerator 1, the clamped positive normal input has sqrt in
       [2^-63, 2^64] and reciprocal in [2^-64, 2^63]. Both stay finite
       normal in every rounding mode: the remaining clamps are identities.
       Keep the same sqrt and division, with no approximate rsqrt. Unknown
       numerators retain the original path without runtime dispatch. */
    if (__builtin_constant_p(s) && s == 0x3F800000u)
        return f2u(1.0f / r);
    return f_out(f2u(F5(s) / u2f(f_in5(f2u(r)))));
}
