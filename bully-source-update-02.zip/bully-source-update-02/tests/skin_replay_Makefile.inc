TARGET = bully_skin_replay_test
OBJS = main.o reference.o candidate.o native_skin.o native_mesh.o
INCDIR = . candidate
VPATH = candidate
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -Werror -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fno-strict-aliasing
BUILD_PRX = 1
LIBS = -lm -lpsppower
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully validated skin batches
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
