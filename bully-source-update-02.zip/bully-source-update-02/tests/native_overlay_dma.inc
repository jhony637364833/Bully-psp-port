#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
static uint8_t ram[0x20000],spr[0x4000],vumem[0x10000];
static uint8_t*hle_ram=ram,*hle_spr=spr;
static uint32_t hle_ram_end=sizeof ram;
static unsigned count,begins;
static uint32_t records[8192][3];
static volatile unsigned witness;
static void bully_overlay_dma_begin(void){begins++;}
static void bully_overlay_dma_feed(unsigned ch,const void*p,unsigned bytes,uint32_t a){
 assert(count<8192);records[count][0]=ch;records[count][1]=a;records[count++][2]=bytes;
 const unsigned char*b=p;for(unsigned i=0;i<bytes;i++)witness+=b[i];
}
static uint8_t*dma_qw(uint32_t a){
 if((a&0x80000000u)||(a&0x70000000u)==0x70000000u)return spr+(a&0x3ff0);
 a&=0x1ffffff0u;if(a<sizeof ram)return ram+a;
 if(a>=0x10000000u && a<0x10004000u)return spr+(a&0x3ff0);
 if(a>=0x11000000u && a<0x11010000u)return vumem+a-0x11000000u;
 return 0;
}
/* ACTUAL_NATIVE_DMA */
static void reset(void){count=begins=0;memset(ram,0,sizeof ram);}
static void expect(unsigned i,unsigned ch,uint32_t a,unsigned bytes){assert(i<count);assert(records[i][0]==ch && records[i][1]==a && records[i][2]==bytes);}
static void tag(uint32_t at,unsigned id,unsigned n,uint32_t ref,unsigned irq){uint32_t v[4]={n|(id<<28)|(irq<<31),ref,0,0};memcpy(ram+at,v,16);}
int main(void){
 reset();assert(native_overlay_feed(2,0x100,3));assert(count==1);expect(0,2,0x100,48);
 reset();assert(!native_overlay_feed(2,0x1fff0,2));assert(count==1);expect(0,2,0x1fff0,16);
 for(unsigned i=0;i<2;i++){reset();assert(native_overlay_feed(1,i?0x70003ff0:0x80003ff0,2));assert(count==2);expect(0,1,0x70003ff0,16);expect(1,1,0x70000000,16);}
 reset();assert(!native_overlay_feed(2,0x10003ff0,2));assert(count==1);expect(0,2,0x10003ff0,16);
 reset();assert(!native_overlay_feed(2,0x1100fff0,2));assert(count==1);expect(0,2,0x1100fff0,16);
 reset();native_overlay_dma(0,0,0,0,0);assert(count==0 && begins==0);
 reset();native_overlay_dma(2,0,0x200,2,0);assert(count==1 && begins==1);expect(0,2,0x200,32);
 reset();tag(0x100,1,1,0,0);tag(0x120,7,1,0,0);native_overlay_dma(1,0x44,0,0,0x100);assert(count==4 && begins==1);expect(0,1,0x108,8);expect(1,1,0x110,16);expect(2,1,0x128,8);expect(3,1,0x130,16);
 reset();tag(0x100,5,0,0x200,0);tag(0x200,6,1,0,0);tag(0x110,7,1,0,0);native_overlay_dma(1,4,0,0,0x100);assert(count==2);expect(0,1,0x210,16);expect(1,1,0x120,16);
 reset();tag(0x100,0,2,0x80003ff0,0);native_overlay_dma(2,4,0,0,0x100);assert(count==2);expect(0,2,0x70003ff0,16);expect(1,2,0x70000000,16);
 for(unsigned tie=0;tie<2;tie++){reset();tag(0x100,1,1,0,1);tag(0x120,7,1,0,0);native_overlay_dma(2,4|(tie<<7),0,0,0x100);assert(count==(tie?1u:2u));}
 reset();tag(0x100,2,0,0x100,0);native_overlay_dma(1,0x44,0,0,0x100);assert(count==4096);
 reset();tag(0x100,5,0,0x200,0);tag(0x200,5,0,0x300,0);tag(0x300,5,0,0x400,0);native_overlay_dma(1,0x44,0,0,0x100);assert(count==3);
 puts("PASS 15 native DMA boundary/chain/TTE/IRQ/wrap/stack/loop cases against the actual helper body");return 0;
}
