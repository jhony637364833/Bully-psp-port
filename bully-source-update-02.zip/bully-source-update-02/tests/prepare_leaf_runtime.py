"""Build an asset-free harness from fourteen locally generated Bully leaf functions.

The user supplies prepared C from their own matching disc. No guest code is
bundled in this generator. Run the generated program to compare full contexts
and independent 64 KB RAM windows, with and without register preservation.
"""
import argparse,importlib.util
from pathlib import Path

TARGETS=('fn_00129480','fn_0012b8b0','fn_0012b8d0','fn_0012b8e0',
         'fn_0012b900','fn_0012b910','fn_0012b920','fn_001313d0',
         'fn_00132030','fn_00184850','fn_003f6ff0','fn_001860c0',
         'fn_00186240','fn_001294e0')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepared',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
    args=parser.parse_args()
    spec=importlib.util.spec_from_file_location('leaf_csave',args.app/'ps2rc/pipeline/leaf_csave.py')
    opt=importlib.util.module_from_spec(spec);spec.loader.exec_module(opt)
    bodies={}
    for p in sorted(args.prepared.glob('*.c')):
        for m in opt.DEF.finditer(p.read_text(encoding='ascii')):
            if m[1] in TARGETS:
                if m[1] in bodies:raise ValueError('duplicate '+m[1])
                if not opt.leaf_preserves_context(m[2]):raise ValueError('not a qualifying leaf '+m[1])
                bodies[m[1]]=m[2]
    if set(bodies)!=set(TARGETS):raise ValueError('missing leaves: '+str(set(TARGETS)-set(bodies)))
    d=args.output;d.mkdir(parents=True,exist_ok=True)
    (d/'r5900_rt.h').write_bytes((args.app/'runtime/r5900_rt.h').read_bytes())
    (d/'main.c').write_bytes((Path(__file__).parent/'leaf_runtime_main.c').read_bytes())
    (d/'leaves.c').write_text('#include "r5900_rt.h"\n'+''.join('void '+n+'(R5900Ctx *c)\n{\n'+bodies[n]+'}\n' for n in TARGETS))
    for label,protect in [('reference',True),('candidate',False)]:
        lines=['#include "r5900_rt.h"']
        for i,n in enumerate(TARGETS):
            lines += ['extern void '+n+'(R5900Ctx *);','void '+label+str(i)+'(R5900Ctx *c) {'+('R5900CSave s;rt_cs_save(c,&s);' if protect else '')+n+'(c);'+('rt_cs_restore(c,&s);' if protect else '')+'}']
        (d/(label+'.c')).write_text('\n'.join(lines)+'\n')
        (d/(label+'.decl')).write_text('\n'.join('extern void '+label+str(i)+'(R5900Ctx *);' for i in range(len(TARGETS))))
    (d/'table.inc').write_text('\n'.join('{reference'+str(i)+',candidate'+str(i)+',"'+n+'"},' for i,n in enumerate(TARGETS)))
    (d/'Makefile').write_text('''TARGET = bully_leaf_test
OBJS = main.o leaves.o reference.o candidate.o
INCDIR = .
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -Wno-unused-variable -Wno-unused-label -Wno-unused-but-set-variable -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off
BUILD_PRX = 1
LIBS = -lm -lpsppower
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully exact leaf preservation
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
''')
    print('Generated 14-leaf harness; use make for PSP, or compile main.c/leaves.c/reference.c/candidate.c with a strict floating-point host compiler and -lm.')

if __name__=='__main__':main()
