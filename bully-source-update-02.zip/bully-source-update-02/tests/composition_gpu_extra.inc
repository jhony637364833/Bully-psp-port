
 bully_world_camera_end(1);bully_world_overlay_present();
 /* Actual GE path: the early HUD buffer survives the next camera clear. */
 feed_sky(0x800000ff,0,1);unsigned hud_buffer=overlay_draw_offset;
 read_pixels(before);assert((before[2*480+2]&0xffffff)==0xff);
 bully_world_camera_begin(1);assert(overlay_draw_offset!=hud_buffer&&overlay_defer_world);
 fixture_sky=0;fixture_case=0;bully_world_begin();bully_world_draw(1,1);bully_world_camera_end(1);
 unsigned world_buffer=overlay_draw_offset;
 overlay_draw_offset=hud_buffer;read_pixels(after);overlay_draw_offset=world_buffer;
 assert(!memcmp(before,after,sizeof before));
 bully_world_overlay_present();assert(overlay_draw_offset==world_buffer&&!overlay_defer_world);
 /* UI-only flips still present and repeated UI restores the world. */
 feed_sky(0x80ff0000,0,1);read_pixels(before);assert((before[2*480+2]&0xffffff)==0xff0000);
 bully_world_overlay_present();assert(overlay_draw_offset!=world_buffer);
 printf("PASS actual GE early HUD survives next world clear; world-only flip deferred; UI-only flip presents\n");
