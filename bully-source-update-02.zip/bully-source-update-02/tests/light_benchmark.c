#define _POSIX_C_SOURCE 200809L
#include "native_light.h"
#include <stdio.h>
#include <time.h>

void bully_test106_light_color(const BullyNativeVertex *,const BullyNativeLight *,float[3]);
static volatile float sink;
static double elapsed(struct timespec a,struct timespec b) {
    return b.tv_sec-a.tv_sec+(b.tv_nsec-a.tv_nsec)*1e-9;
}
static double run(void (*color)(const BullyNativeVertex *,const BullyNativeLight *,float[3]),float blend,unsigned mono) {
    BullyNativeVertex v={0};BullyNativeLight light={0};float rgb[3];
    light.blend=blend;light.monochrome=mono;
    for(unsigned k=0;k<3;k++) {
        light.gain[k]=.8f;light.material[k]=.5f;v.color_secondary[k]=200-k;
    }
    struct timespec start,end;clock_gettime(CLOCK_MONOTONIC,&start);
    for(unsigned i=0;i<10000000;i++) {
        for(unsigned k=0;k<3;k++)v.color[k]=(i+k)&255;
        color(&v,&light,rgb);sink=rgb[0];
    }
    clock_gettime(CLOCK_MONOTONIC,&end);return elapsed(start,end);
}
int main(void) {
    const float blends[]={0.0f,.35f,1.0f};
    for(unsigned repeat=0;repeat<3;repeat++)for(unsigned b=0;b<3;b++)for(unsigned mono=0;mono<2;mono++) {
        double old,new;
        if(repeat&1) { new=run(bully_light_color,blends[b],mono);old=run(bully_test106_light_color,blends[b],mono); }
        else { old=run(bully_test106_light_color,blends[b],mono);new=run(bully_light_color,blends[b],mono); }
        printf("repeat=%u mono=%u blend=%.2f baseline_s=%.6f candidate_s=%.6f ratio=%.3f\n",
               repeat,mono,blends[b],old,new,old/new);
    }
    return 0;
}
