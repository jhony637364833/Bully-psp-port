#include "native_texture_alpha.h"
#include "native_state.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#define WORLD_TEXTURE_BYTES 65536
static const BullyNativeState *material_state;
static unsigned queued=3;
static struct{unsigned color;}verts[384];
static unsigned texture_alpha_minimum,texture_alpha_minimum_valid;
static int has_texture=1;
static BullyNativeTexture texture;
static uint8_t texels[WORLD_TEXTURE_BYTES];

/* These isolated alpha fixtures use the owned texture buffer. */
static const unsigned char *material_texels=texels;
