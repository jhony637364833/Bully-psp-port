/* Entirely synthetic geometry/textures; no game assets or captures required. */
static unsigned prepare_case(unsigned id,BullyNativeObject*o,BullyNativeState*state){
 texture_alpha_minimum_valid=0;
 memset(o,0,sizeof(*o));o->near_plane=1;o->far_plane=100;
 memset(state,0,sizeof(*state));unsigned fn=id%8,variant=(id/8)%4,mode=id/32;
 unsigned reference=variant==3?254:126,alpha=variant==0?125:variant==1?126:variant==2?127:253;
 if(id>=96){fn=5;reference=126;alpha=125;mode=(id-96)%3;}
 state->test=1|(fn<<1)|((reference/2)<<4)|(1<<12)|(1<<16)|(2<<17);
 state->alpha=id%3==0?0x68:id%3==1?0x44:0x88;state->alpha_fixed=128;state->blend=1;
 if(id>=96&&id<100)state->zmask=1;
 if(id>=100&&id<104)state->test&=~1u;
 if(id>=104)state->test&=~(3u<<12);
 material_state=state;has_texture=mode!=0;
 memset(&texture,0,sizeof texture);texture.texture.psm=GU_PSM_8888;
 texture.texture.total_bytes=4096;texture.texture.nlevels=1;
 texture.texture.level[0].width=texture.texture.level[0].height=texture.texture.level[0].bufw=32;
 texture.texture.level[0].rows=32;texture.texture.level[0].bytes=4096;
 texture.filter=id%2?1:2;texture.wrap_u=texture.wrap_v=3;
 texture.texture.alpha_class=mode<2?TC_ALPHA_OPAQUE:id%2?TC_ALPHA_CUTOUT:TC_ALPHA_BLEND;
 for(unsigned y=0;y<32;y++)for(unsigned x=0;x<32;x++){
  unsigned a=mode<2?255:id%2?((x/4+y/4)%2?255:0):x*8;
  ((uint32_t*)texels)[y*32+x]=(a<<24)|(x*7)|((y*7)<<8)|(64u<<16);
 }
 unsigned n=id<96&&fn==5&&variant==0?384:6;
 for(unsigned j=0;j<n;j++){
  unsigned v=j%3;float z=2.0f+(j/3%7)*.1f;
  static const float xy[3][2]={{.15f,.15f},{.85f,.25f},{.25f,.9f}};
  unsigned a=variant==2&&j%2?0:alpha;
  verts[j]=(GeVertex){v==1?1:0,v==2?1:0,(a<<24)|0x00d060a0u,xy[v][0]*z,xy[v][1]*z,z};
 }
 return n;
}
int main(void){
 freopen("alpha-fail.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
 unsigned control=0x01000001;__asm__ volatile("ctc1 %0,$31"::"r"(control));init();
 unsigned certified_count=0,controls=0,total_old=0,total_new=0,nonempty=0;
 for(unsigned id=0;id<108;id++){
  BullyNativeObject o;BullyNativeState state;unsigned n=prepare_case(id,&o,&state);
  queued=n;int certified=all_alpha_fail();setup(&o);draw_calls=0;reference_flush();unsigned old=draw_calls;total_old+=old;readback(color_reference);
  unsigned changed=0;for(unsigned j=0;j<480*272;j++)if((color_reference[j]&0xffffffu)!=0x223344u)changed++;
  setup(&o);queued=n;reference_flush();readback(color_candidate);
  if(memcmp(color_reference,color_candidate,sizeof color_reference)){printf("ERROR baseline_self case=%u\n",id);return 1;}
  if(certified){
   depth_witness(&o,witness_reference);
   for(unsigned j=0;j<480*272;j++)if((witness_reference[j]&0xffffffu)!=0x55ee33u){printf("ERROR baseline_depth case=%u pixel=%u\n",id,j);return 2;}
  }
  setup(&o);queued=n;draw_calls=0;candidate_flush();total_new+=draw_calls;readback(color_candidate);
  if(memcmp(color_reference,color_candidate,sizeof color_reference)){printf("ERROR candidate_pixels case=%u\n",id);return 3;}
  if(certified){
   certified_count++;if(changed)nonempty++;
   depth_witness(&o,witness_candidate);
   if(memcmp(witness_reference,witness_candidate,sizeof witness_reference)){printf("ERROR candidate_depth case=%u\n",id);return 4;}
   setup(&o);start();sceGuDisable(GU_ALPHA_TEST);sceGuDisable(GU_TEXTURE_2D);sceGuDisable(GU_BLEND);sceGuEnable(GU_DEPTH_TEST);sceGuDepthFunc(GU_LEQUAL);sceGuDepthMask(GU_FALSE);
   sceKernelDcacheWritebackRange(verts,n*sizeof(*verts));sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,n,0,verts);finish();depth_witness(&o,witness_candidate);
   if(!memcmp(witness_reference,witness_candidate,sizeof witness_reference)){printf("ERROR depth_control case=%u\n",id);return 5;}controls++;
  }
  printf("case=%u certified=%d draws=%u/%u pixels_exact=1 changed=%u\n",id,certified,old,certified?1:old,changed);
 }
 if(!certified_count||certified_count!=controls||nonempty!=certified_count){printf("ERROR vacuous cases=%u controls=%u nonempty=%u\n",certified_count,controls,nonempty);return 6;}
 printf("COMPLETE errors=0 cases=108 certified=%u positive_depth_controls=%u total_draws=%u/%u\n",certified_count,controls,total_old,total_new);sceGuDisplay(GU_FALSE);sceGuTerm();sceKernelExitGame();return 0;
}
