
static int passes(unsigned fn,unsigned a,unsigned r){return fn==5?a>=r:fn==6?a>r:a!=r;}
int main(void){
 BullyNativeState state={0};material_state=&state;
 texture.texture.nlevels=1;texture.texture.psm=TC_GU_T8;texture.texture.clut_psm=TC_GU_8888;
 texture.texture.clut_entries=256;texture.texture.clut_bytes=1024;texture.texture.clut_offset=16;texture.texture.total_bytes=1040;
 texture.texture.level[0]=(TcPspLevel){0,16,4,4,4,4};texture.texture.alpha_class=TC_ALPHA_BLEND;
 memset(texels,1,16);uint64_t decisions=0,certified=0;
 for(unsigned t=0;t<256;t++){
  texels[16+4+3]=(uint8_t)t;texture_alpha_minimum_valid=0;
  for(unsigned v=0;v<256;v++){
   verts[0].color=verts[2].color=v<<24;verts[1].color=255u<<24;
   for(unsigned fn=5;fn<=7;fn++)for(unsigned ref=0;ref<256;ref++){
    state.test=1|(fn<<1)|(ref<<4)|(1<<12);
    unsigned r=ref<128?ref*2:255;
    int need=needs_alpha_fail_pass();decisions++;
    assert(texture_alpha_minimum_valid && texture_alpha_minimum==t);
    if(!need){unsigned actual0=t==255?v:v*t/256,actual1=v*t/255;
     assert(passes(fn,actual0,r)&&passes(fn,actual1,r));certified++;
    }
   }
  }
 }
 // Guard behavior and unsupported-texture fallback remain conservative.
 state.test=1|(6<<1)|(1<<12);state.zmask=1;assert(!needs_alpha_fail_pass());state.zmask=0;
 state.test&=~1u;assert(!needs_alpha_fail_pass());state.test=1|(6<<1);assert(!needs_alpha_fail_pass());
 material_state=0;assert(!needs_alpha_fail_pass());material_state=&state;
 state.test=1|(6<<1)|(1<<12);texture.texture.psm=TC_GU_8888;texture_alpha_minimum_valid=0;assert(needs_alpha_fail_pass());
 state.test=1|(1<<1)|(1<<12);assert(!needs_alpha_fail_pass());
 printf("PASS decisions=%llu certified=%llu guards=6 cached_minima=256 errors=0\n",(unsigned long long)decisions,(unsigned long long)certified);
 return 0;
}
