#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bully_test_dir=$(mktemp -d)
trap 'rm -rf "$bully_test_dir"' EXIT
bully_src=app/games/SLUS-21269_v1.02/src
${CC:-cc} -O2 -g -Wall -Wextra -Werror -fsanitize=address,undefined \
 -I"$bully_src" tests/audio_sync_test.c "$bully_src/audio_stretch.c" -lm -o "$bully_test_dir/test"
"$bully_test_dir/test"
