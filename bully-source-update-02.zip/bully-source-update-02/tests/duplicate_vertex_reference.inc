static unsigned channel(float f) { return f<=0?0:f>=255?255:(unsigned)f; }
/* Positive screen coordinates need only the upper clamp. Retain the original
 * library path for zero, negative, NaN and flushed subnormal comparisons. */
static inline float screen_clamp(float value,float maximum) {
    if(value>0.0f)return value<maximum?value:maximum;
    return fminf(maximum,fmaxf(0.0f,value));
}

/* A strip shares two vertices with its next triangle. Transform and shade
 * each decoded vertex once; a three-entry stack ring also handles skin skips. */
static void prepare_vertex(const BullyNativeVertex *src,BullyClipVertex *out) {
    for(int k=0;k<3;k++) {
        float p=object_view.view[3][k];
        for(int j=0;j<3;j++)p+=src->position[j]*object_view.view[j][k];
        out->p[k]=p;out->color[k]=src->color[k]*2.0f;
    }
    out->alpha=255;
    if(material_light) {
        bully_light_color(src,material_light,out->color);
        out->alpha=bully_light_alpha(src,material_light);
    }
    for(int k=0;k<2;k++)out->uv[k]=src->uv[k];
}
static void triangle(const BullyClipVertex *a,const BullyClipVertex *b,const BullyClipVertex *c,BullyClipCache *cache,const int codes[3]) {
    BullyClipVertex in[3]={*a,*b,*c},out[10];
    BullyClipMemo *memo=clip_memo_enabled && clip_memo_storage && !object_view.bones ? &clip_memo:0;
    int n=bully_clip_triangle_classified(in,object_view.near_plane,object_view.far_plane,codes,out,cache,memo);
    if(!n)return;
    /* A clipped polygon is triangulated as a fan. Prepare each polygon
     * vertex once, keeping screen coordinates separate from GE positions.
     * All UV validation still finishes before any triangle is submitted. */
    GeVertex projected[10],clipped[24];
    float screen_x[10],screen_y[10];
    for(int j=0;j<n;j++) {
        const BullyClipVertex *v=&out[j];
        projected[j].u=v->uv[0];projected[j].v=v->uv[1];
        if(!isfinite(projected[j].u) || !isfinite(projected[j].v))return;
        screen_x[j]=screen_clamp(480*v->p[0]/v->p[2],480);
        screen_y[j]=screen_clamp(272*v->p[1]/v->p[2],272);
        projected[j].color=(channel(v->alpha)<<24)|channel(v->color[0])|(channel(v->color[1])<<8)|(channel(v->color[2])<<16);
        projected[j].x=v->p[0];projected[j].y=v->p[1];projected[j].z=v->p[2];
    }
    int count=0;
    for(int i=1;i<n-1;i++) {
        float area=(screen_x[i]-screen_x[0])*(screen_y[i+1]-screen_y[0])-
                   (screen_x[i+1]-screen_x[0])*(screen_y[i]-screen_y[0]);
        if(fabsf(area)<0.001f)continue;
        clipped[count++]=projected[0];
        clipped[count++]=projected[i];
        clipped[count++]=projected[i+1];
    }
    if(!count)return;
    if(queued+(unsigned)count>WORLD_BATCH_VERTICES)flush_vertices();
    for(int i=0;i<count;i++)verts[queued++]=clipped[i];
    triangles+=count/3;
}
/* Visibility and projection belong to each shared vertex. Safe screen-edge
 * crossings use GE interpolation; near/far and guard-band crossings retain
 * the reference CPU clipper. Edge color/UV rounding may differ from software. */
typedef struct {
    BullyClipVertex vertex;
    GeVertex draw;
    float screen_x,screen_y;
    int code,guard_safe;
} PreparedVertex;
static void prepare_cached(const BullyNativeVertex *src,PreparedVertex *out) {
    prepare_vertex(src,&out->vertex);
    out->code=bully_clip_vertex_code(&out->vertex,object_view.near_plane,object_view.far_plane);
    out->guard_safe=0;
    if(out->code<0 || (out->code&3))return;
    const BullyClipVertex *v=&out->vertex;
    if(!out->code) {
        out->screen_x=screen_clamp(480*v->p[0]/v->p[2],480);
        out->screen_y=screen_clamp(272*v->p[1]/v->p[2],272);
        out->guard_safe=1;
    } else {
        /* GE's 12-bit screen coordinates include the viewport offset.
         * Keep a wide margin from both hardware limits; unusual geometry
         * retains the original six-plane double-precision CPU clipper. */
        out->screen_x=480*v->p[0]/v->p[2];
        out->screen_y=272*v->p[1]/v->p[2];
        out->guard_safe=out->screen_x>=-480 && out->screen_x<=960 &&
                        out->screen_y>=-272 && out->screen_y<=544;
    }
    out->draw.u=v->uv[0];out->draw.v=v->uv[1];
    out->draw.color=(channel(v->alpha)<<24)|channel(v->color[0])|(channel(v->color[1])<<8)|(channel(v->color[2])<<16);
    out->draw.x=v->p[0];out->draw.y=v->p[1];out->draw.z=v->p[2];
}
static void triangle_cached(const PreparedVertex *a,const PreparedVertex *b,const PreparedVertex *c,BullyClipCache *cache) {
    if(a->code<0 || b->code<0 || c->code<0)return;
    if(a->code & b->code & c->code)return;
    if((a->code | b->code | c->code) && !(a->guard_safe && b->guard_safe && c->guard_safe &&
        object_view.near_plane>=0.0001f && object_view.far_plane<=65536.0f)) {
        int codes[3]={a->code,b->code,c->code};
        triangle(&a->vertex,&b->vertex,&c->vertex,cache,codes);return;
    }
    float area=(b->screen_x-a->screen_x)*(c->screen_y-a->screen_y)-
               (b->screen_y-a->screen_y)*(c->screen_x-a->screen_x);
    if(fabsf(area)<0.001f)return;
    if(queued+3>WORLD_BATCH_VERTICES)flush_vertices();
    verts[queued++]=a->draw;verts[queued++]=b->draw;verts[queued++]=c->draw;
    triangles++;
}
static void draw_strip(const BullyNativeVertex *v,const uint8_t *skip,size_t n) {
    PreparedVertex ring[3];BullyClipCache cache;bully_clip_cache_reset(&cache);
    PreparedVertex *a=&ring[1],*b=&ring[2],*current=&ring[0];
    for(size_t i=0;i<n;i++) {
        prepare_cached(&v[i],current);
        if(i>=2 && (!skip || !skip[i]))triangle_cached(a,b,current,&cache);
        PreparedVertex *next=a;a=b;b=current;current=next;
    }
}
static void draw_batch(const BullyNativeVertex *v,size_t n,void *context) {
    (void)context;draw_strip(v,0,n);
}
static void draw_skin_batch(const BullyNativeVertex *v,const uint8_t *skip,size_t n,void *context) {
    (void)context;draw_strip(v,skip,n);
}
