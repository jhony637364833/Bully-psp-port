"""Check the generated overlay loader calls flush the state read by its HLE hook.

Usage: python tests/check_overlay_hook_boundary.py WORK/build/gen
The game-derived generated C is supplied by the converter, not stored in tests.
"""
from pathlib import Path
import re
import sys

source = '\n'.join(p.read_text() for p in Path(sys.argv[1]).glob('main_*.c'))
for caller, saved in [('00122900', 19), ('00122a00', 18)]:
    match = re.search(r'^void fn_' + caller + r'\(R5900Ctx \*c\)\n\{\n(.*?)^\}', source, re.M | re.S)
    assert match, 'missing loader ' + caller
    calls = [line for line in match[1].splitlines() if 'fn_00122870(c);' in line]
    assert len(calls) == 1
    before = calls[0].split('fn_00122870(c);')[0]
    for register in (31, saved):
        assert re.search(r'c->r\[' + str(register) + r'\]\.(?:d|w)\[0\]\s*=', before), (caller, register)
    print(caller + ': RA and saved overlay pointer synchronized at hook call')
