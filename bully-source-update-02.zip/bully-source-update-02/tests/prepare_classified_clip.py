# CPU fallback helper fixture. Accelerated rendering is tested separately by the full GPU fixtures.
"""Generate exact math/renderer checks against frozen build39."""
from pathlib import Path
import argparse,re
repo=Path(__file__).resolve().parents[1];t=repo/'tests';g=repo/'app/games/SLUS-21269_v1.02/src'
a=argparse.ArgumentParser();a.add_argument('output',type=Path);args=a.parse_args();base=args.output.resolve()
reference=(t/'classified_clip_reference_39.inc').read_text()
for n in ['bully_clip_triangle_memoized','bully_clip_triangle_cached','bully_clip_triangle','bully_clip_vertex_code','bully_clip_cache_reset']:reference=re.sub(r'\b'+n+r'\b','ref_'+n,reference)
for kind in ['math','renderer']:
 p=base/kind;p.mkdir(parents=True,exist_ok=True)
 for n in ['world_clip.c','world_clip.h','clip_memo.h','clip_lerp.h']:(p/n).write_bytes((g/n).read_bytes())
 (p/'reference.c').write_text(reference)
 if kind=='math':(p/'main.c').write_bytes((t/'classified_clip_main.c').read_bytes())
 else:
  body=(g/'psp/world_display.c').read_text();body=body[body.index('static unsigned channel'):body.index('void bully_world_draw')].split('/* GPU strip dispatch.',1)[0]
  parts=[]
  for label,source in [('reference',(t/'classified_render_reference_39.inc').read_text()),('candidate',body)]:
   if label=='reference':source=source.replace('bully_clip_triangle_memoized','ref_bully_clip_triangle_memoized')
   for n in ['channel','screen_clamp','prepare_vertex','triangle','PreparedVertex','prepare_cached','same_vertex_inputs','triangle_cached','draw_strip','draw_batch','draw_skin_batch']:source=re.sub(r'\b'+n+r'\b',label+'_'+n,source)
   parts.append(source)
  (p/'main.c').write_text((t/'classified_render_head.inc').read_text()+(t/'renderer_fpu_test.inc').read_text()+'\n'.join(parts)+(t/'classified_render_main.inc').read_text())
 objects='main.o world_clip.o reference.o'+(' native_light.o' if kind=='renderer' else '')
 make='.DEFAULT_GOAL := all\nTARGET = classified_clip\nOBJS = '+objects+'\nINCDIR = . '+str(g)+'\nVPATH = '+str(g)+'\nCFLAGS = -O2 -G0 -Wall -Wextra -Werror -Wno-unused-function -Wno-misleading-indentation -fno-fast-math -frounding-math -ffp-contract=off\nBUILD_PRX = 1\nLIBS = -lm\nEXTRA_TARGETS = EBOOT.PBP\nPSP_EBOOT_TITLE = Bully classified clipping\nPSPSDK = $(shell psp-config --pspsdk-path)\ninclude $(PSPSDK)/lib/build.mak\n$(OBJS): world_clip.h clip_memo.h clip_lerp.h\n'
 (p/'Makefile').write_text(make)
print('Prepared math32768cases and renderer1280*3, independent frozen39 reference')
