#include "native_state.h"
#include "native_texture.h"
#include "native_texture_alpha.h"
#include "native_object.h"
#include "world_projection.h"
#include <pspkernel.h>
#include <pspgu.h>
#include <pspge.h>
#include <pspdisplay.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
PSP_MODULE_INFO("Bully alpha-fail check",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
typedef struct {float u,v;unsigned color;float x,y,z;} GeVertex;
static unsigned list[4096] __attribute__((aligned(16)));
static GeVertex verts[384] __attribute__((aligned(16)));
static unsigned char texels[65536] __attribute__((aligned(16)));
static unsigned queued,draw_calls;
static int has_texture=1;
static BullyNativeTexture texture;
static const BullyNativeState *material_state;
static void start(void){sceGuStart(GU_DIRECT,list);}
static void finish(void){sceGuFinish();sceGuSync(0,0);}

#define WORLD_TEXTURE_BYTES 65536
static unsigned texture_alpha_minimum,texture_alpha_minimum_valid;

/* These isolated alpha fixtures use the owned texture buffer. */
static const unsigned char *material_texels=texels;
/* All fixture vertices are already in camera space. */
static void select_vertex_space(void){}
