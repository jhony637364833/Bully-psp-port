# CPU fallback helper fixture. Accelerated rendering is tested separately by the full GPU fixtures.
"""Generate an asset-free PSP/host comparison against the pre-rotation strip loop."""
from pathlib import Path
import argparse,re
repo=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('output',type=Path);args=a.parse_args();p=args.output.resolve();p.mkdir(parents=True,exist_ok=True)
g=repo/'app/games/SLUS-21269_v1.02/src';s=(g/'psp/world_display.c').read_text()
candidate=s[s.index('static unsigned channel'):s.index('void bully_world_draw')].split('/* GPU strip dispatch.',1)[0]
reference=candidate[:candidate.index('static void draw_strip(')]+(repo/'tests/strip_rotate_reference.inc').read_text()+candidate[candidate.index('static void draw_batch('):]
parts=[]
for label,body in [('reference',reference),('candidate',candidate)]:
 for name in ['channel','screen_clamp','prepare_vertex','triangle','PreparedVertex','prepare_cached','same_vertex_inputs','triangle_cached','draw_strip','draw_batch','draw_skin_batch']:
  body=re.sub(r'\b'+name+r'\b',label+'_'+name,body)
 parts.append(body)
(p/'main.c').write_text((repo/'tests/strip_rotate_head.inc').read_text()+(repo/'tests/renderer_fpu_test.inc').read_text()+'#include \"clip_memo.h\"\nstatic BullyClipMemo clip_memo;\nstatic BullyClipMemoSet *clip_memo_storage;\nstatic int clip_memo_enabled;\n'+'\n'.join(parts)+(repo/'tests/strip_rotate_main.inc').read_text())
make=(repo/'tests/strip_rotate_Makefile.inc').read_text();start=make.index('BULLY_SRC = ');end=make.index('\n',start);make=make[:start]+'BULLY_SRC = '+str(g)+make[end:];(p/'Makefile').write_text(make)
print('Prepared5120stripcomparisons; PSPmakeorhostcc with native_light.c,world_clip.c,-lm,strictFP,ASanUBSan')
