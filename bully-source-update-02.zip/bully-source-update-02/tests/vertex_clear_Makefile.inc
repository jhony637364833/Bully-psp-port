.DEFAULT_GOAL := all
TARGET = bully_vertex_work
OBJS = main.o baseline-prepare.o candidate-prepare.o baseline-native_mesh.o candidate-native_mesh.o native_light.o
INCDIR = .
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -Wno-unused-variable -Wno-unused-label -Wno-unused-but-set-variable -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fstrict-aliasing
BUILD_PRX = 1
LIBS = -lm -lpsppower
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully vertex work
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak

main.o: compressed_checks.inc native_mesh.h
$(OBJS): native_mesh.h
