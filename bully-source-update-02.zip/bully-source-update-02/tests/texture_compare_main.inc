#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
#include "candidate-native_texture.c"
int main(void){
 unsigned char a[544],b[544];unsigned cases=0;
 for(unsigned x=0;x<16;x++)for(unsigned y=0;y<16;y++)for(unsigned n=0;n<=512;n++){
  for(unsigned k=0;k<n;k++)a[x+k]=b[y+k]=(unsigned char)(k*13+n);
  assert(texture_bytes_equal(a+x,b+y,n));cases++;
  if(n){unsigned at=(n*7+x*17+y)%n;b[y+at]^=128;assert(!texture_bytes_equal(a+x,b+y,n));cases++;}
 }
 size_t page=(size_t)sysconf(_SC_PAGESIZE);
 unsigned char *p=mmap(0,page*4,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(p!=MAP_FAILED);
 assert(!mprotect(p+page,page,PROT_NONE));assert(!mprotect(p+3*page,page,PROT_NONE));
 for(unsigned n=0;n<=512;n++){
  unsigned char *x=p+page-n,*y=p+3*page-n;
  memset(x,0x7d,n);memset(y,0x7d,n);assert(texture_bytes_equal(x,y,n));cases++;
  for(unsigned k=0;k<n;k++){y[k]^=1;assert(!texture_bytes_equal(x,y,n));y[k]^=1;cases++;}
 }
 assert(!munmap(p,page*4));printf("PASS %u exact equality/alignment/guard-page cases\n",cases);
}
