"""Check converted indexed alpha bounds and actual renderer pass decisions.

Uses synthetic textures only. Requires a host compiler with ASan/UBSan.
"""
from pathlib import Path
import tempfile,subprocess,os
repo=Path(__file__).resolve().parents[1]
g=repo/'app/games/SLUS-21269_v1.02/src'
t=repo/'tests'
s=(g/'psp/world_display.c').read_text()
a=s[s.index('static unsigned alpha_reference'):s.index('static void apply_state')]
needs=s[s.index('static int needs_alpha_fail_pass'):s.index('/* Texture alpha modulation')]
with tempfile.TemporaryDirectory(prefix='bully-texture-alpha-') as temp:
 directory=Path(temp)
 sources={'bounds':(t/'texture_alpha_bounds_main.inc').read_text(),'decision':(t/'texture_alpha_decision_head.inc').read_text()+a+needs+(t/'texture_alpha_decision_main.inc').read_text()}
 for name,source in sources.items():
  path=directory/(name+'.c');path.write_text(source)
  subprocess.run([os.environ.get('CC','cc'),'-O2','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+str(g),str(path),'-o',str(directory/name)],check=True)
  subprocess.run([str(directory/name)],check=True)
