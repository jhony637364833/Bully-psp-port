#include "candidate/native_object.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully skin batch replay",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
PSP_MAIN_THREAD_STACK_SIZE_KB(128);
PSP_HEAP_SIZE_KB(1024);
static void mode(unsigned m,unsigned p){uint32_t f=0x01000000u|m|((p&1)?0x800000u:0)|((p&2)?0x7cu:0);__asm__ volatile("ctc1 %0,$31"::"r"(f):"memory");}
static void restore(uint32_t f){__asm__ volatile("ctc1 %0,$31"::"r"(f):"memory");}
static uint32_t status(int dep){uint32_t f;__asm__ volatile("cfc1 %0,$31":"=r"(f):"r"(dep):"memory");return f;}
#else
#include <fenv.h>
static void mode(unsigned m,unsigned p){static const int r[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(r[m]);feclearexcept(FE_ALL_EXCEPT);if(p&2)feraiseexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW|FE_UNDERFLOW|FE_INEXACT);}
static void restore(uint32_t f){feclearexcept(FE_ALL_EXCEPT);if(f)feraiseexcept((int)f);}
static uint32_t status(int dep){(void)dep;return (uint32_t)fetestexcept(FE_ALL_EXCEPT);}
#endif
int reference_object(const uint8_t*,size_t,uint32_t,uint32_t,BullyNativeVertex*,BullyNativeObject*);
int candidate_object(const uint8_t*,size_t,uint32_t,uint32_t,BullyNativeVertex*,BullyNativeObject*);
int candidate_cached(const uint8_t*,size_t,uint32_t,uint32_t,BullyNativeVertex*,BullyNativeObject*,BullyNativeSkinCache*);
int candidate_replay(const BullyNativeSkinCache*,unsigned,BullySkinVisit,void*);
#define RAM 0x600000
#define PAL 0x500000u
#define MAX_VERTICES (64*3*256)
static uint8_t original[RAM],snapshot[RAM];
static uint8_t attrs[4][4096],previous[4][4096];
static uint32_t seed=0x19ab3265u;static unsigned mesh_index;
static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static void put(uint8_t*p,uint32_t v){for(unsigned k=0;k<4;k++)p[k]=(uint8_t)(v>>(8*k));}
static uint32_t raw(float v){uint32_t u;memcpy(&u,&v,4);return u;}
static void real(uint8_t*p,float v){put(p,raw(v));}
#include "builder.inc"
static struct {uint32_t before;BullyNativeSkinCache cache;uint32_t after;} guarded;
static struct {uint32_t before;BullyNativeVertex v[256];uint32_t after;} sa,sb,sc;
static BullyNativeVertex recorded[MAX_VERTICES];static uint8_t recorded_skip[MAX_VERTICES];
static unsigned record_count,record_calls,read_count,read_calls,visit_errors;
static size_t sizes[192];
static BullyNativeSkinCache backup;
static FILE*f;static unsigned cases,successes,cached,overflowed,replayed;
static void record(const BullyNativeVertex*v,const uint8_t*skip,size_t n,void*ctx){
 (void)ctx;if(record_count+n>MAX_VERTICES || record_calls>=192){visit_errors++;return;}
 sizes[record_calls++]=n;memcpy(recorded+record_count,v,n*sizeof(*v));memcpy(recorded_skip+record_count,skip,n);record_count+=(unsigned)n;
}
static void compare_visit(const BullyNativeVertex*v,const uint8_t*skip,size_t n,void*ctx){
 (void)ctx;if(read_calls>=record_calls || n!=sizes[read_calls++] || read_count+n>record_count){visit_errors++;return;}
 if(memcmp(v,recorded+read_count,n*sizeof(*v)) || memcmp(skip,recorded_skip+read_count,n))visit_errors++;
 read_count+=(unsigned)n;
}
static unsigned fixture(unsigned meshes,unsigned bones,unsigned n,unsigned batches,unsigned variant){
 memset(original,0,65536);memset(original+PAL,0,bones*64);memset(original+0x58a5f0,0,32);
 original[0x100]=1;put(original+0x104,0x200);put(original+0x118,0x300);
 put(original+0x300+8,0x01000037);put(original+0x300+24,1);put(original+0x300+84,0x700);put(original+0x300+96,0xb00);
 put(original+0x400,4);put(original+0x414,1);
 for(unsigned r=0;r<4;r++)for(unsigned k=0;k<3;k++){real(original+0x200+80+r*16+k*4,r==k?1:0);real(original+0x400+32+r*16+k*4,r==k?1:0);}
 real(original+0x480,1);real(original+0x484,100);
 put(original+0x58a5f4,0x3000);put(original+0x58a5f8,0x3000);put(original+0x58a5fc,PAL);
 put(original+0x3100,0x600);put(original+0x3300,0x500);put(original+0x500,bones);put(original+0x604,bones);
 put(original+0x700,1);put(original+0x704,meshes);put(original+0xb00,meshes);
 unsigned triangles=batches*(n-2-(n>7?1+(n-8)/11:0));
 for(mesh_index=0;mesh_index<meshes;mesh_index++){
  unsigned chain=65536+mesh_index*32768;memset(original+chain,0,32768);build(bones,n,1+(mesh_index%4),batches,variant);
  unsigned entry=0x1000+mesh_index*48;put(original+0xb04+mesh_index*4,entry);put(original+entry+32,chain);
  put(original+0x714+mesh_index*12,n*batches-2*(batches-1));put(original+0x718+mesh_index*12,0x9000+mesh_index*4);
 }
 put(original+0x708,meshes*(n*batches-2*(batches-1)));put(original+0x310,meshes*triangles);
 return triangles;
}
static int run(unsigned m,unsigned meshes,unsigned bones,unsigned n,unsigned batches,unsigned corruption,unsigned nullcache){
 fixture(meshes,bones,n,batches,corruption&1);
 unsigned last=65536+(meshes-1)*32768;
 switch(corruption){
 case 2:original[0x100]=2;break;case 3:put(original+0x400,3);break;
 case 4:put(original+0x708,0);break;case 5:put(original+0x310,0);break;
 case 6:put(original+last,0xf0000000);break;case 7:put(original+PAL,0x7fc01234);break;
 case 8:put(original+0x704,65);break;case 9:put(original+0x58a5fc,PAL+1);break;
 case 10:put(original+0x604,bones+1);break;case 11:put(original+0x3100,0);break;
 case 12:put(original+0x240000+(meshes-1)*12288,0x3f800003);break;
 case 13:put(original+last+36,0x7f800000);break;
 default:break;
 }
 if(corruption>=14){unsigned offsets[]={0x100,0x104,0x118,0x308,0x310,0x318,0x354,0x360,0x400,0x414,0x480,0x484,0x500,0x604,0x700,0x704,0x708,0xb00,0xb04,0x1020,0x58a5f4,0x58a5f8,0x58a5fc,PAL,last,last+4,last+12,0x240000};unsigned at=offsets[rnd()%(sizeof(offsets)/sizeof(*offsets))];original[at]^=(uint8_t)(1u<<(rnd()&7));}
 if(cases%37==0)memcpy(snapshot,original,RAM);
 memset(&guarded,0xa5,sizeof(guarded));memset(&sa,0x97,sizeof(sa));sb=sa;sc=sa;
 BullyNativeObject a,b,c;memset(&a,0x5a,sizeof(a));b=a;c=a;
 mode(m,cases&3);int va=reference_object(original,RAM,0x100,0x400,sa.v,&a);uint32_t fa=status(va);
 mode(m,cases&3);int vb=candidate_cached(original,RAM,0x100,0x400,sb.v,&b,nullcache?NULL:&guarded.cache);uint32_t fb=status(vb);
 mode(m,cases&3);int vc=candidate_object(original,RAM,0x100,0x400,sc.v,&c);uint32_t fc=status(vc);
 if(va!=vb || va!=vc || fa!=fb || fa!=fc || memcmp(&a,&b,sizeof(a)) || memcmp(&a,&c,sizeof(a)) || memcmp(&sa,&sb,sizeof(sa)) || memcmp(&sa,&sc,sizeof(sa)) || guarded.before!=0xa5a5a5a5 || guarded.after!=0xa5a5a5a5){fprintf(f,"ERROR validation case=%u mode=%u result=%d/%d csr=%08lx/%08lx\n",cases,m,va,vb,(unsigned long)fa,(unsigned long)fb);return 1;}
 if(!corruption && !va){fprintf(f,"ERROR invalid fixture meshes=%u bones=%u n=%u batches=%u\n",meshes,bones,n,batches);return 1;}
 if(!nullcache && !va && guarded.cache.complete){fprintf(f,"ERROR failed cache committed\n");return 1;}
 if(!corruption && !nullcache && guarded.cache.complete!=(meshes*batches<=BULLY_SKIN_CACHE_BATCHES && meshes*batches*n<=BULLY_SKIN_CACHE_VERTICES)){fprintf(f,"ERROR cache capacity boundary\n");return 1;}
 if(va){
  successes++;if(!nullcache){cached+=guarded.cache.complete;overflowed+=!guarded.cache.complete;}
  record_count=record_calls=read_count=read_calls=visit_errors=0;
  restore(fa);
  for(unsigned i=0;i<a.meshes;i++){size_t count,used,tris;if(!bully_skin_chain(original,RAM,a.mesh[i].stream,a.palette,a.bones,sa.v,record,NULL,&count,&used,&tris)){fprintf(f,"ERROR oracle render\n");return 1;}}
  uint32_t render_a=status(va);
  restore(fb);
  for(unsigned i=0;i<b.meshes;i++)if(candidate_replay(nullcache?NULL:&guarded.cache,i,compare_visit,NULL)){replayed++;}else{size_t count,used,tris;if(!bully_skin_chain(original,RAM,b.mesh[i].stream,b.palette,b.bones,sb.v,compare_visit,NULL,&count,&used,&tris)){fprintf(f,"ERROR fallback render\n");return 1;}}
  uint32_t render_b=status(vb);
  if(render_a!=render_b){fprintf(f,"ERROR render CSR case=%u mode=%u csr=%08lx/%08lx\n",cases,m,(unsigned long)render_a,(unsigned long)render_b);return 1;}
  if(!nullcache && guarded.cache.complete && cases%29==0){
   backup=guarded.cache;unsigned calls=read_calls;
   guarded.cache.batch[guarded.cache.first[0]+guarded.cache.count[0]-1].count=guarded.cache.used+1;
   if(candidate_replay(&guarded.cache,0,compare_visit,NULL) || read_calls!=calls){fprintf(f,"ERROR partial malformed replay\n");return 1;}
   guarded.cache=backup;
   if(candidate_replay(NULL,0,compare_visit,NULL) || candidate_replay(&guarded.cache,guarded.cache.meshes,compare_visit,NULL) || candidate_replay(&guarded.cache,0,NULL,NULL)){fprintf(f,"ERROR invalid replay parameter\n");return 1;}
  }
  if(visit_errors || record_count!=read_count || record_calls!=read_calls){fprintf(f,"ERROR replay case=%u visits=%u vertices=%u/%u calls=%u/%u\n",cases,visit_errors,record_count,read_count,record_calls,read_calls);return 1;}
 }
 if(cases%37==0){
  BullyNativeObject out;
  mode(m,cases&3);candidate_object(original,RAM,0x100,0x400,sb.v,&out);
  if(memcmp(snapshot,original,RAM)){fprintf(f,"ERROR RAM mutated\n");return 1;}
 }
 cases++;return 0;
}
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);f=fopen("skin-replay.log","w");
#else
 f=stdout;
#endif
 if(!f)return 2;
 const unsigned mesh_counts[]={1,2,8,16,64},bone_counts[]={1,8,64},sizes_n[]={3,8,64,256};
 for(unsigned m=0;m<4;m++){
  for(unsigned i=0;i<5;i++)for(unsigned j=0;j<3;j++)for(unsigned k=0;k<4;k++)for(unsigned batch=1;batch<=3;batch+=2)if(run(m,mesh_counts[i],bone_counts[j],sizes_n[k],batch,0,0))goto fail;
  for(unsigned c=1;c<114;c++)if(run(m,1+c%8,1+c%64,3+c%28,1+c%3,c,c&1))goto fail;
  fprintf(f,"mode=%u cases=%u success=%u cached=%u overflow=%u replayed=%u errors=0\n",m,cases,successes,cached,overflowed,replayed);fflush(f);
 }
 fprintf(f,"COMPLETE cases=%u success=%u cached=%u overflow=%u replayed=%u errors=0 size=%u\n",cases,successes,cached,overflowed,replayed,(unsigned)sizeof(BullyNativeSkinCache));fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
fail:fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 1;
}
