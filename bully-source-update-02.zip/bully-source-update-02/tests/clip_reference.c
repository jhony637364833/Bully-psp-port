#include "world_clip.h"
#include <math.h>
#include <string.h>
static double distance_to(const BullyClipVertex *v, int plane, double near, double far)
{
    switch(plane) {
    case 0:return (double)v->p[2]-near;
    case 1:return far-v->p[2];
    case 2:return v->p[0];
    case 3:return (double)v->p[2]-v->p[0];
    case 4:return v->p[1];
    default:return (double)v->p[2]-v->p[1];
    }
}
int bully_clip_triangle(const BullyClipVertex input[3], float near, float far,
                        BullyClipVertex output[10])
{
    BullyClipVertex a[10],b[10];
    if(!input || !output || !isfinite(near) || !isfinite(far) || near<=0 || far<=near) return 0;
    for(int i=0;i<3;i++) for(int k=0;k<3;k++)
        if(!isfinite(input[i].p[k]) || !isfinite(input[i].color[k])) return 0;
    for(int i=0;i<3;i++)for(int k=0;k<2;k++)
        if(!isfinite(input[i].uv[k]))return 0;
    memcpy(a,input,3*sizeof(*a));
    int n=3;
    for(int plane=0;plane<6 && n;plane++) {
        int m=0;
        for(int i=0;i<n;i++) {
            const BullyClipVertex *u=&a[i],*v=&a[(i+1)%n];
            double du=distance_to(u,plane,near,far),dv=distance_to(v,plane,near,far);
            if(du>=0) { if(m==10)return 0; b[m++]=*u; }
            if((du<0)!=(dv<0)) {
                if(m==10)return 0;
                double t=du/(du-dv);
                for(int k=0;k<3;k++) {
                    b[m].p[k]=(float)((1-t)*u->p[k]+t*v->p[k]);
                    b[m].color[k]=(float)((1-t)*u->color[k]+t*v->color[k]);
                }
                for(int k=0;k<2;k++)
                    b[m].uv[k]=(float)((1-t)*u->uv[k]+t*v->uv[k]);
                m++;
            }
        }
        n=m;memcpy(a,b,(size_t)n*sizeof(*a));
    }
    if(n<3)return 0;
    memcpy(output,a,(size_t)n*sizeof(*a));return n;
}
/* Frozen pre-optimization implementation used only as a differential oracle. */
