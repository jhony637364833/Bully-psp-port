#include "candidate/native_skin.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully palette reuse test",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
PSP_HEAP_SIZE_KB(1024);
static void mode(unsigned m,unsigned p){uint32_t f=0x01000000u|m|((p&1)?0x800000u:0)|((p&2)?0x7cu:0);__asm__ volatile("ctc1 %0,$31"::"r"(f):"memory");}
static uint32_t status(int dep){uint32_t f;__asm__ volatile("cfc1 %0,$31":"=r"(f):"r"(dep):"memory");return f;}
#else
#include <fenv.h>
static void mode(unsigned m,unsigned p){static const int r[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(r[m]);feclearexcept(FE_ALL_EXCEPT);if(p&2)feraiseexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW|FE_UNDERFLOW|FE_INEXACT);}
static uint32_t status(int dep){(void)dep;return (uint32_t)fetestexcept(FE_ALL_EXCEPT);}
#endif
int reference_skin_chain(const uint8_t*,size_t,uint32_t,uint32_t,unsigned,BullyNativeVertex*,BullySkinVisit,void*,size_t*,size_t*,size_t*);
int candidate_skin_chain(const uint8_t*,size_t,uint32_t,uint32_t,unsigned,BullyNativeVertex*,BullySkinVisit,void*,size_t*,size_t*,size_t*);
#define RAM 65536
#define PAL 40960u
#define SCRATCH (256*sizeof(BullyNativeVertex))
static unsigned char original[RAM],arena_a[RAM+256] __attribute__((aligned(16))),arena_b[RAM+256] __attribute__((aligned(16))),sa[SCRATCH+128] __attribute__((aligned(16))),sb[SCRATCH+128] __attribute__((aligned(16)));
static unsigned char attrs[4][4096],previous[4][4096];
static uint32_t seed=0x19ab3265u;
static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static void put(uint8_t *p,uint32_t v){for(unsigned k=0;k<4;k++)p[k]=(uint8_t)(v>>(8*k));}
static uint32_t raw(float v){uint32_t u;memcpy(&u,&v,4);return u;}
static void real(uint8_t*p,float v){put(p,raw(v));}
static unsigned build(unsigned bones,unsigned n,unsigned inf,unsigned batches,unsigned variant){
 memset(original,0,sizeof(original));
 for(unsigned b=0;b<bones;b++)for(unsigned r=0;r<4;r++)for(unsigned k=0;k<3;k++){
  float v=r<3?(r==k?1.0f:0.0f):(float)((int)((b*13+k*7)%31)-15)/8.0f;
  if(variant&1)v=(float)((int)(rnd()%129)-64)/32.0f;
  real(original+PAL+b*64+r*16+k*4,v);
 }
 unsigned at=256;
 for(unsigned batch=0;batch<batches;batch++){
  unsigned widths[4]={16,8,3,16};memset(attrs,0,sizeof(attrs));
  for(unsigned i=0;i<n;i++){
   for(unsigned k=0;k<3;k++)real(attrs[0]+i*16+k*4,(float)((int)(rnd()%257)-128)/16.0f);
   put(attrs[0]+i*16+12,(i%11==7)?0x8000u:0);
   for(unsigned k=0;k<2;k++)real(attrs[1]+i*8+k*4,(float)((int)(rnd()%257)-128)/32.0f);
   for(unsigned k=0;k<3;k++)attrs[2][i*3+k]=(uint8_t)rnd();
   for(unsigned k=0;k<inf;k++){
    unsigned bone=(i*7+k*11+batch*5)%bones;
    uint32_t v=raw(inf==1?1.0f:inf==2?.5f:inf==3?(k==2?.5f:.25f):.25f);
    put(attrs[3]+i*16+k*4,v|((bone+1)*4u));
   }
  }
  if(batch)for(unsigned k=0;k<4;k++)memcpy(attrs[k],previous[k]+(n-2)*widths[k],2*widths[k]);
  unsigned weights=24576+batch*4096;memcpy(original+weights,attrs[3],n*16);
  put(original+at,0x30000000u+n);put(original+at+4,weights);put(original+at+8,0x01000104u);put(original+at+12,0x6c008003u|((n&255)<<16));at+=16;
  unsigned tag=at,cursor=at+8;
  put(original+cursor,0x01000104u);cursor+=4;put(original+cursor,0x05000000u);cursor+=4;
  for(unsigned k=0;k<3;k++){
   unsigned cmd=k==0?0x6c:k==1?0x64:0x6a;
   put(original+cursor,(cmd<<24)|((n&255)<<16)|0x8000u|k);cursor+=4;
   unsigned length=(n*widths[k]+3)&~3u;memcpy(original+cursor,attrs[k],n*widths[k]);cursor+=length;
  }
  put(original+cursor,0x04000000u|n);cursor+=4;put(original+cursor,batch?0x17000000u:0x15000000u);cursor+=4;
  unsigned end=(cursor+15)&~15u;put(original+tag,0x10000000u+(end-tag-16)/16);at=end;
  memcpy(previous,attrs,sizeof(attrs));
 }
 put(original+at,0x60000000u);at+=16;return at;
}
typedef struct {uint8_t *ram;unsigned mutate,visits,vertices;BullyNativeVertex v[768];uint8_t skip[768];} Events;
static Events ea,eb;
static void visit(const BullyNativeVertex*v,const uint8_t*skip,size_t n,void*ctx){
 Events*e=ctx;if(e->vertices+n>768){e->visits=999;return;}
 memcpy(e->v+e->vertices,v,n*sizeof(*v));memcpy(e->skip+e->vertices,skip,n);e->vertices+=(unsigned)n;e->visits++;
 if(e->mutate==1)real(e->ram+PAL+48,(float)(e->visits*17));
 if(e->mutate==2 && e->visits==1)put(e->ram+PAL+48,0x7fc01234u);
 if(e->mutate==3){put(e->ram+PAL+48,e->visits&1?0x80000001u:0x00800000u);put(e->ram+PAL+60,0x7fc00000u);}
}
static FILE*f;static unsigned cases,successes,aliased,callbacks,override_kind,override_bits,badparam;
static int compare(unsigned m,unsigned bones,unsigned n,unsigned inf,unsigned batches,unsigned align,unsigned alias,unsigned cb,unsigned corruption){
 unsigned end=build(bones,n,inf,batches,corruption);
 if(override_kind){unsigned at=override_kind==1?PAL+48:override_kind==2?24576:override_kind==3?292:296+n*16;put(original+at,override_kind==2?(override_bits&~1023u)|4u:override_bits);}
 if(corruption>=2){unsigned p=corruption%3==0?PAL+(rnd()%(bones*64)):corruption%3==1?256+rnd()%(end-256):24576+rnd()%(batches*4096);original[p]^=(uint8_t)(1u<<(rnd()&7));}
 memset(arena_a,0xa5,sizeof(arena_a));memset(arena_b,0xa5,sizeof(arena_b));
 uint8_t*ra=arena_a+64+align,*rb=arena_b+64+align;memcpy(ra,original,RAM);memcpy(rb,original,RAM);
 memset(sa,0x97,sizeof(sa));memset(sb,0x97,sizeof(sb));BullyNativeVertex*a=(void*)(sa+64),*b=(void*)(sb+64);
 if(alias){int offset=alias==1?0:alias==2?32:alias==3?-1024:(int)(bones*64);a=(void*)(((uintptr_t)(ra+PAL+offset)+3)&~(uintptr_t)3);b=(void*)(((uintptr_t)(rb+PAL+offset)+3)&~(uintptr_t)3);aliased++;}
 memset(&ea,0,sizeof(ea));memset(&eb,0,sizeof(eb));ea.ram=ra;eb.ram=rb;ea.mutate=eb.mutate=cb?cb-1:0;
 size_t ca=123,ua=456,ta=789,cc=123,uc=456,tc=789;
 size_t bytes=badparam==1?0:badparam==2?256:badparam==3?PAL+16:RAM;
 unsigned nb=badparam==4?0:badparam==5?65:bones;
 unsigned chain=badparam==6?0:badparam==7?257:badparam==8?RAM-16:256;
 unsigned pal=badparam==9?0:badparam==10?PAL+1:badparam==11?RAM-16:PAL;
 mode(m,cases&3);int va=reference_skin_chain(badparam==12?NULL:ra,bytes,chain,pal,nb,badparam==13?NULL:a,cb?visit:NULL,&ea,badparam==14?NULL:&ca,badparam==15?NULL:&ua,badparam==16?NULL:&ta);uint32_t fa=status(va);
 mode(m,cases&3);int vb=candidate_skin_chain(badparam==12?NULL:rb,bytes,chain,pal,nb,badparam==13?NULL:b,cb?visit:NULL,&eb,badparam==14?NULL:&cc,badparam==15?NULL:&uc,badparam==16?NULL:&tc);uint32_t fb=status(vb);
 if(!corruption && !alias && cb<3 && !badparam && !override_kind && !va){fprintf(f,"INVALID FIXTURE mode=%u bones=%u n=%u inf=%u batches=%u\n",m,bones,n,inf,batches);return 1;}
 ea.ram=NULL;eb.ram=NULL;
 if(va!=vb||ca!=cc||ua!=uc||ta!=tc||fa!=fb||memcmp(arena_a,arena_b,sizeof(arena_a))||memcmp(sa,sb,sizeof(sa))||memcmp(&ea,&eb,sizeof(ea))){fprintf(f,"ERROR mode=%u case=%u bones=%u n=%u inf=%u batches=%u align=%u alias=%u cb=%u corrupt=%u result=%d/%d csr=%08lx/%08lx\n",m,cases,bones,n,inf,batches,align,alias,cb,corruption,va,vb,(unsigned long)fa,(unsigned long)fb);return 1;}
 if(va)successes++;
 if(cb)callbacks++;
 cases++;return 0;
}
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);f=fopen("skin-test.log","w");
#else
 f=stdout;
#endif
 if(!f)return 2;
 static const unsigned sizes[]={3,4,8,16,64,256};
 for(unsigned m=0;m<4;m++){
  for(unsigned bones=1;bones<=64;bones++)for(unsigned sz=0;sz<6;sz++)for(unsigned inf=1;inf<=4;inf++)if(compare(m,bones,sizes[sz],inf,1,(bones+sz+inf)&3,0,0,0))goto fail;
  for(unsigned a=0;a<4;a++)for(unsigned al=0;al<5;al++)for(unsigned cb=0;cb<5;cb++)if(compare(m,1+(a*13+al*7+cb)%64,3+(cb%3)*5,1+(al&3),3,a,al,cb,0))goto fail;
  for(unsigned i=0;i<5000;i++)if(compare(m,1+rnd()%64,3+rnd()%30,1+rnd()%4,1+rnd()%3,rnd()&3,(i%7==0)?1+rnd()%4:0,i%6?0:1+rnd()%4,1+i%20))goto fail;
  static const uint32_t edges[]={0,0x80000000,1,0x80000001,0x007fffff,0x807fffff,0x00800000,0x80800000,0x3f7fffff,0x3f800000,0xbf800000,0x3f800001,0x7f7fffff,0xff7fffff,0x7f800000,0xff800000,0x7fc12345,0x7f801234};
  for(override_kind=1;override_kind<=4;override_kind++)for(unsigned i=0;i<sizeof(edges)/sizeof(*edges);i++){override_bits=edges[i];if(compare(m,8,8,2,3,0,0,1,0))goto fail;}
  override_kind=0;
  for(badparam=1;badparam<=16;badparam++)if(compare(m,8,8,2,3,0,0,1,0))goto fail;
  badparam=0;
  fprintf(f,"mode=%u cases=%u success=%u aliases=%u callbacks=%u errors=0\n",m,cases,successes,aliased,callbacks);fflush(f);
 }
 fprintf(f,"COMPLETE cases=%u success=%u aliases=%u callbacks=%u errors=0\n",cases,successes,aliased,callbacks);fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
 fail:fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 1;
}
