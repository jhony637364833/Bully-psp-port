"""Check actual sky admission and camera clear helpers using synthetic states."""
from pathlib import Path
import argparse,subprocess,tempfile,json
p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args()
r=Path(__file__).resolve().parents[1];t=r/'tests';g=r/'app/games/SLUS-21269_v1.02/src'
scratch=tempfile.TemporaryDirectory(prefix='bully-sky-');b=a.output.resolve() if a.output else Path(scratch.name);b.mkdir(parents=True,exist_ok=True)
s=(g/'psp/overlay_live.c').read_text();body=s[s.index('static int sky_underlay('):s.index('static void state(void*o)')]
s=(g/'psp/world_display.c').read_text();flow=s[s.index('int bully_world_underlay_begin('):s.index('/* Compose overlays after')]
(b/'sky-host.c').write_text((t/'sky_underlay_head.inc').read_text()+flow+body+(t/'sky_underlay_main.inc').read_text())
cmd=['gcc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-fsanitize=address,undefined','-I'+str(g),str(b/'sky-host.c'),'-o',str(b/'sky-host')]
(b/'host-command.json').write_text(json.dumps(cmd));subprocess.run(cmd,check=True);subprocess.run([str(b/'sky-host')],check=True)
