#include "native_light.h"
#include "world_projection.h"
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
static unsigned checks;
#define CHECK(x) do { assert(x);checks++; } while(0)
static void word(unsigned char *r,unsigned a,unsigned w) {
    r[a]=w;r[a+1]=w>>8;r[a+2]=w>>16;r[a+3]=w>>24;
}
static void number(unsigned char *r,unsigned a,float f) {
    unsigned w;memcpy(&w,&f,4);word(r,a,w);
}
static unsigned char *fixture(void) {
    unsigned char *r=calloc(1,0x700000);assert(r);
    word(r,0x100+48,0x200);word(r,0x100+60,0x300);
    word(r,0x200,0x400);word(r,0x400+32,0x500);word(r,0x500,0x10000001);
    word(r,0x6d5278,0x01000404);word(r,0x6d527c,0x6c0203d0);
    word(r,0x6d528c,2);
    for(unsigned k=0;k<3;k++){number(r,0x6d5280+4*k,1);r[0x100+68+k]=255;}
    r[0x100+71]=255;
    number(r,0x300,1);number(r,0x8000-7404,.5f);
    return r;
}
static void light_tests(void) {
    unsigned char *r=fixture();BullyNativeLight light,unchanged;
    memset(&light,0xa5,sizeof(light));unchanged=light;
    CHECK(!bully_native_light(r,0x6d5280,0x100,0x8000,&light));
    CHECK(!memcmp(&light,&unchanged,sizeof(light)));
    CHECK(!bully_native_light(r,0x700000,0x100,7495,&light));
    CHECK(bully_native_light(r,0x700000,0x100,0x8000,&light));
    CHECK(light.stream==0x500 && light.material_id==0x2f4 && light.blend==.5f);
    BullyNativeVertex v={0};float rgb[3];
    v.color[3]=128;v.color_secondary[3]=128;
    CHECK(bully_light_alpha(&v,&light)>=255);
    v.color[3]=0;CHECK(fabsf(bully_light_alpha(&v,&light)-128.60237f)<.001f);
    light.blend=-3;light.monochrome=1;CHECK(fabsf(bully_light_alpha(&v,&light)-128.60237f)<.001f);
    light.blend=.5f;light.monochrome=0;
    r[0x100+71]=128;CHECK(bully_native_light(r,0x700000,0x100,0x8000,&light));
    CHECK(fabsf(bully_light_alpha(&v,&light)-64.55334f)<.001f);
    r[0x100+71]=0;CHECK(bully_native_light(r,0x700000,0x100,0x8000,&light));
    CHECK(bully_light_alpha(&v,&light)==0);
    r[0x100+71]=255;CHECK(bully_native_light(r,0x700000,0x100,0x8000,&light));
    v.color[0]=0;v.color[1]=80;v.color[2]=160;
    v.color_secondary[0]=160;v.color_secondary[1]=120;v.color_secondary[2]=80;
    bully_light_color(&v,&light,rgb);
    CHECK(fabsf(rgb[0]-80)<.01f && fabsf(rgb[1]-100)<.01f && fabsf(rgb[2]-120)<.01f);
    light.blend=0;bully_light_color(&v,&light,rgb);CHECK(rgb[0]==0 && fabsf(rgb[2]-160)<.01f);
    light.blend=1;bully_light_color(&v,&light,rgb);CHECK(fabsf(rgb[0]-160)<.01f);
    light.monochrome=1;bully_light_color(&v,&light,rgb);
    CHECK(fabsf(rgb[0]-172)<.01f && rgb[0]==rgb[1] && rgb[1]==rgb[2]);
    /* Bright light must saturate before a dark material tint is applied. */
    number(r,0x6d5280,8);r[0x100+68]=64;
    CHECK(bully_native_light(r,0x700000,0x100,0x8000,&light));
    bully_light_color(&v,&light,rgb);CHECK(fabsf(rgb[0]-64)<.01f);
    const float bad[]={NAN,INFINITY};
    for(unsigned i=0;i<2;i++) { number(r,0x8000-7404,bad[i]);CHECK(!bully_native_light(r,0x700000,0x100,0x8000,&light)); }
    /* The original shader does not clamp a finite blend factor. */
    number(r,0x8000-7404,1.25f);number(r,0x6d5280,1);r[0x100+68]=255;
    CHECK(bully_native_light(r,0x700000,0x100,0x8000,&light));
    bully_light_color(&v,&light,rgb);CHECK(fabsf(rgb[0]-200)<.01f);
    number(r,0x8000-7404,.5f);number(r,0x300,NAN);
    CHECK(!bully_native_light(r,0x700000,0x100,0x8000,&light));number(r,0x300,1);
    word(r,0x6d527c,0x6c0203d1);CHECK(!bully_native_light(r,0x700000,0x100,0x8000,&light));
    word(r,0x6d527c,0x6c0203d0);word(r,0x6d528c,0);
    CHECK(!bully_native_light(r,0x700000,0x100,0x8000,&light));
    word(r,0x6d528c,2);word(r,0x100+60,0xfffffffc);
    CHECK(!bully_native_light(r,0x700000,0x100,0x8000,&light));free(r);
}
static unsigned visits;
static void visit(const BullyNativeVertex *v,size_t n,void *ctx) {
    (void)ctx;CHECK(n==3);CHECK(v[0].color[0]==0);
    CHECK(v[0].color_secondary[0]==248 && v[0].color_secondary[1]==0);
    CHECK(v[0].color_secondary[3]==128);visits++;
}
static void decoder_tests(void) {
    unsigned char r[256]={0};unsigned p=24;
    word(r,p,0x01000104);p+=4;word(r,p,0x05000000);p+=4;
    const unsigned cmds[]={0x69038000,0x65038001,0x6f03c002,0x6f03c003};
    const unsigned lengths[]={20,12,8,8};
    for(unsigned i=0;i<4;i++) {
        word(r,p,cmds[i]);p+=4;
        if(i==3) {r[p]=31;r[p+1]=128;}
        p+=lengths[i];
    }
    word(r,p,0x04000003);p+=4;word(r,p,0x15000000);p+=4;
    p=(p+15)&~15u;word(r,16,0x10000000|((p-32)/16));
    word(r,p,0x60000000);word(r,p+12,0x11000000);
    BullyNativeVertex scratch[256];size_t count,used;
    CHECK(bully_compressed_chain(r,p+16,16,scratch,visit,0,&count,&used));
    CHECK(count==3 && used==p && visits==1);
    CHECK(!bully_compressed_chain(r,p+15,16,scratch,0,0,&count,&used));
    CHECK(count==0 && used==0);
}
static void projection_tests(void) {
    float m[16];CHECK(bully_projection_matrix(1,100,m));
    const float points[][3]={{0,0,1},{1,1,1},{25,75,100},{2,1,4}};
    for(unsigned i=0;i<4;i++) {
        const float *p=points[i];float c[4];
        for(unsigned k=0;k<4;k++)c[k]=p[0]*m[k]+p[1]*m[4+k]+p[2]*m[8+k]+m[12+k];
        CHECK(fabsf((c[0]/c[3]+1)/2-p[0]/p[2])<1e-6f);
        CHECK(fabsf((1-c[1]/c[3])/2-p[1]/p[2])<1e-6f);
        CHECK(fabsf((c[2]/c[3]+1)/2-(100.0f/99)*(1-1/p[2]))<1e-6f);
        CHECK(c[3]==p[2]);
    }
    /* At the screen midpoint of endpoints with z=1 and z=4, UV=0.2,
     * rather than the 0.5 produced by the previous 2D affine path. */
    float uv=((0.0f/1)+(1.0f/4))/((1.0f/1)+(1.0f/4));
    CHECK(fabsf(uv-.2f)<1e-6f);
    CHECK(!bully_projection_matrix(0,100,m));
    CHECK(!bully_projection_matrix(1,1,m));
    CHECK(!bully_projection_matrix(1,INFINITY,m));
}
int main(void) {light_tests();decoder_tests();projection_tests();printf("%u assertions passed\n",checks);return 0;}
