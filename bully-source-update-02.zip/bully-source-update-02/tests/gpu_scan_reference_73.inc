static int gpu_strip_bounds(const BullyNativeVertex *v,size_t n) {
    float lo[3],hi[3],clo[3]={0},chi[3]={0},error[3];
    for(unsigned k=0;k<3;k++)lo[k]=hi[k]=v[0].position[k];
    for(size_t i=0;i<n;i++)for(unsigned k=0;k<3;k++) {
        float x=v[i].position[k];if(!isfinite(x))return 0;
        if(x<lo[k])lo[k]=x;
        if(x>hi[k])hi[k]=x;
    }
    if(!isfinite(object_view.near_plane) || !isfinite(object_view.far_plane) ||
       object_view.near_plane<=0 || object_view.far_plane<=object_view.near_plane)return 0;
    for(unsigned k=0;k<3;k++) {
        float magnitude=fabsf(object_view.view[3][k]);
        for(unsigned j=0;j<3;j++) {
            float extent=fabsf(lo[j])>fabsf(hi[j])?fabsf(lo[j]):fabsf(hi[j]);
            magnitude+=extent*fabsf(object_view.view[j][k]);
        }
        error[k]=(magnitude+1.0f)*0.0001f;
        if(!isfinite(error[k]))return 0;
    }
    float center[3],extent[3];
    for(unsigned j=0;j<3;j++) {
        center[j]=lo[j]*0.5f+hi[j]*0.5f;
        extent[j]=hi[j]*0.5f-lo[j]*0.5f;
    }
    for(unsigned k=0;k<3;k++) {
        float c=object_view.view[3][k],e=0;
        for(unsigned j=0;j<3;j++) {
            c+=center[j]*object_view.view[j][k];
            e+=extent[j]*fabsf(object_view.view[j][k]);
        }
        clo[k]=c-e;chi[k]=c+e;
        if(!isfinite(clo[k]) || !isfinite(chi[k]))return 0;
    }
    if(chi[2]<object_view.near_plane-error[2] || clo[2]>object_view.far_plane+error[2] ||
       chi[0]<-error[0] || chi[1]<-error[1] ||
       clo[0]>chi[2]+error[0]+error[2] || clo[1]>chi[2]+error[1]+error[2])return -1;
    if(clo[2]>object_view.near_plane+error[2] && chi[2]<object_view.far_plane-error[2] &&
       object_view.near_plane>=0.0001f && object_view.far_plane<=65536.0f &&
       clo[0]>-clo[2]+error[0]+error[2] && clo[1]>-clo[2]+error[1]+error[2] &&
       chi[0]<2*clo[2]-error[0]-2*error[2] && chi[1]<2*clo[2]-error[1]-2*error[2])return 1;
    return 0;
}
static inline int gpu_same_position(const BullyNativeVertex *a,const BullyNativeVertex *b) {
    for(unsigned k=0;k<3;k++) {
        uint32_t x,y;memcpy(&x,&a->position[k],4);memcpy(&y,&b->position[k],4);
        if(x!=y)return 0;
    }
    return 1;
}
/* On the GPU path FP traps are disabled and entry FCR is restored at exit.
 * Lighting consumes only these two color banks and the immutable material.
 * Reuse the already packed result without extra FCR reads or cache storage. */
static inline int gpu_same_colors(const BullyNativeVertex *a,const BullyNativeVertex *b) {
    uint32_t a0,a1,b0,b1;
    memcpy(&a0,a->color,4);memcpy(&b0,b->color,4);
    memcpy(&a1,a->color_secondary,4);memcpy(&b1,b->color_secondary,4);
    return a0==b0 && a1==b1;
}
static int draw_gpu_strip(const BullyNativeVertex *v,const uint8_t *skip,size_t n) {
    if(n<12 || n>256)return 0;
    uint32_t saved=clip_fpu_read();if(saved&0x00020f80u)return 0;
    int bounds=gpu_strip_bounds(v,n);
    if(bounds<=0){clip_fpu_write(saved);return bounds<0;}
    GeVertex prepared[256];
    for(size_t i=0;i<n;i++) {
        if(!isfinite(v[i].uv[0]) || !isfinite(v[i].uv[1])){clip_fpu_write(saved);return 0;}
        unsigned color=0xff000000u;
        if(material_light && i && gpu_same_colors(&v[i-1],&v[i])) {
            color=prepared[i-1].color;
        } else if(material_light) {
            float rgb[3],alpha;bully_light_color(&v[i],material_light,rgb);alpha=bully_light_alpha(&v[i],material_light);
            if(!isfinite(alpha) || !isfinite(rgb[0]) || !isfinite(rgb[1]) || !isfinite(rgb[2])){clip_fpu_write(saved);return 0;}
            color=(channel(alpha)<<24)|channel(rgb[0])|(channel(rgb[1])<<8)|(channel(rgb[2])<<16);
        } else {
            /* Exact integer form of the default byte*2 then channel clamp. */
            for(unsigned k=0;k<3;k++){unsigned x=(unsigned)v[i].color[k]*2;if(x>255)x=255;color|=x<<(k*8);}
        }
        prepared[i]=(GeVertex){v[i].uv[0],v[i].uv[1],color,v[i].position[0],v[i].position[1],v[i].position[2]};
    }
    int selected=0;
    for(size_t i=2;i<n;i++) {
        if(skip && skip[i])continue;
        if(gpu_same_position(&v[i-2],&v[i-1]) || gpu_same_position(&v[i-1],&v[i]) || gpu_same_position(&v[i-2],&v[i]))continue;
        if(!selected){if(!gpu_vertex_space){flush_vertices();gpu_vertex_space=1;}selected=1;}
        if(queued+3>WORLD_BATCH_VERTICES)flush_vertices();
        verts[queued++]=prepared[i-2];verts[queued++]=prepared[i-1];verts[queued++]=prepared[i];triangles++;
    }
    clip_fpu_write(saved);return 1;
}


