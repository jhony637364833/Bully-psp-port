"""Compare current native renderer with pre-consolidation command submission.
Requires host GCC/ASan/UBSan and PSP SDK headers, but no game assets.
"""
from pathlib import Path
import argparse,subprocess,tempfile,hashlib,json
repo=Path(__file__).resolve().parents[1];tests=repo/'tests'
a=argparse.ArgumentParser();a.add_argument('--output',type=Path);a.add_argument('--sdk-include',type=Path);args=a.parse_args()
sdk=args.sdk_include
if sdk is None:sdk=Path(subprocess.check_output(['psp-config','--pspsdk-path'],text=True).strip())/'include'
assert (sdk/'pspgu.h').is_file(), 'PSP SDK headers required'
g=repo/'app/games/SLUS-21269_v1.02/src'
with tempfile.TemporaryDirectory(prefix='bully-submission-') as tmp:
 p=args.output.resolve() if args.output else Path(tmp);p.mkdir(parents=True,exist_ok=True)
 (p/'hle.h').write_bytes((tests/'psp_state_smoke/hle.h').read_bytes())
 head=(tests/'world_submission_host.inc').read_text();fixture=(tests/'world_submission_fixture.inc').read_text()+(tests/'texture_cache_unavailable.inc').read_text();results={}
 for name,source in [('reference',tests/'world_submission_reference.inc'),('candidate',g/'psp/world_display.c')]:
  body=source.read_text()
  if 'static __attribute__((noinline)) uint32_t clip_fpu_read' in body:
   # Optional allocation remains denied. FPU callbacks now also serve
   # adjacent-vertex reuse; preserve host state with the shared adapter.
   begin=body.index('static __attribute__((noinline)) uint32_t clip_fpu_read')
   end=body.index('static void allocate_clip_memo',begin)
   body=body[:begin]+(tests/'renderer_fpu_test.inc').read_text()+body[end:]
  if name=='candidate':
   # This pre-consolidation reference defines exact CPU vertices. Build 68's
   # intentional GPU rounding is checked by the separate GPU differentials.
   # Select the real CPU fallback while comparing command-list consolidation.
   dispatch='if(draw_gpu_strip(v,skip,n))return;'
   assert body.count(dispatch)==1, 'CPU fallback dispatch changed; review adapter'
   body=body.replace(dispatch,'/* CPU fallback selected for this fixture. */')
  (p/(name+'.c')).write_text(head+body+fixture)
  cmd=['cc','-O2','-Wall','-Wno-int-to-pointer-cast','-fno-fast-math','-ffp-contract=off','-fsanitize=address,undefined','-I'+str(p),'-I'+str(g),'-I'+str(sdk),str(p/(name+'.c')),str(g/'world_clip.c'),'-lm','-o',str(p/name)]
  subprocess.run(cmd,check=True);results[name]=subprocess.check_output([str(p/name)],text=True);(p/(name+'.log')).write_text(results[name])
 normalize=lambda s:[' '.join(l.split()[:3]) for l in s.splitlines()]
 assert normalize(results['reference'])==normalize(results['candidate']), 'GPU command/vertex/texture mismatch'
 count=lambda s:sum(int(l.split('starts=')[1].split()[0]) for l in s.splitlines() if 'starts=' in l)
 before,after=map(count,[results['reference'],results['candidate']]);assert after<before
 print('PASS 512 cases: exact ordered commands/vertices/textures except verified redundant identity MODEL setters; GPU read lifetimes and list capacity; ASan/UBSan; lists',before,'->',after)
