#include "native_skin.h"
#include <math.h>
#include <string.h>
static uint32_t word(const uint8_t *p) {
    return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static float number(const uint8_t *p) {
    uint32_t v=word(p);float f;memcpy(&f,&v,4);return f;
}
static int range(size_t bytes,size_t at,size_t n) {
    return at>=4 && at<=bytes && n<=bytes-at;
}
int bully_skin_chain(const uint8_t *ram,size_t bytes,uint32_t chain,
                     uint32_t palette,unsigned bones,BullyNativeVertex *scratch,
                     BullySkinVisit visit,void *context,size_t *count,
                     size_t *used,size_t *triangles) {
    const uint8_t *attrs[4]={0},*prev[4]={0};
    const unsigned widths[4]={16,8,3,16},commands[4]={0x6c,0x64,0x6a,0x6c};
    size_t at=chain,n=0,previous_n=0,total=0,tris=0;
    unsigned seen=0,cycle=0,closed=0,batches=0;
    uint8_t skip[256];
    if(!count || !used || !triangles)return 0;
    *count=*used=*triangles=0;
    if(!ram || !scratch || !bones || bones>64 || (chain&15) || (palette&15) ||
       !range(bytes,palette,bones*64u))return 0;
    for(unsigned b=0;b<bones;b++)for(unsigned r=0;r<4;r++)for(unsigned k=0;k<3;k++)
        if(!isfinite(number(ram+palette+b*64+r*16+k*4)))return 0;
    /* Sequential tags only: no CALL/NEXT/loops, at most2048 strip batches. */
    for(unsigned tags=0;tags<8192;tags++) {
        if(!range(bytes,at,16))return 0;
        uint32_t tag=word(ram+at),address=word(ram+at+4);
        unsigned type=tag>>28;size_t payload=(tag&65535)*16u;
        if(tag&0x0fff0000u || (type!=1 && type!=3 && type!=6))return 0;
        if(type==3) {
            /* Exact observed REF: one weight UNPACK in the tag, external data. */
            uint32_t unpack=word(ram+at+12);
            unsigned items=(unpack>>16)&255; if(!items)items=256;
            if(seen || closed || (address&15) || !range(bytes,address,payload) ||
               word(ram+at+8)!=0x01000104u || (unpack&0xff00ffffu)!=0x6c008003u ||
               payload!=items*16u)return 0;
            attrs[3]=ram+address;n=items;seen=8;cycle=1;at+=16;continue;
        }
        if(address || !range(bytes,at,16+payload))return 0;
        size_t cursor=at+8,end=at+16+payload;
        while(cursor<end) {
            uint32_t code=word(ram+cursor);cursor+=4;
            unsigned cmd=code>>24,num=(code>>16)&255,imm=code&65535;
            if(cmd==0 || cmd==0x11) { if(num || imm)return 0; }
            else if(cmd==1) { if(num || imm!=0x104 || closed)return 0;cycle=1; }
            else if(cmd==5) { if(num || imm || closed)return 0; }
            else if(cmd==4) {
                if(num || seen!=15 || closed || imm!=n)return 0;
                closed=1;
            } else if(cmd==0x15 || cmd==0x17) {
                if(num || imm || !closed || batches>=2048 ||
                   (cmd==0x15 ? batches!=0 : batches==0) || n<3)return 0;
                if(batches)for(unsigned k=0;k<4;k++)
                    if(memcmp(prev[k]+(previous_n-2)*widths[k],attrs[k],2*widths[k]))return 0;
                for(size_t i=0;i<n;i++) {
                    BullyNativeVertex *v=scratch+i;memset(v,0,sizeof(*v));
                    uint32_t adc=word(attrs[0]+i*16+12);
                    if(adc&~0x8000u)return 0;
                    skip[i]=(adc!=0);
                    float p[3],sum=0;
                    for(unsigned k=0;k<3;k++) {
                        p[k]=number(attrs[0]+i*16+k*4);if(!isfinite(p[k]))return 0;
                        v->color[k]=128;v->normal[k]=(int8_t)attrs[2][i*3+k];
                    }
                    v->color[3]=128;
                    for(unsigned k=0;k<2;k++) {
                        v->uv[k]=number(attrs[1]+i*8+k*4);if(!isfinite(v->uv[k]))return 0;
                    }
                    for(unsigned k=0;k<4;k++) {
                        const uint8_t *weight=attrs[3]+i*16+k*4;
                        uint32_t bits=word(weight);if(!bits)continue;
                        unsigned offset=bits&1023;
                        /* Bully VU loads at721+offset; palette begins at725. */
                        if((offset&3) || offset<4 || offset>4*bones)return 0;
                        float w=number(weight);if(!isfinite(w) || w<=0 || w>1.001f)return 0;
                        sum+=w;unsigned bone=offset/4-1;
                        for(unsigned j=0;j<3;j++) {
                            float value=number(ram+palette+bone*64+48+j*4);
                            for(unsigned r=0;r<3;r++)value+=p[r]*number(ram+palette+bone*64+r*16+j*4);
                            v->position[j]+=w*value;
                        }
                    }
                    if(sum<0.999f || sum>1.001f)return 0;
                    for(unsigned k=0;k<3;k++)if(!isfinite(v->position[k]))return 0;
                    if(i>=2 && !skip[i])tris++;
                }
                if(visit)visit(scratch,skip,n,context);
                total+=n-(batches?2:0);batches++;
                memcpy(prev,attrs,sizeof(prev));previous_n=n;
                memset(attrs,0,sizeof(attrs));seen=cycle=closed=0;n=0;
            } else {
                unsigned k;
                for(k=0;k<3;k++)if(cmd==commands[k] && imm==0x8000u+k)break;
                if(k==3 || !cycle || closed || !(seen&8) || (seen&(1u<<k)))return 0;
                size_t items=num?num:256,length=(items*widths[k]+3)&~(size_t)3;
                if(items!=n || length>end-cursor)return 0;
                attrs[k]=ram+cursor;cursor+=length;seen|=1u<<k;
            }
        }
        at=end;
        if(type==6) {
            if(!batches || seen || closed)return 0;
            *count=total;*used=at-chain;*triangles=tris;return 1;
        }
    }
    return 0;
}
