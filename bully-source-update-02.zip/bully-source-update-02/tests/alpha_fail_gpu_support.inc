/* Explicit color readback is required: CPU loads of emulated VRAM can be stale.
 * Raw depth transfer is not an oracle here; use the occlusion witness below. */
static uint32_t witness_reference[480*272] __attribute__((aligned(16))),witness_candidate[480*272] __attribute__((aligned(16)));
static uint32_t color_reference[480*272] __attribute__((aligned(16))),color_candidate[480*272] __attribute__((aligned(16)));
static void readback(uint32_t*c){start();sceGuCopyImage(GU_PSM_8888,0,0,480,272,512,sceGeEdramGetAddr(),0,0,480,c);finish();sceKernelDcacheInvalidateRange(c,480*272*4);}
static void init(void){
 const unsigned fb=512*272*4; sceGuInit();start();sceGuDrawBuffer(GU_PSM_8888,(void*)0,512);sceGuDispBuffer(480,272,(void*)fb,512);sceGuDepthBuffer((void*)(2*fb),512);
 sceGuOffset(2048-240,2048-136);sceGuViewport(2048,2048,480,272);sceGuScissor(0,0,480,272);sceGuEnable(GU_SCISSOR_TEST);sceGuDepthRange(0,65535);sceGuDisable(GU_CULL_FACE);sceGuDisable(GU_LIGHTING);sceGuEnable(GU_CLIP_PLANES);sceGuShadeModel(GU_SMOOTH);
 const ScePspFMatrix4 identity={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};sceGuSetMatrix(GU_MODEL,&identity);sceGuSetMatrix(GU_VIEW,&identity);finish();
 sceDisplaySetMode(0,480,272);sceGuDisplay(GU_TRUE);
}
static void setup(BullyNativeObject*o){
 ScePspFMatrix4 projection;float matrix[16];if(!bully_projection_matrix(o->near_plane,o->far_plane,matrix))exit(3);memcpy(&projection,matrix,sizeof projection);
 start();sceGuSetMatrix(GU_PROJECTION,&projection);TcPspTex*t=&texture.texture;sceKernelDcacheWritebackRange(texels,t->total_bytes);
 sceGuTexMode(t->psm,0,0,t->swizzled);sceGuTexImage(0,t->level[0].width,t->level[0].height,t->level[0].bufw,texels+t->level[0].offset);
 if(t->clut_entries){sceGuClutMode(t->clut_psm,0,t->clut_entries-1,0);sceGuClutLoad(t->clut_bytes/32,texels+t->clut_offset);}
 sceGuTexFlush();sceGuTexFunc(GU_TFX_MODULATE,GU_TCC_RGBA);int filter=texture.filter==1?GU_NEAREST:GU_LINEAR;sceGuTexFilter(filter,filter);sceGuTexWrap(texture.wrap_u==3?GU_CLAMP:GU_REPEAT,texture.wrap_v==3?GU_CLAMP:GU_REPEAT);sceGuTexScale(1,1);sceGuTexOffset(0,0);if(has_texture)sceGuEnable(GU_TEXTURE_2D);else sceGuDisable(GU_TEXTURE_2D);
 sceGuDepthMask(GU_FALSE);sceGuClearColor(0xff223344u);sceGuClearDepth(65535);sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);apply_state();finish();
}
static void depth_witness(BullyNativeObject*o,uint32_t*dst){
 float z=o->near_plane+(o->far_plane-o->near_plane)*.999f;
 GeVertex quad[6] __attribute__((aligned(16)))={{0,0,0xff55ee33u,0,0,z},{0,0,0xff55ee33u,z,0,z},{0,0,0xff55ee33u,z,z,z},{0,0,0xff55ee33u,0,0,z},{0,0,0xff55ee33u,z,z,z},{0,0,0xff55ee33u,0,z,z}};
 sceKernelDcacheWritebackRange(quad,sizeof quad);start();sceGuDisable(GU_TEXTURE_2D);sceGuDisable(GU_BLEND);sceGuDisable(GU_ALPHA_TEST);sceGuEnable(GU_DEPTH_TEST);sceGuDepthFunc(GU_LEQUAL);sceGuDepthMask(GU_FALSE);
 sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D,6,0,quad);finish();readback(dst);
}
