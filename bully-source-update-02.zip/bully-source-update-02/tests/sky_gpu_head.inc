#include <pspkernel.h>
#include <pspgu.h>
#include <pspge.h>
#include <pspdisplay.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
static void fail_assert(const char*expression,int line){printf("ERROR assertion line=%d expression=%s\n",line,expression);fflush(stdout);sceKernelExitGame();}
#undef assert
#define assert(x) ((x)?(void)0:fail_assert(#x,__LINE__))
PSP_MODULE_INFO("Bully sky depth check",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
