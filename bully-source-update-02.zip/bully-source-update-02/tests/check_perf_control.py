"""Check PCCR translation against EE register semantics and the current COP0 HLE.
Run after applying the source overlay to PS2RC:
  python tests/check_perf_control.py --engine /path/to/PS2RC --output /tmp/perf-control
Use --elf SLUS_212.69 to include the actual game function. Add --psp to build
its PSP fixture with an installed PSP SDK, then launch the resulting EBOOT.
"""
from pathlib import Path
import argparse,importlib.util,os,struct,subprocess,sys

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--engine',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--backend',type=Path);p.add_argument('--elf',type=Path);p.add_argument('--generated',type=Path);p.add_argument('--psp',action='store_true');a=p.parse_args();e=a.engine.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(e))
 from ps2rc.image import Image,Segment,load_elf
 from ps2rc.r5900.decode import decode
 from ps2rc.analysis.width import narrowable
 from ps2rc.analysis.functions import Function
 from ps2rc import backend_c
 if a.backend:
  spec=importlib.util.spec_from_file_location('ps2rc.backend_control_check',a.backend.resolve());backend_c=importlib.util.module_from_spec(spec);spec.loader.exec_module(backend_c)
 # Reuse the actual existing HLE move handlers; the test's independent reference
 # is below. The helper's only exercised case is COP0[25]'s default read path.
 hle=(e/'hle/core/hle_main.c').read_text();start=hle.index('    if (strcmp(what, "mfc0") == 0)',hle.index('void rt_fatal('));end=hle.index('    if (strcmp(what, "di") == 0)',start)
 (out/'cop0_moves.inc').write_text(hle[start:end])
 names=[];bodies=[];meta=[]
 variants=[('exact',{}),('cache',{'cache':True}),('abi',{'cache':True,'abi':True}),('v5',{'cache':True,'abi':True,'v5':backend_c.V5_STEPS['v5s4y3']})]
 for variant,opts in variants:
  for kind in ['read','write','readzero','writezero','disable']:
   selectors=range(32) if kind in ('read','write') else [0]
   for selector in selectors:
    pc=0x1000;mf=lambda rt,sel:0x4000c800|(rt<<16)|(sel<<1);mt=lambda rt,sel:0x4080c800|(rt<<16)|(sel<<1)
    if kind=='read':words=[mf(3,selector),0x0060102d,0x03e00008,0]
    elif kind=='write':words=[0x0080182d,mt(3,selector),mf(2,0),0x03e00008,0]
    elif kind=='readzero':words=[mf(0,0),0x03e00008,0]
    elif kind=='writezero':words=[mt(0,0),mf(2,0),0x03e00008,0]
    else:words=[mf(3,0),0x3c028000,0x00621825,0x00621826,mt(3,0),0x03e00008,0]
    data=struct.pack('<'+'I'*len(words),*words);img=Image('<fixture>',pc,0,[Segment(pc,len(data),len(data),7,data)],[]);addrs=set(range(pc,pc+len(data),4))
    if kind=='disable' and a.elf:
     img=load_elf(str(a.elf));pc=0x120928;addrs=set(range(pc,pc+28,4));assert [img.word(x) for x in sorted(addrs)]==words,'Game instruction contract changed'
    kw=dict(opts)
    if variant=='v5':kw['narrow']=narrowable(img,Function(pc,pc+len(addrs)*4,addrs),{pc},{},wide_args={pc},abi=True)
    body=backend_c.translate_function(img,pc,addrs,func_starts=[pc],**kw);assert 'unsupported' not in body
    name=f'control_{variant}_{kind}_{selector}';body=body.replace(f'fn_{pc:08x}',name);bodies.append(body);names.append(name);meta.append((kind,selector))
 if a.generated:
  import re
  text=(a.generated/'main_004.c').read_text();match=re.search(r'^void fn_00120928\(R5900Ctx \*c\)\n\{\n.*?^\}',text,re.M|re.S);assert match
  name='control_prepared_disable';bodies.append(match[0].replace('fn_00120928',name));names.append(name);meta.append(('disable',0))
 # MFPC/MTPC remain deliberately unsupported; don't claim event-count emulation.
 for word in [0x4002c801,0x4082c801]:
  try:backend_c.stmt(decode(word,0x1000))
  except backend_c.Unsupported:pass
  else:raise AssertionError('Unexpected counter support: revisit the test contract')
 declarations='\n'.join(f'void {n}(R5900Ctx *);' for n in names)
 kinds={'read':0,'write':1,'readzero':2,'writezero':3,'disable':4}
 table='\n'.join('{'+f'{n},{kinds[k]},{s}'+'},' for n,(k,s) in zip(names,meta))
 (out/'generated.c').write_text('#include "r5900_rt.h"\n'+'\n'.join(bodies))
 template=Path(__file__).with_name('perf_control_fixture.c').read_text();(out/'main.c').write_text(template.replace('/* DECLARATIONS */',declarations).replace('/* CASES */',table))
 header=e/'runtime/r5900_rt.h';(out/'r5900_rt.h').write_bytes(header.read_bytes())
 if a.psp:
  make='''TARGET = bully_perf_control
OBJS = main.o generated.o
INCDIR = .
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -Wno-unused-variable -Wno-unused-label -Wno-unused-but-set-variable
BUILD_PRX = 1
LIBS = -lm
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully save restore control
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
''';(out/'Makefile').write_text(make);subprocess.run(['make','-C',str(out)],check=True)
 else:
  cmd=[os.environ.get('CC','gcc'),'-O1','-g','-std=gnu11','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(out),str(out/'main.c'),str(out/'generated.c'),'-lm','-o',str(out/'check')];subprocess.run(cmd,check=True);subprocess.run([str(out/'check')],check=True)
 print(f'PASS generated {len(names)} cases in four compiler modes')
if __name__=='__main__':main()
