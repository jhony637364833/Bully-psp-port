# Material-state GPU regression test

Build with PSPDEV configured and pspdev/bin on PATH:

```
make -C tests/psp_state_smoke
```

Run that directory's EBOOT.PBP in PPSSPP. This is a synthetic diagnostic,
not the game EBOOT. Sample the panel centers at20%,50%,80% of screen width:

| Emulated time | Left | Center | Right |
|---|---|---|---|
| 0–3s | blue (0,0,255) | (128,0,127) | green (0,255,0) |
| 3–6s | blue | red (255,0,0) | green |
| 6–8s | cyan (0,255,255) | (128,127,127) | green |
| 8–10s | cyan | white (255,255,255) | green |

The right panel draws a green surface behind an alpha-failed foreground,
confirming FB_ONLY does not write depth. The middle panel exercises opaque
texture fast paths, then actual compressed material/vertex alpha, then the
original GS additive equation(Cs-0)*FIX128/128+Cd. The final phase must retain
the cyan destination and ignore the half vertex alpha for its fixed blend.

Wall time may be longer than emulated time. This task verified all phases in
PPSSPP1.20.4/OpenGL with exact pixel assertions.

The current diagnostic advances virtual time between objects and sends a wrong-camera
end followed by a valid and duplicate end. All four phases were observed after the
camera-boundary repair; neither virtual ticks nor duplicate ends may split a scene.

Current diagnostic calls bully_world_overlay_present after camera completion,
matching the guest flip hook. The phase times above are nominal at60iterations/s;
software rendering can take substantially longer. Current verification observes
the expected pixel phases rather than assuming wall-clock phase boundaries.
