#include <pspkernel.h>
#include <pspdisplay.h>
#include <string.h>
#include "native_object.h"
#include "native_skin.h"
#include "native_texture.h"
#include "native_state.h"
PSP_MODULE_INFO("Bully state test",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER | THREAD_ATTR_VFPU);
int hle_ge_on;uint8_t *hle_ram;uint32_t hle_ram_end;uint64_t hle_frame;
void bully_world_enable(void);
void bully_world_camera_begin(uint32_t);
void bully_world_camera_end(uint32_t);
void bully_world_overlay_present(void);
void bully_world_draw(uint32_t,uint32_t);
static unsigned panel, phase;
void bully_world_begin(void);
void bully_world_capture_state(uint32_t,uint32_t);
void bully_world_capture_light(uint32_t,uint32_t);
int bully_native_state(const uint8_t *r,size_t b,uint32_t p,uint32_t gp,BullyNativeState *s) {
 memset(s,0,sizeof(*s));s->stream=0x500;s->material=0x2f4;s->test=panel==1?0x5064d:0x5140b;s->alpha=phase>=480 && panel==2?0x68:0x44;s->alpha_fixed=128;s->blend=1;s->zmask=(phase>=180 && panel==3);return 1;
}
int bully_native_object(const uint8_t *r,size_t b,uint32_t o,uint32_t c,BullyNativeVertex *s,BullyNativeObject *out) {
 (void)r;(void)b;(void)o;(void)c;(void)s;memset(out,0,sizeof(*out));
 for(int k=0;k<3;k++)out->view[k][k]=1;
 out->near_plane=1;out->far_plane=100;out->meshes=1;
 out->mesh[0].stream=0x500;out->mesh[0].compressed=1;out->mesh[0].material=0x2f4;return 1;
}
int bully_native_texture(const uint8_t *r,size_t b,uint32_t m,void *dst,size_t cap,BullyNativeTexture *out) {
 (void)r;(void)b;(void)m;if(cap<4096)return 0;memset(out,0,sizeof(*out));
 out->texture.alpha_class=(panel>0 && panel<4 && !(panel==2 && phase>=180))?TC_ALPHA_BLEND:TC_ALPHA_OPAQUE;
 out->texture.psm=3;out->texture.total_bytes=4096;
 out->texture.level[0].width=out->texture.level[0].height=out->texture.level[0].bufw=32;
 out->filter=2;out->wrap_u=out->wrap_v=3;
 for(int y=0;y<32;y++)for(int x=0;x<32;x++)((uint32_t*)dst)[y*32+x]=panel==0?(phase>=360?0xffffff00u:0xffff0000u):panel==4?0xff00ff00u:panel==3?0x400000ffu:(panel==2 && phase>=180)?0xff0000ffu:0x800000ffu;
 return 1;
}
int bully_compressed_chain(const uint8_t *r,size_t b,uint32_t a,BullyNativeVertex *s,BullyNativeVisit visit,void *ctx,size_t *n,size_t *used) {
 (void)r;(void)b;(void)a;memset(s,0,194*sizeof(*s));
 /* 192 triangles cross the 128-triangle submission boundary. */
 for(int i=0;i<194;i++) {
  float t=(i/2)/96.0f;
  float z=panel==0?2:panel==4?1.5f:1;
  s[i].position[0]=(panel==0?(.05f+.9f*t):(((panel==4?3:panel)-1)*.3f+(.05f+.3f*t)))*z;
  s[i].position[1]=(i%2?.8f:.2f)*z;s[i].position[2]=z;
  s[i].uv[0]=t;s[i].uv[1]=i%2;
  memset(s[i].color,128,4);
  memset(s[i].color_secondary,128,4);
  if(phase>=360 && panel==2)s[i].color[3]=0;
 }
 *n=194;*used=0;if(visit)visit(s,194,ctx);return 1;
}
int bully_native_decode(const uint8_t *r,size_t b,BullyNativeVertex *v,size_t cap,size_t *n) {return 0;}
int bully_skin_chain(const uint8_t *r,size_t b,uint32_t a,uint32_t p,unsigned bones,BullyNativeVertex *s,BullySkinVisit f,void *ctx,size_t *n,size_t *used,size_t *tris) {return 0;}
static uint8_t ram_fixture[0x700000];
static void put(unsigned at,unsigned value){memcpy(ram_fixture+at,&value,4);}
int main(void) {
 hle_ram=ram_fixture;hle_ram_end=sizeof ram_fixture;
 put(0x100+48,0x200);put(0x100+60,0x300);put(0x200,0x400);put(0x400+32,0x500);put(0x500,0x10000001);
 put(0x6d5278,0x01000404);put(0x6d527c,0x6c0203d0);put(0x6d528c,2);
 for(unsigned k=0;k<3;k++)put(0x6d5280+4*k,0x40000000); /* gain 2 => original neutral128 becomes255 */
 memset(ram_fixture+0x100+68,255,4);put(0x300,0x3f800000);

 bully_world_enable();
 for(phase=0;phase<600;phase++) {bully_world_camera_begin(1);for(panel=0;panel<5;panel++){bully_world_begin();if(panel && panel<4)bully_world_capture_state(1,1);if(phase>=360)bully_world_capture_light(0x100,0x8000);bully_world_draw(1,1);hle_frame++;}bully_world_camera_end(2);bully_world_camera_end(1);bully_world_camera_end(1);/* Match the guest flip hook after completing the camera. */bully_world_overlay_present();sceDisplayWaitVblankStart();}
 sceKernelExitGame();return 0;
}

#include "../texture_cache_unavailable.inc"

/* These fixtures synthesize expanded vertices rather than packed DMA data.
 * Keep using their original visitor; the raw bridge has its own differential
 * tests in prepare_raw_mesh.py. */
int bully_compressed_chain_raw(const uint8_t*r,size_t b,uint32_t a,
    BullyNativeVertex*s,BullyNativeVisit visit,BullyNativeRawVisit raw,
    void*ctx,size_t*n,size_t*used) {
    (void)raw;return bully_compressed_chain(r,b,a,s,visit,ctx,n,used);
}

void bully_overlay_flush(void){}
void bully_overlay_underlay_flush(void){}
int bully_native_object_cached(const uint8_t*r,size_t b,uint32_t o,uint32_t c,BullyNativeVertex*s,BullyNativeObject*out,BullyNativeSkinCache*cache){(void)cache;return bully_native_object(r,b,o,c,s,out);}
int bully_native_skin_replay(const BullyNativeSkinCache*c,unsigned mesh,BullySkinVisit visit,void*ctx){(void)c;(void)mesh;(void)visit;(void)ctx;return 0;}

int bully_native_state_shadow(const uint8_t*r,size_t b,uint32_t gp,BullyNativeState*s){(void)r;(void)b;(void)gp;(void)s;return 0;}
