void NORMALIZER(R5900Ctx *c)
{
    int32_t r2 = (int32_t)c->r[2].d[0], r4 = (int32_t)c->r[4].d[0];
    uint32_t f0 = c->fpr[0].u, f1 = c->fpr[1].u, f2 = c->fpr[2].u, f3 = c->fpr[3].u, f4 = c->fpr[4].u;
    uint32_t acc_ = c->acc.u;
    const R5900Mem m_ = {c->ram, c->ram_mask};
    f2 = f_in5(rmb_lw(m_, (uint32_t)((uint64_t)(int64_t)r4), 0));
    f3 = f_in5(rmb_lw(m_, (uint32_t)((uint64_t)(int64_t)r4), 4));
    f4 = f_in5(rmb_lw(m_, (uint32_t)((uint64_t)(int64_t)r4), 8));
    acc_ = f2u(u2f(f2) * u2f(f2));
    acc_ = f2u(u2f(acc_) + (u2f(f3) * u2f(f3)));
    f1 = f2u(u2f(acc_) + (u2f(f4) * u2f(f4)));
    r2 = (int32_t)(SX32(0x3f800000u));
    f0 = f_in5((uint32_t)((uint64_t)(int64_t)r2));
    
    f0 = fpu_rsqrt5(f0, f1);
    f1 = f_in5(rmb_lw(m_, (uint32_t)((uint64_t)(int64_t)r4), 0));
    f1 = f2u(u2f(f1) * u2f(f0));
    rmb_sw(m_, (uint32_t)((uint64_t)(int64_t)r4), 0, f1);
    f1 = f_in5(rmb_lw(m_, (uint32_t)((uint64_t)(int64_t)r4), 4));
    f1 = f2u(u2f(f1) * u2f(f0));
    rmb_sw(m_, (uint32_t)((uint64_t)(int64_t)r4), 4, f1);
    f1 = f_in5(rmb_lw(m_, (uint32_t)((uint64_t)(int64_t)r4), 8));
    f1 = f2u(u2f(f1) * u2f(f0));
    rmb_sw(m_, (uint32_t)((uint64_t)(int64_t)r4), 8, f1); c->r[2].d[0] = (uint64_t)(int64_t)r2; c->fpr[0].u = f0; c->fpr[1].u = f1; return;
}
