"""Reproduce whole-object validation and skin batch replay checks against build24."""
from pathlib import Path
import argparse

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
 p.add_argument('--output',type=Path,required=True)
 a=p.parse_args();here=Path(__file__).parent;d=a.output;d.mkdir(parents=True,exist_ok=True)
 src=a.app/'games/SLUS-21269_v1.02/src'
 for name in ['reference','candidate']:
  sub=d/name;sub.mkdir(exist_ok=True)
  for filename in ['native_object.c','native_object.h','native_skin.c','native_skin.h','native_mesh.c','native_mesh.h']:
   source=here/('skin_replay_object_'+('header_' if filename.endswith('.h') else '')+'reference.inc') if name=='reference' and filename.startswith('native_object.') else src/filename
   (sub/filename).write_bytes(source.read_bytes())
  text='#define bully_native_object '+name+'_object\n'
  if name=='candidate':text+='#define bully_native_object_cached candidate_cached\n#define bully_native_skin_replay candidate_replay\n'
  (d/(name+'.c')).write_text(text+'#include "'+name+'/native_object.c"\n')
 for source,dest in [('skin_replay_main.c','main.c'),('skin_replay_builder.inc','builder.inc'),('skin_replay_Makefile.inc','Makefile')]:(d/dest).write_bytes((here/source).read_bytes())
 renderer=(src/'psp/world_display.c').read_text();start=renderer.index('static void allocate_skin_cache(');end=renderer.index('\n}',start)+2
 (d/'allocation-test.c').write_text((here/'skin_replay_allocation_template.inc').read_text().replace('@ALLOCATE_BODY@',renderer[start:end]))
 print('Expected COMPLETE cases=932 ... errors=0 size=136212; allocation-test: five paths PASS.')

if __name__=='__main__':main()
