from pathlib import Path
import argparse,shutil
r=Path(__file__).resolve().parents[1];t=r/'tests';g=r/'app/games/SLUS-21269_v1.02/src'
a=argparse.ArgumentParser();a.add_argument('output',type=Path);args=a.parse_args()
for kind in ['copied','view']:
 p=args.output.resolve()/kind;p.mkdir(parents=True,exist_ok=True)
 for src,name in [(g/'native_texture.c','candidate.c'),(g/'native_texture.h','native_texture.h'),(t/'native_texture_reference_70.inc','reference.c'),(t/('native_texture_cache_'+kind+'.inc'),'main.c')]:shutil.copy2(src,p/name)
 (p/'Makefile').write_text((t/'native_texture_cache_Makefile.inc').read_text().replace('@SOURCE@',str(g)))
