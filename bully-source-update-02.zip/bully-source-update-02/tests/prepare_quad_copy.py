"""Prepare preservation checks from a matching converted game build; no game bodies bundled."""
from pathlib import Path
import argparse,re,json
D=re.compile(r'^void (fn_[0-9a-f]{8})\(R5900Ctx \*c\)\n\{\n(.*?)^\}',re.M|re.S)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--build',type=Path,required=True);p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app');p.add_argument('--output',type=Path,required=True);a=p.parse_args();t=Path(__file__).parent
 target='fn_0037eeb0';callees=['fn_00129480','fn_001294e0','fn_0012c010','fn_001313d0'];fs={}
 for path in sorted((a.build/'gen').glob('*.c')):
  for m in D.finditer(path.read_text()):
   if m[1] in {target,*callees}:
    if m[1] in fs:raise ValueError('duplicate '+m[1])
    fs[m[1]]=m[2]
 if set(fs)!={target,*callees}:raise ValueError('missing generated bodies')
 if sorted(set(re.findall(r'\b(fn_[0-9a-f]{8})\(c\)',fs[target])))!=callees:raise ValueError('changed call graph')
 if 'RC_BACKEDGE' in fs[target] or 'rc_dispatch' in fs[target]:raise ValueError('changed scheduler')
 if any(re.search(r'\bfn_[0-9a-f]{8}\(c\)|RC_BACKEDGE|rc_dispatch',fs[n]) for n in callees):raise ValueError('callee no longer leaf')
 patches=json.loads((t/'quad_copy_patches.json').read_text())
 # Candidate skips share the same spelling: normalize each complete six-line
 # region, never a global replacement of identical no-op lines.
 for kind,num in [('lq',2),('sq',4)]:
  group=[q for q in patches if 'rm_'+kind+'(' in q['old']]
  old='\n'.join(q['old'] for q in group);new='\n'.join(q['new'] for q in group)
  if fs[target].count(new)==1 and old not in fs[target]:fs[target]=fs[target].replace(new,old)
  elif fs[target].count(old)!=1:raise ValueError('unexpected quad region '+kind)
 candidate=fs[target]
 for q in patches:
  if candidate.count(q['old'])!=1:raise ValueError('changed quad line')
  candidate=candidate.replace(q['old'],q['new'])
 d=a.output;d.mkdir(parents=True,exist_ok=True)
 app=(a.app/'runtime/r5900_rt.h').read_text();start=app.index('/* Sequential raw quad transfers for the geometry bridge.');end=app.index('/* ------------------------------------------------------------------ integer helpers */',start)
 (d/'baseline.h').write_text(app[:start]+app[end:]);(d/'candidate_host.h').write_text(app);(d/'candidate_psp.h').write_bytes((a.build/'hle/rt/r5900_rt.h').read_bytes())
 (d/'r5900_rt.h').write_text('#ifdef __PSP__\n#include "candidate_psp.h"\n#else\n#include "candidate_host.h"\n#endif\n')
 head='#define R5900_CS_VFPU 1\n#include "r5900_rt.h"\n'+''.join('void '+n+'(R5900Ctx*);\n' for n in callees)
 (d/'leaves.c').write_text('#include "r5900_rt.h"\n'+''.join('void '+n+'(R5900Ctx *c)\n{\n'+fs[n]+'}\n' for n in callees))
 for label,body in [('reference',fs[target]),('candidate',candidate)]:
  (d/(label+'.c')).write_text(head+'void '+label+'(R5900Ctx *c)\n{\n'+body+'}\n')
 (d/'candidate.c').open('a').write('\nint rt_cs_vfpu_enabled;\nvoid candidate_enable(int enabled){rt_cs_vfpu_enabled=enabled;}\nvoid candidate_load(R5900Mem m,uint32_t a,R5900Reg128*d){rm_lq2(m,a,d);}\nvoid candidate_store(R5900Mem m,uint32_t a,const R5900Reg128*s){rm_sq4(m,a,s);}\n')
 for src,dst in [('quad_copy_main.c','main.c'),('quad_copy_Makefile.inc','Makefile'),('quad_copy_vfpu_load.h','vfpu_load.h'),('quad_copy_vfpu_store.h','vfpu_store.h')]: (d/dst).write_bytes((t/src).read_bytes())
 print('Expected COMPLETE function=8000 direct=15463 wraps=6231 aliases=2722 errors=0')
if __name__=='__main__':main()
