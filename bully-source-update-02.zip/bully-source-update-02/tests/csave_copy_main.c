#include "candidate/r5900_rt.h"
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully aligned state copies",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
PSP_HEAP_SIZE_KB(512);
#endif
_Static_assert(sizeof(R5900Reg128)==16 && _Alignof(R5900Reg128)>=16,"GPR alignment");
_Static_assert(_Alignof(R5900Ctx)>=16 && _Alignof(R5900CSave)>=16,"context/save alignment");
_Static_assert(offsetof(R5900Ctx,r)%16==0 && offsetof(R5900CSave,r)%16==0,"GPR offsets");
_Static_assert(sizeof(((R5900Ctx*)0)->fpr[0])==4,"contiguous FPR unions");
_Static_assert(offsetof(R5900Ctx,fpr)%4==0 && offsetof(R5900CSave,f)%4==0,"FPR offsets");
_Static_assert(sizeof(R5900CSave)==192,"complete preserved state");
extern void reference_save(const R5900Ctx*,R5900CSave*);
extern void candidate_save(const R5900Ctx*,R5900CSave*);
extern void reference_restore(R5900Ctx*,const R5900CSave*);
extern void candidate_restore(R5900Ctx*,const R5900CSave*);
extern void reference_roundtrip(R5900Ctx*);
extern void candidate_roundtrip(R5900Ctx*);
static unsigned char ca[sizeof(R5900Ctx)+256] __attribute__((aligned(16)));
static unsigned char cb[sizeof(ca)] __attribute__((aligned(16)));
static unsigned char original[sizeof(ca)] __attribute__((aligned(16)));
static unsigned char expected[sizeof(ca)] __attribute__((aligned(16)));
static unsigned char sa[sizeof(R5900CSave)+256] __attribute__((aligned(16)));
static unsigned char sb[sizeof(sa)] __attribute__((aligned(16)));
static unsigned char save_expected[sizeof(sa)] __attribute__((aligned(16)));
static uint32_t seed=0x23a77f29;
static uint32_t rnd(void){seed=seed*1664525u+1013904223u;return seed;}
static void bytes(void*p,size_t n,unsigned pattern){unsigned char*d=p;for(size_t i=0;i<n;i++)d[i]=pattern==0?0:pattern==1?255:pattern==2?(unsigned char)(1u<<(i%8)):(unsigned char)(rnd()>>24);}
// Different values in every context byte test preservation of untouched fields.
void perturb(R5900Ctx*c){unsigned char*p=(unsigned char*)c;for(size_t i=0;i<sizeof(*c);i++)p[i]^=(unsigned char)(i*37u+1);}
static void oracle_save(const R5900Ctx*c,R5900CSave*s){for(unsigned i=0;i<8;i++)memcpy(&s->r[i],&c->r[16+i],16);memcpy(&s->r[8],&c->r[30],16);for(unsigned i=0;i<12;i++)s->f[i]=c->fpr[20+i].u;}
static void oracle_restore(R5900Ctx*c,const R5900CSave*s){for(unsigned i=0;i<8;i++)memcpy(&c->r[16+i],&s->r[i],16);memcpy(&c->r[30],&s->r[8],16);for(unsigned i=0;i<12;i++)c->fpr[20+i].u=s->f[i];}
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);FILE*f=fopen("copy-test.log","w");
#else
 FILE*f=stdout;
#endif
 if(!f)return 2;
 unsigned total=0;
 for(unsigned pattern=0;pattern<4;pattern++)for(unsigned k=0;k<10000;k++){
  size_t co=64+16*(k%4),so=64+16*((k/4)%4);
  R5900Ctx*a=(void*)(ca+co),*b=(void*)(cb+co),*o=(void*)(original+co),*x=(void*)(expected+co);
  R5900CSave*s=(void*)(sa+so),*t=(void*)(sb+so),*u=(void*)(save_expected+so);
  bytes(ca,sizeof(ca),pattern);memcpy(cb,ca,sizeof(ca));memcpy(original,ca,sizeof(ca));
  bytes(sa,sizeof(sa),3);memcpy(sb,sa,sizeof(sa));memcpy(save_expected,sa,sizeof(sa));
  oracle_save(o,u);reference_save(a,s);candidate_save(b,t);
  if(memcmp(sa,save_expected,sizeof(sa))||memcmp(sb,save_expected,sizeof(sb))||memcmp(ca,original,sizeof(ca))||memcmp(cb,original,sizeof(cb)))goto fail;
  perturb(a);perturb(b);memcpy(expected,ca,sizeof(ca));oracle_restore(x,u);
  reference_restore(a,s);candidate_restore(b,t);
  if(memcmp(ca,expected,sizeof(ca))||memcmp(cb,expected,sizeof(cb))||memcmp(sa,save_expected,sizeof(sa))||memcmp(sb,save_expected,sizeof(sb)))goto fail;
  // Real stack-allocated save objects also cross an opaque callee boundary.
  memcpy(ca,original,sizeof(ca));memcpy(cb,original,sizeof(cb));reference_roundtrip(a);candidate_roundtrip(b);
  if(memcmp(ca,expected,sizeof(ca))||memcmp(cb,expected,sizeof(cb)))goto fail;
  total++;
  if(k==9999){fprintf(f,"pattern=%u comparisons=%u errors=0\n",pattern,total);fflush(f);}
  continue;
  fail:fprintf(f,"ERROR pattern=%u case=%u co=%u so=%u\n",pattern,k,(unsigned)co,(unsigned)so);fflush(f);
#ifdef __PSP__
  fclose(f);sceKernelExitGame();
#endif
  return 1;
 }
 fprintf(f,"COMPLETE comparisons=%u errors=0\n",total);fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
}
