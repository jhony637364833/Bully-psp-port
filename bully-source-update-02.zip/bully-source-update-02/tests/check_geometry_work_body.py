"""Require the compiler specialization to retain the prepared body exactly."""
import sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
name='void fn_0012a5c0__ynguest(' if 'void fn_0012a5c0__ynguest(' in s else 'void fn_0012a5c0('
start=s.index(name);end=s.index('\nvoid fn_',start+1)
expected=s[start:end].replace(name,'void y_nat_0012a5c0(',1)
p=Path(__file__).resolve().parents[1]/'app/games/SLUS-21269_v1.02/src/geometry_work_fast.c'
actual=p.read_text();actual=actual[actual.index('void y_nat_0012a5c0('):]
assert actual==expected
assert actual.count('RC_BACKEDGE_AT')==5
print('Geometry-work compiler specialization matches original body and five safe points')
