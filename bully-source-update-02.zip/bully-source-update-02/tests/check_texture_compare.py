from pathlib import Path
import tempfile,shutil,subprocess,argparse
r=Path(__file__).resolve().parents[1];g=r/'app/games/SLUS-21269_v1.02/src'
p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args()
with tempfile.TemporaryDirectory(prefix='bully-texture-compare-') as temp:
 d=a.output.resolve() if a.output else Path(temp);d.mkdir(parents=True,exist_ok=True)
 shutil.copy2(g/'native_texture.c',d/'candidate-native_texture.c')
 shutil.copy2(r/'tests/texture_compare_main.inc',d/'main.c')
 subprocess.run(['cc','-O2','-fsanitize=address,undefined','-I'+str(g),str(d/'main.c'),str(g/'texconv.c'),'-lm','-o',str(d/'check')],check=True)
 subprocess.run([str(d/'check')],check=True)
