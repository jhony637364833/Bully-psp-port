#include <stdint.h>
#ifdef __PSP__
static __attribute__((noinline)) uint32_t clip_fpu_read(void) {
    uint32_t x;__asm__ volatile("cfc1 %0,$31":"=r"(x)::"memory");return x;
}
static __attribute__((noinline)) void clip_fpu_write(uint32_t x) {
    __asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(x):"memory");
}
#else
#include <fenv.h>
/* Host adapter: preserve rounding and exception flags. PSP fixtures also
 * compare the hardware's comparison-condition and cause bits. */
static uint32_t clip_fpu_read(void) {
    return ((uint32_t)fegetround()<<16)|(unsigned)fetestexcept(FE_ALL_EXCEPT);
}
static void clip_fpu_write(uint32_t x) {
    fesetround((int)(x>>16));feclearexcept(FE_ALL_EXCEPT);
    feraiseexcept((int)(x&0xffff));
}
#endif
