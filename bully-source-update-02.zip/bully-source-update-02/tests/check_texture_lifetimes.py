from pathlib import Path
import subprocess,json
import argparse,tempfile
r=Path(__file__).resolve().parents[1];t=r/'tests';g=r/'app/games/SLUS-21269_v1.02/src'
a=argparse.ArgumentParser();a.add_argument('--output',type=Path);a.add_argument('--sdk-include',type=Path);args=a.parse_args()
scratch=tempfile.TemporaryDirectory(prefix='bully-texture-lifetimes-');p=args.output.resolve() if args.output else Path(scratch.name);p.mkdir(parents=True,exist_ok=True)
sdk=args.sdk_include or Path(subprocess.check_output(['psp-config','--pspsdk-path'],text=True).strip())/'include'
(p/'hle.h').write_bytes((t/'psp_state_smoke/hle.h').read_bytes());(p/'native_texture.h').write_bytes((g/'native_texture.h').read_bytes())
head=(t/'world_submission_host.inc').read_text();head=head.replace('SceSize sceKernelTotalFreeMemSize(void){return 0;}', '''static unsigned fake_active,fake_allocs,fake_frees,borrowed;
static unsigned char fake_cache[1536*1024] __attribute__((aligned(16)));
SceSize sceKernelTotalFreeMemSize(void){
#ifdef CACHE_DENIED
return 0;
#else
return 8*1024*1024;
#endif
}''').replace('SceSize sceKernelMaxFreeMemSize(void){return 0;}','SceSize sceKernelMaxFreeMemSize(void){return sceKernelTotalFreeMemSize();}')
head=head.replace('(void)a;(void)b;(void)c;(void)d;(void)e;return -1;', '''(void)a;(void)c;(void)e;if(strcmp(b,"world_tex"))return -1;assert(!fake_active && d==sizeof(fake_cache));fake_active=1;fake_allocs++;return 11;''')
head=head.replace('void*sceKernelGetBlockHeadAddr(SceUID a){(void)a;return 0;}', 'void*sceKernelGetBlockHeadAddr(SceUID a){assert(a==11 && fake_active);return fake_cache;}')
head=head.replace('int sceKernelFreePartitionMemory(SceUID a){(void)a;return 0;}', 'int sceKernelFreePartitionMemory(SceUID a){assert(a==11 && fake_active && !read_count && !host_open);memset(fake_cache,0xd3,32768);fake_active=0;fake_frees++;return 0;}')
fixture=(t/'world_submission_fixture.inc').read_text()
extra='''
size_t bully_native_texture_cache_bytes(void){return sizeof(fake_cache);}
void bully_native_texture_cache_init(BullyNativeTextureCache *c){assert((void*)c==fake_cache && fake_active);memset(fake_cache,0,32768);}
int bully_native_texture_view(const uint8_t*r,size_t bytes,uint32_t material,void*dst,size_t cap,BullyNativeTexture*out,BullyNativeTextureCache*c,const void**view){
 assert(!read_count); /* No eviction is allowed while GU reads an old entry. */
 int ok=bully_native_texture(r,bytes,material,dst,cap,out);if(!ok)return ok;
 if(!c){*view=dst;return 1;}
 assert(fake_active && (void*)c==fake_cache);memset(fake_cache,0x93,32768);
 uint8_t *pixels=fake_cache+8192*(borrowed++%3);memcpy(pixels,dst,out->texture.total_bytes);
 memset(dst,0xa7,cap); /* A renderer using its old scratch pointer now fails. */
 *view=pixels;return 1;
}
'''
fixture=extra+fixture
fixture=fixture.replace('bully_world_shutdown();puts("COMPLETE errors=0");', '''bully_world_shutdown();assert(!fake_active && fake_allocs==fake_frees);
#if defined(CANDIDATE) && !defined(CACHE_DENIED)
 assert(fake_allocs>=64 && borrowed>100);
#endif
puts("COMPLETE errors=0");''')
results={}
for mode in ['available','denied']:
 for name in ['reference','candidate']:
  body=((g/'psp/world_display.c') if name=='candidate' else (t/'texture_renderer_reference_70.inc')).read_text()
  start=body.index('static __attribute__((noinline)) uint32_t clip_fpu_read');end=body.index('static void allocate_clip_memo',start);body=body[:start]+(t/'renderer_fpu_test.inc').read_text()+body[end:]
  f=p/(mode+'-'+name+'.c');f.write_text(head+body+fixture);exe=f.with_suffix('')
  cmd=['cc','-O2','-Wall','-Wno-int-to-pointer-cast','-fno-fast-math','-ffp-contract=off','-fsanitize=address,undefined','-I'+str(p),'-I'+str(g),'-I'+str(sdk),str(f),str(g/'world_clip.c'),'-lm','-o',str(exe)]
  if name=='candidate':cmd.insert(1,'-DCANDIDATE')
  if mode=='denied':cmd.insert(1,'-DCACHE_DENIED')
  subprocess.run(cmd,check=True);result=subprocess.check_output([str(exe)],text=True);(p/(mode+'-'+name+'.log')).write_text(result);results[mode,name]=result
 normalize=lambda s:[' '.join(line.split()[:3]) for line in s.splitlines()]
 assert normalize(results[mode,'reference'])==normalize(results[mode,'candidate']),mode
print('PASS 512 available + 512 denied complete-renderer cases: exact ordered commands/vertices/texture bytes, poisoned scratch, rotating borrowed pointers, eviction only after reads, release after sync, allocation/free balance, ASan/UBSan')
