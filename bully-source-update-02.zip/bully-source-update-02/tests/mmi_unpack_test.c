#include "r5900_rt.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully packed bounds test",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
#define RANDOM_CASES 50000
#else
#define RANDOM_CASES 2000000
#endif
static inline R5900Reg128 reference_unpack(R5900Reg128 s,R5900Reg128 t) {
    R5900Reg128 r;
    for(unsigned i=0;i<8;i++){r.b[2*i]=t.b[i];r.b[2*i+1]=s.b[i];}
    return r;
}
static uint32_t seed=0x1327bc05;
static uint32_t random_word(void){seed=seed*1664525u+1013904223u;return seed;}
static unsigned checks;
static void compare(R5900Reg128 s,R5900Reg128 t) {
    R5900Reg128 a=reference_unpack(s,t),b=mmi_pextlb(s,t);
    checks++;if(memcmp(&a,&b,sizeof(a))){puts("packed interleave mismatch");exit(1);}
    R5900Reg128 zero={{0,0}};
    a=reference_unpack(zero,reference_unpack(zero,t));
    b=mmi_pextlb(zero,mmi_pextlb(zero,t));
    checks++;if(memcmp(&a,&b,sizeof(a))){puts("packed bound expansion mismatch");exit(1);}
    for(unsigned i=0;i<4;i++)if(b.w[i]!=t.b[i]){puts("byte expansion ISA mismatch");exit(1);}
}
#ifdef __PSP__
/* Match two generated expansions: old code reads the stored guest zero,
 * new code exposes the ISA constant. Outputs feed a checksum each time. */
__attribute__((noinline)) static R5900Reg128 old_bounds(R5900Ctx *c, R5900Reg128 t) {
    return reference_unpack(c->r[0],reference_unpack(c->r[0],t));
}
__attribute__((noinline)) static R5900Reg128 new_bounds(R5900Ctx *c, R5900Reg128 t) {
    (void)c; R5900Reg128 z={{0,0}};
    return mmi_pextlb(z,mmi_pextlb(z,t));
}
static void benchmark(void) {
    R5900Ctx c;memset(&c,0,sizeof c);
    uint32_t sums[2]={0,0}, elapsed[2];
    for(unsigned pass=0;pass<2;pass++) {
        unsigned start=sceKernelGetSystemTimeLow();
        uint32_t x=0x2741589;
        for(unsigned i=0;i<200000;i++) {
            x=x*1664525u+1013904223u;
            R5900Reg128 t={{x,0}},o;
            o=pass?new_bounds(&c,t):old_bounds(&c,t);
            sums[pass]+=o.w[0]+o.w[1]*3+o.w[2]*5+o.w[3]*7;
        }
        elapsed[pass]=sceKernelGetSystemTimeLow()-start;
    }
    printf("bounds benchmark: old=%u us new=%u us checksum=%08x/%08x\n",elapsed[0],elapsed[1],sums[0],sums[1]);
    if(sums[0]!=sums[1])exit(1);
}
#endif
int main(void) {
#ifdef __PSP__
    if(!freopen("mmi-unpack.log","w",stdout))return 2;
#endif
    /* Independent byte-lane oracle; exercise every pair of source bytes in
     * every source position, including all one-hot and sign-bit patterns. */
    for(unsigned x=0;x<256;x++)for(unsigned y=0;y<256;y++) {
        R5900Reg128 s,t;memset(&s,x,sizeof s);memset(&t,y,sizeof t);compare(s,t);
    }
    for(unsigned i=0;i<RANDOM_CASES;i++) {
        R5900Reg128 s,t;
        for(unsigned k=0;k<4;k++){s.w[k]=random_word();t.w[k]=random_word();}
        compare(s,t);
    }
    printf("packed bounds comparisons=%u errors=0\n",checks);
#ifdef __PSP__
    benchmark();fflush(stdout);sceKernelExitGame();
#endif
    return 0;
}
