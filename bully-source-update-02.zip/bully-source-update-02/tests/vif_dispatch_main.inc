#include "native_vif.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("VIF dispatch",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
#endif
void baseline_init(BullyVif*,BullyGif*);
int baseline_feed(BullyVif*,const void*,size_t,uint32_t);
static BullyVif *active;
static unsigned fail_after,calls,mutate;
int bully_gif_feed(BullyGif*g,const void*p,size_t n,uint32_t addr){
 const unsigned char*s=p;calls++;g->tags++;g->bitblt=(g->bitblt^addr)*1099511628211ull;
 for(size_t k=0;k<n;k++)g->bitblt=(g->bitblt^s[k])*1099511628211ull;
 if(mutate){active->cl=1+calls%8;active->wl=9+calls%8;g->upload_ok^=1;}
 return !fail_after||calls!=fail_after;
}
static unsigned seed=321,cases;
static unsigned rnd(void){seed=1664525u*seed+1013904223u;return seed;}
static void compare(BullyVif *a,BullyVif*b,BullyGif*ga,BullyGif*gb,const void*p,size_t n,uint32_t addr){
 active=a;calls=0;int ar=baseline_feed(a,p,n,addr);unsigned ac=calls;
 active=b;calls=0;int br=bully_vif_feed(b,p,n,addr);
 BullyVif aa=*a,bb=*b;aa.gif=bb.gif=0;
 if(ar!=br||ac!=calls||memcmp(&aa,&bb,sizeof aa)||memcmp(ga,gb,sizeof *ga)){printf("ERROR case=%u rc=%d/%d callbacks=%u/%u\n",cases,ar,br,ac,calls);fflush(stdout);assert(0);}
 cases++;
}
int main(void){
#ifdef __PSP__
 freopen("vif.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
#endif
 uint8_t raw[260],before[260];BullyVif a,b;BullyGif ga,gb;
 for(unsigned cmd=0;cmd<256;cmd++)for(unsigned num=0;num<256;num++)for(unsigned cycle=0;cycle<4;cycle++){
  memset(&ga,0,sizeof ga);gb=ga;baseline_init(&a,&ga);bully_vif_init(&b,&gb);
  a.cl=b.cl=cycle==0?1:cycle==1?4:cycle==2?256:1;
  a.wl=b.wl=cycle==0?1:cycle==1?1:cycle==2?1:256;
  a.commands=b.commands=UINT64_MAX-1;
  uint32_t word=cmd<<24|num<<16|(rnd()&65535);memcpy(raw+(num&3),&word,4);
  compare(&a,&b,&ga,&gb,raw+(num&3),4,0x100000);
 }
 printf("all256commandbytes/256counts/4cycles pass\n");
 for(unsigned test=0;test<50000;test++){
  for(unsigned i=0;i<sizeof raw;i++)raw[i]=(uint8_t)rnd();
  memcpy(before,raw,sizeof raw);
  memset(&ga,0,sizeof ga);ga.upload_ok=1;gb=ga;baseline_init(&a,&ga);bully_vif_init(&b,&gb);
  a.cl=b.cl=1+rnd()%256;a.wl=b.wl=1+rnd()%256;
  if(test%3==0)a.skip=b.skip=4*(rnd()%32);
  if(test%3==1){a.direct=b.direct=16*(rnd()%16);a.used=b.used=4*(rnd()%4);a.quad_linear=b.quad_linear=test&1;a.quad_addr=b.quad_addr=0x100000;}
  fail_after=test%5;mutate=test%2;
  for(unsigned offset=0;offset<256;offset+=16){uint32_t addr=test%7==0?UINT32_MAX-8:test%7==1?0x100000+offset*2:0x100000+offset;compare(&a,&b,&ga,&gb,raw+(test%4)+offset,16,addr);}
  compare(&a,&b,&ga,&gb,0,0,0);compare(&a,&b,&ga,&gb,0,4,0);compare(&a,&b,&ga,&gb,raw,3,0);
  assert(!memcmp(raw,before,sizeof raw));
 }
 printf("COMPLETE cases=%u full_parser/GIF/callback/input/state exact errors=0\n",cases);fflush(stdout);
#ifdef __PSP__
 fclose(stdout);sceKernelExitGame();
#endif
 return 0;
}
