"""Compare the production screen clamp with its original expression.

Default: run ASan/UBSan host checks. --psp-dir DIR: emit an asset-free PSP
harness; build with make -C DIR, then launch EBOOT.PBP in PPSSPP and inspect
clamp-test.log for COMPLETE errors=0.
"""
from pathlib import Path
import argparse, os, subprocess, tempfile
repo=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--psp-dir',type=Path)
args=p.parse_args()
source=(repo/'app/games/SLUS-21269_v1.02/src/psp/world_display.c').read_text()
start=source.index('static inline float screen_clamp(')
end=source.index('\n}',start)+2
helper=source[start:end]+'\n'
head=(repo/'tests/screen_clamp_head.inc').read_text()
main=(repo/'tests/screen_clamp_main.inc').read_text()
def emit(directory):
 directory.mkdir(parents=True,exist_ok=True)
 (directory/'clamp-test.c').write_text(head+helper+main)
if args.psp_dir:
 directory=args.psp_dir.resolve();emit(directory)
 (directory/'Makefile').write_text(""".DEFAULT_GOAL := all
TARGET = clamp_test
OBJS = clamp-test.o
CFLAGS = -O2 -G0 -Wall -fno-fast-math -frounding-math -ffp-contract=off
BUILD_PRX = 1
LIBS = -lm
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully screen clamp check
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
""")
 print('Generated PSP harness:',directory)
else:
 with tempfile.TemporaryDirectory(prefix='bully-clamp-') as temp:
  directory=Path(temp);emit(directory)
  subprocess.run([os.environ.get('CC','cc'),'-O2','-fno-fast-math','-frounding-math','-ffp-contract=off','-fsanitize=address,undefined',str(directory/'clamp-test.c'),'-lm','-o',str(directory/'host-test')],check=True)
  subprocess.run([str(directory/'host-test')],check=True)
