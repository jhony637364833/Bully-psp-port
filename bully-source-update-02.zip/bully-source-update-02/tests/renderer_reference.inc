/* Frozen triangle/strip implementation before FPS optimization. */
static unsigned channel(float f) { return f<=0?0:f>=255?255:(unsigned)f; }
static void triangle(const BullyNativeVertex *a,const BullyNativeVertex *b,const BullyNativeVertex *c) {
    const BullyNativeVertex *src[3]={a,b,c};
    BullyClipVertex in[3],out[10];
    for(int i=0;i<3;i++) for(int k=0;k<3;k++) {
        float p=object_view.view[3][k];
        for(int j=0;j<3;j++)p+=src[i]->position[j]*object_view.view[j][k];
        in[i].p[k]=p;in[i].color[k]=src[i]->color[k]*2.0f;
    }
    if(material_light)for(int i=0;i<3;i++)
        bully_light_color(src[i],material_light,in[i].color);
    for(int i=0;i<3;i++)for(int k=0;k<2;k++)in[i].uv[k]=src[i]->uv[k];
    int n=bully_clip_triangle(in,object_view.near_plane,object_view.far_plane,out);
    if(!n)return;
    GeVertex clipped[24];
    int count=0;
    for(int i=1;i<n-1;i++) {
        int ix[3]={0,i,i+1};
        GeVertex projected[3];
        for(int j=0;j<3;j++) {
            BullyClipVertex *v=&out[ix[j]];
            projected[j].u=v->uv[0];
            projected[j].v=v->uv[1];
            if(!isfinite(projected[j].u) || !isfinite(projected[j].v))return;
            projected[j].x=fminf(480,fmaxf(0,480*v->p[0]/v->p[2]));
            projected[j].y=fminf(272,fmaxf(0,272*v->p[1]/v->p[2]));
            projected[j].z=65535*(object_view.far_plane/(object_view.far_plane-object_view.near_plane))*(1-object_view.near_plane/v->p[2]);
            projected[j].z=fminf(65535,fmaxf(0,projected[j].z));
            projected[j].color=0xff000000|channel(v->color[0])|(channel(v->color[1])<<8)|(channel(v->color[2])<<16);
        }
        float area=(projected[1].x-projected[0].x)*(projected[2].y-projected[0].y)-(projected[2].x-projected[0].x)*(projected[1].y-projected[0].y);
        if(fabsf(area)<0.001f)continue;
        for(int j=0;j<3;j++) {
            /* Area rejection uses projected pixels; submitted positions retain
             * camera depth so GE computes the reciprocal-W interpolation. */
            projected[j].x=out[ix[j]].p[0];
            projected[j].y=out[ix[j]].p[1];
            projected[j].z=out[ix[j]].p[2];
            clipped[count++]=projected[j];
        }
    }
    if(!count)return;
    if(queued+(unsigned)count>WORLD_BATCH_VERTICES)flush_vertices();
    for(int i=0;i<count;i++)verts[queued++]=clipped[i];
    triangles+=count/3;
}
static void draw_batch(const BullyNativeVertex *v,size_t n,void *context) {
    (void)context;
    for(size_t i=2;i<n;i++)triangle(&v[i-2],&v[i-1],&v[i]);
}
static void draw_skin_batch(const BullyNativeVertex *v,const uint8_t *skip,size_t n,void *context) {
    (void)context;
    for(size_t i=2;i<n;i++)if(!skip[i])triangle(&v[i-2],&v[i-1],&v[i]);
}
