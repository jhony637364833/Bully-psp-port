#include "world_clip.h"
#include "clip_memo.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully classified math",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
static unsigned getstate(void){unsigned x;__asm__ volatile("cfc1 %0,$31":"=r"(x));return x;}
static void setstate(unsigned x){__asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(x):"memory");}
#else
#include <fenv.h>
static unsigned getstate(void){return (unsigned)fetestexcept(FE_ALL_EXCEPT);}
static void setstate(unsigned x){int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(modes[x&3]);feclearexcept(FE_ALL_EXCEPT);}
#endif
int ref_bully_clip_triangle_memoized(const BullyClipVertex[3],float,float,BullyClipVertex[10],BullyClipCache *,BullyClipMemo *);
static unsigned seed=343239;
static unsigned next(void){seed=seed*1664525u+1013904223u;return seed;}
static float scalar(unsigned x){float y;memcpy(&y,&x,4);return y;}
int main(void){
#ifdef __PSP__
 freopen("classified-math.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
#endif
 unsigned total=0;
 for(unsigned mode=0;mode<4;mode++)for(unsigned fs=0;fs<2;fs++)for(unsigned t=0;t<4096;t++){
  BullyClipVertex input[3],before[3],expected[10],out[10];int codes[3];
  float near=1,far=100;
  setstate(0);
  if(t%17==0)near=scalar(next());if(t%23==0)far=scalar(next());
  for(unsigned i=0;i<3;i++)for(unsigned k=0;k<9;k++){
   unsigned bits=next();float v=t&1?scalar(bits):(float)(bits%16384)/128-8;
   memcpy((unsigned char *)&input[i]+k*4,&v,4);
  }
  memcpy(before,input,sizeof input);
  for(unsigned i=0;i<3;i++)codes[i]=bully_clip_vertex_code(&input[i],near,far);
  unsigned state=mode|(fs?1u<<24:0)|((t&2)?0x80007cu:0);
  for(unsigned cached=0;cached<2;cached++){
   BullyClipCache a,b;bully_clip_cache_reset(&a);bully_clip_cache_reset(&b);
   for(unsigned repeat=0;repeat<2;repeat++){
    memset(expected,0xa5,sizeof expected);memset(out,0xa5,sizeof out);
    setstate(state);int n=ref_bully_clip_triangle_memoized(input,near,far,expected,cached?&a:0,0);unsigned r=getstate();
    setstate(state);int m=bully_clip_triangle_classified(input,near,far,codes,out,cached?&b:0,0);unsigned c=getstate();
    if(n!=m || memcmp(expected,out,sizeof out) || r!=c || memcmp(before,input,sizeof input)){
     printf("ERROR mode=%u fs=%u case=%u cache=%u repeat=%u n=%d/%d fpu=%08x/%08x\n",mode,fs,t,cached,repeat,n,m,r,c);return 1;
    }
    total++;
   }
  }
 }
 puts("COMPLETE cases=32768 comparisons=131072 classified_planes/codes/tails/input/cache/FCR31=exact modes=4 FS_modes=2 errors=0");
#ifdef __PSP__
 sceKernelExitGame();
#endif
 return total==131072?0:1;
}
