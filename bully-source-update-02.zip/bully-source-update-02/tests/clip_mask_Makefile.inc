TARGET = bully_clip_mask_test
OBJS = main.o reference.o candidate.o
INCDIR = .
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -Werror -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fno-strict-aliasing
BUILD_PRX = 1
LIBS = -lm -lpsppower
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully exact branchless order
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
