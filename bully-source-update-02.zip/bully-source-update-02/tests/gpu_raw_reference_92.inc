static int baseline_gpu_strip_bounds(const BullyNativeVertex *v,size_t n) {
    _Static_assert(_Alignof(BullyNativeVertex)>=4 && offsetof(BullyNativeVertex,color)==20 && offsetof(BullyNativeVertex,color_secondary)==24,"aligned vertex input fields");
    float lo[3],hi[3],clo[3]={0},chi[3]={0},error[3];
    float lo0=v[0].position[0],hi0=lo0;
    float lo1=v[0].position[1],hi1=lo1;
    float lo2=v[0].position[2],hi2=lo2;
    for(size_t i=0;i<n;i++) {
        uint32_t bits0;memcpy(&bits0,__builtin_assume_aligned(&v[i].position[0],4),sizeof(bits0));
        if((bits0&0x7f800000u)==0x7f800000u)return 0;
        float x0=v[i].position[0];
        if(x0<lo0)lo0=x0;
        if(x0>hi0)hi0=x0;
        uint32_t bits1;memcpy(&bits1,__builtin_assume_aligned(&v[i].position[1],4),sizeof(bits1));
        if((bits1&0x7f800000u)==0x7f800000u)return 0;
        float x1=v[i].position[1];
        if(x1<lo1)lo1=x1;
        if(x1>hi1)hi1=x1;
        uint32_t bits2;memcpy(&bits2,__builtin_assume_aligned(&v[i].position[2],4),sizeof(bits2));
        if((bits2&0x7f800000u)==0x7f800000u)return 0;
        float x2=v[i].position[2];
        if(x2<lo2)lo2=x2;
        if(x2>hi2)hi2=x2;
    }
    lo[0]=lo0;hi[0]=hi0;
    lo[1]=lo1;hi[1]=hi1;
    lo[2]=lo2;hi[2]=hi2;
    if(!isfinite(object_view.near_plane) || !isfinite(object_view.far_plane) ||
       object_view.near_plane<=0 || object_view.far_plane<=object_view.near_plane)return 0;
    for(unsigned k=0;k<3;k++) {
        float magnitude=fabsf(object_view.view[3][k]);
        for(unsigned j=0;j<3;j++) {
            float extent=fabsf(lo[j])>fabsf(hi[j])?fabsf(lo[j]):fabsf(hi[j]);
            magnitude+=extent*fabsf(object_view.view[j][k]);
        }
        error[k]=(magnitude+1.0f)*0.0001f;
        if(!isfinite(error[k]))return 0;
    }
    float center[3],extent[3];
    for(unsigned j=0;j<3;j++) {
        center[j]=lo[j]*0.5f+hi[j]*0.5f;
        extent[j]=hi[j]*0.5f-lo[j]*0.5f;
    }
    for(unsigned k=0;k<3;k++) {
        float c=object_view.view[3][k],e=0;
        for(unsigned j=0;j<3;j++) {
            c+=center[j]*object_view.view[j][k];
            e+=extent[j]*fabsf(object_view.view[j][k]);
        }
        clo[k]=c-e;chi[k]=c+e;
        if(!isfinite(clo[k]) || !isfinite(chi[k]))return 0;
    }
    if(chi[2]<object_view.near_plane-error[2] || clo[2]>object_view.far_plane+error[2] ||
       chi[0]<-error[0] || chi[1]<-error[1] ||
       clo[0]>chi[2]+error[0]+error[2] || clo[1]>chi[2]+error[1]+error[2])return -1;
    if(clo[2]>object_view.near_plane+error[2] && chi[2]<object_view.far_plane-error[2] &&
       object_view.near_plane>=0.0001f && object_view.far_plane<=65536.0f &&
       clo[0]>-clo[2]+error[0]+error[2] && clo[1]>-clo[2]+error[1]+error[2] &&
       chi[0]<2*clo[2]-error[0]-2*error[2] && chi[1]<2*clo[2]-error[1]-2*error[2])return 1;
    return 0;
}
static inline int baseline_gpu_same_position(const BullyNativeVertex *a,const BullyNativeVertex *b) {
    for(unsigned k=0;k<3;k++) {
        uint32_t x,y;memcpy(&x,__builtin_assume_aligned(&a->position[k],4),4);memcpy(&y,__builtin_assume_aligned(&b->position[k],4),4);
        if(x!=y)return 0;
    }
    return 1;
}
/* On the GPU path FP traps are disabled and entry FCR is restored at exit.
 * Lighting consumes only these two color banks and the immutable material.
 * Reuse the already packed result without extra FCR reads or cache storage. */
static inline int baseline_gpu_same_colors(const BullyNativeVertex *a,const BullyNativeVertex *b) {
    uint32_t a0,a1,b0,b1;
    memcpy(&a0,__builtin_assume_aligned(a->color,4),4);memcpy(&b0,__builtin_assume_aligned(b->color,4),4);
    memcpy(&a1,__builtin_assume_aligned(a->color_secondary,4),4);memcpy(&b1,__builtin_assume_aligned(b->color_secondary,4),4);
    return a0==b0 && a1==b1;
}
/* Mask only secondary RGB when the zero-blend shader does not consume it. */
static inline int baseline_gpu_same_masked_colors(const BullyNativeVertex *a,const BullyNativeVertex *b,uint32_t mask) {
    uint32_t x0,y0,x1,y1;
    memcpy(&x0,__builtin_assume_aligned(a->color,4),4);memcpy(&y0,__builtin_assume_aligned(b->color,4),4);
    memcpy(&x1,__builtin_assume_aligned(a->color_secondary,4),4);memcpy(&y1,__builtin_assume_aligned(b->color_secondary,4),4);
    return x0==y0 && !((x1^y1)&mask);
}
static int baseline_draw_gpu_strip(const BullyNativeVertex *v,const uint8_t *skip,size_t n) {
    if(n<12 || n>256)return 0;
    uint32_t saved=clip_fpu_read();if(saved&0x00020f80u)return 0;
    int bounds=baseline_gpu_strip_bounds(v,n);
    if(bounds<=0){clip_fpu_write(saved);return bounds<0;}
    GeVertex prepared[256];
    int primary_only=material_light && material_light->blend==0.0f;
    uint32_t secondary_mask=primary_only?0xff000000u:~0u;
    for(size_t i=0;i<n;i++) {
        uint32_t uv0,uv1;
        memcpy(&uv0,__builtin_assume_aligned(&v[i].uv[0],4),4);
        memcpy(&uv1,__builtin_assume_aligned(&v[i].uv[1],4),4);
        if((uv0&0x7f800000u)==0x7f800000u || (uv1&0x7f800000u)==0x7f800000u){clip_fpu_write(saved);return 0;}
        unsigned color=0xff000000u;
        if(material_light && i && baseline_gpu_same_masked_colors(&v[i-1],&v[i],secondary_mask)) {
            color=prepared[i-1].color;
        } else if(material_light) {
            float rgb[3],alpha;
            if(primary_only) {
                for(unsigned k=0;k<3;k++) {
                    float a=v[i].color[material_light->monochrome?0:k];
                    if(material_light->monochrome)a+=12;
                    float lit=a*material_light->gain[k];
                    rgb[k]=(lit<255.0f?lit:255.0f)*material_light->material[k]*2.0f;
                }
            } else bully_light_color(&v[i],material_light,rgb);
            alpha=bully_light_alpha(&v[i],material_light);
            if(!isfinite(alpha) || !isfinite(rgb[0]) || !isfinite(rgb[1]) || !isfinite(rgb[2])){clip_fpu_write(saved);return 0;}
            color=(channel(alpha)<<24)|channel(rgb[0])|(channel(rgb[1])<<8)|(channel(rgb[2])<<16);
        } else {
            /* Exact integer form of the default byte*2 then channel clamp. */
            for(unsigned k=0;k<3;k++){unsigned x=(unsigned)v[i].color[k]*2;if(x>255)x=255;color|=x<<(k*8);}
        }
        prepared[i]=(GeVertex){v[i].uv[0],v[i].uv[1],color,v[i].position[0],v[i].position[1],v[i].position[2]};
    }
    int selected=0;
    for(size_t i=2;i<n;i++) {
        if(skip && skip[i])continue;
        if(baseline_gpu_same_position(&v[i-2],&v[i-1]) || baseline_gpu_same_position(&v[i-1],&v[i]) || baseline_gpu_same_position(&v[i-2],&v[i]))continue;
        if(!selected){if(!gpu_vertex_space){flush_vertices();gpu_vertex_space=1;}selected=1;}
        if(queued+3>WORLD_BATCH_VERTICES)flush_vertices();
        verts[queued++]=prepared[i-2];verts[queued++]=prepared[i-1];verts[queued++]=prepared[i];triangles++;
    }
    clip_fpu_write(saved);return 1;
}


