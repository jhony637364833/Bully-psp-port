"""Differential GS capture and sky material bounds, synthetic RAM only."""
from pathlib import Path
import argparse,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args()
r=Path(__file__).resolve().parents[1];t=r/'tests';g=r/'app/games/SLUS-21269_v1.02/src'
scratch=tempfile.TemporaryDirectory(prefix='bully-float-sky-');b=a.output.resolve() if a.output else Path(scratch.name);b.mkdir(parents=True,exist_ok=True)
s=(g/'psp/world_display.c').read_text();body=s[s.index('static BullyNativeState float_sky_state;'):s.index('static const int alpha_functions')]
(b/'float-state-host.c').write_text((t/'float_sky_head.inc').read_text()+body+(t/'float_sky_main.inc').read_text())
subprocess.run(['gcc','-O2','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-I'+str(g),str(b/'float-state-host.c'),str(g/'native_state.c'),'-o',str(b/'float-state-host')],check=True)
subprocess.run([str(b/'float-state-host')],check=True)
