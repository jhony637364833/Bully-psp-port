#include "native_object.h"
#include "native_light.h"
#include "world_clip.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully strip rotate check",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
static unsigned getcsr(void){unsigned x;__asm__ volatile("cfc1 %0,$31":"=r"(x));return x;}
static void setcsr(unsigned x){__asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(x));}
#else
#include <fenv.h>
static unsigned getcsr(void){return fetestexcept(FE_ALL_EXCEPT);}
static void setcsr(unsigned x){int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(modes[x&3]);feclearexcept(FE_ALL_EXCEPT);}
#endif
typedef struct {float u,v;unsigned color;float x,y,z;} GeVertex;
#define WORLD_BATCH_VERTICES 384
static GeVertex verts[384],record[30000],expected[30000];
static unsigned queued,triangles,recorded,flushes;
static BullyNativeObject object_view;
static const BullyNativeLight *material_light;
static void flush_vertices(void){assert(recorded+queued<30000);memcpy(record+recorded,verts,queued*sizeof(*verts));recorded+=queued;queued=0;flushes++;}
