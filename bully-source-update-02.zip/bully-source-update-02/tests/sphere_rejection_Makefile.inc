.DEFAULT_GOAL := all
TARGET = bully_sphere_flags
OBJS = main.o baseline.o candidate.o
INCDIR = .
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -Wno-unused-variable -Wno-unused-label -Wno-unused-but-set-variable -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fstrict-aliasing
BUILD_PRX = 1
LIBS = -lm -lpsppower
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully sphere flags
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
