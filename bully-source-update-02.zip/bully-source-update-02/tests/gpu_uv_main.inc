static uint32_t seed=1767;static uint32_t rnd(void){seed=seed*1664525u+1013904223u;return seed;}
static void mode_set(unsigned mode,unsigned test){
#ifdef __PSP__
 uint32_t x=(test&1?0x01000000u:0)|mode|(test&2?0x00800000u:0);
 if(test%19==0)x|=0x80; /* enabled trap must bypass all GPU work */
 clip_fpu_write(x);
#else
 int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(modes[mode]);feclearexcept(FE_ALL_EXCEPT);if(test&2)feraiseexcept(FE_INEXACT);
#endif
}
int main(void){
#ifdef __PSP__
 freopen("gpu-light.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
#endif
 static BullyNativeVertex v[256],before[256];static GeVertex expected[1024];uint8_t skip[256];unsigned successes=0,bypasses=0;
 for(unsigned mode=0;mode<4;mode++)for(unsigned test=0;test<2048;test++){
  mode_set(0,4);unsigned n=12+rnd()%245;BullyNativeLight light={0};memset(&object_view,0,sizeof object_view);
  for(unsigned k=0;k<3;k++){object_view.view[k][k]=1;light.gain[k]=(rnd()%1024)/512.0f;light.material[k]=(rnd()%256)/512.0f;}
  object_view.near_plane=1;object_view.far_plane=100;light.blend=(rnd()%512)/256.0f;light.material_alpha=(rnd()%256)/512.0f;light.monochrome=test%3==0;
  if(test%11==0){uint32_t bits[]={0,0x80000000u,1,0x7f7fffffu,0x7f800000u,0xff800000u,0x7fc12345u,0x7f800001u};uint32_t x=bits[(test/11)%8];memcpy(&light.material[(test/11)%3],&x,4);}
  memset(v,0,sizeof v);
  for(unsigned i=0;i<n;i++){
   v[i].position[0]=.5f+i*.01f;v[i].position[1]=.2f+(i%2);v[i].position[2]=20;
   v[i].uv[0]=i*.01f;v[i].uv[1]=i%2;for(unsigned k=0;k<4;k++){v[i].color[k]=rnd()>>24;v[i].color_secondary[k]=rnd()>>24;}
   if(i && (test%4==0 || (test%4==1 && i%3) || (test%4==2 && i%2))){memcpy(v[i].color,v[i-1].color,4);memcpy(v[i].color_secondary,v[i-1].color_secondary,4);}
   v[i].normal[0]=(int8_t)i;skip[i]=test%5==0 || (test%5==1 && i%3==0);
  }
  if(test%13==0){uint32_t bits[]={0,0x80000000u,1,0x80000001u,0x7f7fffffu,0x7f800000u,0xff800000u,0x7fc12345u,0x7f800001u};uint32_t x=bits[(test/13)%9];memcpy(&v[n/2].uv[(test/13)%2],&x,4);}
  if(test%17==0)v[n/2].position[2]=.5f;
  if(test%23==0)for(unsigned i=0;i<n;i++)v[i].position[0]=-200;
  if(test%29==0)for(unsigned i=0;i<n;i++)v[i].position[0]-=10;
  if(test%31==0){uint32_t bits[]={0,0x80000000u,1,0x80000001u,0x7f7fffffu,0x7f800000u,0xff800000u,0x7fc12345u,0x7f800001u};uint32_t x=bits[(test/31)%9];memcpy(&v[n/2].position[test%3],&x,4);}
  memcpy(before,v,sizeof v);material_light=test%7?&light:0;
  int ret[2],space[2];uint32_t fcr[2];unsigned counts[2],tris[2],fs[2];
  for(unsigned side=0;side<2;side++){
   queued=test%2?3:0;memset(verts,0,sizeof verts);captured_count=triangles=flushes=0;gpu_vertex_space=test%2;
   mode_set(mode,test);
   ret[side]=side?candidate_draw_gpu_strip(v,test%3?skip:0,n):baseline_draw_gpu_strip(v,test%3?skip:0,n);
   fcr[side]=clip_fpu_read();space[side]=gpu_vertex_space;flush_vertices();counts[side]=captured_count;tris[side]=triangles;fs[side]=flushes;
   if(!side)memcpy(expected,captured,captured_count*sizeof(*captured));
   else if(ret[0]!=ret[1] || fcr[0]!=fcr[1] || space[0]!=space[1] || counts[0]!=counts[1] || tris[0]!=tris[1] || fs[0]!=fs[1] || memcmp(expected,captured,counts[0]*sizeof(*captured)) || memcmp(before,v,sizeof v)){
    printf("ERROR mode=%u test=%u return=%d/%d FCR=%08x/%08x counts=%u/%u\n",mode,test,ret[0],ret[1],fcr[0],fcr[1],counts[0],counts[1]);return 1;
   }
  }
  successes+=ret[1]!=0;bypasses+=ret[1]==0;
 }
 assert(reuse_hits>100 && successes>100 && bypasses>100);printf("COMPLETE cases=8192 reuse_hits=%u success=%u fallback=%u errors=0\n",reuse_hits,successes,bypasses);
#ifdef __PSP__
 sceKernelExitGame();
#endif
 return 0;
}
