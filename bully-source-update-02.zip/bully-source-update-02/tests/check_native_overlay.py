"""Portable native GIF/VIF/geometry tests. Only synthetic game data is used."""
from pathlib import Path
import argparse, struct, subprocess, tempfile

p = argparse.ArgumentParser()
p.add_argument('--app', type=Path, default=Path(__file__).resolve().parents[1] / 'app')
p.add_argument('--output', type=Path)
a = p.parse_args()
b = a.output or Path(tempfile.mkdtemp(prefix='bully-overlay-'))
b.mkdir(parents=True, exist_ok=True)
src = a.app.resolve() / 'games/SLUS-21269_v1.02/src'
fixture = Path(__file__).resolve().parent
flags = ['gcc', '-O2', '-Wall', '-Wextra', '-Werror', '-Wno-misleading-indentation',
         '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-I', str(src)]
common = [str(src / n) for n in ('native_gif.c', 'native_vif.c', 'overlay_geometry.c')]
for name in ('replay', 'fuzz'):
    subprocess.run(flags + common + [str(fixture / ('native_overlay_' + name + '.c')), '-o', str(b / name)], check=True)
subprocess.run([str(b / 'fuzz')], check=True)

def tag(n, mode=0):
    return struct.pack('<QQ', n | (1 << 60) | (mode << 58), 14 if mode == 0 else 0)

def ad(r, v):
    return struct.pack('<QQ', v, r)

writes = [(0x18, 0x720000006c00), (6, 1)]
expected = []
xy = [(0, 0, 0, 0), (640, 0, 32, 0), (0, 448, 0, 32), (640, 448, 32, 32)]
for repeat in range(82):
    writes.append((0, 0x15c))
    for x, y, u, v in xy:
        writes += [(3, u * 16 | v * 16 << 16), (1, 0x80808080),
                   (5, (x * 16 + 0x6c00) | (y * 16 + 0x7200) << 16)]
    for ids in ((0, 1, 2), (1, 2, 3)):
        expected.append('D 15c 1 3' + ''.join(f' {x} {y} {u} {v} 80808080' for x, y, u, v in (xy[i] for i in ids)))
writes += [(6, 2), (0, 0x4e), (1, 0x20000000), (3, 0), (5, 0x8e006c00), (5, 0x72009400)]
expected.append('D 4e 2 2 0 448 0 0 20000000 640 0 0 0 20000000')
gif = tag(len(writes)) + b''.join(ad(r, v) for r, v in writes)
checks = 0
for mode, data, chunks in [(0, gif, [16, 32, 48, 112, 4096, len(gif)]),
                           (1, bytes(12) + struct.pack('<I', 0x50000000 | len(gif) // 16) + gif, [4, 8, 12, 16, 28, 112, 4096])]:
    path = b / f'synthetic-{mode}.bin'
    path.write_bytes(data)
    for chunk in chunks:
        q = subprocess.run([str(b / 'replay'), str(path), str(mode), str(chunk), '0x100000'], capture_output=True, text=True)
        assert q.returncode == 0, q.stderr
        assert q.stdout.splitlines() == expected
        assert q.stderr.strip() == 'batches=3', q.stderr
        checks += 1
# Contiguous native transfer callback must identify the original header and
# ignore image payload bytes, even when those bytes resemble register words.
payload = bytes(range(256)) * 32
upload = tag(1) + ad(0x50, 0x123400000000) + tag(3) + ad(0x51, 0) + ad(0x52, 64 | 64 << 32) + ad(0x53, 0) + tag(len(payload) // 16, 2) + payload
path = b / 'upload.bin'
path.write_bytes(upload)
for chunk in [16, 32, 48, 112, 4096, len(upload)]:
    q = subprocess.run([str(b / 'replay'), str(path), '0', str(chunk), '0x100000'], capture_output=True, text=True)
    assert q.returncode == 0, q.stderr
    assert q.stdout.strip() == 'U 123400000000 100020 8272', q.stdout
    checks += 1
print(f'PASS {checks} synthetic ordered geometry/upload replays; 166 triangles in 3 batches; 50000 bounded fuzz cases')

# Compile the actual PSP DMA walker without PSP APIs, retaining its exact body.
mmio = (src / 'hle_mmio.c').read_text()
start = mmio.index('static int native_overlay_feed(')
end = mmio.index('\n#endif', start)
dma = (fixture / 'native_overlay_dma.inc').read_text().replace('/* ACTUAL_NATIVE_DMA */', mmio[start:end])
(b / 'dma.c').write_text(dma)
subprocess.run(flags + [str(b / 'dma.c'), '-o', str(b / 'dma')], check=True)
subprocess.run([str(b / 'dma')], check=True)
