#include "audio_stretch.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned simulate(int mode) {
    int16_t memory[16384*2],input[256*2],converted[257*2],out[AS_HOP*2];
    AsRing ring;AsResampler resampler={0};AudioStretch sync;
    as_ring_init(&ring,memory,16384);
    as_init(&sync,&ring,mode,4096,4u*AS_ONE);sync.smin=AS_ONE;
    unsigned sound=0;uint32_t sample=0;
    /* Game produces a 440 Hz stereo tone at half real time, in bursts.
     * The output must retain substantially more audible hops than raw gaps. */
    for(unsigned hop=0;hop<1800;hop++) {
        if(hop%8==0)for(int batch=0;batch<8;batch++) {
            for(unsigned i=0;i<256;i++) {
                int16_t v=(int16_t)(10000*sin(6.283185307179586*440*sample++/48000));
                input[2*i]=v;input[2*i+1]=-v;
            }
            uint32_t n=as_resample48(&resampler,input,256,converted);
            assert(n<=257);as_ring_write(&ring,converted,n);
        }
        int active=as_hop(&sync,out,AS_HOP);
        if(hop>=300 && active)sound++;
    }
    assert(ring.lost==0);
    return sound;
}
int main(void) {
    /* Resampler state must be independent of producer chunk sizes. */
    int16_t input[4800*2],a[4802*2],b[4802*2];
    for(unsigned i=0;i<4800*2;i++)input[i]=(int16_t)(i*13);
    AsResampler whole={0},chunked={0};
    unsigned na=as_resample48(&whole,input,4800,a),nb=0;
    for(unsigned i=0;i<4800;i+=64) {
        unsigned n=4800-i<64?4800-i:64;
        nb+=as_resample48(&chunked,input+i*2,n,b+nb*2);
    }
    assert(na==nb && na>=4409 && na<=4411);
    assert(!memcmp(a,b,na*4));
    unsigned gap=simulate(AS_GAP),stretch=simulate(AS_STRETCH);
    printf("Audible hops after warmup: direct gaps=%u, synchronized=%u / 1500\n",gap,stretch);
    assert(stretch>gap*3/2 && stretch>1350);
    puts("Audio synchronization checks passed");
    return 0;
}
