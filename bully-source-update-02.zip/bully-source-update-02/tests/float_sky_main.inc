int main(void){
 unsigned gp=0x8000;put(0x130,0x200);put(0x13c,0x500);put(0x200,0x300);put(0x320,0x600);put(0x600,0x10000001);
 uint32_t seed=0x432853;
 for(unsigned i=0;i<20000;i++){
  seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;
  put(gp-25152,i<2?(i?0x513fb:0x3140b):seed&0xfffff);
  put(gp-25112,i<2?0x68:seed%256);put(gp-25108,128);put(gp-25164,1);put(gp-25096,0x58);
  BullyNativeState old,shadow,unchanged;memset(&old,0xa5,sizeof old);shadow=old;unchanged=old;memcpy(saved,ram,sizeof ram);
  int a=bully_native_state(ram,sizeof ram,0x100,gp,&old),c=bully_native_state_shadow(ram,sizeof ram,gp,&shadow);assert(a==c);
  if(a){old.stream=old.material=0;assert(!memcmp(&old,&shadow,sizeof old));}else assert(!memcmp(&shadow,&unchanged,sizeof shadow));
  assert(!memcmp(ram,saved,sizeof ram));if(i<2){assert(c&&shadow.alpha==0x68&&shadow.alpha_fixed==128&&shadow.blend&&shadow.zmask);}
 }
 put(gp-25152,0x513fb);put(gp-25112,0x68);put(gp-25108,128);
 put(0x1000,0x2000);const char*names[]={"SKY_high","SKY_tile","SKY_bot","SKY_high2","sky_high","SKY_other",""};
 for(unsigned i=0;i<7;i++){memset(ram+0x2010,0,32);strcpy((char*)ram+0x2010,names[i]);assert(float_sky_material(0x1000)==(i<3));}
 assert(!float_sky_material(0));assert(!float_sky_material(0x1001));assert(!float_sky_material(sizeof ram));
 put(0x1000,sizeof ram-80);assert(!float_sky_material(0x1000));
 bully_world_capture_float_state(123,gp);assert(float_sky_object==123);
 put(gp-25164,0);bully_world_capture_float_state(456,gp);assert(!float_sky_object);
 put(gp-25164,1);bully_world_capture_float_state(123,gp);assert(float_sky_object==123);
 bully_world_capture_float_state(456,1);assert(!float_sky_object);
 BullyNativeState out,before;memset(&out,0xa5,sizeof out);before=out;
 assert(!bully_native_state_shadow(0,sizeof ram,gp,&out));assert(!memcmp(&out,&before,sizeof out));
 assert(!bully_native_state_shadow(ram,32,gp,&out));assert(!memcmp(&out,&before,sizeof out));
 assert(!bully_native_state_shadow(ram,sizeof ram,gp,0));
 puts("PASS 20000 old/new GS shadow cases exact; observed sky states, bounded material identity, stale-object reset, no RAM writes, unchanged output on failure");return 0;
}
