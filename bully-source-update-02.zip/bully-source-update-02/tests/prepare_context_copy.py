"""Prepare raw saved-context copy differential tests from the current runtime."""
from pathlib import Path
import argparse

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
 p.add_argument('--output',type=Path,required=True)
 a=p.parse_args();here=Path(__file__).parent;d=a.output;d.mkdir(parents=True,exist_ok=True)
 (d/'r5900_rt.h').write_bytes((a.app/'runtime/r5900_rt.h').read_bytes())
 for src,dst in [('context_copy_main.c','main.c'),('context_copy_candidate.c','candidate.c'),('context_copy_api.inc','candidate.h'),('context_copy_Makefile.inc','Makefile'),('context_copy_reference.inc','context_copy_reference.inc'),('context_copy_vfpu_load.h','context_copy_vfpu_load.h'),('context_copy_vfpu_store.h','context_copy_vfpu_store.h')]:
  (d/dst).write_bytes((here/src).read_bytes())
 print('Expected COMPLETE comparisons=16000 errors=0 (flag off/on; all four modes)')

if __name__=='__main__':main()
