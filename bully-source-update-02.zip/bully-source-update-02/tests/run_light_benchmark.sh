#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
benchmark_dir=$(mktemp -d)
trap 'rm -rf "$benchmark_dir"' EXIT
light_src=app/games/SLUS-21269_v1.02/src
${CC:-cc} -O2 -Wall -Wextra -Werror -frounding-math -ffp-contract=off \
  -I"$light_src" tests/light_benchmark.c tests/light_test106_reference.c \
  "$light_src/native_light.c" -o "$benchmark_dir/benchmark"
"$benchmark_dir/benchmark"
