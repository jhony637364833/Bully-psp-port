"""Check actual generated save-folder code with fault-injected dependencies.
Usage: python3 tests/check_save_folder.py --generated /path/to/build/gen
Requires GCC with ASan/UBSan; uses the runtime headers delivered in app/runtime.
"""
from pathlib import Path
import argparse
import os
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--generated', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    text = (args.generated / 'main_092.c').read_text()
    start = text.index('void fn_004359b0(')
    end = text.index('\nvoid ', start + 1)
    function = text[start:end]
    rules = root / 'app/games/SLUS-21269_v1.02/lists/normalizer-reuse.tsv'
    rules = [line.split('\t') for line in rules.read_text().splitlines()
             if line.startswith('fn_004359b0\t')]
    assert len(rules) == 1, 'Expected exactly one first-save setup repair'
    _, old, new = rules[0]
    if function.count(new) == 1:
        candidate = function
        baseline = function.replace(new, old)
    else:
        assert function.count(old) == 1, 'Unexpected guest function revision'
        baseline = function
        candidate = function.replace(old, new)
    with tempfile.TemporaryDirectory(prefix='bully-save-folder-') as work:
        work = Path(work)
        for name, body in [('base', baseline), ('candidate', candidate)]:
            (work / ('folder-' + name + '.inc')).write_text(body.replace(
                'void fn_004359b0(', 'void ' + ('baseline' if name == 'base' else name) + '_folder('))
        fixture = Path(__file__).with_name('save_folder_fixture.c')
        subprocess.run([os.environ.get('CC', 'gcc'), '-O1', '-g', '-std=gnu11',
                        '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
                        '-I', str(root / 'app/runtime'), '-I', str(work),
                        str(fixture), '-o', str(work / 'check')], check=True)
        subprocess.run([str(work / 'check')], check=True)


if __name__ == '__main__':
    main()
