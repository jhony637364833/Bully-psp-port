"""Host exact renderer/classified clipping comparisons; asset-free, GCC only."""
from pathlib import Path
import argparse,subprocess,tempfile,sys
repo=Path(__file__).resolve().parents[1];g=repo/'app/games/SLUS-21269_v1.02/src';t=repo/'tests'
a=argparse.ArgumentParser();a.add_argument('--output',type=Path);args=a.parse_args()
with tempfile.TemporaryDirectory(prefix='bully-classified-') as tmp:
 base=args.output.resolve() if args.output else Path(tmp);base.mkdir(parents=True,exist_ok=True)
 subprocess.run([sys.executable,str(t/'prepare_classified_clip.py'),str(base)],check=True)
 for kind in ['math','renderer']:
  p=base/kind
  cmd=['gcc','-O2','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-misleading-indentation','-fno-fast-math','-frounding-math','-ffp-contract=off','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(p),'-I'+str(g),str(p/'main.c'),str(p/'world_clip.c'),str(p/'reference.c')]
  if kind=='renderer':cmd.append(str(g/'native_light.c'))
  cmd+=['-lm','-o',str(p/'host-check')];subprocess.run(cmd,check=True);subprocess.run([str(p/'host-check')],check=True)
print('PASS classified math/renderer, exceptions/FCR31 and exact vertices/flushes against39')
