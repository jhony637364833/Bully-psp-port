#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bully_test_dir=$(mktemp -d)
trap 'rm -rf "$bully_test_dir"' EXIT
bully_src=app/games/SLUS-21269_v1.02/src
flags=(-std=c11 -Wall -Wextra -Werror -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -I"$bully_src")
${CC:-cc} "${flags[@]}" -Dbully_compressed_chain=reference_chain -Dbully_native_decode=reference_decode -c tests/native_mesh_reference.c -o "$bully_test_dir/reference.o"
${CC:-cc} "${flags[@]}" tests/compressed_validation_test.c "$bully_src/native_mesh.c" "$bully_test_dir/reference.o" -o "$bully_test_dir/test"
"$bully_test_dir/test"
