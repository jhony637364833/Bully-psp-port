#include "native_state.h"
#include "native_texture.h"
#include "native_texture_alpha.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
enum {GU_NEVER,GU_ALWAYS,GU_LESS,GU_LEQUAL,GU_EQUAL,GU_GEQUAL,GU_GREATER,GU_NOTEQUAL};
enum {GU_FALSE=0,GU_TRUE=1,GU_TRIANGLES=3,GU_TEXTURE_32BITF=4,GU_COLOR_8888=8,GU_VERTEX_32BITF=16,GU_TRANSFORM_3D=32};
typedef struct {float u,v;unsigned color;float x,y,z;} GeVertex;
static GeVertex verts[384];
static const BullyNativeState *material_state;
static BullyNativeTexture texture;
static int has_texture;
static unsigned queued,draw_calls,alpha_fn,alpha_ref,depth_mask;
typedef struct {unsigned kind,a,b,c;} Command;
static Command trace[2048];static unsigned commands;
static void record(unsigned k,unsigned a,unsigned b,unsigned c){assert(commands<2048);trace[commands++]=(Command){k,a,b,c};}
static void start(void){record(0,0,0,0);}
static void finish(void){record(1,0,0,0);}
static void sceKernelDcacheWritebackRange(const void*p,unsigned n){assert(p==verts);record(2,n,0,0);}
static void sceGuAlphaFunc(unsigned fn,unsigned ref,unsigned mask){assert(mask==255);alpha_fn=fn;alpha_ref=ref;record(3,fn,ref,mask);}
static void sceGuDepthMask(unsigned mask){depth_mask=mask;record(4,mask,0,0);}
static void sceGuDrawArray(unsigned primitive,unsigned type,unsigned n,const void*index,const void*p){
 assert(primitive==GU_TRIANGLES && type==60 && !index);unsigned first=(const GeVertex*)p-verts;assert(first+n<=384);record(5,first,n,(alpha_fn<<8)|(depth_mask<<16)|alpha_ref);
}

#define WORLD_TEXTURE_BYTES 65536
static unsigned texture_alpha_minimum,texture_alpha_minimum_valid;
static unsigned char texels[WORLD_TEXTURE_BYTES];

/* These isolated alpha fixtures use the owned texture buffer. */
static const unsigned char *material_texels=texels;
/* All fixture vertices are already in camera space. */
static void select_vertex_space(void){}
