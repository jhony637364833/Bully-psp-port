# CPU fallback helper fixture. Accelerated rendering is tested separately by the full GPU fixtures.
from pathlib import Path
import tempfile, subprocess, os
repo=Path(__file__).resolve().parents[1]
previous=(repo/'tests/shared_vertex_reference.inc').read_text()
clipped_previous=(repo/'tests/clipped_projection_reference.inc').read_text()
old=(repo/'tests/renderer_reference.inc').read_text();new=(repo/'app/games/SLUS-21269_v1.02/src/psp/world_display.c').read_text()
# Compile the actual triangle/strip bodies with a recorder replacing GU flushes.
head='''#include "native_object.h"
#include "native_light.h"
#include "world_clip.h"
#include "clip_memo.h"
/* This historical comparison checks the normal fallback. Persistent reuse is
 * separately covered by check_clip_memo.py and PSP FCR31 comparisons. */
static BullyClipMemo clip_memo;
static BullyClipMemoSet *clip_memo_storage;
static int clip_memo_enabled;
#include <math.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef struct { float u,v;unsigned color;float x,y,z; } GeVertex;
#define WORLD_BATCH_VERTICES 96
static GeVertex verts[96],record[30000];
static unsigned queued,triangles,recorded;
static BullyNativeObject object_view;
static const BullyNativeLight *material_light;
static void flush_vertices(void){assert(recorded+queued<30000);memcpy(record+recorded,verts,queued*sizeof(*verts));recorded+=queued;queued=0;}
'''
head+=(repo/'tests/renderer_fpu_test.inc').read_text()
main='''
static unsigned seed=1241;
static float randf(void){seed=seed*1664525u+1013904223u;return (seed>>8)*(1.0f/16777216);}
int main(void){
 BullyNativeVertex v[256];uint8_t skip[256];BullyNativeLight light={0};
 for(int k=0;k<3;k++){object_view.view[k][k]=1;light.gain[k]=.8f;light.material[k]=.5f;}
 /* Select the documented CPU fallback for side crossings. Normal cameras
  * intentionally use GE edge clipping (build42); check_gpu_guard.py covers
  * that route separately. Comparing its input vertices with old CPU-clipped
  * output is not a valid equivalence check. */
 object_view.near_plane=0.00001f;object_view.far_plane=100;light.blend=.35f;light.material_alpha=.5f;
 for(unsigned test=0;test<1000;test++){
  recorded=queued=triangles=0;material_light=test%2?&light:0;
  size_t n=test%257;
  for(size_t i=0;i<n;i++){
   memset(&v[i],0,sizeof(v[i]));v[i].color[3]=v[i].color_secondary[3]=128;
   for(int k=0;k<3;k++){v[i].position[k]=randf()*120-10;v[i].color[k]=randf()*255;v[i].color_secondary[k]=randf()*255;}
   if(test%4==0){v[i].position[2]=2+randf()*97;v[i].position[0]=randf()*v[i].position[2];v[i].position[1]=randf()*v[i].position[2];}
   if(test%17==0)v[i].position[0]=-200-randf()*10;
   if(test%19==0 && i==2)v[i].position[1]=NAN;
   for(int k=0;k<2;k++)v[i].uv[k]=randf()*2;
   skip[i]=(i%5==0);
  }
  if(test%3)draw_batch(v,n,0);else draw_skin_batch(v,skip,n,0);
  flush_vertices();fwrite(&recorded,sizeof(recorded),1,stdout);fwrite(record,sizeof(*record),recorded,stdout);
 }
 return 0;
}
'''
with tempfile.TemporaryDirectory(prefix="bully-render-test-") as tmp:
    tmp=Path(tmp)
    for name,src in [('before',old),('previous',previous),('clipped_previous',clipped_previous),('after',new)]:
        body=src[src.index('static unsigned channel'):]
        if 'void bully_world_draw' in body:body=body[:body.index('void bully_world_draw')].split('/* GPU strip dispatch.',1)[0]
        # The baseline predates the alpha field; explicitly retain its opaque contract.
        if name=='before':body=body.replace('int n=bully_clip_triangle', 'for(int j=0;j<3;j++)in[j].alpha=255; int n=bully_clip_triangle')
        source=tmp/(name+'.c');source.write_text(head+body+main)
        game=repo/'app/games/SLUS-21269_v1.02/src'
        subprocess.run([os.environ.get('CC','cc'),'-O2','-fsanitize=address,undefined','-I'+str(game),str(source),str(game/'native_light.c'),str(game/'world_clip.c'),'-lm','-o',str(tmp/name)],check=True)
        with (tmp/(name+'.bin')).open('wb') as output:
            subprocess.run([str(tmp/name)],stdout=output,check=True)
    a=(tmp/'before.bin').read_bytes();b=(tmp/'after.bin').read_bytes()
    assert a==b, 'Submitted GPU vertices changed'
    assert (tmp/'previous.bin').read_bytes()==b, 'Shared caching changed previous GPU output'
    assert (tmp/'clipped_previous.bin').read_bytes()==b, 'Clipped polygon projection changed GPU output'
    print(f'1000 strip cases PASS: {len(a)} identical output bytes')
