#include "clip_lerp.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully integer lerp test",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
#define RANDOM_CASES 20000
#define ADJACENT_CASES 8
#define BOUNDARY_CASES 8
#else
#define RANDOM_CASES 2000000
#define ADJACENT_CASES 512
#define BOUNDARY_CASES 1024
#endif
static uint32_t seed=0xc01dbeef;
static uint32_t random_word(void) { seed=seed*1664525u+1013904223u;return seed; }
static float scalar(uint32_t bits) {float f;memcpy(&f,&bits,4);return f;}
static uint32_t bits(float f) {uint32_t b;memcpy(&b,&f,4);return b;}
static unsigned checks;
static void check(float a,float b,double t) {
    BullyClipWeight w=bully_clip_weight(t);
    float expected=(float)((1-t)*a+t*b),actual=bully_clip_lerp(a,b,&w);
    if(bits(actual)!=bits(expected)) {
        printf("mismatch a=%08x b=%08x t=%a expected=%08x actual=%08x\n",
               bits(a),bits(b),t,bits(expected),bits(actual));exit(1);
    }
    checks++;
}
int main(void) {
#ifdef __PSP__
    if(!freopen("clip-lerp.log","w",stdout))return 2;
    /* Match the game thread's round-toward-zero / flush-to-zero FPU mode.
     * The reference double helpers still round binary32 in software. */
    __asm__ volatile("ctc1 %0, $31" :: "r"(0x01000001));
#endif
    /* Arbitrary finite endpoints, including opposite signs, subnormals,
     * all normal exponent ranges and samples outside the accelerated domain. */
    for(unsigned i=0;i<RANDOM_CASES;i++) {
        uint32_t a=random_word(),b=random_word();
        if((a&0x7f800000u)==0x7f800000u || (b&0x7f800000u)==0x7f800000u)continue;
        double t=(double)random_word()/4294967295.0;
        check(scalar(a),scalar(b),t);
        /* Nearby same-sign endpoints exercise the integer path at all scales. */
        b=(a&0xff800000u)|(b&0x7fffffu);
        check(scalar(a),scalar(b),t);
        if(i%8==0)check(scalar(a),scalar(a),t);
    }
    /* Exact/near half-ULP weights, exponent transitions, adjacent endpoints,
     * cancellation, zero signs and weights near 0 and 1. */
    const double weights[]={0,1,.5,.25,.75,0x1p-1074,0x1p-33,0x1p-32,
        0x1.fffffffffffffp-1,0x1.0000000000001p-1,0x1.fffffffffffffp-2,
        -0.25,1.25};
    const uint32_t special[]={0,0x80000000,1,0x80000001,0x007fffff,
        0x00800000,0x00800001,0x01000000,0x3f000000,0x3f7fffff,
        0x3f800000,0x3f800001,0x40000000,0x7f7fffff,0xff7fffff};
    for(unsigned i=0;i<sizeof(special)/sizeof(*special);i++)
        for(unsigned j=0;j<sizeof(special)/sizeof(*special);j++)
            for(unsigned k=0;k<sizeof(weights)/sizeof(*weights);k++)
                check(scalar(special[i]),scalar(special[j]),weights[k]);
    for(unsigned e=1;e<255;e++)for(unsigned sign=0;sign<2;sign++) {
        for(unsigned i=0;i<ADJACENT_CASES;i++) {
            uint32_t a=(sign<<31)|(e<<23)|(random_word()&0x7fffffu);
            for(unsigned k=0;k<sizeof(weights)/sizeof(*weights);k++) {
                check(scalar(a),scalar(a+1),weights[k]);
                if(e>7)check(scalar(a),scalar(a-(7u<<23)),weights[k]);
            }
        }
    }
    /* Values on each side of powers of two, where ULP size changes. Target
     * tiny weights and weights within 2^-20 of one with a wide endpoint gap. */
    for(unsigned e=8;e<248;e++)for(unsigned span=0;span<=7;span++) {
        float a=scalar(e<<23),b=scalar((e-span)<<23);
        for(unsigned i=0;i<BOUNDARY_CASES;i++) {
            double t=i*0x1p-30;
            check(a,b,t);check(a,b,1-t);check(b,a,t);check(b,a,1-t);
        }
    }
    printf("%u interpolation comparisons: zero differences\n",checks);
#ifdef __PSP__
    fflush(stdout);sceKernelExitGame();
#endif
    return 0;
}
