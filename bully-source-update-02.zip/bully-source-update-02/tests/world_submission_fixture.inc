#include "native_object.h"
#include "native_skin.h"
#include "native_texture.h"
#include "native_state.h"
#include "native_light.h"
int hle_ge_on;uint8_t *hle_ram;uint32_t hle_ram_end;uint64_t hle_frame;
static unsigned fixture_case, fixture_mesh;
static unsigned mesh_count(void){return 1+fixture_case%5;}
static unsigned geometry(unsigned mesh){return (fixture_case/3+mesh)%4;}
static unsigned texture_kind(unsigned mesh){return (fixture_case+mesh)%3;}
#ifndef BEFORE_TEXTURE_WRITE
#define BEFORE_TEXTURE_WRITE() ((void)0)
#endif
int bully_native_state(const uint8_t*r,size_t b,uint32_t p,uint32_t gp,BullyNativeState*s){
 (void)r;(void)b;(void)gp;unsigned mesh=p-1;if(fixture_case!=128 && (fixture_case+mesh)%11==0)return 0;memset(s,0,sizeof(*s));
 s->stream=0x500+mesh*256;s->material=mesh+1;
 unsigned fn=(fixture_case+mesh)%8,ref=(fixture_case%3==0?0:fixture_case%3==1?64:127);
 s->test=1|(fn<<1)|(ref<<4)|(1<<12)|(1<<16)|(2<<17);
 s->zmask=fixture_case%7==0;s->blend=fixture_case%5!=0;
 if(fixture_case!=128 && fixture_case%13==0)s->test&=~1u;
 if(fixture_case!=128 && fixture_case%17==0)s->test&=~(1u<<16);
 s->alpha=fixture_case%3==0?0x68:fixture_case%3==1?0x44:0x88;s->alpha_fixed=128;return 1;
}
int bully_native_light(const uint8_t*r,size_t b,uint32_t p,uint32_t gp,BullyNativeLight*l){
 (void)r;(void)b;(void)gp;unsigned mesh=p-1;memset(l,0,sizeof(*l));
 l->stream=0x500+mesh*256;l->material_id=mesh+1;l->material_alpha=.5f;return fixture_case%2;
}
void bully_light_color(const BullyNativeVertex*v,const BullyNativeLight*l,float out[3]){
 (void)l;for(unsigned k=0;k<3;k++)out[k]=v->color[k]*2;
}
float bully_light_alpha(const BullyNativeVertex*v,const BullyNativeLight*l){(void)v;return l->material_alpha*255;}
int bully_native_object(const uint8_t*r,size_t b,uint32_t o,uint32_t c,BullyNativeVertex*s,BullyNativeObject*out){
 (void)r;(void)b;(void)o;(void)c;(void)s;memset(out,0,sizeof(*out));
 for(unsigned k=0;k<3;k++)out->view[k][k]=1;
 out->near_plane=1;out->far_plane=100;out->meshes=mesh_count();
 for(unsigned m=0;m<out->meshes;m++){out->mesh[m].stream=0x500+m*256;out->mesh[m].compressed=1;out->mesh[m].material=m+1;}
 return 1;
}
int bully_native_texture(const uint8_t*r,size_t b,uint32_t m,void*dst,size_t cap,BullyNativeTexture*out){
 (void)r;(void)b;fixture_mesh=m-1;BEFORE_TEXTURE_WRITE();memset(out,0,sizeof(*out));
 unsigned kind=texture_kind(fixture_mesh);if(!kind)return 0;
 assert(cap>=4096);out->texture.alpha_class=TC_ALPHA_BLEND;
 out->texture.level[0].width=out->texture.level[0].height=out->texture.level[0].bufw=32;
 out->filter=fixture_case%2?1:2;out->wrap_u=out->wrap_v=3;
 if(kind==1){
  out->texture.psm=GU_PSM_8888;out->texture.total_bytes=4096;
  for(unsigned j=0;j<1024;j++)((uint32_t*)dst)[j]=(0x40000000u+((j%3)<<30))|((fixture_case*97+fixture_mesh*2048+j*313)&0xffffff);
 }else{
  out->texture.psm=GU_PSM_T8;out->texture.total_bytes=2048;
  out->texture.clut_entries=256;out->texture.clut_psm=GU_PSM_8888;
  out->texture.clut_bytes=1024;out->texture.clut_offset=1024;
  for(unsigned j=0;j<1024;j++)((uint8_t*)dst)[j]=(uint8_t)(j+fixture_case);
  for(unsigned j=0;j<256;j++)((uint32_t*)((uint8_t*)dst+1024))[j]=0x80000000u|((fixture_case*139+fixture_mesh*3048+j*173)&0xffffff);
 }
 return 1;
}
int bully_compressed_chain(const uint8_t*r,size_t b,uint32_t a,BullyNativeVertex*s,BullyNativeVisit visit,void*ctx,size_t*n,size_t*used){
 (void)r;(void)b;(void)a;unsigned shape=geometry(fixture_mesh);*n=*used=0;if(!shape)return 1;
 size_t count=shape==1?3:194;memset(s,0,count*sizeof(*s));
 for(unsigned i=0;i<count;i++){
  float x=count==3?(i==1?.9f:.1f):.1f+.8f*(i/2)/96;
  float y=count==3?(i==2?.9f:.1f):(i%2?.9f:.1f);
  float z=20+fixture_mesh*3;s[i].position[0]=x*z;s[i].position[1]=y*z;s[i].position[2]=z;
  s[i].uv[0]=x;s[i].uv[1]=y;memset(s[i].color,128,4);memset(s[i].color_secondary,128,4);
 }
 *n=count;if(visit){visit(s,count,ctx);if(shape==3)visit(s,count,ctx);}return 1;
}
int bully_native_decode(const uint8_t*r,size_t b,BullyNativeVertex*v,size_t cap,size_t*n){(void)r;(void)b;(void)v;(void)cap;*n=0;return 0;}
int bully_skin_chain(const uint8_t*r,size_t b,uint32_t a,uint32_t p,unsigned bones,BullyNativeVertex*s,BullySkinVisit f,void*ctx,size_t*n,size_t*used,size_t*tris){
 (void)r;(void)b;(void)a;(void)p;(void)bones;(void)s;(void)f;(void)ctx;*n=*used=*tris=0;return 0;
}
static uint8_t fixture_ram[4096];
static void run_fixture(unsigned test){
 fixture_case=test;hle_ram=fixture_ram;hle_ram_end=sizeof(fixture_ram);hle_frame++;
 bully_world_enable();bully_world_camera_begin(1);bully_world_begin();
 for(unsigned m=0;m<mesh_count();m++){bully_world_capture_state(m+1,1);bully_world_capture_light(m+1,1);}
 bully_world_draw(1,1);
}

int bully_native_object_cached(const uint8_t*r,size_t b,uint32_t o,uint32_t c,BullyNativeVertex*s,BullyNativeObject*out,BullyNativeSkinCache*cache){(void)cache;return bully_native_object(r,b,o,c,s,out);}
int bully_native_skin_replay(const BullyNativeSkinCache*c,unsigned mesh,BullySkinVisit visit,void*ctx){(void)c;(void)mesh;(void)visit;(void)ctx;return 0;}

int main(void){
 for(unsigned test=0;test<512;test++){
  trace_hash=1469598103934665603ull;starts=syncs=max_words=0;
  run_fixture(test);assert(!host_open&&!read_count);
  bully_world_camera_end(2);bully_world_camera_end(1);bully_world_camera_end(1);
  bully_world_overlay_begin();bully_world_overlay_present();
  if(test%8==7)bully_world_shutdown();
  printf("case=%u hash=%016llx draws=%u starts=%u syncs=%u max_trace_words=%u\n",test,(unsigned long long)trace_hash,draw_calls,starts,syncs,max_words);
 }
 bully_world_shutdown();puts("COMPLETE errors=0");return 0;
}

/* These fixtures exercise compressed geometry only. The float-sky pipeline and
 * real overlay composition have separate tests in prepare_sky_gpu.py. */
int bully_native_state_shadow(const uint8_t*r,size_t b,uint32_t gp,BullyNativeState*s){(void)r;(void)b;(void)gp;(void)s;return 0;}
void bully_overlay_underlay_flush(void){}

/* These fixtures synthesize expanded vertices rather than packed DMA data.
 * Keep using their original visitor; the raw bridge has its own differential
 * tests in prepare_raw_mesh.py. */
int bully_compressed_chain_raw(const uint8_t*r,size_t b,uint32_t a,
    BullyNativeVertex*s,BullyNativeVisit visit,BullyNativeRawVisit raw,
    void*ctx,size_t*n,size_t*used) {
    (void)raw;return bully_compressed_chain(r,b,a,s,visit,ctx,n,used);
}
