#include "candidate/r5900_rt.h"
#include <stdio.h>
#include <stdlib.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully exact FPR rsqrt",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
PSP_HEAP_SIZE_KB(1024);
static void setstatus(unsigned m,unsigned p){uint32_t f=(1u<<24)|m|((p&1)?0x800000:0)|((p&2)?0x7c:0)|((p&4)?0x1f000:0);__asm__ volatile("ctc1 %0,$31"::"r"(f):"memory");}
static uint32_t status(uint32_t dep){uint32_t f;__asm__ volatile("cfc1 %0,$31":"=r"(f):"r"(dep):"memory");return f;}
#else
#include <fenv.h>
static void setstatus(unsigned m,unsigned p){static const int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(modes[m]);feclearexcept(FE_ALL_EXCEPT);if(p&2)feraiseexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW|FE_UNDERFLOW|FE_INEXACT);}
static uint32_t status(uint32_t dep){(void)dep;return (uint32_t)fetestexcept(FE_ALL_EXCEPT);}
#endif
void reference_normalizer(R5900Ctx*),candidate_normalizer(R5900Ctx*);
uint32_t reference_one(uint32_t),candidate_one(uint32_t),reference_generic(uint32_t,uint32_t),candidate_generic(uint32_t,uint32_t);
#include "trace.inc"
static uint32_t seed=0x629173ab;
static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static R5900Ctx a,b,initial;
static unsigned char ra[65536+128] __attribute__((aligned(16))),rb[sizeof(ra)] __attribute__((aligned(16)));
static const uint32_t edge[]={
 0,0x80000000,1,0x80000001,0x007fffff,0x807fffff,
 0x00800000,0x80800000,0x00800001,0x80800001,
 0x3f800000,0xbf800000,0x3f800001,0xbf800001,
 0x5f000000,0xdf000000,0x7f7fffff,0xff7fffff,
 0x7f800000,0xff800000,0x7fc00000,0xffc00000,0x7f800001,0xff800001};
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);FILE*f=fopen("normalize-test.log","w");
#else
 FILE*f=stdout;
#endif
 if(!f)return 2;
 unsigned total=0,n=sizeof(edge)/sizeof(edge[0]),systematic=n*n*n;
 unsigned scalar_total=0;
 static const uint32_t mant[]={0,1,2,0x3fffff,0x400000,0x7ffffd,0x7ffffe,0x7fffff};
 for(unsigned m=0;m<4;m++){
  for(unsigned i=0;i<1004096;i++){
   uint32_t t=i<4096?(((i>>11)<<31)|(((i>>3)&255)<<23)|mant[i&7]):rnd(),s0=rnd();
   setstatus(m,i&7);uint32_t x=reference_one(t),fx=status(x);
   setstatus(m,i&7);uint32_t y=candidate_one(t),fy=status(y);
   if(x!=y||fx!=fy){fprintf(f,"ERROR one mode=%u i=%u t=%08x x=%08x/%08x y=%08x/%08x\n",m,i,(unsigned)t,(unsigned)x,(unsigned)fx,(unsigned)y,(unsigned)fy);goto fail;}
   setstatus(m,i&7);x=reference_generic(s0,t);fx=status(x);
   setstatus(m,i&7);y=candidate_generic(s0,t);fy=status(y);
   if(x!=y||fx!=fy){fprintf(f,"ERROR generic mode=%u i=%u\n",m,i);goto fail;}
   scalar_total++;
  }
  fprintf(f,"scalar mode=%u comparisons=%u errors=0\n",m,scalar_total);fflush(f);
  for(unsigned i=0;i<systematic+10000+8192;i++){
   for(unsigned j=0;j<sizeof(initial);j+=4){uint32_t v=rnd();memcpy((unsigned char*)&initial+j,&v,4);}
   memset(ra,(unsigned char)(i*37u+17u),sizeof(ra));
   memset(ra,0xa5,64);memset(ra+64+65536,0x5a,64);
   unsigned base=(rnd()%16382u)*4u;
   for(unsigned j=0;j<3;j++){
    unsigned index=j==0?i%n:j==1?(i/n)%n:(i/n/n)%n;
    uint32_t v=i<systematic?edge[index]:i>=systematic+10000?trace[i-systematic-10000][j]:rnd();memcpy(ra+64+base+4*j,&v,4);
   }
   initial.r[4].w[0]=(rnd()&0xffff0000u)|base;initial.ram_mask=65535;
   memcpy(rb,ra,sizeof(ra));a=initial;b=initial;a.ram=ra+64;b.ram=rb+64;
   setstatus(m,i&7);reference_normalizer(&a);uint32_t fa=status(a.fpr[0].u);setstatus(m,i&7);candidate_normalizer(&b);uint32_t fb=status(b.fpr[0].u);a.ram=NULL;b.ram=NULL;
   if(fa!=fb||memcmp(&a,&b,sizeof(a))||memcmp(ra,rb,sizeof(ra))){fprintf(f,"ERROR mode=%u case=%u base=%u\n",m,i,base);goto fail;}
   for(unsigned j=0;j<64;j++)if(ra[j]!=0xa5||rb[j]!=0xa5||ra[64+65536+j]!=0x5a||rb[64+65536+j]!=0x5a){fprintf(f,"ERROR guard\n");goto fail;}
   total++;
  }
  fprintf(f,"mode=%u comparisons=%u errors=0\n",m,total);fflush(f);
 }
 fprintf(f,"COMPLETE comparisons=%u scalars=%u errors=0\n",total,scalar_total);fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
 fail:fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 1;
}
