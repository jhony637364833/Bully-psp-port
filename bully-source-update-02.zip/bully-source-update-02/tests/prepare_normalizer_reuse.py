"""Generate full-context/RAM differential checks for coordinate reuse.

The frozen original generated function is independent of the pack text patches.
Both variants use the supplied unchanged runtime header and strict FP flags.
"""
from pathlib import Path
import argparse

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();d=a.output;d.mkdir(parents=True,exist_ok=True)
    here=Path(__file__).parent
    reference=(here/'normalizer_reuse_reference.inc').read_text()
    candidate=reference;count=0
    rules=a.app/'games/SLUS-21269_v1.02/lists/normalizer-reuse.tsv'
    for line in rules.read_text().splitlines():
        if not line.strip() or line.lstrip().startswith('#'):continue
        fn,old,new=line.split('\t')
        if fn!='fn_001860c0' or candidate.count(old)!=1:
            raise ValueError('patch does not match the frozen original exactly once')
        candidate=candidate.replace(old,new);count+=1
    if count!=3:raise ValueError('expected exactly three coordinate replacements')
    header=(a.app/'runtime/r5900_rt.h').read_bytes()
    for name,body in [('reference',reference),('candidate',candidate)]:
        (d/name).mkdir(exist_ok=True);(d/name/'r5900_rt.h').write_bytes(header)
        (d/(name+'.c')).write_text('#include "'+name+'/r5900_rt.h"\n'+body.replace('fn_001860c0',name+'_normalize'))
    (d/'main.c').write_bytes((here/'normalizer_reuse_main.c').read_bytes())
    (d/'Makefile').write_bytes((here/'normalizer_reuse_Makefile.inc').read_bytes())
    print('Expected COMPLETE comparisons=95296 errors=0')

if __name__=='__main__':main()
