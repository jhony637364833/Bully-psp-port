# CPU fallback helper fixture. Accelerated rendering is tested separately by the full GPU fixtures.
from pathlib import Path
import re
import argparse
r=Path(__file__).resolve().parents[1];t=r/'tests'
a=argparse.ArgumentParser(description='Exact adjacent-vertex reuse checks on PSP and host')
a.add_argument('--app',type=Path,default=r/'app');a.add_argument('--output',type=Path,required=True)
args=a.parse_args();g=args.app/'games/SLUS-21269_v1.02/src';d=args.output;d.mkdir(parents=True,exist_ok=True)
head=(t/'strip_rotate_head.inc').read_text().replace('Bully strip rotate check','Bully duplicate vertex check')
head+='''
static unsigned reuse_hits;
#ifdef __PSP__
static __attribute__((noinline)) uint32_t clip_fpu_read(void) {uint32_t x;__asm__ volatile("cfc1 %0,$31":"=r"(x)::"memory");return x;}
static __attribute__((noinline)) void clip_fpu_write(uint32_t x) {reuse_hits++;__asm__ volatile("ctc1 %0,$31\\n\\tnop\\n\\tnop"::"r"(x):"memory");}
#else
/* Preserve the host rounding mode and exception flags separately. This is a
 * host adapter, not an emulation of Allegrex's FP comparison condition bit. */
static uint32_t clip_fpu_read(void){return ((uint32_t)fegetround()<<16)|(unsigned)fetestexcept(FE_ALL_EXCEPT);}
static void clip_fpu_write(uint32_t x){reuse_hits++;fesetround((int)(x>>16));feclearexcept(FE_ALL_EXCEPT);feraiseexcept((int)(x&0xffff));}
#endif
#include "clip_memo.h"
static BullyClipMemo clip_memo;
static BullyClipMemoSet *clip_memo_storage;
static int clip_memo_enabled;
'''
parts=[]
for label in ['reference','candidate']:
 s=((t/'duplicate_vertex_reference.inc') if label=='reference' else (g/'psp/world_display.c')).read_text()
 if label=='candidate':s=s[s.index('static unsigned channel'):s.index('void bully_world_draw')].split('/* GPU strip dispatch.',1)[0]
 for name in ['channel','screen_clamp','prepare_vertex','triangle','PreparedVertex','prepare_cached','triangle_cached','draw_strip','draw_batch','draw_skin_batch']:s=re.sub(r'\b'+name+r'\b',label+'_'+name,s)
 parts.append(s)
main=(t/'strip_rotate_main.inc').read_text().replace('strip-rotate.log','duplicate.log').replace('test<1280','test<640').replace('COMPLETE cases=5120','COMPLETE cases=2560')
main=main.replace('   skip[i]=', '''   if(test>=320) {
    static const uint32_t edge[]={0,0x80000000u,1,0x80000001u,0x007fffffu,0x00800000u,0x7f7fffffu,0xff7fffffu,0x7f800000u,0xff800000u,0x7fc12345u,0x7f800001u,0xff800001u,0x3f800000u};
    uint32_t bits=edge[(test+i)%(sizeof(edge)/sizeof(*edge))];
    memcpy(&v[i].position[test%3],&bits,4);
   }
   if(i && (test%3==0 ? i%4!=0 : test%3==1 ? i%2!=0 : 0)) {
    v[i]=v[i-1];
    /* Fields not consumed by preparation must not affect the result. */
    v[i].normal[0]=(int8_t)i;((unsigned char*)&v[i])[31]=(unsigned char)(test+i);
   }
   skip[i]=''')
main=main.replace(' puts("COMPLETE', ' assert(reuse_hits>100);printf("reuse_hits=%u\\n",reuse_hits);\n puts("COMPLETE')
(d/'main.c').write_text(head+'\n'.join(parts)+main)
make=(t/'strip_rotate_Makefile.inc').read_text();start=make.index('BULLY_SRC = ');end=make.index('\n',start);make=make[:start]+'BULLY_SRC = '+str(g)+make[end:];(d/'Makefile').write_text(make)
