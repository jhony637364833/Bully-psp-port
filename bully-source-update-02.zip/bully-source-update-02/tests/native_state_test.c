#include "native_state.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
static unsigned char ram[32768];
static void put(unsigned p,unsigned v){for(int k=0;k<4;k++)ram[p+k]=v>>(8*k);}
int main(void){
 const unsigned gp=30000,pipe=100,slot=200,entry=220,stream=512;
 put(pipe+48,slot);put(pipe+60,312);put(slot,entry);put(entry+32,stream);put(stream,0x10000001);
 put(gp-25152,0x5064d);put(gp-25112,0x88);put(gp-25096,0x78);
 BullyNativeState s,old;
 assert(bully_native_state(ram,sizeof(ram),pipe,gp,&s));
 assert(s.stream==stream&&s.material==300&&s.test==0x5064d&&s.alpha==0x88&&s.blend==1&&s.zmask==0);
 put(gp-25152,0x513fb);put(gp-25112,0x44);put(gp-25164,1);
 assert(bully_native_state(ram,sizeof(ram),pipe,gp,&s));assert(s.zmask==1&&s.alpha==0x44&&((s.test>>12)&3)==1);
 put(gp-25112,0x68);put(gp-25108,128);
 assert(bully_native_state(ram,sizeof(ram),pipe,gp,&s));old=s;
 put(gp-25108,127);assert(!bully_native_state(ram,sizeof(ram),pipe,gp,&s));assert(!memcmp(&s,&old,sizeof(s)));
 put(gp-25112,0x44);put(gp-25152,0x5264d);assert(!bully_native_state(ram,sizeof(ram),pipe,gp,&s));
 put(gp-25152,0x5464d);assert(!bully_native_state(ram,sizeof(ram),pipe,gp,&s));
 put(gp-25152,0x5064d);put(entry+32,513);assert(!bully_native_state(ram,sizeof(ram),pipe,gp,&s));
 put(entry+32,512);assert(!bully_native_state(ram,100,pipe,gp,&s));
 assert(!bully_native_state(ram,sizeof(ram),pipe,10,&s));
 assert(!bully_native_state(0,sizeof(ram),pipe,gp,&s));
 puts("material-state capture: observed states and malformed/unsupported inputs PASS");
}
