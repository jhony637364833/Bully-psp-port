"""Compile all three modes: host reference, compact PSP, explicit PSP reference."""
import importlib.util
import os
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("prepare_gen", root / "app/ps2rc/pipeline/prepare_gen.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
ctx = m.Ctx(set(), set(), set(), {}, False, [])
ctx.native = {"fn_00001000"}
source = '''typedef struct {int value;} R5900Ctx;
void fn_00001000(R5900Ctx *c)
{
    c->value++;
}
void fn_00002000(R5900Ctx *c)
{
    c->value = 5;
}
'''
prepared = m.process_c(source, False, ctx)
assert ctx.native_found == ctx.native
assert m.process_c(source, False, m.Ctx(set(), set(), set(), {}, False, [])) == source
runner = '''
#include <assert.h>
void y_nat_00001000(R5900Ctx *c) {c->value=7;}
int main(void) {
    R5900Ctx c={0};fn_00001000(&c);assert(c.value==7);
    fn_00002000(&c);assert(c.value==5);
#if !defined(__PSP__) || defined(HLE_KEEP_NATIVE_REFERENCE)
    fn_00001000__ynguest(&c);assert(c.value==6);
#endif
    return 0;
}
'''
with tempfile.TemporaryDirectory() as tmp:
    p = Path(tmp) / 'check.c';p.write_text(prepared+runner)
    for name, flags, kept in [('host', [], True), ('psp', ['-D__PSP__'], False),
                              ('psp-reference', ['-D__PSP__', '-DHLE_KEEP_NATIVE_REFERENCE'], True)]:
        exe = Path(tmp) / name
        subprocess.run([os.environ.get('CC','cc'), '-std=c11', '-Wall', '-Wextra', '-Werror',
                        *flags, str(p), '-o', str(exe)], check=True)
        subprocess.run([str(exe)], check=True)
        symbols = subprocess.check_output(['nm', str(exe)], text=True)
        assert ('fn_00001000__ynguest' in symbols) == kept
        print(name+': wrapper, following function and reference visibility passed')
