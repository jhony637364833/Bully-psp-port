"""Build the existing sky fixture with actual GE early-HUD preservation checks."""
from pathlib import Path
import argparse,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();t=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(t/'prepare_sky_gpu.py'),'--output',str(a.output)],check=True)
p=a.output/'main.c';s=p.read_text();needle=' puts("COMPLETE sky/depth preservation';assert s.count(needle)==1
p.write_text(s.replace(needle,(t/'composition_gpu_extra.inc').read_text()+needle))

startup=(t/'composition_gpu_startup.inc').read_text()
f=a.output/'main.c';s=f.read_text();needle=' fixture_case=0;hle_ram=fixture_ram;hle_ram_end=sizeof fixture_ram;bully_world_enable();bully_world_camera_begin(1);'
assert s.count(needle)==1;f.write_text(s.replace(needle,startup+needle))
