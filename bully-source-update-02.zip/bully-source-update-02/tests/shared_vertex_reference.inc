/* Frozen renderer immediately before shared visibility/projection caching. */
static unsigned channel(float f) { return f<=0?0:f>=255?255:(unsigned)f; }
/* A strip shares two vertices with its next triangle. Transform and shade
 * each decoded vertex once; a three-entry stack ring also handles skin skips. */
static void prepare_vertex(const BullyNativeVertex *src,BullyClipVertex *out) {
    for(int k=0;k<3;k++) {
        float p=object_view.view[3][k];
        for(int j=0;j<3;j++)p+=src->position[j]*object_view.view[j][k];
        out->p[k]=p;out->color[k]=src->color[k]*2.0f;
    }
    out->alpha=255;
    if(material_light) {
        bully_light_color(src,material_light,out->color);
        out->alpha=bully_light_alpha(src,material_light);
    }
    for(int k=0;k<2;k++)out->uv[k]=src->uv[k];
}
static void triangle(const BullyClipVertex *a,const BullyClipVertex *b,const BullyClipVertex *c) {
    BullyClipVertex in[3]={*a,*b,*c},out[10];
    int n=bully_clip_triangle(in,object_view.near_plane,object_view.far_plane,out);
    if(!n)return;
    GeVertex clipped[24];
    int count=0;
    for(int i=1;i<n-1;i++) {
        int ix[3]={0,i,i+1};
        GeVertex projected[3];
        for(int j=0;j<3;j++) {
            BullyClipVertex *v=&out[ix[j]];
            projected[j].u=v->uv[0];
            projected[j].v=v->uv[1];
            if(!isfinite(projected[j].u) || !isfinite(projected[j].v))return;
            projected[j].x=fminf(480,fmaxf(0,480*v->p[0]/v->p[2]));
            projected[j].y=fminf(272,fmaxf(0,272*v->p[1]/v->p[2]));
            projected[j].color=(channel(v->alpha)<<24)|channel(v->color[0])|(channel(v->color[1])<<8)|(channel(v->color[2])<<16);
        }
        float area=(projected[1].x-projected[0].x)*(projected[2].y-projected[0].y)-(projected[2].x-projected[0].x)*(projected[1].y-projected[0].y);
        if(fabsf(area)<0.001f)continue;
        for(int j=0;j<3;j++) {
            /* Area rejection uses projected pixels; submitted positions retain
             * camera depth so GE computes the reciprocal-W interpolation. */
            projected[j].x=out[ix[j]].p[0];
            projected[j].y=out[ix[j]].p[1];
            projected[j].z=out[ix[j]].p[2];
            clipped[count++]=projected[j];
        }
    }
    if(!count)return;
    if(queued+(unsigned)count>WORLD_BATCH_VERTICES)flush_vertices();
    for(int i=0;i<count;i++)verts[queued++]=clipped[i];
    triangles+=count/3;
}
static void draw_strip(const BullyNativeVertex *v,const uint8_t *skip,size_t n) {
    BullyClipVertex ring[3];
    for(size_t i=0;i<n;i++) {
        prepare_vertex(&v[i],&ring[i%3]);
        if(i>=2 && (!skip || !skip[i]))
            triangle(&ring[(i-2)%3],&ring[(i-1)%3],&ring[i%3]);
    }
}
static void draw_batch(const BullyNativeVertex *v,size_t n,void *context) {
    (void)context;draw_strip(v,0,n);
}
static void draw_skin_batch(const BullyNativeVertex *v,const uint8_t *skip,size_t n,void *context) {
    (void)context;draw_strip(v,skip,n);
}
