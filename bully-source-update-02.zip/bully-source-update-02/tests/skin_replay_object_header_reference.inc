/* Based on PS2RC by SandstoneDev: https://github.com/SandstoneDev/PS2RC
 * Read-only adapter for the observed SLUS-21269 v1.02 static native object.
 * These offsets are title/version specific, not a general RenderWare ABI.
 */
#ifndef BULLY_NATIVE_OBJECT_H
#define BULLY_NATIVE_OBJECT_H
#include "native_mesh.h"
#define BULLY_NATIVE_MAX_MESHES 64

typedef struct {
    uint32_t stream, bytes, vertices, material, compressed;
} BullyNativeMeshView;
typedef struct {
    float view[4][3]; /* Row-vector local-to-camera transform; translation in row 3. */
    float near_plane, far_plane;
    uint32_t triangles, meshes;
    uint32_t palette, bones; /* Skin only: valid immediately after original setup. */
    BullyNativeMeshView mesh[BULLY_NATIVE_MAX_MESHES];
} BullyNativeObject;

/* Reads a RAM image without mutation or allocation. Only the observed perspective
 * camera, static native strips and verified0x25f118 skin strips are accepted. Float meshes use
 * inline RET; compressed meshes use bounded CNT batches and an empty RET.
 * scratch must hold 256 vertices and must not overlap ram or out.
 * All mesh attributes/counts are checked before out is committed. Zero means
 * unsupported or malformed; out is untouched. No textures are dereferenced.
 */
int bully_native_object(const uint8_t *ram, size_t bytes, uint32_t object,
                        uint32_t camera, BullyNativeVertex *scratch,
                        BullyNativeObject *out);
#endif
