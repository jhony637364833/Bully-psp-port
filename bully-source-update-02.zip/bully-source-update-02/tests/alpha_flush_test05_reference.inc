/* Frozen build05 flush: ordered per-triangle alpha pass/fail oracle. */
static void reference_flush(void) {
    if(!queued)return;
    sceKernelDcacheWritebackRange(verts,queued*sizeof(*verts));start();
    unsigned type=GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_3D;
    if(needs_alpha_fail_pass()) {
        /* Preserve primitive order for AFAIL=FB_ONLY, including overlapping
         * triangles: pass writes Z, fail writes only color. The entire
         * bounded vertex batch fits the command list; wait only before reuse. */
        for(unsigned i=0;i<queued;i+=3) {
            sceGuDrawArray(GU_TRIANGLES,type,3,0,verts+i);
            sceGuAlphaFunc(alpha_functions[inverse_alpha[(material_state->test>>1)&7]],alpha_reference(material_state),255);
            sceGuDepthMask(GU_TRUE);
            sceGuDrawArray(GU_TRIANGLES,type,3,0,verts+i);
            sceGuAlphaFunc(alpha_functions[(material_state->test>>1)&7],alpha_reference(material_state),255);
            sceGuDepthMask(material_state->zmask?GU_TRUE:GU_FALSE);
            draw_calls+=2;
        }
    } else {
        sceGuDrawArray(GU_TRIANGLES,type,queued,0,verts);draw_calls++;
    }
    finish();queued=0;
}
