#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdint.h>
#include "candidate.c"
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Texture cache differential",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
#endif
int reference_texture(const uint8_t*,size_t,uint32_t,void*,size_t,BullyNativeTexture*);
#define RAM_BYTES (512u*1024u)
static uint8_t ra[RAM_BYTES] __attribute__((aligned(16))),rb[RAM_BYTES] __attribute__((aligned(16)));
static uint8_t da[65552] __attribute__((aligned(16))),db[65552] __attribute__((aligned(16)));
static void put32(uint8_t *p,uint32_t x){memcpy(p,&x,4);}static void put64(uint8_t *p,uint64_t x){memcpy(p,&x,8);}
static unsigned upload_make(uint8_t *p,unsigned w,unsigned h,unsigned bytes,unsigned seed){
 memset(p,0,80);put64(p,3ull|(1ull<<60));put64(p+8,14);p[0x18]=0x51;p[0x28]=0x52;p[0x38]=0x53;
 put64(p+0x20,w|((uint64_t)h<<32));put64(p+0x40,(bytes/16)|(2ull<<58));
 for(unsigned i=0;i<bytes;i++){p[80+i]=(uint8_t)(seed+i*13+(i>>4));}return 80+bytes;
}
static unsigned make_texture(unsigned t,unsigned *pixel_bytes,unsigned *second){
 memset(ra+0x100,0,0x300);unsigned kind=t%6,w=16u<<((t/6)%5),h=16u<<((t/11)%5),depth,fmt,palette=0;
 if(kind==0){depth=4;fmt=TC_PF_PAL4|TC_PF_8888;palette=64;}
 else if(kind==1){depth=8;fmt=TC_PF_PAL8|TC_PF_8888;palette=1024;}
 else if(kind==2){depth=16;fmt=TC_PF_1555;}
 else if(kind==3){depth=32;fmt=TC_PF_8888;}
 else if(kind==4){depth=32;fmt=TC_PF_888;}
 else {depth=8;fmt=TC_PF_PAL8|TC_PF_1555;palette=512;}
 if(t%3==0)fmt|=TC_PF_MIPMAP;
 put32(ra+0x100,0x200);put32(ra+0x200,0x300);put32(ra+0x250,0x1101);
 put32(ra+0x304,0x1050);put32(ra+0x308,palette?0x70050:0);put32(ra+0x30c,w);put32(ra+0x310,h);put32(ra+0x314,depth);ra[0x323]=fmt>>8;
 unsigned swizzle=palette && (t&1);*pixel_bytes=w*h*depth/8;
 unsigned end=0x1000+upload_make(ra+0x1000,swizzle?w/2:w,swizzle?h/2:h,*pixel_bytes,t);*second=0;
 if(fmt&TC_PF_MIPMAP){*second=end+80;end+=upload_make(ra+end,w/2,h/2,w*h*depth/32,t+19);}
 memset(ra+end,0,80);
 if(palette)upload_make(ra+0x70000,kind==0?8:16,kind==0?2:16,palette,t+33);
 return palette;
}
int main(void){
#ifdef __PSP__
 freopen("texture-cache.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
#endif
 void *storage=malloc(bully_native_texture_cache_bytes()+15);assert(storage);BullyNativeTextureCache *cache=(void*)(((uintptr_t)storage+15)&~(uintptr_t)15);bully_native_texture_cache_init(cache);
 unsigned borrowed=0;unsigned cases=0,success=0,failed=0,wraps=0;uint32_t last_cursor=0;
 for(unsigned t=0;t<1024;t++){
  unsigned pixel_bytes,second,palette=make_texture(t,&pixel_bytes,&second);
  for(unsigned pass=0;pass<3;pass++){
   size_t bytes=RAM_BYTES,cap=65536;uint32_t material=0x100;unsigned variant=pass==2?t%16:0;
   if(variant==1)ra[0x1050+(t%pixel_bytes)]^=0x97;
   if(variant==2 && palette)ra[0x70050+(t%palette)]^=0x41;
   if(variant==3)put32(ra+0x250,0x1100);
   if(variant==4)put32(ra+0x30c,31);
   if(variant==5)ra[0x1000]=0;
   if(variant==6)bytes=0x1050+pixel_bytes-1;
   if(variant==7)cap=16;
   if(variant==12)material=0;
#if SIZE_MAX>UINT32_MAX
   if(variant==13)cap=(size_t)UINT32_MAX+1;
#else
   if(variant==13)cap=0;
#endif
   if(variant==14)put32(ra+0x250,0x1304);
   if(variant==15 && second)ra[second]^=0xff;
   memcpy(rb,ra,RAM_BYTES);memset(da,0xa5,sizeof da);memset(db,0xa5,sizeof db);
   BullyNativeTexture oa,ob;memset(&oa,0x3c,sizeof oa);memset(&ob,0x3c,sizeof ob);
   void *ad=da+(variant==8),*bd=db+(variant==8);BullyNativeTexture *ao=&oa,*bo=&ob;
   if(variant==9){ao=(void*)(da+16);bo=(void*)(db+16);}
   if(variant==10){ad=ra+0x1060;bd=rb+0x1060;}
   if(variant==11){ao=(void*)(ra+0x304);bo=(void*)(rb+0x304);}
   const void *view=(const void *)(uintptr_t)0x1234;
   int a=reference_texture(ra,bytes,material,ad,cap,ao),b=bully_native_texture_view(rb,bytes,material,bd,cap,bo,cache,&view);
   int pixels_ok=1;
   if(b) {
    pixels_ok=!memcmp(ad,view,ao->texture.total_bytes);
    if(view!=bd){borrowed++;for(unsigned j=0;j<sizeof db;j++)if(db[j]!=0xa5)pixels_ok=0;}
    else pixels_ok&=!memcmp(da,db,sizeof da);
   } else pixels_ok=view==(const void *)(uintptr_t)0x1234 && !memcmp(da,db,sizeof da);
   if(a!=b || !pixels_ok || memcmp(ra,rb,RAM_BYTES) || memcmp(&oa,&ob,sizeof oa)){
    printf("ERROR t=%u pass=%u variant=%u return=%d/%d hits=%u misses=%u\n",t,pass,variant,a,b,(unsigned)cache->hits,(unsigned)cache->misses);return 1;
   }
   cases++;success+=a!=0;failed+=a==0;if(cache->cursor<last_cursor)wraps++;last_cursor=cache->cursor;
  }
 }
 assert(borrowed>500);printf("borrowed=%u\n",borrowed);
 assert(cache->hits>500 && cache->misses>500 && wraps>5 && success>100 && failed>100);
 printf("COMPLETE cases=%u success=%u rejected=%u hits=%u misses=%u arena_wraps=%u header=%u errors=0\n",cases,success,failed,(unsigned)cache->hits,(unsigned)cache->misses,wraps,(unsigned)offsetof(BullyNativeTextureCache,data));free(storage);
#ifdef __PSP__
 sceKernelExitGame();
#endif
 return 0;
}
