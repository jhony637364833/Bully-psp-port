from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parents[1]
s=(r/'app/games/SLUS-21269_v1.02/src/render_probe.c').read_text();s=s[s.index('void GUEST(00223ad0)'):]
h='''#include <stdint.h>
#include <assert.h>
#include <string.h>
typedef struct {uint64_t d[2];} Reg;
typedef struct {Reg r[32];} R5900Ctx;
#define HLE_PSP 1
#define GUEST(a) guest_##a
#define HLE(a) void hook_##a(R5900Ctx *c)
static unsigned begins,ends,called;static uint32_t result,seen;
static unsigned flip_order,flips,flushes,presents;
static R5900Ctx *flip_context,expected_flip;
void guest_00223ad0(R5900Ctx *c){called++;c->r[2].d[0]=result;c->r[7].d[0]=123;}
void guest_00223a78(R5900Ctx *c){called++;c->r[2].d[0]=result;c->r[7].d[0]=456;}
void bully_world_camera_begin(uint32_t camera){begins++;seen=camera;}
void bully_world_camera_end(uint32_t camera){ends++;seen=camera;}
void guest_00240c00(R5900Ctx *c){assert(flip_order++==0);flips++;called++;c->r[2].d[0]=result;c->r[7].d[0]=789;}
void bully_overlay_flush(void){assert(flip_order++==1);flushes++;assert(!memcmp(flip_context,&expected_flip,sizeof(expected_flip)));}
void bully_world_overlay_present(void){assert(flip_order++==2);presents++;assert(!memcmp(flip_context,&expected_flip,sizeof(expected_flip)));}
'''
t='''int main(void){R5900Ctx c={0};result=0;hook_00223ad0(&c);assert(called==1&&begins==0&&c.r[2].d[0]==0&&c.r[7].d[0]==123);result=0x1234;hook_00223ad0(&c);assert(called==2&&begins==1&&seen==result&&c.r[2].d[0]==result);result=0;hook_00223a78(&c);assert(called==3&&ends==0&&c.r[7].d[0]==456);result=0x1234;hook_00223a78(&c);assert(called==4&&ends==1&&seen==result&&c.r[2].d[0]==result);
 for(unsigned i=0;i<2;i++){
  result=i?0x1234:0;flip_order=0;flip_context=&c;
  expected_flip=c;expected_flip.r[2].d[0]=result;expected_flip.r[7].d[0]=789;
  hook_00240c00(&c);
  assert(called==5+i&&flips==i+1&&flushes==i+1&&presents==i+1&&flip_order==3);
  assert(!memcmp(&c,&expected_flip,sizeof(c)));
 }
 return 0;}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'test.c').write_text(h+s+t);subprocess.run(['cc','-std=c11','-Wall','-Werror',str(p/'test.c'),'-o',str(p/'test')],check=True);subprocess.run([str(p/'test')],check=True)
print('Guest calls/returns, camera boundaries, and guest-flush-present ordering passed')
