#include "clip_memo.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <math.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully clip memo check",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
static uint32_t read_fpu(void){uint32_t x;__asm__ volatile("cfc1 %0,$31":"=r"(x)::"memory");return x;}
static void write_fpu(uint32_t x){__asm__ volatile("ctc1 %0,$31\n\tnop\n\tnop"::"r"(x):"memory");}
static uint32_t start_fpu(unsigned mode,unsigned fs,unsigned flags){return mode|(fs<<24)|flags;}
#else
#include <fenv.h>
static uint32_t read_fpu(void){return ((uint32_t)fegetround()<<16)|(uint32_t)fetestexcept(FE_ALL_EXCEPT);}
static void write_fpu(uint32_t x){fesetround((int)(x>>16));feclearexcept(FE_ALL_EXCEPT);feraiseexcept((int)(x&0xffffu));}
static uint32_t start_fpu(unsigned mode,unsigned fs,unsigned flags){int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};(void)fs;return ((uint32_t)modes[mode]<<16)|((flags&4)?FE_INEXACT:0)|((flags&8)?FE_UNDERFLOW:0);}
#endif
extern int reference_clip(const BullyClipVertex *,float,float,BullyClipVertex *,BullyClipCache *);
extern int reference_plain(const BullyClipVertex *,float,float,BullyClipVertex *);
static BullyClipMemoSet sets[2048];
static unsigned seed=1341;
static unsigned rnd(void){seed=seed*1664525u+1013904223u;return seed;}
static float randf(void){return (rnd()>>8)*(1.0f/16777216.0f);}
static uint32_t fake_state;
static uint32_t fake_read(void){return fake_state;}
static void fake_write(uint32_t v){fake_state=v;}
static void key_checks(void){
 BullyClipMemo m;BullyClipMemoSet tiny[1];BullyClipMemoEntry *pending;BullyClipVertex u={{-1,2,10},{50,100,150},{.1f,.2f},127},v={{5,2,10},{100,120,50},{.3f,.4f},255},out,saved;
 memset(&saved,0x42,sizeof(saved));
 assert(!bully_clip_memo_init(0,tiny,1,fake_read,fake_write,0));
 assert(!bully_clip_memo_init(&m,tiny,0,fake_read,fake_write,0));
 assert(!bully_clip_memo_init(&m,tiny,3,fake_read,fake_write,0));
 assert(!bully_clip_memo_init(&m,tiny,1,0,fake_write,0));
 assert(!bully_clip_memo_init(&m,tiny,1,fake_read,0,0));
 assert(bully_clip_memo_init(&m,tiny,1,fake_read,fake_write,0xf80));
 fake_state=0x01000004;assert(!bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending)&&!pending);
 assert(!bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending)&&pending);
 fake_state=0x01800044;bully_clip_memo_commit(&m,pending,&saved);
 for(unsigned byte=0;byte<2*sizeof(u)+12;byte++) {
  BullyClipVertex a=u,b=v;float near=1,far=100;unsigned plane=2;
  if(byte<sizeof(u))((unsigned char*)&a)[byte]^=1;
  else if(byte<2*sizeof(u))((unsigned char*)&b)[byte-sizeof(u)]^=1;
  else if(byte<2*sizeof(u)+4)((unsigned char*)&near)[byte-2*sizeof(u)]^=1;
  else if(byte<2*sizeof(u)+8)((unsigned char*)&far)[byte-2*sizeof(u)-4]^=1;
  else plane^=1u<<((byte-2*sizeof(u)-8)*8);
  fake_state=0x01000004;memset(&out,0xa5,sizeof(out));BullyClipVertex untouched=out;
  assert(!bully_clip_memo_lookup(&m,&a,&b,plane,near,far,&out,&pending));assert(!memcmp(&out,&untouched,sizeof(out)));
  /* The uncommitted miss cannot become a hit. Original is still the MRU way. */
  assert(!bully_clip_memo_lookup(&m,&a,&b,plane,near,far,&out,&pending));
  fake_state=0x01000004;assert(bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending));assert(fake_state==0x01800044&&!memcmp(&out,&saved,sizeof(out)));
 }
 fake_state=0x01000005;assert(!bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending));
 fake_state=0xf80;unsigned miss=m.misses;assert(!bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending)&&!pending&&m.misses==miss&&m.bypasses==1);
 fake_state=0;assert(!bully_clip_memo_lookup(&m,&v,&u,3,1,100,&out,&pending));
 assert(!bully_clip_memo_lookup(&m,&v,&u,3,1,100,&out,&pending)&&pending);
 fake_state=0xf80;bully_clip_memo_commit(&m,pending,&saved);fake_state=0;
 assert(!bully_clip_memo_lookup(&m,&v,&u,3,1,100,&out,&pending));
 fake_state=0x01000004;bully_clip_memo_reset(&m);assert(!bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending));
 if(!pending)assert(!bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending)&&pending);
 bully_clip_memo_commit(&m,pending,&saved);m.epoch=0xffffffffu;bully_clip_memo_reset(&m);assert(m.epoch==1&&!bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending));
 /* One-set collision pressure: repeatedly replacing both ways must never return
  * a different ordered edge or accidentally commit an incomplete reservation. */
 for(unsigned i=0;i<300;i++) {
  u.p[0]=(float)i;fake_state=0;
  assert(!bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending)&&!pending);
  assert(!bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending)&&pending);
  bully_clip_memo_commit(&m,pending,&u);
 }
 assert(m.admissions>=300);
 puts("KEYS endpoint/plane/near/far/FPU mutations, incomplete commit, enabled-trap bypass, collisions, reset/wrap PASS");
}
int main(void){
#ifdef __PSP__
 freopen("clip-memo.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
#endif
 key_checks();BullyClipMemo memo;assert(bully_clip_memo_init(&memo,sets,2048,read_fpu,write_fpu,
#ifdef __PSP__
 0x00020f80u
#else
 0
#endif
 ));
 unsigned cases=0;BullyClipVertex input[3],before[3],expected[10],actual[10];
 for(unsigned mode=0;mode<4;mode++)for(unsigned fs=0;fs<2;fs++)for(unsigned test=0;test<256;test++) {
  write_fpu(start_fpu(0,0,0));
  for(unsigned i=0;i<3;i++) {
   for(unsigned k=0;k<3;k++){input[i].p[k]=randf()*140-20;input[i].color[k]=randf()*300-20;}
   for(unsigned k=0;k<2;k++)input[i].uv[k]=randf()*4-1;input[i].alpha=randf()*300-20;
  }
  float near=1,far=100;
  if(test%4==0)for(unsigned i=0;i<3;i++){input[i].p[2]=10+i;input[i].p[0]=i==0?-1:5;input[i].p[1]=i==2?7:2;}
  if(test%13==0)input[0].p[0]=-0.0f;
  if(test%17==0)input[2].uv[1]=INFINITY;
  if(test%19==0)input[1].p[2]=NAN;
  if(test%23==0){uint32_t bits=1;memcpy(&input[0].p[1],&bits,4);}
  if(test%29==0)near=-1;
  if(test%31==0)far=near;
  memcpy(before,input,sizeof(input));uint32_t initial=start_fpu(mode,fs,test&12);
  BullyClipCache reference_cache;bully_clip_cache_reset(&reference_cache);
  write_fpu(initial);memset(expected,0xa5,sizeof expected);int n=reference_clip(input,near,far,expected,&reference_cache);uint32_t expected_fpu=read_fpu();
  for(unsigned repeat=0;repeat<3;repeat++) {
   BullyClipCache cache;bully_clip_cache_reset(&cache);write_fpu(initial);memset(actual,0xa5,sizeof actual);
   int got=bully_clip_triangle_memoized(input,near,far,actual,&cache,&memo);uint32_t fpu=read_fpu();
   if(n!=got || fpu!=expected_fpu || memcmp(actual,expected,sizeof actual) || memcmp(input,before,sizeof input)) {
    printf("ERROR case=%u mode=%u fs=%u repeat=%u count=%d/%d fpu=%08x/%08x\n",test,mode,fs,repeat,n,got,(unsigned)expected_fpu,(unsigned)fpu);return 1;
   }
  }
  /* Public null-memo/default API still follows the old independent reference. */
  write_fpu(initial);memset(expected,0xa5,sizeof expected);n=reference_plain(input,near,far,expected);expected_fpu=read_fpu();
  write_fpu(initial);memset(actual,0xa5,sizeof actual);int got=bully_clip_triangle(input,near,far,actual);uint32_t fpu=read_fpu();assert(n==got&&expected_fpu==fpu&&!memcmp(actual,expected,sizeof actual));
  cases++;
 }
 assert(memo.hits>1000 && memo.misses>1000);
 printf("COMPLETE cases=%u cached_repeats=3 modes=4 FS_modes=2 endpoint_bytes=exact polygon_order=exact output_tail=exact source=unchanged FPU=exact hits=%u misses=%u memo_bytes=%u errors=0\n",cases,memo.hits,memo.misses,(unsigned)sizeof sets);
#ifdef __PSP__
 sceKernelExitGame();
#endif
 return 0;
}
