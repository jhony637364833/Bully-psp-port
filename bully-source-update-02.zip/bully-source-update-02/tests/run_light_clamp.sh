#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bully_light_test_dir=$(mktemp -d)
trap 'rm -rf "$bully_light_test_dir"' EXIT
bully_light_src=app/games/SLUS-21269_v1.02/src
${CC:-cc} -O2 -Wall -Wextra -Werror -frounding-math -ffp-contract=off -fsanitize=address,undefined -I"$bully_light_src" tests/light_clamp_test.c tests/light_test04_reference.c "$bully_light_src/native_light.c" -lm -o "$bully_light_test_dir/test"
"$bully_light_test_dir/test"
