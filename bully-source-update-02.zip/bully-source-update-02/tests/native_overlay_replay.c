#include "native_gif.h"
#include "native_vif.h"
#include "overlay_geometry.h"
#include <stdio.h>
#include <stdlib.h>
static BullyOverlayGeometry geom;static unsigned pending,batches;
static void flush(void*o){(void)o;if(pending){batches++;pending=0;}}
static void draw(void*o,unsigned prim,const BullyOverlayContext*s,const BullyOverlayVertex*v,unsigned n){
 (void)o;unsigned add=n==2?6:3;if(pending+add>384)flush(0);pending+=add;
 printf("D %x %llx %u",prim,(unsigned long long)s->tex0,n);
 for(unsigned i=0;i<n;i++)printf(" %.8g %.8g %.8g %.8g %08x",v[i].x,v[i].y,v[i].u,v[i].v,v[i].color);puts("");
}
static void reg(void*o,unsigned r,uint64_t v){(void)o;bully_overlay_geometry_reg(&geom,r,v);}
static void upload(void*o,uint64_t b,uint32_t a,uint32_t n){(void)o;printf("U %llx %x %u\n",(unsigned long long)b,a,n);}
int main(int argc,char**argv){
 if(argc!=5)return 2;unsigned vif=strtoul(argv[2],0,0),chunk=strtoul(argv[3],0,0),addr=strtoul(argv[4],0,0);if(!chunk || chunk%4 || (!vif && chunk%16))return 2;
 FILE*f=fopen(argv[1],"rb");if(!f)return 2;unsigned char*p=malloc(chunk);if(!p)return 2;
 bully_overlay_geometry_init(&geom,flush,draw,0);BullyGif g;BullyVif v;bully_gif_init(&g,reg,upload,0);bully_vif_init(&v,&g);
 size_t n;while((n=fread(p,1,chunk,f))){if(!(vif?bully_vif_feed(&v,p,n,addr):bully_gif_feed(&g,p,n,addr)))return 3;addr+=(uint32_t)n;}
 fclose(f);free(p);flush(0);fprintf(stderr,"batches=%u\n",batches);return g.left || v.direct || v.skip || v.used?4:0;
}
