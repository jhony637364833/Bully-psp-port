static uint32_t seed=819;static uint32_t rnd(void){seed=seed*1664525u+1013904223u;return seed;}
static void setmode(unsigned mode,unsigned test){
#ifdef __PSP__
 uint32_t x=(test&1?0x01000000u:0)|mode|(test&2?0x00800000u:0);
 if(test%19==0)x|=0x80;
 clip_fpu_write(x);
#else
 int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(modes[mode]);feclearexcept(FE_ALL_EXCEPT);if(test&2)feraiseexcept(FE_INEXACT);
#endif
}
static unsigned ref_half(const uint8_t*p){return p[0]|((unsigned)p[1]<<8);}
static float fixed(const uint8_t*p){unsigned x=ref_half(p);return (x<32768?(int)x:(int)x-65536)*(1.0f/128);}
static void put16(uint8_t*p,unsigned x){p[0]=(uint8_t)x;p[1]=(uint8_t)(x>>8);}
static uint8_t memory[4][1600],before[4][1600];
static BullyNativeVertex expanded[256];static GeVertex expected[1024];
int main(void){
#ifdef __PSP__
 freopen("gpu-light.log","w",stdout);setvbuf(stdout,0,_IONBF,0);
#endif
 unsigned success=0,fallback=0,outside=0,inside=0,crossing=0;
 for(unsigned m=0;m<4;m++)for(unsigned t=0;t<2048;t++){
  setmode(0,4);memset(memory,0x93,sizeof memory);memset(expanded,0,sizeof expanded);
  const uint8_t *attrs[4];unsigned offset=(t%4)*2;for(unsigned k=0;k<4;k++)attrs[k]=memory[k]+offset;
  unsigned n=3+rnd()%254;
  BullyNativeLight light={0};memset(&object_view,0,sizeof object_view);object_view.near_plane=1;object_view.far_plane=100;
  for(unsigned k=0;k<3;k++){object_view.view[k][k]=1;light.gain[k]=(rnd()%1024)/512.0f;light.material[k]=(rnd()%256)/512.0f;}
  light.blend=t%2?((rnd()%512)/256.0f):0;light.material_alpha=(rnd()%256)/512.0f;light.monochrome=t%3==0;
  if(t%7==0){for(unsigned j=0;j<4;j++)for(unsigned k=0;k<3;k++)object_view.view[j][k]=((int)(rnd()%8192)-4096)/1024.0f;}
  if(t%11==0){uint32_t bits[]={0,0x80000000u,1,0x80000001u,0x00800000u,0x7f7fffffu,0x7f800000u,0xff800000u,0x7fc12345u,0x7f800001u};uint32_t x=bits[(t/11)%10];switch((t/11)%5){case 0:memcpy(&light.blend,&x,4);break;case 1:memcpy(&light.gain[t%3],&x,4);break;case 2:memcpy(&light.material[t%3],&x,4);break;case 3:memcpy(&light.material_alpha,&x,4);break;default:memcpy(&object_view.view[t%4][t%3],&x,4);break;}}
  if(t%13==0){object_view.near_plane=t%2?0.0001f:-1;object_view.far_plane=t%3?65536:object_view.near_plane;}
  for(unsigned i=0;i<n;i++){
   unsigned x=64+rnd()%128,y=32+rnd()%128,z=2560;
   if(t%5==0){x=rnd();y=rnd();z=rnd();}
   if(t%17==0)x=32768;
   put16(memory[0]+offset+6*i,x);put16(memory[0]+offset+6*i+2,y);put16(memory[0]+offset+6*i+4,z);
   if(i && t%3==0 && i%4)memcpy(memory[0]+offset+6*i,memory[0]+offset+6*(i-1),6);
   for(unsigned k=0;k<2;k++)put16(memory[1]+offset+4*i+2*k,rnd());
   for(unsigned k=2;k<4;k++){unsigned c=rnd()>>8;if(i && t%4==0)c=ref_half(memory[k]+offset+2*(i-1));if(k==3&&t%4==2)c=(c&0x7fff)|(ref_half(memory[k]+offset)&0x8000);put16(memory[k]+offset+2*i,c);}
   for(unsigned k=0;k<3;k++)expanded[i].position[k]=fixed(attrs[0]+6*i+2*k);
   for(unsigned k=0;k<2;k++)expanded[i].uv[k]=fixed(attrs[1]+4*i+2*k);
   unsigned c0=ref_half(attrs[2]+2*i),c1=ref_half(attrs[3]+2*i);
   for(unsigned k=0;k<3;k++){expanded[i].color[k]=((c0>>(5*k))&31)<<3;expanded[i].color_secondary[k]=((c1>>(5*k))&31)<<3;}
   expanded[i].color[3]=(c0&0x8000)?128:0;expanded[i].color_secondary[3]=(c1&0x8000)?128:0;
  }
  memcpy(before,memory,sizeof memory);material_light=t%7?&light:0;
  setmode(m,t);int ba=baseline_gpu_strip_bounds(expanded,n);setmode(m,t);int bb=raw_bounds(attrs[0],n);
  if(ba!=bb){printf("ERROR bounds %u %u %d %d\n",m,t,ba,bb);return 1;}
  outside+=ba<0;inside+=ba>0;crossing+=ba==0;
  int ret[2],space[2];uint32_t fcr[2];unsigned counts[2],tris[2],fs[2];
  for(unsigned side=0;side<2;side++){
   queued=t%2?3:0;memset(verts,0,sizeof verts);captured_count=triangles=flushes=0;gpu_vertex_space=t%2;
   setmode(m,t);ret[side]=side?draw_raw_batch(attrs,n,0):baseline_draw_gpu_strip(expanded,0,n);
   fcr[side]=clip_fpu_read();space[side]=gpu_vertex_space;flush_vertices();counts[side]=captured_count;tris[side]=triangles;fs[side]=flushes;
   if(!side)memcpy(expected,captured,captured_count*sizeof(*captured));
   else if(ret[0]!=ret[1]||fcr[0]!=fcr[1]||space[0]!=space[1]||counts[0]!=counts[1]||tris[0]!=tris[1]||fs[0]!=fs[1]||memcmp(expected,captured,counts[0]*sizeof(*captured))||memcmp(before,memory,sizeof memory)){
    printf("ERROR GPU mode=%u test=%u return=%d/%d FCR=%08x/%08x counts=%u/%u tris=%u/%u flush=%u/%u\n",m,t,ret[0],ret[1],fcr[0],fcr[1],counts[0],counts[1],tris[0],tris[1],fs[0],fs[1]);return 1;
   }
  }
  success+=ret[1]!=0;fallback+=ret[1]==0;
 }
 assert(success>100&&fallback>100&&inside>100&&outside>100&&crossing>100);
 printf("COMPLETE cases=8192 success=%u fallback=%u bounds=%u/%u/%u errors=0\n",success,fallback,inside,outside,crossing);fflush(stdout);
#ifdef __PSP__
 sceKernelExitGame();
#endif
 return 0;
}
