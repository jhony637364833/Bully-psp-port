#!/usr/bin/env bash
# Usage: bash tests/run_texture_cache_replay.sh HOST_BUILD RAM_SNAPSHOT CTX_SNAPSHOT
# Snapshots must be captured immediately before fn_0024d848 on the same host ABI.
set -euo pipefail
repo="$(cd "$(dirname "$0")/.." && pwd)"
build="$(realpath "$1")"
scratch="$(mktemp -d)"
trap 'rm -rf "$scratch"' EXIT
python3 - "$build/gen/main_029.c" "$scratch/cache_baseline.inc" <<'PYCODE'
import sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
start='void fn_0024d848__ynguest(' if 'void fn_0024d848__ynguest(' in s else 'void fn_0024d848('
s=s[s.index(start):s.index('void fn_0024dd68(')].replace(start,'void cache_baseline(',1)
Path(sys.argv[2]).write_text(s)
PYCODE
cc -O2 -g -fno-strict-aliasing -fsanitize=address,undefined \
 -I"$build/hle/rt" -I"$build/gen" -I"$scratch" \
 "$repo/tests/texture_cache_replay.c" -lm -o "$scratch/replay"
"$scratch/replay" "$2" "$3"
