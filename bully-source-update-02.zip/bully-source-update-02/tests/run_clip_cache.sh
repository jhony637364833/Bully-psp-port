#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bully_cache_tmp=$(mktemp -d)
trap 'rm -rf "$bully_cache_tmp"' EXIT
bully_cache_src=app/games/SLUS-21269_v1.02/src
bully_cache_flags=(-O2 -g -Wall -Wextra -Werror -fno-fast-math -frounding-math -ffp-contract=off -fsanitize=address,undefined -I"$bully_cache_src")
"${CC:-cc}" "${bully_cache_flags[@]}" -Dbully_clip_triangle=bully_clip_test03_triangle -Dbully_clip_vertex_code=bully_clip_test03_vertex_code -c tests/clip_test03_reference.c -o "$bully_cache_tmp/reference.o"
"${CC:-cc}" "${bully_cache_flags[@]}" tests/clip_cache_test.c "$bully_cache_src/world_clip.c" "$bully_cache_tmp/reference.o" -lm -o "$bully_cache_tmp/test"
"$bully_cache_tmp/test"
