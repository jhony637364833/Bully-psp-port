TARGET = bully_itof_test
OBJS = main.o reference_test.o candidate_test.o
INCDIR = .
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off
BUILD_PRX = 1
LIBS = -lm -lpsppower
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully exact range itof
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
