"""Generate sphere rejection tests from a converted matching Bully disc.
No game function bodies or game assets are distributed in these tests.
"""
from pathlib import Path
import argparse,re,shutil
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--build',type=Path,required=True);p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app');p.add_argument('--output',type=Path,required=True);a=p.parse_args()
build=a.build.resolve();app=a.app.resolve();d=a.output.resolve();d.mkdir(parents=True,exist_ok=True);t=Path(__file__).resolve().parent
rules=[]
for line in (app/'games/SLUS-21269_v1.02/lists/normalizer-reuse.tsv').read_text().splitlines():
 if line.startswith('fn_001313d0\t'):rules.append(line.split('\t'))
assert len(rules)==1,'requires the one bounded sphere predicate repair';_,old,new=rules[0]
bodies=[]
for source in (build/'gen').glob('main_*.c'):
 m=re.search(r'^void fn_001313d0\(R5900Ctx \*c\)\n\{\n.*?^\}',source.read_text(),re.M|re.S)
 if m:bodies.append(m[0])
assert len(bodies)==1;body=bodies[0]
if new in body:assert body.count(new)==1;body=body.replace(new,old)
assert body.count(old)==1 and body.count('vu0_ctc2(c, 16, (uint32_t)0ull);')==1
for label,s in [('baseline',body),('candidate',body.replace(old,new))]:
 s=s.replace('fn_001313d0',label+'_sphere')+'\n'
 (d/(label+'.c')).write_text('#include "r5900_rt.h"\n'+s)
 (d/(label+'-host.c')).write_text('#include "runtime_host.h"\n'+s)
shutil.copy2(build/'hle/rt/r5900_rt.h',d/'r5900_rt.h');shutil.copy2(app/'runtime/r5900_rt.h',d/'runtime_host.h')
shutil.copy2(t/'sphere_rejection_main.c',d/'main.c');shutil.copy2(t/'sphere_rejection_Makefile.inc',d/'Makefile')
print('Prepared32768 original-predicate/fullcontext/RAM/FPU cases; make here with PSPDEV or run check_sphere_rejection.py')
