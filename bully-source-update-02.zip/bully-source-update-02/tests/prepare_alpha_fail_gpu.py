"""Generate PSP differential from the production helper/flush and frozen build05."""
from pathlib import Path
repo=Path(__file__).resolve().parents[1]
s=(repo/'app/games/SLUS-21269_v1.02/src/psp/world_display.c').read_text()
constants=s[s.index('static const int alpha_functions'):s.index('void bully_world_begin')]
flush=s[s.index('static void flush_vertices'):s.index('static int init')].replace('flush_vertices','candidate_flush')
source=(repo/'tests/alpha_fail_gpu_head.inc').read_text()+constants+(repo/'tests/alpha_flush_test05_reference.inc').read_text()+flush+(repo/'tests/alpha_fail_gpu_support.inc').read_text()+(repo/'tests/alpha_fail_gpu_main.inc').read_text()
(repo/'tests/psp_alpha_fail/generated.c').write_text(source)
