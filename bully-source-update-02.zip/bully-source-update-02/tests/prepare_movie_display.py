"""Prepare synthetic movie display fixtures (no game assets)."""
from pathlib import Path
import argparse
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app');p.add_argument('--output',type=Path,required=True);a=p.parse_args();here=Path(__file__).parent
for variant in ['reference','candidate']:
 d=a.output/variant;d.mkdir(parents=True,exist_ok=True)
 for src,dst in [('movie_display_main.inc','main.c'),('movie_display_Makefile.inc','Makefile'),('movie_display_stub.inc','hle.h')]: (d/dst).write_bytes((here/src).read_bytes())
 source=here/'movie_display_reference.inc' if variant=='reference' else a.app/'games/SLUS-21269_v1.02/src/psp/movie_display.c';(d/'movie_display.c').write_bytes(source.read_bytes())
print('Build each directory with PSPDEV make; phases1..4 wait for ack.txt containing their number.')
