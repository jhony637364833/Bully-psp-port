#include "candidate/native_object.h"
#include <assert.h>
#include <stdio.h>
typedef int SceUID;
#define PSP_SMEM_High 1
#define LOG(...) ((void)0)
static BullyNativeSkinCache *skin_cache;
static int skin_cache_attempted;
static BullyNativeSkinCache storage;
static unsigned total,largest,allocs,frees,fail,nullhead;
static unsigned sceKernelTotalFreeMemSize(void){return total;}
static unsigned sceKernelMaxFreeMemSize(void){return largest;}
static int sceKernelAllocPartitionMemory(int p,const char*n,int type,unsigned bytes,void*v){assert(p==2 && n && type==PSP_SMEM_High && bytes==sizeof(storage) && !v);allocs++;return fail?-1:1;}
static void *sceKernelGetBlockHeadAddr(int id){assert(id==1);return nullhead?NULL:&storage;}
static void sceKernelFreePartitionMemory(int id){assert(id==1);frees++;}
@ALLOCATE_BODY@
int main(void){for(unsigned test=0;test<5;test++){
 skin_cache=NULL;skin_cache_attempted=allocs=frees=fail=nullhead=0;
 total=4*1024*1024;largest=total;
 if(test==0)total=sizeof(storage)+1024*1024-1;
 if(test==1)largest=sizeof(storage)-1;
 if(test==2)fail=1;
 if(test==3)nullhead=1;
 storage.complete=123;allocate_skin_cache();unsigned count=allocs;
 allocate_skin_cache();assert(allocs==count && skin_cache_attempted);
 if(test==4)assert(skin_cache==&storage && !skin_cache->complete);
 else assert(!skin_cache);
 assert(allocs==(test>=2));assert(frees==(test==3));
}puts("PASS five optional-allocation paths and one-attempt policy");return 0;}
