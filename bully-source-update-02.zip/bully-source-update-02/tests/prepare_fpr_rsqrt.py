"""Reproduce exact numerator-one rsqrt/FPR differential checks.

The frozen pre-change helper and generated normalizer are independent oracles.
Trace vectors are synthetic program inputs captured from the measured scene.
"""
from pathlib import Path
import argparse

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
 p.add_argument('--output',type=Path,required=True);a=p.parse_args();here=Path(__file__).parent;d=a.output;d.mkdir(parents=True,exist_ok=True)
 candidate=(a.app/'runtime/r5900_rt.h').read_text()
 start=candidate.index('/* Keep both numerator-one branches')
 end=candidate.index('static inline uint32_t fpu_madda5(',start)
 reference=candidate[:start]+(here/'fpr_rsqrt_reference.inc').read_text()+candidate[end:]
 body=(here/'fpr_normalizer_reference.inc').read_text()
 for name,header in [('reference',reference),('candidate',candidate)]:
  (d/name).mkdir(exist_ok=True);(d/name/'r5900_rt.h').write_text(header)
  text='#include "'+name+'/r5900_rt.h"\nuint32_t '+name+'_one(uint32_t t){return fpu_rsqrt5(0x3f800000u,t);}\nuint32_t '+name+'_generic(uint32_t s,uint32_t t){return fpu_rsqrt5(s,t);}\n'+body.replace('fn_001860c0',name+'_normalizer')
  (d/(name+'.c')).write_text(text)
 for src,dst in [('fpr_rsqrt_main.c','main.c'),('fpr_rsqrt_Makefile.inc','Makefile'),('fpr_rsqrt_trace.inc','trace.inc')]:
  (d/dst).write_bytes((here/src).read_bytes())
 print('Expected COMPLETE comparisons=128064 scalars=4016384 errors=0')

if __name__=='__main__':main()
