TARGET = bully_context_vfpu
OBJS = main.o candidate.o
INCDIR = .
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -Wno-unused-label -Wno-unused-variable -Wno-unused-but-set-variable -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fno-strict-aliasing
BUILD_PRX = 1
LIBS = -lm -lpsppower
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully context raw copy test
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
main.o candidate.o: r5900_rt.h context_fpr_reference.inc candidate.h context_fpr_vfpu_load.h context_fpr_vfpu_store.h
