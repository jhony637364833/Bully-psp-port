"""Exercise the actual overlay texture allocator and 512x512 upload at its bounds."""
from pathlib import Path
import argparse,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args();b=a.output or Path(tempfile.mkdtemp(prefix='bully-overlay-budget-'));b.mkdir(parents=True,exist_ok=True)
g=Path(__file__).resolve().parents[1]/'app/games/SLUS-21269_v1.02/src';s=(g/'psp/overlay_live.c').read_text()
start=s.index('static Cache *texture(');end=s.index('\nvoid bully_overlay_flush',start)
head=r'''
#include <stdint.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "overlay_texture.h"
#include "native_memory.h"
#define ARENA_BYTES BULLY_OVERLAY_ARENA_BYTES
#define PSP_SMEM_High 2
typedef int SceUID;
static unsigned char ram[300000],block[ARENA_BYTES+16] __attribute__((aligned(16)));
static uint8_t *hle_ram=ram;static uint32_t hle_ram_end=sizeof ram;
static unsigned total_free,max_free,mode,allocs,frees,writes;
static unsigned sceKernelTotalFreeMemSize(void){return total_free;}
static unsigned sceKernelMaxFreeMemSize(void){return max_free;}
static int sceKernelAllocPartitionMemory(int p,const char*n,int t,unsigned bytes,void*at){assert(p==2&&!strcmp(n,"overlay_tex")&&t==2&&bytes==ARENA_BYTES&&!at);allocs++;return mode==1?-1:17;}
static void *sceKernelGetBlockHeadAddr(int id){assert(id==17);return mode==2?0:block;}
static void sceKernelFreePartitionMemory(int id){assert(id==17);frees++;}
static void sceKernelDcacheWritebackRange(const void*p,unsigned n){assert(p>= (const void*)block && (const unsigned char*)p+n<=block+ARENA_BYTES);writes++;}
'''
# Retain the production cache/upload layouts and complete texture() implementation.
a0=s.index('typedef struct{uint32_t addr,bytes,serial;} Upload;');a1=s.index('static unsigned list',a0)
c0=s.index('typedef struct{uint64_t tex0;');c1=s.index('int bully_world_overlay_begin',c0)
main=r'''
static void w64(unsigned off,uint64_t v){memcpy(ram+off,&v,8);}
static void packet(unsigned at,unsigned w,unsigned h,unsigned bytes){
 w64(at,3ull|(1ull<<60));w64(at+8,14);
 w64(at+16,0);w64(at+24,0x51);w64(at+32,w|((uint64_t)h<<32));w64(at+40,0x52);
 w64(at+48,0);w64(at+56,0x53);w64(at+64,bytes/16u|(2ull<<58));
}
static void reset(unsigned m){
 serial=2;caches=arena_used=attempted=0;arena=0;mode=m;allocs=frees=writes=0;
 total_free=ARENA_BYTES+1024u*1024u;max_free=ARENA_BYTES;
 memset(block,0xcd,sizeof block);memset(cache,0,sizeof cache);memset(bully_overlay_stats,0,sizeof bully_overlay_stats);
}
int main(void){
 const uint64_t t=UINT64_C(0x2004e00665322300);unsigned pix=64,pn=262144+80,pal=pix+pn,cn=1024+80;
 packet(pix,256,256,262144);packet(pal,16,16,1024);w64(pal+80,UINT64_C(0x800000ff800000ff));
 uploads[t&16383]=(Upload){pix,pn,1};uploads[(t>>37)&16383]=(Upload){pal,cn,2};
 for(unsigned test=0;test<5;test++){
  reset(test==2?1:test==3?2:0);
  if(test==0)total_free--;if(test==1)max_free--;
  Cache*c=texture(t);
  if(test<4){assert(!c&&attempted);assert(allocs==(test>=2));assert(frees==(test==3));assert(!writes);assert(!texture(t));assert(allocs==(test>=2));}
  else{
   assert(c&&allocs==1&&!frees&&writes==1);
   assert(c->tex.total_bytes==263168&&c->tex.total_bytes>192u*1024u&&c->tex.total_bytes<=ARENA_BYTES);
   for(unsigned i=0;i<262144;i++)assert(block[i]==0);
   for(unsigned i=c->tex.total_bytes;i<sizeof block;i++)assert(block[i]==0xcd);
   assert(texture(t)==c&&bully_overlay_stats[6]==1&&writes==1&&allocs==1);
   TcPs2Info info;TcPolicy pol;TcPspTex plan;assert(bully_overlay_texture_plan(ram,sizeof ram,t,pix,pn,pal,cn,&info,&pol,&plan));
   memset(block,0xcd,sizeof block);assert(tc_convert(&info,&pol,&plan,block,192u*1024u)==TC_ERR_ARG);
   for(unsigned i=0;i<sizeof block;i++)assert(block[i]==0xcd);
  }
 }
 reset(0);uploads[t&16383].addr=sizeof ram;assert(!texture(t)&&!allocs);
 uploads[t&16383]=(Upload){pix,pn,1};assert(!texture(t+(UINT64_C(1)<<26))&&!allocs);
 reset(0);uploads[(t>>37)&16383].bytes=79;assert(!texture(t));
 for(unsigned i=0;i<sizeof block;i++)assert(block[i]==0xcd);
 puts("PASS actual overlay allocator: low total/fragmentation/alloc failure/null head/success; 512x512 indexed upload fits; old192KiB rejected without write; cache reuse; malformed/range/size guards");return 0;
}
'''
(b/'budget.c').write_text(head+s[a0:a1]+s[c0:c1]+s[start:end]+main)
subprocess.run(['gcc','-O2','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie','-I'+str(g),str(b/'budget.c'),str(g/'overlay_texture.c'),str(g/'texconv.c'),'-o',str(b/'budget')],check=True)
subprocess.run([str(b/'budget')],check=True)
