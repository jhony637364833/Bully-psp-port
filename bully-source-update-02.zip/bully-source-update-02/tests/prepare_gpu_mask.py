from pathlib import Path
import re
import argparse
r=Path(__file__).resolve().parents[1];g=r/'app/games/SLUS-21269_v1.02/src';t=r/'tests'
a=argparse.ArgumentParser();a.add_argument('output',type=Path);args=a.parse_args();d=args.output.resolve();d.mkdir(parents=True,exist_ok=True)
head='''#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include "native_object.h"
#include "native_light.h"
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("GPU light reuse check",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER|THREAD_ATTR_VFPU);
#endif
'''+(r/'tests/renderer_fpu_test.inc').read_text()+'''
#define WORLD_BATCH_VERTICES 384
static BullyNativeObject object_view;
static const BullyNativeLight *material_light;
typedef struct {float u,v;uint32_t color;float x,y,z;} GeVertex;
static GeVertex verts[384],captured[1024];
static unsigned queued,triangles,captured_count,flushes,reuse_hits,primary_hits,extra_reuse;
static int gpu_vertex_space;
static void flush_vertices(void){assert(captured_count+queued<=1024);memcpy(captured+captured_count,verts,queued*sizeof(*verts));captured_count+=queued;queued=0;flushes++;}
static unsigned channel(float f){return f<=0?0:f>=255?255:(unsigned)f;}
'''
parts=[]
for label in ['baseline','candidate']:
 s=(t/'gpu_mask_reference_81.inc').read_text() if label=='baseline' else (g/'psp/world_display.c').read_text()
 if label=='candidate':s=s[s.index('static int gpu_strip_bounds'):s.index('static void draw_accelerated_strip')]
 if label=='candidate':s=s.replace('color=prepared[i-1].color;', 'reuse_hits++;if(primary_only&&!gpu_same_colors(&v[i-1],&v[i]))extra_reuse++;color=prepared[i-1].color;').replace('if(primary_only) {', 'if(primary_only) {primary_hits++;')
 for n in ['gpu_strip_bounds','gpu_same_position','gpu_same_colors','gpu_same_masked_colors','draw_gpu_strip']:s=re.sub(r'\b'+n+r'\b',label+'_'+n,s)
 parts.append(s)
(d/'main.c').write_text(head+'\n'.join(parts)+(t/'gpu_mask_main.inc').read_text())
(d/'Makefile').write_text('TARGET = gpu_light\nOBJS = main.o native_light.o\nINCDIR = '+str(g)+'\nVPATH = '+str(g)+'\nCFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -fno-fast-math -frounding-math -ffp-contract=off\nBUILD_PRX = 1\nLIBS = -lm\nEXTRA_TARGETS = EBOOT.PBP\nPSPSDK = $(shell psp-config --pspsdk-path)\ninclude $(PSPSDK)/lib/build.mak\n')
