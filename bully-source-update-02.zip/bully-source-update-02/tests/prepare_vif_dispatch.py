from pathlib import Path
import shutil
import argparse
r=Path(__file__).resolve().parents[1];g=r/'app/games/SLUS-21269_v1.02/src';t=r/'tests'
p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();d=a.output.resolve();d.mkdir(parents=True,exist_ok=True)
for n in ['native_vif.h','native_gif.h']:shutil.copy2(g/n,d/n)
for label in ['baseline','candidate']:
 s=(t/'vif_reference_76.inc').read_text() if label=='baseline' else (g/'native_vif.c').read_text()
 if label=='baseline':s='#define bully_vif_init baseline_init\n#define bully_vif_feed baseline_feed\n'+s
 (d/(label+'.c')).write_text(s)
shutil.copy2(t/'vif_dispatch_main.inc',d/'main.c')
(d/'Makefile').write_text('''.DEFAULT_GOAL := all
TARGET = vif_dispatch
OBJS = main.o baseline.o candidate.o
INCDIR = .
CFLAGS = -O2 -G0 -std=gnu11 -Wall -Wextra -Werror
BUILD_PRX = 1
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = VIF dispatch comparison
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
$(OBJS): native_vif.h native_gif.h
''')
