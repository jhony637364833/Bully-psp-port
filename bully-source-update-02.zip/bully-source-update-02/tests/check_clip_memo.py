"""Run the portable exact-clipping memo regression; requires host GCC only."""
from pathlib import Path
import argparse,subprocess,tempfile,sys
repo=Path(__file__).resolve().parents[1];g=repo/'app/games/SLUS-21269_v1.02/src';t=repo/'tests'
a=argparse.ArgumentParser();a.add_argument('--output',type=Path);args=a.parse_args()
with tempfile.TemporaryDirectory(prefix='bully-clip-memo-') as tmp:
 base=args.output.resolve() if args.output else Path(tmp);base.mkdir(parents=True,exist_ok=True)
 subprocess.run([sys.executable,str(t/'prepare_clip_memo.py'),str(base)],check=True)
 for kind in ['math','renderer']:
  p=base/kind;extra=p/'reference.c' if kind=='math' else g/'native_light.c'
  cmd=['gcc','-O2','-Wall','-Wextra','-Werror','-Wno-unused-function','-Wno-misleading-indentation','-fno-fast-math','-frounding-math','-ffp-contract=off','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(p),'-I'+str(g),str(p/'main.c'),str(p/'world_clip.c'),str(extra),'-lm','-o',str(p/'host-check')]
  subprocess.run(cmd,check=True);subprocess.run([str(p/'host-check')],check=True)
 subprocess.run(['gcc','-O2','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-fsanitize=address,undefined','-I'+str(g),str(t/'clip_memo_retention.c'),'-o',str(base/'retention')],check=True)
 subprocess.run([str(base/'retention')],check=True)
 subprocess.run([sys.executable,str(t/'check_clip_memo_runtime.py'),'--output',str(base/'runtime')],check=True)
print('PASS independent build38 math/renderer comparisons, warm-hit FPU state, mutations, collisions, allocation and camera guards')
