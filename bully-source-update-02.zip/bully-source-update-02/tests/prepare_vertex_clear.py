"""Generate PSP/host full-byte vertex-clear and compressed-mesh checks (build49)."""
from pathlib import Path
import argparse
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();here=Path(__file__).parent;d=a.output;d.mkdir(parents=True,exist_ok=True)
g=a.app/'games/SLUS-21269_v1.02/src'
for f in g.glob('*.h'):(d/f.name).write_bytes(f.read_bytes())
(d/'native_light.c').write_bytes((g/'native_light.c').read_bytes())
for name in ['baseline','candidate']:
 source=(g/'native_mesh.c').read_text()
 if name=='baseline':source=source.replace('bully_native_vertex_clear(v);','memset(v,0,sizeof(*v));')
 source=source.replace('bully_compressed_chain',name+'_compressed').replace('bully_native_decode',name+'_decode')
 (d/(name+'-native_mesh.c')).write_text(source)
 source=(g/'psp/world_display.c').read_text()
 at=source.index('static void prepare_vertex(')
 source=source[at:source.index('static void triangle(',at)]
 source=source.replace('static void prepare_vertex(', 'void '+name+'_prepare(')
 (d/(name+'-prepare.c')).write_text('#include "native_object.h"\n#include "native_light.h"\n#include "world_clip.h"\nextern BullyNativeObject object_view;\nextern const BullyNativeLight *material_light;\n'+source)
source=(here/'compressed_validation_test.c').read_text()
# Renaming main removes C's implicit return; make it explicit.
at=source.rfind('}')
source=source[:at]+'    return 0;\n'+source[at:]
(d/'compressed_checks.inc').write_text(source)
for src,dst in [('vertex_clear_main.c','main.c'),('vertex_clear_Makefile.inc','Makefile')]:
 (d/dst).write_bytes((here/src).read_bytes())
print('Expected COMPLETE vertex=32768 clear=32768 compressed=80000 ... errors=0')
