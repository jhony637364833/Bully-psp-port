static unsigned seed=19275;
static unsigned rnd(void){seed=seed*1664525u+1013904223u;return seed;}
int main(void){
 unsigned certified=0,unchanged=0;Command reference[2048];
 for(unsigned test=0;test<20000;test++){
  BullyNativeState state={0};state.test=(test%11!=0)|((test%8)<<1)|((rnd()%128)<<4)|((test%5!=0)<<12);state.zmask=(test%7==0);
  texture_alpha_minimum_valid=0;
  material_state=test%19?&state:0;has_texture=rnd()%2;texture.texture.alpha_class=rnd()%3;
  unsigned n=(test%129)*3;GeVertex saved[384];memset(verts,0,sizeof verts);
  for(unsigned i=0;i<n;i++){unsigned rgb=rnd()&0xffffffu;unsigned a=rnd()>>24;if(test%3==0)a%=alpha_reference(&state)+1;verts[i].color=rgb|(a<<24);}
  memcpy(saved,verts,sizeof saved);
  unsigned initial_fn=(state.test>>1)&7,initial_ref=alpha_reference(&state),initial_mask=state.zmask;
  queued=n;int proven=all_alpha_fail();commands=draw_calls=0;alpha_fn=initial_fn;alpha_ref=initial_ref;depth_mask=initial_mask;
  reference_flush();unsigned old_commands=commands,old_draws=draw_calls,old_fn=alpha_fn,old_ref=alpha_ref,old_mask=depth_mask;memcpy(reference,trace,commands*sizeof(*trace));assert(!queued);
  queued=n;commands=draw_calls=0;alpha_fn=initial_fn;alpha_ref=initial_ref;depth_mask=initial_mask;flush_vertices();
  assert(!queued && !memcmp(saved,verts,sizeof saved));assert(alpha_fn==old_fn && alpha_ref==old_ref && depth_mask==old_mask);assert(draw_calls<=old_draws);
  if(!proven){assert(commands==old_commands && !memcmp(reference,trace,commands*sizeof(*trace)));unchanged++;}
  else{
   assert(commands==8 && draw_calls==1);assert(trace[2].kind==3 && trace[2].a==inverse_alpha[initial_fn]);assert(trace[3].kind==4 && trace[3].a==1);
   assert(trace[4].kind==5 && trace[4].a==0 && trace[4].b==n);assert(trace[5].kind==3 && trace[5].a==initial_fn);assert(trace[6].kind==4 && trace[6].a==initial_mask);certified++;
  }
 }
 assert(certified && unchanged);printf("20000 command/state comparisons PASS: %u certified, %u unchanged fallbacks\n",certified,unchanged);return 0;
}
