#include "world_clip.h"
#include <assert.h>
#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <math.h>
int baseline_clip(const BullyClipVertex*,float,float,BullyClipVertex*);
static uint32_t seed=91231;
static float randf(void){seed=seed*1664525u+1013904223u;return (seed>>8)*(1.0f/16777216.0f);}
int main(void){
 for(int n=0;n<100000;n++){
  BullyClipVertex in[3],a[10],b[10];
  for(int i=0;i<3;i++){
   for(int k=0;k<3;k++){in[i].p[k]=randf()*150-25;in[i].color[k]=randf()*255;}
   in[i].alpha=randf()*255;
   for(int k=0;k<2;k++)in[i].uv[k]=randf()*4-2;
  }
  if(n%8==0)for(int i=0;i<3;i++){in[i].p[2]=2+randf()*97;in[i].p[0]=randf()*in[i].p[2];in[i].p[1]=randf()*in[i].p[2];}
  if(n%101==0)in[0].p[0]=NAN;
  if(n%103==0)in[1].uv[0]=INFINITY;
  int na=baseline_clip(in,1,100,a),nb=bully_clip_triangle(in,1,100,b);
  assert(na==nb);for(int i=0;i<na;i++){assert(!memcmp(a[i].p,b[i].p,sizeof a[i].p));assert(!memcmp(a[i].color,b[i].color,sizeof a[i].color));assert(!memcmp(a[i].uv,b[i].uv,sizeof a[i].uv));}
 }
 /* Analytic near-plane intersections: alpha endpoints 0/200, halfway=100. */
 BullyClipVertex in[3]={{{0,0,0},{0,0,0},{0,0},0},{{0,0,2},{0,0,0},{0,0},200},{{1,1,2},{0,0,0},{0,0},200}},out[10];
 int count=bully_clip_triangle(in,1,100,out),near_count=0;assert(count==4);
 for(int i=0;i<count;i++)if(out[i].p[2]==1){assert(out[i].alpha==100);near_count++;}
 assert(near_count==2);in[1].alpha=NAN;assert(!bully_clip_triangle(in,1,100,out));
 puts("100000 differential clipping cases PASS");
}
