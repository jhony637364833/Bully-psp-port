#include "candidate/world_clip.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#ifdef __PSP__
#include <pspkernel.h>
#include <psppower.h>
PSP_MODULE_INFO("Bully clip mask test",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
PSP_MAIN_THREAD_STACK_SIZE_KB(128);
static void mode(unsigned m,unsigned p){uint32_t f=0x01000000u|m|((p&1)?0x800000u:0)|((p&2)?0x7cu:0);__asm__ volatile("ctc1 %0,$31"::"r"(f):"memory");}
static uint32_t status(int dep){uint32_t f;__asm__ volatile("cfc1 %0,$31":"=r"(f):"r"(dep):"memory");return f;}
#else
#include <fenv.h>
static void mode(unsigned m,unsigned p){static const int r[]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};fesetround(r[m]);feclearexcept(FE_ALL_EXCEPT);if(p&2)feraiseexcept(FE_INVALID|FE_DIVBYZERO|FE_OVERFLOW|FE_UNDERFLOW|FE_INEXACT);}
static uint32_t status(int dep){(void)dep;return (uint32_t)fetestexcept(FE_ALL_EXCEPT);}
#endif
#define DECL(n) uint32_t n##_key(uint32_t);int n##_code(const BullyClipVertex*,float,float);int n##_triangle(const BullyClipVertex*,float,float,BullyClipVertex*);int n##_cached(const BullyClipVertex*,float,float,BullyClipVertex*,BullyClipCache*);void n##_reset(BullyClipCache*);
DECL(reference) DECL(candidate)
static FILE *f;static unsigned keys,codes,polygons,passed;
static uint32_t seed=0x751e938bu;
static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static float value(uint32_t b){float v;memcpy(&v,&b,4);return v;}
static const uint32_t edge[]={0,0x80000000,1,0x80000001,0x007fffff,0x807fffff,0x00800000,0x80800000,0x3f7fffff,0x3f800000,0xbf800000,0x3f800001,0x7f7fffff,0xff7fffff,0x7f800000,0xff800000,0x7fc12345,0x7f801234,0x00800001,0x80800001,0x3fffffff,0xbfffffff};
static int key(uint32_t b){keys++;if(reference_key(b)!=candidate_key(b)){fprintf(f,"ERROR key=%08lx\n",(unsigned long)b);return 1;}return 0;}
static int code(const BullyClipVertex *v,float near,float far,unsigned m){
 mode(m,codes&3);int a=reference_code(v,near,far);uint32_t fa=status(a);
 mode(m,codes&3);int b=candidate_code(v,near,far);uint32_t fb=status(b);codes++;
 if(a!=b || fa!=fb){fprintf(f,"ERROR code=%u mode=%u value=%d/%d csr=%08lx/%08lx\n",codes,m,a,b,(unsigned long)fa,(unsigned long)fb);return 1;}return 0;
}
typedef struct {uint32_t before;BullyClipCache cache;uint32_t after;} GuardedCache;
static GuardedCache ca,cb;
static int polygon(const BullyClipVertex*in,float near,float far,unsigned m,unsigned kind){
 struct {uint32_t before;BullyClipVertex out[10];uint32_t after;} a,b;
 memset(&a,0x5a,sizeof(a));b=a;
 mode(m,polygons&3);int na=kind==0?reference_triangle(in,near,far,a.out):reference_cached(in,near,far,a.out,kind==1?NULL:&ca.cache);uint32_t fa=status(na);
 mode(m,polygons&3);int nb=kind==0?candidate_triangle(in,near,far,b.out):candidate_cached(in,near,far,b.out,kind==1?NULL:&cb.cache);uint32_t fb=status(nb);polygons++;
 if(na!=nb || fa!=fb || memcmp(&a,&b,sizeof(a)) || memcmp(&ca,&cb,sizeof(ca))){fprintf(f,"ERROR polygon=%u mode=%u kind=%u n=%d/%d csr=%08lx/%08lx\n",polygons,m,kind,na,nb,(unsigned long)fa,(unsigned long)fb);return 1;}if(na)passed++;return 0;
}
int main(void){
#ifdef __PSP__
 scePowerSetClockFrequency(333,333,166);f=fopen("clip-mask.log","w");
#else
 f=stdout;
#endif
 if(!f)return 2;
 for(unsigned i=0;i<sizeof(edge)/sizeof(*edge);i++)if(key(edge[i]))goto fail;
 for(unsigned i=0;i<1048576;i++)if(key(rnd()))goto fail;
 /* Every mantissa at both signs, with exponents0,1,126,254,255 sampled
  * by a rotating five-way sweep. Boundary edges above cover exact endpoints. */
 static const unsigned exponents[]={0,1,126,254,255};
 for(uint32_t i=0;i<0x800000u;i++)for(unsigned sign=0;sign<2;sign++)if(key((sign<<31)|(exponents[i%5]<<23)|i))goto fail;
 for(unsigned m=0;m<4;m++){
  memset(&ca,0xa5,sizeof(ca));cb=ca;reference_reset(&ca.cache);candidate_reset(&cb.cache);
  for(unsigned i=0;i<20000;i++){
   BullyClipVertex v;
   for(unsigned k=0;k<9;k++){uint32_t u=i<22?edge[(i+k)%22]:rnd();memcpy((uint8_t*)&v+k*4,&u,4);}
   float near=i%7?1:value(edge[i%22]),far=i%11?100:value(edge[(i+7)%22]);
   if(code(&v,near,far,m)||code(i%127?&v:NULL,near,far,m))goto fail;
  }
  for(unsigned i=0;i<3000;i++){
   BullyClipVertex in[3];
   for(unsigned v=0;v<3;v++){
    for(unsigned k=0;k<3;k++){in[v].p[k]=(float)((int)(rnd()%257)-64)/8;in[v].color[k]=(float)(rnd()%256);}
    for(unsigned k=0;k<2;k++)in[v].uv[k]=(float)((int)(rnd()%129)-64)/16;
    in[v].alpha=(float)(rnd()%256);
   }
   if(i<22)for(unsigned v=0;v<3;v++)in[v].p[i%3]=value(edge[(i+v)%22]);
   if(i%13==0)in[0].alpha=value(edge[(i/13)%22]);
   if(i%17==0){reference_reset(&ca.cache);candidate_reset(&cb.cache);}
   float near=i%101?1:value(edge[(i/101)%22]),far=i%97?100:value(edge[(i/97)%22]);
   for(unsigned kind=0;kind<3;kind++){
    if(polygon(in,near,far,m,kind)||polygon(in,near,far,m,kind))goto fail;
   }
   if(i%199==0)if(polygon(NULL,near,far,m,2))goto fail;
  }
  fprintf(f,"mode=%u keys=%u codes=%u polygons=%u accepted=%u errors=0\n",m,keys,codes,polygons,passed);fflush(f);
 }
 fprintf(f,"COMPLETE keys=%u codes=%u polygons=%u accepted=%u errors=0\n",keys,codes,polygons,passed);fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 0;
fail:fflush(f);
#ifdef __PSP__
 fclose(f);sceKernelExitGame();
#endif
 return 1;
}
