# Original scheduler reference: PS2RC 0.1.1, commit 332a437f21f7ef694943caef885a7d28410cbc41.
# Retain app/LICENSE and app/NOTICE.md.
from pathlib import Path
import subprocess
import argparse
parser=argparse.ArgumentParser(description='Compare actual scheduler polling boundaries with the original PS2RC 0.1.1 function')
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--scheduler', type=Path, default=Path(__file__).resolve().parents[1]/'app/hle/core/hle_sched.c')
args=parser.parse_args()
b=args.output.resolve();b.mkdir(parents=True,exist_ok=True)
pre=r'''
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define RC_BACKEDGE_PERIOD 1024u
#define HLE_PACK_WAIT_LOOP_QUANTUM 1
#define PZ_SCOPE(x) (void)0
#define is_wait_loop(x) ((x)==0x1f3ac4u || (x)==0x1f5a84u)
typedef struct {int dummy;} R5900Ctx;
static uint32_t be_skipped,hle_backedge_count,hle_where,last_slow_where;
static int hle_in_intr,hle_opt_idle_skip;
static uint64_t hle_stat_backedges,hle_stat_idle_skips,hle_stat_idle_skipped_cycles,hle_vtime;
static uint64_t times[128],observed[128];static unsigned kind[128],num,idx,pending,counter,handler_cost;
static void backedge_soon(void){if(hle_backedge_count<1023){be_skipped+=1023-hle_backedge_count;hle_backedge_count=1023;}}
static uint64_t next_event_time(void){return idx<num?times[idx]:hle_vtime+100000;}
static void due_events(void){while(idx<num && times[idx]<=hle_vtime){pending|=1u<<idx;backedge_soon();idx++;}}
/* Pending event identities are stored separately to avoid 32-bit mask limits. */
static unsigned delivered;
static void hle_deliver_interrupts(void){while(delivered<idx){observed[delivered]=hle_vtime;if(kind[delivered])counter++;delivered++;hle_vtime+=handler_cost;}pending=0;}
static void hle_check_limits(void){}
static void hle_time_charge(uint64_t n){hle_vtime+=n;due_events();}
static void hle_safe_point(R5900Ctx*c,uint64_t n){(void)c;hle_time_charge(n);hle_deliver_interrupts();}
static void hle_bootpace_pace(uint64_t n){(void)n;}
static void hle_plat_pace(uint64_t n){(void)n;}
static void (*hle_pack_pace)(uint64_t);
'''.replace('pending|=1u<<idx;','pending=1;')
base='void hle_backedge_slow(R5900Ctx *c)\n{\n    uint32_t done = RC_BACKEDGE_PERIOD - be_skipped;    /* back-edges really executed since the last slow path */\n    be_skipped = 0;\n    hle_backedge_count = 0;\n    hle_stat_backedges += done;\n    if (!c || hle_in_intr) { hle_time_charge(8ull * done); return; }\n    hle_safe_point(c, 8ull * done);\n    uint32_t w = hle_where;\n    int skip = hle_opt_idle_skip && w == last_slow_where && is_wait_loop(w);\n    last_slow_where = w;\n    if (!skip) return;\n    uint64_t t = next_event_time();\n    if (t > hle_vtime) {\n        { PZ_SCOPE(pace); hle_bootpace_pace(t); if (hle_pack_pace) hle_pack_pace(t); hle_plat_pace(t); }   /* never ahead of real time (PAL frame pacing) */\n        hle_stat_idle_skipped_cycles += t - hle_vtime;\n        hle_vtime = t;\n    }\n    hle_stat_idle_skips++;\n    due_events();\n    hle_check_limits();\n    hle_deliver_interrupts();\n}\n\nvoid hle_safe_point(';cand=args.scheduler.read_text()
def fn(s,name):return s[s.index('void hle_backedge_slow('):s.index('\nvoid hle_safe_point(',s.index('void hle_backedge_slow('))].replace('void hle_backedge_slow(',f'void {name}(')
main=r'''
typedef struct {uint64_t time,obs[128];unsigned count,be,backedge,events,delivered;} Result;
static uint32_t seed=0x353535;static uint32_t rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static Result run(void(*f)(R5900Ctx*),unsigned opt,unsigned start,unsigned old,unsigned mode,uint64_t now,unsigned bc){
 hle_vtime=now;hle_backedge_count=bc;be_skipped=0;hle_where=mode?0x1f5a84:0x1f3ac4;last_slow_where=0;hle_in_intr=0;hle_opt_idle_skip=opt;idx=delivered=pending=0;counter=start;hle_stat_idle_skips=hle_stat_idle_skipped_cycles=hle_stat_backedges=0;memset(observed,0,sizeof observed);
 R5900Ctx c={0};unsigned guard=0;
 while((mode?counter==old:counter<2) && ++guard<100000){hle_backedge_count=1024;f(&c);}
 if(guard>=100000){fprintf(stderr,"timeout\n");exit(1);}
 Result r={0};r.time=hle_vtime;r.count=counter;r.be=be_skipped;r.backedge=hle_backedge_count;r.events=idx;r.delivered=delivered;memcpy(r.obs,observed,sizeof observed);return r;
}
int main(void){
 for(unsigned i=0;i<20000;i++){
  uint64_t now=rnd()%1000000,t=now;num=16;handler_cost=rnd()%128;
  for(unsigned j=0;j<num;j++){t+=1+rnd()%20000;times[j]=t;kind[j]=j%3==2;}
  unsigned mode=i&1,start=rnd()%2,bc=rnd()%1024;
  Result a=run(reference,0,start,start,mode,now,bc),c=run(candidate,1,start,start,mode,now,bc);
  if(memcmp(&a,&c,sizeof a)){fprintf(stderr,"mismatch case %u time %llu/%llu counter %u/%u be %u/%u backedge %u/%u events %u/%u delivered %u/%u\n",i,(unsigned long long)a.time,(unsigned long long)c.time,a.count,c.count,a.be,c.be,a.backedge,c.backedge,a.events,c.events,a.delivered,c.delivered);return 1;}
 }
 puts("PASS 20000 actual scheduler function comparisons: virtual time, every event delivery timestamp, wait counter, backedge/interrupt state exact");return 0;
}
'''
(b/'quantized-test.c').write_text(pre+fn(base,'reference')+fn(cand,'candidate')+main)
subprocess.run(['gcc','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-Wall','-Wextra','-Werror',str(b/'quantized-test.c'),'-o',str(b/'quantized-test')],check=True)
subprocess.run([str(b/'quantized-test')],check=True)
