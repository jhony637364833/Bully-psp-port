#define R5900_CS_VFPU 1
#include "r5900_rt.h"
int rt_cs_vfpu_enabled;
void candidate_enable(int enabled){rt_cs_vfpu_enabled=enabled;}
void candidate_save(const R5900Ctx*c,R5900CSave*s){rt_cs_save(c,s);}
void candidate_restore(R5900Ctx*c,const R5900CSave*s){rt_cs_restore(c,s);}
