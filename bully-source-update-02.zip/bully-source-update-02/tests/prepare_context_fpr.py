"""Prepare saved FPR raw-transfer differential checks using the current runtime."""
from pathlib import Path
import argparse
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--app',type=Path,default=Path(__file__).resolve().parents[1]/'app')
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);here=Path(__file__).parent
(a.output/'r5900_rt.h').write_bytes((a.app/'runtime/r5900_rt.h').read_bytes())
for src,dst in [('context_fpr_main.c','main.c'),('context_fpr_candidate.c','candidate.c'),('context_fpr_api.inc','candidate.h'),('context_fpr_Makefile.inc','Makefile'),('context_fpr_reference.inc','context_fpr_reference.inc'),('context_fpr_vfpu_load.h','context_fpr_vfpu_load.h'),('context_fpr_vfpu_store.h','context_fpr_vfpu_store.h')]:
 (a.output/dst).write_bytes((here/src).read_bytes())
print('Expected COMPLETE comparisons=16000 errors=0; flag off/on, four rounding modes, register/control preservation')
