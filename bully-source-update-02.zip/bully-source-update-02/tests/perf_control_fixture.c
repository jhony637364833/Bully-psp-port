#include "r5900_rt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("ControlTest",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
#endif
static uint32_t hle_cop0[32];
static int hle_in_intr;
static struct { int intr_disabled; } dummy_thread, *hle_cur=&dummy_thread;
static void hle_deliver_interrupts(void) { abort(); }
static uint32_t cop0_read(int rd) { if(rd!=25)abort();return hle_cop0[rd]; }
#define ST_EIE 0x10000u
#define VVLOG(...) ((void)0)
#define VLOG(...) ((void)0)
void rt_fatal(R5900Ctx *c,const char *what,uint32_t pc,uint32_t value) {
 (void)pc;
 if(((value>>11)&31)!=25 || (value&63))abort();
 #include "cop0_moves.inc"
 abort();
}
/* DECLARATIONS */
struct Case {void (*f)(R5900Ctx *);unsigned kind,selector;};
static const struct Case cases[]={
/* CASES */
};
static uint32_t rng=0x598f0ac9;
static uint32_t next(void){rng^=rng<<13;rng^=rng>>17;return rng^=rng<<5;}
static R5900Ctx actual,expected;
static uint8_t ram[16];
static unsigned tests;
int main(void) {
 FILE *result=stdout;
 #ifdef __PSP__
 result=fopen("control-results.txt","w");if(!result)sceKernelExitGame();
 #endif
 for(unsigned i=0;i<sizeof(cases)/sizeof(*cases);i++)for(unsigned j=0;j<260;j++) {
  memset(&actual,0,sizeof(actual));actual.ram=ram;actual.ram_mask=15;
  for(unsigned r=1;r<32;r++)for(unsigned lane=0;lane<4;lane++)actual.r[r].w[lane]=next();
  for(unsigned k=0;k<32;k++)hle_cop0[k]=0xfeed0000u+k;
  uint32_t control=j==0?0:j==1?0xffffffffu:j==2?0x80000000u:j==3?0x7fffffffu:next();
  hle_cop0[25]=control;expected=actual;const struct Case *t=&cases[i];uint32_t wanted=control;
  if(t->kind==0){expected.r[2].d[0]=expected.r[3].d[0]=(uint64_t)(int64_t)(int32_t)control;}
  else if(t->kind==1){if(!t->selector)wanted=actual.r[4].w[0];expected.r[3].d[0]=actual.r[4].d[0];expected.r[2].d[0]=(uint64_t)(int64_t)(int32_t)wanted;}
  else if(t->kind==3){wanted=0;expected.r[2].d[0]=0;}
  else if(t->kind==4){wanted=control&0x7fffffffu;expected.r[2].d[0]=0xffffffff80000000ull;expected.r[3].d[0]=wanted;}
  t->f(&actual);tests++;
  if(memcmp(&actual,&expected,sizeof(actual)) || hle_cop0[25]!=wanted){fprintf(result,"FAIL case=%u iteration=%u kind=%u selector=%u status=%08x expected=%08x\n",i,j,t->kind,t->selector,hle_cop0[25],wanted);fflush(result);return 1;}
  for(unsigned k=0;k<32;k++)if(k!=25 && hle_cop0[k]!=(0xfeed0000u+k))abort();
 }
 fprintf(result,"PASS PCCR register/state cases=%u; four compiler modes; full context and upper GPR halves preserved\n",tests);fflush(result);
 #ifdef __PSP__
 fclose(result);sceKernelExitGame();
 #endif
 return 0;
}
