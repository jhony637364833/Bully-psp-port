#include "world_clip.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#ifdef __PSP__
#include <pspkernel.h>
PSP_MODULE_INFO("Bully exact edge cache",0,1,0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);
#define STRIPS 64
#define RANDOM_CASES 2000
#define EXTREMES 128
#else
#include <fenv.h>
#define STRIPS 1000
#define RANDOM_CASES 100000
#define EXTREMES 2048
#endif
int bully_clip_test03_triangle(const BullyClipVertex[3],float,float,BullyClipVertex[10]);
static uint32_t seed=0x931fb4;static unsigned checks;
static uint32_t rnd(void){seed=seed*1664525u+1013904223u;return seed;}
static float fraction(void){return (float)(int32_t)rnd()/2147483648.0f;}
static BullyClipVertex vertex(unsigned i,unsigned fixture) {
 BullyClipVertex v;
 float z=4.0f;
 v.p[2]=z;
 v.p[0]=fixture==0?(i%2?-1.0f:5.0f):fixture==1?(i%2?1.0f:3.0f):fraction()*8;
 v.p[1]=(float)i/16.0f-0.5f;
 for(unsigned k=0;k<3;k++)v.color[k]=fraction()*255;
 for(unsigned k=0;k<2;k++)v.uv[k]=fraction()*3;
 v.alpha=(float)(rnd()&255);return v;
}
static void compare(BullyClipVertex t[3],float near,float far,BullyClipCache *cache) {
 struct {uint32_t before;BullyClipVertex out[10];uint32_t after;} a,b;
 memset(&a,0x5a,sizeof a);b=a;
 int na=bully_clip_test03_triangle(t,near,far,a.out),nb=bully_clip_triangle_cached(t,near,far,b.out,cache);
 checks++;
 if(na!=nb||memcmp(&a,&b,sizeof a)){printf("cache mismatch check=%u n=%d/%d\n",checks,na,nb);exit(1);}
 for(unsigned p=0;p<6;p++)if(cache->initialized&&cache->count[p]>2){puts("invalid cache count");exit(1);}
}
static void suite(void) {
 struct {uint32_t before;BullyClipCache cache;uint32_t after;} guarded;
 memset(&guarded,0xa5,sizeof guarded);BullyClipCache *cache=&guarded.cache;
 /* Make each plane parameter affect a reused crossing edge, including an
  * adjacent binary32 plane value and exact signed-zero attribute keys. */
 bully_clip_cache_reset(cache);
 BullyClipVertex special[3]={
  {{-.5f,.2f,.5f},{1,2,3},{0,0},0},
  {{2,1,5},{100,200,250},{1,2},255},
  {{.5f,1,2},{40,60,80},{2,1},128}};
 const float near_values[]={.75f,1.0f,0x1.000002p0f,.75f};
 const float far_values[]={3.0f,4.0f,0x1.fffffep1f,3.0f};
 for(unsigned k=0;k<4;k++)compare(special,near_values[k],6,cache);
 for(unsigned k=0;k<4;k++)compare(special,.25f,far_values[k],cache);
 for(unsigned k=0;k<3;k++)special[k].color[0]=0.0f;
 compare(special,.75f,4,cache);
 for(unsigned k=0;k<3;k++)special[k].color[0]=-0.0f;
 compare(special,.75f,4,cache);
 BullyClipVertex a[10],b[10];memset(a,0x4a,sizeof a);memcpy(b,a,sizeof a);
 int na=bully_clip_triangle(special,.75f,4,a);
 int nb=bully_clip_triangle_cached(special,.75f,4,b,0);
 if(na!=nb||memcmp(a,b,sizeof a)){puts("null cache mismatch");exit(1);}checks++;
 for(unsigned n=0;n<EXTREMES;n++) {
  BullyClipVertex t[3]={
   {{-1,.2f,4},{0,0,0},{0,0},0},
   {{5,1,4},{0,0,0},{0,0},0},
   {{2,3,4},{0,0,0},{0,0},0}};
  for(unsigned v=0;v<3;v++)for(unsigned k=0;k<6;k++) {
   uint32_t bits=rnd();if((bits&0x7f800000u)==0x7f800000u)bits^=0x00800000u;
   float value;memcpy(&value,&bits,4);
   if(k<3)t[v].color[k]=value;else if(k<5)t[v].uv[k-3]=value;else t[v].alpha=value;
  }
  compare(t,1,100,cache);compare(t,1,100,cache);
 }
 for(unsigned s=0;s<STRIPS;s++){
  bully_clip_cache_reset(cache);BullyClipVertex ring[3];
  for(unsigned i=0;i<129;i++){
   ring[i%3]=vertex(i,s%3);
   if(i>=2){BullyClipVertex t[3]={ring[(i-2)%3],ring[(i-1)%3],ring[i%3]};compare(t,1,100,cache);}
  }
 }
 for(unsigned i=0;i<RANDOM_CASES;i++){
  if(i%37==0)bully_clip_cache_reset(cache);
  BullyClipVertex t[3];for(unsigned k=0;k<3;k++)t[k]=vertex(rnd()%64,2);
  compare(t,1,100,cache);
  /* Same coordinates, every individual attribute changed; endpoint order and
   * either plane value change independently. No geometry-only cache key. */
  for(unsigned k=0;k<3;k++){
   for(unsigned c=0;c<3;c++){t[k].color[c]=fraction()*255;compare(t,1,100,cache);}
   for(unsigned c=0;c<2;c++){t[k].uv[c]=fraction()*3;compare(t,1,100,cache);}
   t[k].alpha=fraction()*255;compare(t,1,100,cache);
  }
  BullyClipVertex swap=t[0];t[0]=t[1];t[1]=swap;compare(t,1,100,cache);
  compare(t,2,100,cache);compare(t,2,3,cache);compare(t,1,100,cache);
  if(i%101==0){t[0].p[2]=NAN;compare(t,1,100,cache);compare(t,NAN,100,cache);compare(t,1,INFINITY,cache);compare(t,0,100,cache);compare(t,100,1,cache);}
 }
 if(guarded.before!=0xa5a5a5a5||guarded.after!=0xa5a5a5a5){puts("cache bounds corrupted");exit(1);}
}
#ifdef __PSP__
static void benchmark(unsigned fixture){
 BullyClipVertex vertices[65],out[10];for(unsigned i=0;i<65;i++)vertices[i]=vertex(i,fixture);
 unsigned times[2],sums[2];BullyClipCache cache;
 for(unsigned pass=0;pass<2;pass++){
  unsigned sum=0,start=sceKernelGetSystemTimeLow();
  for(unsigned n=0;n<128;n++){
   bully_clip_cache_reset(&cache);
   for(unsigned i=2;i<65;i++){
    BullyClipVertex t[3]={vertices[i-2],vertices[i-1],vertices[i]};
    int size=pass?bully_clip_triangle_cached(t,1,100,out,&cache):bully_clip_test03_triangle(t,1,100,out);
    sum+=(unsigned)size;
    if(size){uint32_t bits;memcpy(&bits,&out[0].alpha,4);sum+=bits;}
   }
  }
  times[pass]=sceKernelGetSystemTimeLow()-start;sums[pass]=sum;
 }
 printf("strip fixture=%u old=%u cached=%u us sums=%08x/%08x\n",fixture,times[0],times[1],sums[0],sums[1]);
 if(sums[0]!=sums[1])exit(1);
}
#endif
int main(void){
#ifdef __PSP__
 if(!freopen("clip-cache.log","w",stdout))return 2;
 unsigned mode=0x01000001;__asm__ volatile("ctc1 %0,$31"::"r"(mode));
 suite();printf("PSP cached polygon comparisons=%u errors=0\n",checks);
 benchmark(0);benchmark(1);benchmark(2);fflush(stdout);sceKernelExitGame();
#else
 const int modes[]={FE_TONEAREST,FE_TOWARDZERO,FE_DOWNWARD,FE_UPWARD};
 for(unsigned m=0;m<4;m++){if(fesetround(modes[m]))return 2;suite();}
 printf("cached polygon comparisons=%u errors=0\n",checks);
#endif
 return 0;
}
