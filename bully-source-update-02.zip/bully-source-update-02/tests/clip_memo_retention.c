#include "clip_memo.h"
#include <assert.h>
#include <stdio.h>
static uint32_t state;
static uint32_t get(void){return state;}
static void set(uint32_t x){state=x;}
int main(void){
 BullyClipMemo m;BullyClipMemoSet storage[1];BullyClipVertex u={0},v={0},out;BullyClipMemoEntry *pending;
 assert(bully_clip_memo_init(&m,storage,1,get,set,0));
 for(unsigned pass=0;pass<20;pass++){
  for(unsigned i=0;i<2;i++){
   u.p[0]=(float)i;int hit=bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending);
   if(hit)assert(!memcmp(&u,&out,sizeof(u)));else bully_clip_memo_commit(&m,pending,&u);
  }
  for(unsigned i=0;i<3;i++){
   u.p[0]=(float)(10+pass*3+i);assert(!bully_clip_memo_lookup(&m,&u,&v,2,1,100,&out,&pending));bully_clip_memo_commit(&m,pending,&u);
  }
 }
 printf("RETENTION two_repeated_edges three_one_use_edges per_pass=20 hits=%u admissions=%u expected_hits=36\n",m.hits,m.admissions);
 return m.hits==36 && m.admissions==2?0:1;
}
