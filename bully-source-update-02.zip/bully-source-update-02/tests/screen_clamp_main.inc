
static __attribute__((noinline)) float reference(float x,float maximum){return fminf(maximum,fmaxf(0.0f,x));}
static uint32_t rng=0x894353;
static uint32_t next(void){rng=rng*1664525u+1013904223u;return rng;}
static uint32_t bits(float f){uint32_t u;memcpy(&u,&f,4);return u;}
static float value(uint32_t u){float f;memcpy(&f,&u,4);return f;}
int main(void){
#ifdef __PSP__
 freopen("clamp-test.log","w",stdout);setvbuf(stdout,0,_IONBF,0);const unsigned tests=100000;
#else
 const unsigned tests=1000000;const int rounding[4]={FE_TONEAREST,FE_TOWARDZERO,FE_UPWARD,FE_DOWNWARD};
#endif
 const uint32_t edge[]={0,0x80000000u,1,0x80000001u,0x7fffffu,0x800000u,0x3f800000u,0xbf800000u,0x43880000u,0x4387ffffu,0x43880001u,0x43f00000u,0x43efffffu,0x43f00001u,0x7f7fffffu,0xff7fffffu,0x7f800000u,0xff800000u,0x7fc00000u,0x7f800001u,0xffc32514u};
 for(unsigned mode=0;mode<4;mode++){
#ifdef __PSP__
 unsigned fcr=0x01000000u|mode;__asm__ volatile("ctc1 %0,$31"::"r"(fcr));
#else
 fesetround(rounding[mode]);
#endif
 for(unsigned t=0;t<tests;t++){
  float x=value(t<sizeof(edge)/sizeof(*edge)?edge[t]:next());
  if(t>30 && t%4==1)x=(next()>>8)*(512.0f/16777216);
  for(unsigned kind=0;kind<2;kind++){
   float maximum=kind?272:480;uint32_t a=bits(reference(x,maximum)),c=bits(screen_clamp(x,maximum));
   if(a!=c){printf("ERROR mode=%u case=%u input=%08x maximum=%u old=%08x new=%08x\n",mode,t,(unsigned)bits(x),kind,(unsigned)a,(unsigned)c);return 1;}
  }
 }
 printf("mode=%u comparisons=%u errors=0\n",mode,tests*2);
 }
 puts("COMPLETE errors=0");
#ifdef __PSP__
 sceKernelExitGame();
#endif
 return 0;
}
