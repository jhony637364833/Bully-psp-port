"""Prepare the real PSP sky/depth fixture; uses synthetic geometry only."""
from pathlib import Path
import argparse
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
r=Path(__file__).resolve().parents[1];t=r/'tests';g=r/'app/games/SLUS-21269_v1.02/src';d=a.output.resolve();d.mkdir(parents=True,exist_ok=True)
(d/'hle.h').write_bytes((t/'sky_gpu_hle.inc').read_bytes())
(d/'main.c').write_text((t/'sky_gpu_head.inc').read_text()+(g/'psp/world_display.c').read_text()+(t/'sky_gpu_fixture.inc').read_text()+(t/'texture_cache_unavailable.inc').read_text()+(t/'sky_gpu_main.inc').read_text())
(d/'overlay_live.c').write_bytes((g/'psp/overlay_live.c').read_bytes())
(d/'Makefile').write_text(""".DEFAULT_GOAL := all
TARGET = sky_test
OBJS = main.o overlay_live.o world_clip.o native_state.o native_gif.o native_vif.o overlay_geometry.o overlay_texture.o texconv.o
BULLY_SRC = """+str(g)+"""
INCDIR = . $(BULLY_SRC)
VPATH = $(BULLY_SRC)
CFLAGS = -O2 -G0 -Wall -fno-math-errno -fno-fast-math -frounding-math -ffp-contract=off
native_state.o: CFLAGS += -Dbully_native_state=fixture_unused_native_state
BUILD_PRX = 1
LIBS = -lpspgu -lpspge -lm
EXTRA_TARGETS = EBOOT.PBP
PSP_EBOOT_TITLE = Bully sky depth check
PSPSDK = $(shell psp-config --pspsdk-path)
include $(PSPSDK)/lib/build.mak
""")
print('Prepared',d,'; run make there with PSPDEV/bin on PATH, then launch EBOOT.PBP; sky.log must finish with COMPLETE.')
