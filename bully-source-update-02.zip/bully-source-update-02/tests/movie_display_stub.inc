#include <stdint.h>
#include <stdio.h>
#include <string.h>
#define LOG printf
