# Bully PSP source investigation

Target: **PPSSPP on Android phones**. The requested 14 rendered gameplay FPS
and mission/cinematic fixes remain unverified.

Recovered the supplied source106 prerequisite, integrated the supplied lighting
optimization, and repaired stale rendering diagnostics. The user's R4 executable
and timing configuration are preserved in task inputs. This source baseline
predates R3/R4 and must not be presented as a replacement for those timing fixes.

## Results

- Host lighting: 2,048,576 comparisons passed under ASan/UBSan.
- Native PSP lighting in desktop PPSSPP: 1,148,576 comparisons passed.
- Software renderer fallback and GPU guard checks passed.
- Native material rendering passed all four documented color/depth phases.
- The new full game archive resolves the missing-disc boot failure. Its program
  is byte-identical to the earlier R4 EBOOT (only menu assets differ).
- Controlled office testing: 10.8 FPS at the default333MHz budget versus
  30.25 FPS at1000MHz, with the executable unchanged. Yard standing/walking/later
  view averages improved from5.81/4.88/3.50 to17.86/15.00/10.50 FPS. Higher
  budgets slowed the game clock here; the14FPS minimum remains unresolved.
  See [the PPSSPP profile](docs/PPSSPP_PROFILE.md) for installation and limits.

See [fresh findings and limits](docs/INVESTIGATION.md). Supplied historical
reports remain in docs/ and VALIDATION.md; they are not current test results.

## Host checks

With a C compiler supporting ASan/UBSan, Python 3.11+ and make:

```sh
bash tests/run_native_light.sh
bash tests/run_light_clamp.sh
bash tests/run_audio_sync.sh
bash tests/run_clip_differential.sh
python3 tests/renderer_differential.py
python3 tests/check_gpu_guard.py
python3 tests/check_camera_hooks.py
python3 tests/check_overlay_composition.py --source app/games/SLUS-21269_v1.02/src/psp/world_display.c
python3 tests/check_camera_perf.py
```

The historical renderer test explicitly selects the software fallback. The GPU
guard fixture independently checks normal-camera GE clipping and exact fallback
behavior; GE output is intentionally not identical to software triangulation.

## Native diagnostic builds

Use PSP GCC15.2.0 and PSPSDK; export PSPDEV and add its bin/ to PATH:

```sh
make -C tests/psp_light_clamp
make -C tests/psp_projection_smoke
make -C tests/psp_state_smoke
```

These EBOOTs are synthetic diagnostics, not the game. Render diagnostics now call
the same presentation hook as the guest flip. The material test's four phases
can take over a minute with software rendering. See its README for expected pixels.

## Full game build

Overlay app/ on PS2RC0.1.1 at commit
`332a437f21f7ef694943caef885a7d28410cbc41` and use a matching local disc.
The expected boot ELF identity is in app/games/SLUS-21269_v1.02/pack.toml.
The CLI imports successfully with this overlay. The full game archive now
provides matching disc inputs. R4 reconstruction still needs its unsupplied
timing/audio source changes; rebuilding source106 alone would discard them. The Windows0.2.0 converter is not a verified substitute for that baseline.
See [the supplied build instructions](docs/SOURCE106_README.md).

## Attribution

Based on PS2RC by SandstoneDev
https://github.com/SandstoneDev/PS2RC
Community: https://discord.gg/wV8x46ZTDu

PS2RC source and derived changes retain app/LICENSE and app/NOTICE.md.
The root license does not relicense them. No game assets or EBOOTs are tracked.
