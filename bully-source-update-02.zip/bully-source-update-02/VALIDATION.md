# Current test build 106

See [OPTIMIZATION_TEST_106.md](docs/OPTIMIZATION_TEST_106.md) for original startup-screen capture, GPU composition, memory-boundary checks and game/menu regression. Build 101 performance work remains included. Outdoor HUD and 14 FPS remain unresolved.

# Current test build 101

See [OPTIMIZATION_TEST_101.md](docs/OPTIMIZATION_TEST_101.md) for raw-vs-expanded GPU output/FCR, parser overlap/callback checks and the fresh gameplay comparison. Earlier vertex-load and build 51 checkpoint repairs remain included. Device FPS and overlay repair remain unresolved.

# Current test build 92

See [OPTIMIZATION_TEST_92.md](docs/OPTIMIZATION_TEST_92.md) for exact GPU-helper output/FCR checks and the fresh gameplay comparison. Earlier vertex-load and build 51 save repairs remain included. Device FPS remains unverified.

# Current test build 81

See [OPTIMIZATION_TEST_81.md](docs/OPTIMIZATION_TEST_81.md) for exact GPU-helper output/FCR checks and the fresh gameplay comparison. Earlier vertex-load and build 51 save repairs remain included. Device FPS remains unverified.

# Current test build 78

See [OPTIMIZATION_TEST_78.md](docs/OPTIMIZATION_TEST_78.md) for exact texture mutation and comparison boundary checks and the fresh gameplay comparison. Earlier vertex-load and build 51 save repairs remain included. Device FPS remains unverified.

# Current test build 77

See [OPTIMIZATION_TEST_77.md](docs/OPTIMIZATION_TEST_77.md) for exact VIF parser/state/callback checks and the fresh gameplay comparison. Earlier vertex-load and build 51 save repairs remain included. Device FPS remains unverified.

# Current test build 76

See [OPTIMIZATION_TEST_76.md](docs/OPTIMIZATION_TEST_76.md) for exact GPU-helper output/FCR checks and the fresh gameplay comparison. Earlier vertex-load and build 51 save repairs remain included. Device FPS remains unverified.

# Current test build 73

See [OPTIMIZATION_TEST_73.md](docs/OPTIMIZATION_TEST_73.md) for texture mutation, buffer lifetime, alpha and gameplay checks and the fresh gameplay comparison. Earlier vertex-load and build 51 save repairs remain included. Device FPS remains unverified.

# Current test build 70

See [OPTIMIZATION_TEST_70.md](docs/OPTIMIZATION_TEST_70.md) for exact GPU-helper output/FCR checks and the fresh gameplay comparison. Earlier vertex-load and build 51 save repairs remain included. Device FPS remains unverified.

# Current test build 68

See [OPTIMIZATION_TEST_68.md](docs/OPTIMIZATION_TEST_68.md) for CPU fallback, bounds, GPU image and state checks and the fresh gameplay comparison. Earlier vertex-load and build 51 save repairs remain included. Device FPS remains unverified.

# Current test build 55

See [OPTIMIZATION_TEST_55.md](docs/OPTIMIZATION_TEST_55.md) for exact host/PSP renderer checks and the fresh gameplay comparison. Build 54 vertex loads and build 51 save repairs remain included. Device FPS remains unverified.

# Current test build 54

See [OPTIMIZATION_TEST_54.md](docs/OPTIMIZATION_TEST_54.md) for the focused host/PSP tests and matched gameplay measurements. Build 51 save repairs remain included; device FPS remains unverified.

# Current test build 51

See [OPTIMIZATION_TEST_51.md](docs/OPTIMIZATION_TEST_51.md). The earlier forced-checkpoint restore stop is repaired; exact EBOOT cold-load and clean-card gameplay smokes pass. Normal user save points, Android/physical PSP and 14 FPS remain unverified.

# Current test build 50

See [OPTIMIZATION_TEST_50.md](docs/OPTIMIZATION_TEST_50.md). Cold slot verification passed; applying the forced initial-scene checkpoint still fails. This is not a complete save/load pass.

# Current test build 49

See [OPTIMIZATION_TEST_49.md](docs/OPTIMIZATION_TEST_49.md) for current checks and limitations.

# Current test build 48

See [OPTIMIZATION_TEST_48.md](docs/OPTIMIZATION_TEST_48.md) for the collision repair, measured speed and checks. Earlier records describe their own builds.

# Current test build 46

See [OPTIMIZATION_TEST_46.md](docs/OPTIMIZATION_TEST_46.md) for the HUD composition repair and its checks. Earlier records below describe their own builds. 14 FPS remains unmet.

# Current build 15

See [OPTIMIZATION_TEST_15.md](docs/OPTIMIZATION_TEST_15.md) for current changes, checks
and measured limits. Android 14 FPS remains unverified. Earlier records follow.

# Current optimization validation

For the current build06, see [OPTIMIZATION_TEST_06.md](docs/OPTIMIZATION_TEST_06.md)
and TEST-RESULTS-06.md in the update ZIP. The text below is the supplied historical
graphics-repair record and refers to its own earlier executable and measurements.
Android 14 FPS and sustained gameplay remain unverified.

## Supplied historical validation

# Bully PSP: tested graphics repair

**The large black ground areas are repaired in the tested outdoor scene. The port is still not playable: measured rendering remains about 0.5 FPS in this sandbox, and player movement is not verified.**

Tested on 2026-10-25 with PPSSPP 1.20.4, OpenGL, 1× resolution, PSP-2000/3000 memory, and sound enabled. Target: Bully NTSC-U SLUS-21269 v1.02, supplied pack 4, PS2RC 0.1.1.

**Exact game EBOOT SHA-256:**
`f5b7d548f841723aeee94644463de0f7fb1d28507cef74b7bee12586255ab9ac`

The standalone EBOOT, small update and complete-folder archive use this same binary.

## What changed

- Restored supported per-material blending, alpha tests, depth comparisons and depth-write masks from the original game bridge.
- Corrected additive GS blend `0x68/FIX128`: source **plus destination**, rather than replacing the destination. Earlier intermediate builds had this mapping wrong.
- Restored compressed vertex/material alpha from both packed color banks and interpolated it through clipping.
- Preserved triangle order for color-only alpha failures. Removed redundant failure passes when opaque textures and the minimum vertex alpha guarantee a passing test.
- Specialized the texture-cache function with local registers synchronized at guest/scheduler boundaries. Compiled another profiled function with inlining while retaining its exact prepared body and strict floating-point rules.
- Deferred the existing 8 KB mesh and 64 KB texture buffers until after the intro. Full 32 MB guest RAM and the startup reserve remain intact.
- Retained earlier perspective-correct textures, prelighting and buffered audio repairs.

## Actual scene and performance

Grass and the paving beside the gate now appear where the earlier build showed large black regions. See `before-after.png` and `scene-preview.png`.

The first scene retained 121 objects, 24,722 triangles, 415 textured meshes, 377 lit meshes, 14 skinned objects and **zero texture misses**.

| Measurement | Previous graphics repair (`9aa0d948`) | Delivered build (`f5b7d548`) |
|---|---:|---:|
| Draw calls at simulation frame 664 | 6,769 | 3,896 |
| Wall time for five observed rendered frames | 10.17 s | 10.18 s |
| Observed short-sample rendering rate | ≈0.49 FPS | ≈0.49 FPS |
| Wall time, simulation ticks 660–720 | 57.79 s | 58.80 s |
| Estimated rendered rate over that interval | ≈0.52 FPS | ≈0.51 FPS |

Draw calls fell by about **42%** in the sampled frame, but **no meaningful overall FPS improvement was demonstrated**. The original AV baseline also measured approximately 0.49 FPS in the short sample. Translated game logic remains a performance bottleneck; replacing the game folder alone does not resolve it.

The longer estimate assumes the observed two simulation ticks per rendered frame. Short-sample polling has a two-second resolution. The runtime's logged “real” time is an emulated PSP clock, not wall time; its corresponding final interval was 58.55 seconds. These are bounded emulator measurements, not a physical-PSP benchmark or sustained gameplay certification. Raw measurements are in `performance.json`.

## Checks

- Final converter build passed with PSP GCC 15.2.0; all 247 disc files validated.
- Native lighting/alpha: **56 ASan/UBSan assertions passed**.
- Clipping: **100,000 differential position/RGB/UV cases passed**, plus analytic alpha interpolation and nonfinite-alpha rejection.
- Renderer: **1,000 opaque strip cases passed**, producing 13,159,192 identical submitted vertex bytes against the earlier renderer.
- Alpha batch selection: **10 sanitizer boundary assertions passed**, including inclusive/strict comparisons and mixed textures.
- Actual PSP renderer smoke: **all four pixel phases passed**, covering transparency, color-only failure without depth writes, opaque/masked-depth shortcuts, half vertex alpha with opaque texture, and fixed additive blending. See `renderer-tests.png`. One earlier short timeout and an interrupted run were superseded by completed passing runs.
- Mechanical checks passed for both native specializations. All seven texture-cache and five profiled-function scheduler checkpoints remain present.
- Texture-cache differential replay passed 16 captured-call cases across scheduler offsets, comparing complete context, 32 MB RAM and callback traces. An earlier 224 raster/mode fixture replay also passed.
- Final host replay through frame 760 matched the baseline: 3,735,555,765 virtual cycles, 126 idle jumps, 2,758 syscalls, 34 hooks, 66,284 MMIO accesses, 2,018 interrupt calls, two thread switches and 415,958,570 backedges. No detected code-region writes or hardware-address aliases.
- Full game EBOOT booted with full RAM, played the intro, reached the outdoor scene and continued through the observed simulation frame 815. The emulator was then stopped deliberately after verification.

## Audio/video evidence retained from earlier checks

Audio implementation is unchanged. Earlier PSP audio smoke recorded 439.89 Hz from a 440 Hz tone, with no dropped frames/errors after startup. Supplied PMF/WAV assets decoded with ffmpeg; the PMF check emitted one non-monotonic DTS warning. Intro playback and audio output were exercised, but complete movie playback and every speech/music cue were not verified. Six audio-driver calls remain unresolved. Slow simulation can still starve audio despite buffering.

## Remaining limitations

- Rendering remains too slow for playable gameplay.
- UI, additional rendering pipelines and complete character lighting remain incomplete.
- One skin object produces 2,395 triangles against a declared 2,402; its validation rejection is preserved.
- Both keyboard and direct API probes showed no obvious character movement. The direct API probe held analog-right plus D-pad-right from frames 761–801 for 62.03 wall seconds. The game logged pad buttons `0020`; the input reached its pad layer, but walking was not established. Neutral-stick and button-release acknowledgements were confirmed afterward.
- Physical PSP, Android, Windows GUI, sustained gameplay and saves were not tested here.

## Install the complete folder

Download all **108 parts**, `parts-manifest.json` and `join.py` from `DOWNLOADS.md`. Run `python join.py`, extract `Bully-complete.zip`, then copy `PS2RC_SLUS21269` into `PSP/GAME`, or open its `EBOOT.PBP` in PPSSPP. Select PSP-2000/3000 (64 MB), OpenGL, 1× resolution and sound on. Cross skips the intro after its initial interval. Loading is slow.

Keep your old folder separate. This package includes all 247 converted disc files, the ELF, maps, metadata, configuration, support PRX and intro PMF/WAV. It needs no files from your old folder. Allow roughly 9 GB for the parts, joined ZIP and extracted folder. The PowerShell join alternative was inspected but not executed on Windows.

**If you downloaded the earlier candidate during this task:** keep parts 001–107. Replace part 108, both manifests and the standalone EBOOT with the final files; the join script verifies their hashes. The small update ZIP is an alternative for an already complete matching folder.

## Final package verification

The supplied Python join script reconstructed the final ZIP and verified all 108 part hashes and the archive hash. The 252 unchanged data-file decompression/SHA checks are retained from the earlier verified archive; its data entries were copied unchanged. Final runtime entries and the bundled/downloaded/running EBOOT identity were checked again.

- Archive size: 2,590,191,079 bytes.
- Archive SHA-256: `9bd6f769998e7b98c45a319e41b42da8cae6a9956986f0090d993543f8d8c499`.
- The package manifest lists 257 files; the ZIP also includes the manifest itself and an empty memory-card directory.
- `Bully-render-state-source.zip` contains source, tests and build guidance.
- `Bully-render-state-update.zip` contains the exact game EBOOT and support files, source ZIP, v4 patch, screenshots, logs, measurements and the separate synthetic GPU-test EBOOT.

This is a verified graphics repair and complete converted data folder, **not a completed gameplay port**.
