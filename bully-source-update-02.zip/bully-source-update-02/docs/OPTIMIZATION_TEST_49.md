# Bully PSP optimization test 49

Targets: PSP-2000, PSP-3000 and Android PPSSPP. **14 gameplay FPS remains unmet/unverified.**

## Change

The build48 gameplay profile identified compressed-mesh/skinned-mesh expansion and repeated vertex clears among the remaining work. Build49 replaces each 32-byte per-vertex library memset with eight aligned Allegrex integer stores. This avoids the function call and its register spills. All bytes, including padding, are cleared before source attributes are read. Host builds retain memset. Other clears remain unchanged.

Only native_mesh.c, native_skin.c and their shared native_mesh.h change runtime source. Only two native objects change; all171 generated guest objects and the renderer remain build48. There is no FPU/VFPU arithmetic change, extra memory allocation or omitted geometry. The build48 original collision-predicate repair and build46 overlay composition repair remain included.

A separate attempt to avoid overwritten color calculations passed host tests but failed a PSP downward-rounding edge case. That attempt was rejected; world_display.c and color/position calculations remain byte-identical to build48.

## Measured comparison

Fresh sequential desktop PPSSPP1.20.4 runs, normal333MHz/bus166MHz, PSP-2000 memory profile, JIT, OpenGL buffered rendering,1x, frameskip0. No alt-speed or Skip buffer effects. No compiler, sampler, test or second emulator ran during either selected120–240-camera timing interval.

| Camera interval | Build48 | Build49 | Camera throughput gain |
| --- | ---: | ---: | ---: |
|120 to180|17.261802s|16.799062s|2.75%|
|180 to240|17.621966s|17.184359s|2.55%|

These count camera completions, **not gameplay FPS**. This is one matched desktop comparison, not Android or physical PSP evidence. The improvement is modest. Previous48 timing17.2640/17.6223s closely agrees with the fresh48 baseline17.2618/17.6220s.

## Checks

- PSP fixture:32768 full-byte clear/guard/FPU-status checks and80000 compressed validation/draw differential cases across four rounding modes and both FS settings; zero errors. An additional32768 unchanged prepare-vertex comparisons also pass.
- PSP skin palette:26896 cases, including overlapping scratch/input, callback mutations, malformed data and complete RAM/scratch/FCR status; zero differences. Host ASan/UBSan palette also passed; expected successful-case totals differ between host and PSP FTZ.
- Host whole-object skin replay:932 cases,549 successes,427 cached,84 overflow cases and4749 successful mesh replays; zero errors under ASan/UBSan.
- Host compressed and combined clear/mesh fixtures passed ASan/UBSan.512 renderer-submission cases passed exact command/vertex/texture/lifetime checks. Renderer GPU/sky/composition checks are reused from earlier accepted builds because those sources and arithmetic are unchanged; no fresh GPU result is claimed.
- All ten world summaries and five gameplay/Start/Select PNGs are byte-identical to fresh48. Start paused at242 and resumed250; Select paused251 and resumed259. Neither froze in this scene.
- Published test generator reconstructs the executed PSP fixture source, headers and Makefile byte-for-byte, including corrected include dependencies. Its runtime pass is reused by exact input identity.
- Final packaging audits check runtime checksums, ZIP CRCs, source content, engine overlay equality,171 unchanged guest objects, two tested native objects, executable identities, previous downloads and original emulator config. Patch dry-run is recorded separately.

## Test files

EBOOT.PBP: 16994884 bytes; SHA256 `cbbd77343a4921eb3934b57187bfb139e3d45a3e3b89525d2dedafbcba80df9f`.

Use bully-optimization-test-49.zip for the executable, required plugin/config, installation instructions, licenses and this report. Keep your existing converted disc/media and save files; the update does not replace them. Use the separate cumulative source ZIP or patch to inspect/rebuild the changes. Older versioned48 downloads remain available.

Reproduce focused PSP checks with `python3 tests/prepare_vertex_clear.py --output /tmp/bully-vertex-clear`, then `make -C /tmp/bully-vertex-clear` using PSP GCC15.2.0 and run its EBOOT with PPSSPP. Expect `COMPLETE vertex=32768 clear=32768 compressed=80000 ... errors=0`. Existing prepare_skin_palette.py and prepare_skin_replay.py generate the skin checks. Build source overlays PS2RC commit332a437f21f7ef694943caef885a7d28410cbc41; existing compiler cache stamps are older and must be reconciled for the next full converter build.

## Still unresolved

Complete sky/cloud rendering, every combat/tutorial/subtitle/map overlay, school-door entry, walking/physics/saves and audible audio are not verified. This build does not claim a new sky or combat-overlay repair. It preserves the captured sky and tutorial/objective overlays, including the existing defects. The full14FPS target requires further optimization and device measurement. No physical PSP or Android device is available in this sandbox.
