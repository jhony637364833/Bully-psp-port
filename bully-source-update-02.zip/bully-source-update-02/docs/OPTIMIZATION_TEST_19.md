# Bully PSP experimental test 19

**Android 14 FPS remains unverified.** Build 19 removes redundant floating point
clamps in a hot geometry calculation. Graphics, audio and simulation work remain.

## Install

The runtime ZIP includes EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, installation
instructions, licenses and checksums. Copy test-build/ contents into a BACKUP of
your complete converted game folder. Keep disc/, SLUS_212.69, discmap.txt,
iso_meta.bin, BULN.pmf, BULN.wav and memcard/. Fresh-boot; do not reuse a save
state from a different executable. Read INSTALL.txt.

EBOOT.PBP: 16,499,652 bytes. SHA256: `0e69105aa325289183651dd1319e6cbf51dc7e7f6191311fed105e84d76c5353`.

Optional ppsspp-settings/ contains the previously verified experimental
2000 MHz virtual-clock fragment and rollback fragments. Read CONFIG-TEST-18.md
before manually merging it. This exceeds PPSSPP 1.20.4's UI slider maximum;
it changes the virtual PSP instruction budget, not the phone physical clock.
Do not increase it arbitrarily. Roll back to Auto/0 if needed. Compare builds at
the SAME clock/settings. These settings are not automatically applied by EBOOT.

Matching cumulative source/patch target PS2RC 0.1.1 revision
332a437f21f7ef694943caef885a7d28410cbc41, PSP GCC 15.2.0 / SDK 20261001,
Bully SLUS-21269 v1.02 ELF SHA256
597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc.

## Exact optimization

The pre-change fpu_rsqrt5 contract clamps its input, computes sqrt, clamps that
result, divides the clamped numerator by it, then clamps the output. It first
returns signed FMAX for an exponent-zero denominator. That branch remains.

When the compiler knows the numerator is exactly 1.0, the positive clamped
normal input has sqrt in [2^-63, 2^64]. Its reciprocal is in [2^-64, 2^63].
Both remain finite normal in every rounding mode, so the post-sqrt input clamp
and output clamp are identities. The candidate performs the SAME sqrt and
division in the same order, with no approximate reciprocal-square-root.
Unknown numerators retain the original path without a runtime dispatch.
Signed-zero, subnormal, negative and nonfinite denominator handling is retained.

The PSP scalar unity wrapper shrinks from 160 to 84 bytes; the extracted original
fn_001860c0 normalizer fixture shrinks from 476 to 404 bytes. The generic wrapper's 43
instruction words match exactly. In the full game ELF, fn_001860c0 shrinks
from 504 to 424 bytes. The runtime header outside the added constant
specialization/comment is unchanged, and all 187 prepared game C units match
build 17. All 230 compilation units were rebuilt. Old v0 native overrides stay
disabled. No preserved-state, RAM layout or public interface contract changes.

## Matched opening-scene measurement

| Counter 8 to 80 | Build 17 | Build 19 |
| --- | ---: | ---: |
| First host seconds | 14.269780 | 14.112258 |
| Reverse-order repeat seconds | 14.282824 | 14.119647 |
| Mean seconds | 14.276302 | 14.115952 |
| Camera completions / host second | 5.0433 | 5.1006 |

**1.14% higher pooled camera throughput.** Each build completes 144
measured camera events. First eight scene summaries match exactly, including
9,809 draw submissions. The later long gap remains.

Sequential order: 17, 19, 19, 17. Linux PPSSPP 1.20.4/JIT, Mesa 26.0.8 llvmpipe
LLVM 21.1.8, OpenGL 1x, normal 100% speed, frameskip 0, sound enabled with dummy
physical audio, virtual CPU 2000 MHz/bus 1000. Same media/private configuration.
Live unchanged camera/frame counters polled every 10 ms with a monotonic host
clock, loaded ELF prologue checked allowing PPSSPP's first-word JIT patch.
No compiler/tests/other emulator during measured windows.

These are camera completions, not gameplay FPS. Desktop results do not prove
Android 14 FPS, sustained motion, controls, saves or audible quality. No final
performance guarantee is made. Build 17/18 downloads remain for comparison.

## Verification

Fresh checks:

- Host ASan/UBSan strict floating point: 4,016,384 scalar comparisons, including
  both signs/all 256 exponents/eight mantissa boundaries and one million random
  denominators per mode. Random generic numerators checked too.
- 40,000 full-context and 64 KiB RAM comparisons of the ORIGINAL generated
  normalizer versus the same body with the changed helper. Random untouched
  registers/state and special input representations included.
- PSP EBOOT repeats the same 4,016,384 scalar and 40,000 context/RAM checks in
  all four hardware rounding modes with flush-to-zero. Zero errors on host/PSP.
- Portable generator reproduces the exact six test inputs; frozen reference
  helper is the original build 17 implementation. No expected results weakened.
- Full converter, prepared-code identity, two ordered game comparisons,
  archive CRC/checksums, source/engine/binary identity and patch dry-run.

Earlier renderer, clipping, alpha/depth/GPU, audio, converter and preservation
results are reused for unchanged implementation inputs. Those suites were not
all rerun. Initial portable generator attempts used a missing staging path;
corrected setup reproduced the tested fixture exactly. No correctness failures
were waived.

## Reproduce the changed math checks

From the source overlay root after installing its app/ on the stated engine:

```sh
python3 tests/prepare_unity_rsqrt.py --output /tmp/bully-rsqrt-test
make -C /tmp/bully-rsqrt-test
```

Boot the separate test EBOOT. rsqrt-test.log must end with:
`COMPLETE scalars=4016384 vectors=40000 errors=0`.
For host checks, in that generated directory:

```sh
cc -O2 -g -std=gnu11 -fsanitize=address,undefined -fno-omit-frame-pointer -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off main.c reference.c candidate.c -lm -o test
./test
```

For Android acceptance send your phone model, PPSSPP version/settings,
session.log and real-time recording with the FPS display, comparing the same
scene at identical settings. The requested >=14 FPS remains outstanding.
