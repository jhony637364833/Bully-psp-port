# Bully PSP optimization test 08

**The requested 14 FPS on Android remains unverified.**

## Download contents

The runtime update includes EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, installation
instructions, license/notices and SHA256SUMS.txt. Keep your existing complete
converted disc/media folder and saves. The separate source ZIP includes the
cumulative source overlay, portable tests and build instructions.

EBOOT size: **16,657,172 bytes**

SHA256: `0ef34913c3950bb06570d99b17367d5f6f3dff47bfd6465511561833481f4080`

Built with PS2RC 0.1.1 at `332a437f21f7ef694943caef885a7d28410cbc41`,
PSP GCC 15.2.0, matching SLUS-21269 v1.02 disc and strict floating-point flags.

## Change from Build 06

Screen projection now uses a comparison for positive screen-coordinate clamping.
Zero, negative, NaN and subnormal values that compare as zero retain the original
fminf/fmaxf expression. Projection arithmetic/order, lighting, geometry, clipping,
alpha/depth behavior, draw order, audio and game simulation are unchanged.
No approximate math, frame skipping or geometry removal was introduced.
Build 06's conservative all-alpha-fail draw optimization is retained.

## Verification

- 8,000,000 exact float-bit host comparisons across four rounding modes under
  ASan/UBSan; arbitrary bits, dense positive values and boundary/nonfinite cases.
- 800,000 exact PSP comparisons across four rounding modes with flush-to-zero.
- 3,000 renderer strips per host rounding mode against frozen Build 06; about
  32.49 MB of identical recorded data per mode under ASan/UBSan.
- Original portable renderer suite: 1,000 strips / 11,213,104 identical bytes.
- PSP replay: 24 rounding/topology/lighting cases, 929 captured strips and
  40,896 vertices per case; exact output counts/bytes/checksums.
- Portable scalar test compiles for PSP; generated C is equivalent to the actual
  passing PSP harness. Run `python3 tests/check_screen_clamp.py` on a host, or
  add `--psp-dir /path/to/test`, build that folder with make, then run its EBOOT.
  The diagnostic is separate from the game and needs no commercial assets.
- Complete converter build passed. Fresh game reached three measurement windows
  with no fatal/deadlock report before intentional termination. All fields of
  the first eight scene summaries equal Build 06. Screenshot inspected: entrance,
  road, ground and character render.
- Unchanged alpha-fail GPU/depth, material-state, lighting, clipping, audio and
  MMI results retain their earlier valid passes. They were not all rerun.

## Measurements and limits

Fully visible PSP strip component times fell 141,915 → 121,625 microseconds
(unlit) and 170,926 → 150,088 (lit), about 12–14%. Captured unlit work fell
77,031 → 74,677; captured lit work 102,357 → 101,691. Fully outside work was
slightly slower in the sample (62,772 → 63,282 and 86,716 → 88,412).
These are component timings, not gameplay FPS.

| Opening scene | Build 06 | Build 08 |
| --- | ---: | ---: |
| Completed camera passes | 27 | 28 |
| Host seconds | 10.316369 | 10.254214 |
| Camera passes / host second | 2.6172 | 2.7306 |
| Average emulated camera time, microseconds | 336907.26 | 323229.11 |

Observed camera throughput increased **4.3%**. One short run per version and
50 ms observer polling do not establish a sustained gain. Camera passes can
share a gameplay frame; this table is not an FPS measurement.

Both game runs used Linux PPSSPP 1.20.4/JIT, system Mesa 26.0.8 llvmpipe
LLVM 21.1.8, PSP-2000/3000, 1× OpenGL, frameskip 0, sound enabled with dummy
physical audio, identical test configuration/media and empty test memory cards.
Earlier reports used bundled softpipe: their host times must not be directly
compared with these. Changing the cloud driver was test-environment calibration;
it is not an Android port optimization or a delivered PPSSPP setting.

Android performance, sustained gameplay, the historical later guest stall,
controls, saves, full visual equivalence and audible quality remain unverified.
Existing unsupported graphics/audio pipelines remain.

## Install and test

Close PPSSPP. Copy the CONTENTS of test-build/ into a backup of your complete
converted game folder. Keep disc/, SLUS_212.69, discmap.txt, iso_meta.bin,
BULN.pmf, BULN.wav and memcard/. Follow INSTALL.txt and fresh-boot the new EBOOT;
do not load an emulator save state made with an older executable.

Send your phone model, PPSSPP version/settings, session.log and a real-time
recording of the same scene with frameskip 0 to measure progress toward 14 FPS.
