# Bully PSP test build 92

## Result

For GPU lighting with zero blend, the renderer omits the unused secondary-RGB interpolation. Adjacent-result reuse compares primary RGBA and secondary alpha; nonzero blends retain full-color comparison and the original shader. A comparison mask is computed once per strip. No cache, allocation or rendering-setting change.

The successful repeat baseline measured **0.99–1.41% higher desktop camera throughput over build 81**. A preceding baseline comparison also showed a small positive gain. This is a modest improvement, not gameplay FPS or physical-device proof. **14 gameplay FPS remains unmet; the disappearing-overlay issue remains unresolved.**

|60-camera interval|Build 81 repeat baseline|Build 92|
|---|---:|---:|
|120–180|12.535528 s|12.412890 s|
|180–240|12.916517 s|12.736634 s|

Runs used 333 MHz, JIT, OpenGL, buffered 1× rendering and frameskip 0, without concurrent heavy work during timing. Five gameplay/menu PNGs match byte for byte. Start and Select pause/resume passed.

One baseline attempt exited during startup before any timing samples. It was not counted as a pass. The subsequent attempt completed; the startup-exit cause was not established. Build/source/configuration integrity checks passed, and no out-of-memory kill was recorded.

## Validation

- Fresh host ASan/UBSan and PSP: **8,192 full GPU differential cases each**, checking return values, packed vertices, triangle/submission order, flushes, source bytes and full restored floating-point state.
- Tests include nonzero/zero/signed-zero/subnormal/exceptional blends, extreme gains/materials, exceptional alpha and UV values, rounding modes, trap bypass, primary-color repetition with changing secondary RGB, and changed secondary alpha. More than 21,000 additional reuse hits were exercised on each platform.
- Public fixture generator reproduces the executed test source byte for byte.
- Public CPU lighting/helpers, bounds, texture processing and submission logic remain unchanged. Their previous validation is reused; those suites were not rerun.
- Earlier channel-cache trials were rejected for insufficient gains. This build adds no persistent lighting cache.

## Reproduce

```sh
python3 tests/prepare_gpu_mask.py /tmp/bully-gpu-mask
make -C /tmp/bully-gpu-mask
```

Run the fixture EBOOT on PSP/PPSSPP. For host checks, compile generated `main.c` with game `native_light.c`, `-O2 -fsanitize=address,undefined -frounding-math -ffp-contract=off`, include the game source directory and link `-lm`.

Physical PSP/Android FPS, audible audio and normal device saves remain unverified. Previous build 81 downloads remain available. Back up your memory card before testing.
