# Bully PSP test build 73

## Result

Optional texture caching improved desktop PPSSPP camera throughput **4.55–4.57%** over a fresh build 70 baseline. This is not a gameplay FPS measurement. **14 gameplay FPS remains unmet; the reported disappearing overlay remains unresolved.**

| 60-camera interval | Build 70 | Build 73 |
|---|---:|---:|
|120–180|14.186718 s|13.569455 s|
|180–240|14.559578 s|13.923043 s|

Both runs used 333 MHz, JIT, OpenGL, buffered 1× rendering and frameskip 0. All five gameplay/menu screenshots were byte-identical; Start and Select pause/resume passed.

## Changes

A bounded 1.5 MiB texture cache avoids repeated conversion. Every lookup still parses and plans the texture and compares metadata and actual source/palette bytes. Changed inputs force conversion. Cached pixels can be submitted directly to the GPU; existing synchronization completes reads before the next cache operation. Shutdown releases the allocation after GPU synchronization. Allocation failure retains ordinary conversion.

This trades memory for conversion work: the sampled scene retained 1,555,200 free bytes after the texture, skin and clip caches. Larger later scenes and physical PSP/Android memory behavior are unverified. Original copied texture APIs remain available. Borrowed views expire at the next operation on that cache, as documented in the header.

## Validation

- Host ASan/UBSan and PSP: 3,072 copied-cache and 3,072 borrowed-view comparisons each against the original converter, covering source/palette/mip/header mutations, malformed inputs, capacities, aliases and eviction. Exact results, metadata and applicable output/RAM bytes.
- 1,024 renderer lifetime cases with poisoned scratch/evicted buffers, allocation denial and balanced shutdown release.
- Legacy checks passed: 512 ordered submissions; 30,000 texture cases; 210,000 malformed cases; 65,536 modulation checks; 50,331,648 alpha decisions; 10 alpha boundaries; 7,137,920 all-fail bounds and 20,000 command comparisons.
- Extended GPU comparison: 65 cases per renderer with repeat/depth controls. Three cases differ from the original CPU reference: five color pixels total (maximum channel error 2), one depth-witness pixel. Existing GPU comparison limits passed. This retains the previously disclosed GPU rounding behavior; it is not an exact CPU-rendering claim.
- Sky PSP fixture compiled; its runtime check was not run.
- Four-direction movement for 480 cameras exercised cache mutation/eviction. Screenshots inspected without an obvious new texture defect. HUD disappearance persisted.
- Formatting cleanup produced byte-identical production and PSP test binaries, allowing those completed runtime checks to be reused.

## Reproducing focused tests

From the source root, with PSP SDK and host C compiler available:

```sh
python3 tests/prepare_native_texture_cache.py /tmp/bully-cache-test
python3 tests/check_texture_lifetimes.py --output /tmp/bully-lifetime-test
```

For each generated `copied` and `view` directory, run `make` for the PSP fixture and run its EBOOT in PPSSPP or PSP. For host sanitizer validation, compile `reference.c` separately with `-Dbully_native_texture=reference_texture`, then link `main.c`, that object and `app/games/SLUS-21269_v1.02/src/texconv.c` with `-O2 -fsanitize=address,undefined -lm` and include both the fixture and game source directories.

No physical-device FPS, audible audio or normal device-save verification was available. Earlier save repairs remain included. Back up your memory card before testing. Previous build 70 downloads remain available.
