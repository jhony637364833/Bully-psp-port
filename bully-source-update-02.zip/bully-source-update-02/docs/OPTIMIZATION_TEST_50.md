# Test build 50 — save folder and filename repair

Targets PSP-2000/3000 and Android PPSSPP. Experimental test build. **14 FPS remains unmet. This update contains save handling repairs; it does not claim an FPS improvement or a complete save/load fix.**

## Changes

- Complete first-save folder initialization before writing a slot. The supplied game's routine at `004359b0` returned success immediately after creating a folder (`00435a58`), leaving the current directory at the card root. Its save worker and finalizer then wrote `BullyFile1`, `FileTableBully`, and `icon.sys` outside the expected folder. The repair continues through the original existing-folder initialization path. It retains the original space checks, icon/gallery/table creation and error handling.
- Restore Bully's four known lowercase icon filenames when the PSP directory API reports their uppercase 8.3 forms after restart: `ICON.SYS`, `ICON0.ICN`, `ICON1.ICN`, and `ICON2.ICN`. Bully compares these names case-sensitively. The adapter applies only to files in the Bully pack; other names, directories and packs are unchanged. The generic PS2 card namespace remains case-sensitive.
- Keep the original save format, version, checksum and verifier. No corruption check is bypassed. No diagnostic injection, forced save or restore suppression is included in the downloadable EBOOT.

This deliberately repairs the supplied first-folder early-success behavior; it is not a change to generic PS2 `sceMcMkdir` semantics. Both the supplied ELF and PS2SDK implementation were inspected before selecting this repair.

## What passed

- Existing memory card core/host tests: nocard, basic, recover, unformatted, full, norename. These are baseline results reused because the core and host backend are unchanged.
- Actual generated folder routine: 480 assertions under AddressSanitizer/UndefinedBehaviorSanitizer, covering existing-folder RAM/operation equivalence, new-folder initialization, state/free-space boundaries and injected setup failures.
- Actual PSP filename helper: 30 assertions for Bully and 30 for another pack, including unchanged directories, mixed case and unrelated names.
- Converter preparation applies the repair exactly once and reconstructs the tested function exactly. Public regression scripts are included in the cumulative source ZIP.
- The final EBOOT without diagnostics boots from a clean card and completes 80 camera passes in the initial gameplay scene. This is a smoke check, not a performance measurement.
- PSP build: only `main_092.o` and `hle_mcfs_psp.o` change from build 49. All other guest/native objects, renderer and audio code remain identical.
- Controlled PPSSPP 1.20.4 tests: the original worker plus finalizer reported success but the next launch reported corruption. The repaired worker creates all eight expected files under `/BASLUS-21269BULLY000/`. The filename repair lets startup accept the slot and read its data. A separate cold-launch diagnostic confirms folder refresh and the original slot verifier succeed, with all 21,736 save bytes identical to the saved bytes (SHA256 `628eba75c37456fa08f87aad2953093fbb146e5759b2cc70161900f6f49af520`).

## Remaining failure — read before testing

The test checkpoint was forced in the initial school scene before normal in-game saving is available. Allowing that checkpoint to restore gameplay reaches unsupported guest function `00120928` and stops. This remains unresolved; the test does not establish that a normal user checkpoint can restore gameplay. A later diagnostic suppressed applying that forced checkpoint **only to isolate cold filesystem/slot verification**. That diagnostic pass is not evidence that full restoration works, and that suppression is absent from the delivered EBOOT.

A corrupted save folder and its `session.log` from the user's device are needed to test a real checkpoint, determine whether its data remains recoverable, and distinguish this remaining failure from the artificial checkpoint's missing preconditions. Existing corrupted saves are not automatically reconstructed or removed.

Physical PSP, Android PPSSPP, audible audio, complete sky/tutorial/combat/subtitle overlays and school entry remain unverified. Earlier build 49 performance measurements describe camera throughput, not actual gameplay FPS. No new speed measurement is claimed here.

## Installation and test

1. Back up the entire existing game folder, especially `memcard/slot1/`, before replacing files. Keep that backup outside the live card directory.
2. Extract the test ZIP's contents into the existing game folder, replacing its EBOOT, helper and configuration. Keep the existing disc/media assets; they are not included again. The ZIP contains no memory card or diagnostic save files.
3. Leave PPSSPP at normal speed with frameskip and Skip buffer effects disabled. PSP-1000 is not supported.
4. Test an existing slot only after backing it up. For a fresh-save test, use a normal in-game save point, wait for completion, exit, restart, and load it.
5. Send the complete failing `memcard/slot1/` folder and `session.log`, the build number and whether the test used a fresh or existing slot. Do not delete the original failing files.
