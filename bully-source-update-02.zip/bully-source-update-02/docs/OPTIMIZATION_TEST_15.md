# Bully PSP experimental test 15

**This build improves a measured complete-game camera interval. The Android
14 FPS goal remains unverified.** Build 11 is retained for comparison/rollback.

## Download identity

EBOOT.PBP: **16,647,796 bytes**; SHA256:
`a0b6c66de221c05eab4c049f620b6e964362b39c0fb0b9b3578e39c80b9dc564`

The update includes EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, installation instructions,
notices/licenses and checksums. Keep your existing converted disc/media and saves.
The source ZIP is the cumulative overlay for PS2RC 0.1.1 at commit
332a437f21f7ef694943caef885a7d28410cbc41, PSP GCC 15.2.0 / SDK 20261001,
Bully SLUS-21269 v1.02 guest ELF
597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc.

## What changed

A later-scene native profile found about 74% of sampled running JIT work in two
translated geometry functions. Their most frequent blocks were register-state
copies around calls. Many small callees never touch the registers being saved.

An optional converter pass now examines the final prepared C, after hook,
native, site and zone substitution. For the two selected Bully callers it removes
27 save/restore pairs around ten proven leaves. The original saved-register
contract (nine 128-bit GPRs and twelve FPRs) is preserved. Unknown context use,
address escape, helper calls, indirect calls, missing/hooked/duplicate bodies,
dynamic indices, saved-register accesses and scheduler checkpoints retain the
original protection. Linker function wrapping is rejected with this option.
The pass is off unless the pack explicitly selects callers.

All callee operations, guest memory effects, arithmetic, floating-point rules,
call ordering and loop safe points remain. The old v0 native bodies remain
disabled. No renderer, texture, audio, simulation algorithm, frame-skip or
approximate-math change was made. Only two generated compilation units changed.
The separate aligned-copy prototype was investigated but was not included.

## Complete-game measurement

| Same opening-scene interval | Build 11 | Build 15 |
| --- | ---: | ---: |
| Camera completions, counter 8 to 80 | 72 | 72 |
| Independent host elapsed seconds | 44.062173 | 32.599036 |
| Camera completions / host second | 1.6341 | 2.2087 |

**Elapsed time fell 26.02%; camera throughput increased
35.16%.** This interval includes the later long gap between
camera completions. That gap still exists. The first eight logged scene
summaries match exactly, including every geometry/state/count field and the
9,809 submitted draws. Both completed the interval without a fatal/deadlock
report before deliberate termination. Both screenshots were inspected.

One sequential pair, Linux PPSSPP 1.20.4 JIT, PSP-2000/3000, OpenGL 1x,
Mesa 26.0.8 llvmpipe LLVM 21.1.8, virtual CPU **1000 MHz** (actual boot report
1000 CPU / 500 bus), normal 100% emulation, frameskip 0 and sound enabled with
dummy physical audio. Same media/settings; private configuration copies.
No compiler, tests or other emulator ran in the measured windows.

The observer read existing camera/frame counters from live PSP RAM every 10 ms;
the counters and three unpatched executable prologue instructions were checked
against ELF symbols/bytes. PPSSPP's documented JIT patch was allowed only in the
first prologue word. Reads took tens of microseconds. This avoids using buffered
log arrival times for the measured interval.

Camera completions are **not gameplay FPS**. There can be multiple camera passes
in one gameplay frame. A single Linux pair does not establish an Android result,
sustained playability, or the same gain at Auto/333 MHz.

## Verification

Fresh checks for this change:

- Exact source comparison: only 27 preservation wrappers disappear, with every
  existing loop checkpoint unchanged.
- Conservative classifier: 38 unsafe/unknown negative cases; portable asset-free
  tests cover the full saved-register set, other callers, missing/hooked/duplicate
  bodies, indirect calls, malformed configuration and idempotence. A prefix-match
  defect found during development was fixed before these passes.
- Ten actual locally generated leaves: **40,000 full context + 64 KB RAM
  comparisons** on the host under ASan/UBSan, all four rounding modes; another
  **40,000 comparisons on PSP in PPSSPP**, all four FPU modes with FTZ. Every
  saved register is checked independently. Zero differences/errors.
- Initial random fixtures put stack/matrix data beyond the valid guest-memory
  window and failed in the unchanged reference. The fixtures were constrained
  to valid guest addresses; the passing runs use those corrected fixtures.
- Fourteen affected converter build/profile regression tests pass.
- Complete converter/build passes, with exactly two generated units recompiled.
  fn_0012a5c0 shrank from 0xa8b0 to 0x8cd4 bytes; fn_0037eeb0 from 0x2a40 to
  0x1eac bytes. No old native implementation was enabled.
- The portable harness generator's C/header output matches the executed PSP
  harness byte for byte. Runtime/source archive checks are recorded separately.

Build 11's geometry, clipping, texture/alpha/depth, GPU and audio checks are
reused for identical implementation inputs; those suites were not all rerun.
The original register-preservation requirement is not relaxed. The source ZIP
contains the asset-free classifier tests and a harness generator that extracts
the ten leaves from your own locally prepared translation.

## Install and Android test

Follow INSTALL.txt. Close PPSSPP, copy test-build/ contents into a backup of your
complete converted game folder, and fresh-boot this EBOOT. Keep disc/,
SLUS_212.69, discmap.txt, iso_meta.bin, BULN.pmf, BULN.wav and memcard/.

For the measured configuration comparison, use game-specific PPSSPP settings:
System > Change emulated PSP's CPU clock = **1000 MHz**, 1x resolution, frameskip
0, normal speed and sound enabled. Use the same backend/settings/scene for build
11 and build 15. PPSSPP labels the virtual-clock option unstable; it changes the
emulated PSP instruction budget, not your phone's physical clock. Restore
**Auto (0)** and fresh-boot if pacing, controls or sound worsen. Test Auto/0
separately if that is your usual configuration; this code works with either.

Send phone model, PPSSPP version/settings, session.log and a real-time recording
with the FPS display. Android sustained FPS, full gameplay/controls/saves, full
visual equivalence and actual audible quality remain unverified. Existing
unsupported graphics/audio pipelines remain.

## Reproduce the optimization checks

Apply the cumulative app/ overlay to the stated PS2RC revision and build through
its Python converter (`python -m ps2rc.convert ...`). The optional pass is applied
by that converter's Builder.prepare; the legacy mk/build.sh path does not apply
this pass. The pack selects only fn_0012a5c0 and fn_0037eeb0 through
build.leaf_csave_callers. Removing that option preserves the original wrappers.
The final prepared C is required for the pass so hooked implementations cannot
be mistaken for their guest originals.

From this source overlay's root, run the asset-free checks:

```sh
python3 tests/check_leaf_csave.py
python3 tests/prepare_leaf_runtime.py --prepared /path/to/work/build/gen_prep --output /tmp/bully-leaf-test
```

For PSP, run `make -C /tmp/bully-leaf-test` with the documented PSP toolchain on
PATH and boot its EBOOT in PPSSPP. A passing leaf-test.log ends with
`COMPLETE comparisons=40000 errors=0`. This harness is a separate test executable;
it is not the game EBOOT.

For host verification, compile the four generated C files with strict math and
sanitizers:

```sh
cd /tmp/bully-leaf-test
cc -O2 -g -std=gnu11 -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fsanitize=address,undefined -fno-omit-frame-pointer main.c leaves.c reference.c candidate.c -lm -o test
./test
```

The generated leaves come from the user's own matching disc. No generated guest
source or commercial media is bundled with these test tools.
