# Optimization test 02 — bounded integer clipping interpolation

The baseline is test01's actual clipper (`tests/clip_test01_reference.c`).
The game still requires a measured Android test; **14 FPS is not established**.

## Main change

PSP has hardware single precision but implements double arithmetic in software.
Crossing edges interpolate nine values: position XYZ, color RGB, UV and alpha.
This update accelerates those interpolations using 32-bit fixed-point weights
and 64-bit integer products. It preserves the original double distance and
intersection weight, plane order, validation, geometry and all attributes.

A conservative error bound covers both weight truncation and the original double
expression's rounding. The fast result is accepted only when that interval fits
within one float rounding cell, with an additional quarter-ULP guard at exponent
transitions. Wide exponent gaps, opposite signs, invalid domains and ambiguous
rounding retain the original expression. Identical finite endpoints use their
exact value, including signed zero. Ineffectual zero terms avoid extra double
products/sums, and `1-t` is calculated once per intersection. No global fast-math flags are introduced.
See `app/games/SLUS-21269_v1.02/src/clip_lerp.h` for the bound and implementation.

This changes how interpolation is calculated while retaining the existing
bitwise output contract. Frozen reference tests are kept unchanged.

## Checks

- Host ASan/UBSan: 18,753,065 interpolation comparisons, zero differences.
- PSP: 210,760 interpolation comparisons in the game thread's round-toward-zero / flush-to-zero FPU mode, zero differences.
- Complete polygons: 105,061 comparisons including alpha, zero differences.
- Original clipping: 100,000 cases and 7,939,133 ordering/classifier checks pass.
- Four renderer bodies: 1,000 strips, 11,213,104 identical submission bytes.
- Full EBOOT build succeeds using PSP GCC 15.2.0 and the same PS2RC revision.

PSP diagnostic under PPSSPP 1.20.4/OpenGL, 10,000 triangles per fixture:

| Fixture | Test01 (PSP us) | Test02 (PSP us) |
| --- | ---: | ---: |
| Visible | 31,111 | 31,347 |
| Side crossing | 972,345 | 484,880 |
| Multiple planes | 2,849,308 | 1,584,405 |

These are isolated emulated PSP-clock timings, **not game FPS**. The fully
visible path does not use interpolation. Host hardware doubles are faster than
the integer method; the host microbenchmark regresses and does not predict PSP
performance. Sustained game performance needs independent wall-clock measurement.

## Reproduce

Run `bash tests/run_clip_lerp.sh`, `bash tests/run_clip_edges.sh`,
`bash tests/run_clip_differential.sh`, and `python3 tests/renderer_differential.py`.
For PSP, add pspdev/bin to PATH and run `make -C tests/psp_clip_lerp`.
Run that EBOOT to write `clip-lerp.log`. Build `tests/psp_clip_edges` with
`BASELINE=clip_test01_reference` to compare clipping with test01; clean first
when switching baselines. The frozen reference source comes from the supplied
port and test01, with its original notices/licenses retained.

Use the installation procedure in INSTALL.txt. Keep your complete disc/media and
save data, start the new EBOOT from a fresh boot, and avoid old emulator states.
Full runtime comparison results are in the delivered TEST-RESULTS-02.md.

## Opening-scene game comparison

A fresh test01 boot completed 17 camera passes in 10.283 host seconds (1.653/s).
The final test02 boot completed 22 in 10.533 host seconds (2.089/s): an observed
26.3% increase in camera-completion rate. Both use Linux PPSSPP 1.20.4, software
Mesa OpenGL, JIT, 1x, PSP-2000/3000, frameskip 0, dummy physical audio and the
same game files/config. The first eight camera summaries match exactly in all
logged fields; a candidate capture shows the Bullworth entrance scene.

This is a short sample with 50 ms polling, one fresh boot each and different intro
skip times. Only post-startup camera windows are compared; they cover nearby
passes rather than an identical recorded draw replay. Multiple cameras can
belong to one gameplay frame. This is not gameplay FPS, Android acceptance,
complete pixel equivalence or a sustained-gameplay test. The historical later
guest-work pause is outside this sample. **14 FPS remains unmet.**
