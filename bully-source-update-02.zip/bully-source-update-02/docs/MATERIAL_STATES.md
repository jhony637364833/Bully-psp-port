# Compressed material render states

The earlier renderer used one state for every material: no blending, alpha > 0,
and depth testing/writes enabled. The original SLUS-21269 v1.02 bridge instead
sets GS TEST, ALPHA, PRIM and ZBUF for each mesh. This is a rendering repair:
it preserves original game-selected states for the supported equations instead
of forcing the former adapter defaults. Geometry, lighting gains, strip order,
full 32MB guest RAM and skin topology checks remain unchanged.

## Evidence and mapping

After guest bridge 0x0029dc50, capture matching stream/material identities and:

| Register | Address relative to GP | Observed values |
|---|---:|---|
| ZBUF | -25168 | 0x01000118, 0x101000118 |
| TEST | -25152 | 0x5064d, 0x513fb, 0x5140b |
| ALPHA | -25112 | 0x88, 0x44, 0x8000000068 |
| PRIM | -25096 | 0x78, 0x58 |

The first scene contains 377 compressed material submissions. All have blending
enabled; 40 mask depth writes. The black4 meshes have zero RGB in both prelight
banks and blended textures. Raising vertex brightness is not a correct repair.

- ALPHA 0x44 maps to source-alpha / inverse-source-alpha blending.
- ALPHA 0x88 maps to source-alpha / zero.
- ALPHA 0x68 with FIX=128 maps to additive source plus destination
  (`(Cs - 0) * 128/128 + Cd`). Its D selector is1 (destination).
- Alpha reference is scaled by two to match the existing texture converter.
  Supported references are 0..127; references beyond that and unsupported
  blend equations retain the old adapter fallback.
- GS reversed depth comparisons map to GE forward depth comparisons.
- AFAIL=KEEP discards failed fragments.
- AFAIL=FB_ONLY draws failed fragments into color without depth writes, using
  complementary alpha tests for each triangle. Up to128 triangles share one bounded command list and one GPU wait;
  the two draws for each triangle remain adjacent. This preserves ordering even where triangles overlap.
- If depth is already masked, both FB_ONLY branches are identical and can be
  one draw. Conservatively opaque textures with a guaranteed passing alpha
  comparison also require one draw. The minimum queued vertex alpha must
  guarantee the captured comparison passes. Opaque texels preserve vertex alpha.
- Build06 adds a second proven case for FB_ONLY with depth writing enabled:
  NEVER, or a GEQUAL/GREATER reference above the entire submitted vertex-alpha
  bound, means every passing draw is empty. Texture modulation cannot increase
  that bound. One ordered color-only fail draw then replaces those empty passes
  and repeated fail draws. The original alpha function and depth mask are restored.
  Mixed or unproven batches retain adjacent per-triangle pass/fail draws. Primitive
  order, blending and observable depth behavior remain the original contract.

The original bridge runs unchanged. Lighting is captured before it consumes
its globals; GS state is captured afterward. Unsupported state is not guessed.
The adapter does not yet implement DATE, ZB_ONLY/RGB_ONLY alpha-fail modes,
material states for the other pipelines. Compressed lit meshes now use the
original vertex/material alpha mapping, interpolated through clipping; see
LIGHTING.md. Unsupported lighting paths retain their original opaque fallback.

## Checks

`bash tests/run_native_state.sh`: sanitizer checks using observed register
fixtures, bounded addresses, unsupported states and unchanged output on failure.

`make -C tests/psp_state_smoke`: real PSP renderer with synthetic textures.
First three seconds: blue, half-red/half-blue, green. After three seconds:
blue, red, green. The final green surface lies behind an alpha-failed foreground
but ahead of the background, testing that FB_ONLY did not write depth. The later
phase exercises the opaque and already-masked depth optimizations.
At six seconds the background turns cyan and the center uses half vertex alpha
with an opaque texture: cyan, half-red/cyan, green. At eight seconds the center
switches to FIX128 additive blending: cyan, white, green. The white center
proves destination color is retained, even though vertex alpha remains half.

## Compiler specialization

`texture_cache_fast.c` specializes the prepared 0x0024d848 texture-residency
body. Its 128-bit guest registers stay local between observable boundaries.
Every guest call and scheduler slow path synchronizes all registers in both
directions, and return writes the complete register bank back. Memory accesses,
HI/LO operations, calls and all seven scheduler safe points are preserved.
The original remains available as fn_0024d848__ynguest. The mechanical checker
verifies the allowed rewrite against that retained body:

```
python3 tests/check_texture_cache_body.py /path/to/build/gen/main_029.c
bash tests/run_texture_cache_replay.sh /path/to/host-build ram.bin context.bin
```

The differential replay consumes a pre-call RAM/context snapshot from the same
host ABI. It compares complete context and32MB RAM, boundary-register traces,
call counts and backedge counters across16 scheduler offsets. Its callbacks
mutate spare registers and RAM to test synchronization in both directions.
This is a correctness check; the delivered report records actual PSP speed.

The existing8KB mesh and64KB texture scratch buffers are allocated once after
the intro from the runtime allocator (64-byte aligned). Their capacities, the
startup reserve, and the full32MB guest RAM remain unchanged.

The profiled function0x0012a5c0 also has a compiler-only native specialization
(`geometry_work_fast.c`). Its prepared body is unchanged except for its name;
five scheduler checkpoints and strict floating-point flags remain intact.
`tests/check_geometry_work_body.py` checks it against the retained generated
body. Full host replay counters must match before accepting a build.

`python3 tests/check_alpha_batch.py` compiles the actual batch-selection helper
and checks inclusive/strict alpha boundaries, varying vertices, mixed textures,
masked depth and rejected comparisons under ASan/UBSan. The PSP smoke's
half-alpha phase tests the inclusive boundary on the GPU.

## Build 11 guaranteed-pass extension

Build 11 can prove passing alpha for converted single-level T4/T8 textures with
8888 CLUTs, using a conservative minimum of all stored index samples. Unused
palette entries need not lower that minimum. Padding remains included; unknown
formats/layouts return zero. Texture metadata is unchanged, and the minimum is
invalidated at every material bind. For partial alpha, floor(vertexMin * texMin /
256) is a conservative lower modulation bound; fully opaque modulation preserves
vertex alpha. The existing inclusive/strict comparison rules then certify the
whole batch. ALWAYS also has no failing fragments. Only proven-empty fail draws
are omitted; unproven triangles retain adjacent pass/fail draws. This extends the
previous opaque-only shortcut while preserving primitive/color/depth order and
final GPU state. See OPTIMIZATION_TEST_11.md for independent bounds and GPU checks.
