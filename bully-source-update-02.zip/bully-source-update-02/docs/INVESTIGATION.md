# Android PPSSPP investigation — 2026-10-29

## Scope and provenance

The repository initially contained only LICENSE. Source pack 106 was recovered
from the prerequisite link in the user's lighting-experiment archive. Its ZIP
SHA256 matches the supplied baseline manifest:
`e413b3b239cb0012d48c4f9aa7ba4d9c0540541912691cc99dd02df148e1b4e6`.
Imported source licenses/notices are preserved. Historical reports are supplied
context, not fresh validation. No game executable, disc files or saves are tracked.

The user's R4 EBOOT/configuration remain unmodified in task inputs. Source 106
predates R3/R4 elapsed movement/audio changes. This source tree does not reproduce
R4, and replacing R4 with a source106 build would lose those changes.

## Changes and baseline contracts

- Import the supplied lighting experiment: select RGB/monochrome once per vertex;
  share only the monochrome prelight interpolation. Preserve the order of gain,
  clamp and material multiplication, alpha, and signed-zero arithmetic.
- Repair the historical CPU renderer fixture by selecting a near plane outside
  the documented GE fast-path range. It still compares every output byte with
  all three frozen CPU renderers. The former normal-camera fixture accidentally
  exercised GE edge clipping introduced intentionally in build42; that path
  does not promise identical software-clipped vertices. The existing independent
  GPU guard fixture retains normal cameras, exact fallback comparisons and GE
  safety/input checks. No renderer behavior or numerical guarantee changed.
- Repair projection/material diagnostic callers: call
  `bully_world_overlay_present()` after the camera completes, as the actual
  guest flip hook in render_probe.c does. The old diagnostic rendered into an
  undisplayed buffer. Camera end still completes the background; the flip owns
  display presentation. Runtime camera/HUD composition is unchanged.

These are source integration and diagnostic repairs. Neither the stale-fixture
failures nor their repairs establish the cause of the reported mission bugs.

## Fresh checks

Environment: Ubuntu26.04.1, host GCC15.2.0, Python3.14.4; official pspdev
v20261001/GCC15.2.0 and desktop PPSSPP1.20.4. Native tests use software OpenGL,
333MHz/default clock, buffered rendering, 1x and frameskip0. No phone tested.

- Host lighting: 2,048,576 comparisons, all four rounding modes and exhaustive
  signed-zero byte pairs, ASan/UBSan passed.
- Native PSP lighting EBOOT in PPSSPP: 1,148,576 comparisons passed across the
  four PSP rounding modes, including exhaustive signed-zero byte pairs.
- CPU fallback renderer: 1,000 strip cases; 11,212,744 identical bytes across
  the candidate and all three frozen implementations; ASan/UBSan passed.
- GPU guard: 12,800 cases, four rounding modes; 9,600 exact fallback cases and
  3,200 GE safety cases passed; 2,912 intentional GE output differences.
- Supplied current-renderer lighting comparison: 1,000 strips, 10,323,184
  identical bytes passed before import. The imported relevant files match.
- Source106 native light: 56 assertions passed. Unchanged clipper: 100,000
  differential cases and 7,939,133 ordering checks passed with zero errors.
- Lighting, projection and material PSP diagnostics compiled, linked and packed.
  Existing misleading-indentation and unused-function warnings remain.
- Host lighting benchmark was noisy and overlapped emulator activity. It cannot
  establish a game speedup or a PSP performance result.

- Native material diagnostic: all four expected panel color triples observed,
  including alpha/depth and additive blending. The first old diagnostic run
  stayed black because it never presented; after the caller fix, a15-second
  attempt observed only phase1. A longer run observed all four phases.
- Native projection diagnostic: center pixel `(48,0,0)` observed, matching the
  documented perspective-correct gradient (rather than affine red near127).
- Camera hooks fixture initially failed to link because it omitted the guest
  flip and overlay stubs now referenced by render_probe.c. Added the missing
  adapters and assertions for guest-call → flush → present ordering and whole
  register-context preservation for zero/nonzero returns; it now passes.
- Actual composition and camera timing tests passed without runtime changes.
- Pinned engine plus app/ overlay: `python -m ps2rc.convert --help` imports and
  exits successfully. This is a CLI import check, not a full conversion.

## Original R4 boot result before full game archive arrived

Cold booted a copy of the three unchanged R4 replacement files in PPSSPP1.20.4.
The log reports333MHz/default clock, successful full32MB guest RAM allocation,
then `elf_open=FAIL err=80010002 path=umd0:/SLUS_212.69` and
`FATAL: cannot open SLUS_212.69`. Result: boot_incomplete, error code4,
zero frames and zero main-loop iterations. The required disc program is absent
from all supplied archives; the game cannot reach a yard or mission here.

R4's lighting instruction pattern matches a source106 compile after relocation
instructions are excluded. The supplied optimized lighting pattern does not
match. This helps identify the baseline but is not a full binary/source proof.
No executable was patched.

## Acceptance status before full game archive arrived

14 rendered gameplay FPS, yard performance, cinematic timing, full mission
animation behavior and sustained Android operation remain unverified. Full game
build/boot needs the matching local disc/runtime data, absent from supplied
archives. R4 rebuild additionally needs its custom timing/audio source, also
absent. The source106 pack identifies the expected boot ELF in pack.toml.

Similar FPS on different phones is a useful clue for investigating emulated
CPU budget or pacing; it does not by itself distinguish either from a port
bottleneck. No PPSSPP CPU-clock override or skipped guest simulation was added.

Based on PS2RC by SandstoneDev
https://github.com/SandstoneDev/PS2RC
Community: https://discord.gg/wV8x46ZTDu

## Full runtime archive follow-up

The later supplied PS2RC_SLUS21269.zip resolves the missing-disc blocker. All355
ZIP entries passed CRC and all248 discmap files have their expected sizes. The
boot executable matches pack.toml. Archive SHA256:
`31517dba0be848dd29bad7c5acfb18466003eae2a8a79709f216bedaa4704193`.

Despite different PBP hashes, the extracted DATA.PSP ELF is byte-identical to R4:
`0e653786e9cd667371575d2b5f50eecf39d7d749736a420140e0356429746511`.
Only menu assets differ. No newer timing source was recovered from this archive.

Cold boots now reach both the supplied office save and the fresh-game yard.
See [PPSSPP profile measurements](PPSSPP_PROFILE.md) for the CPU-budget comparison.
These are configuration experiments with unchanged R4 code. They do not establish
mission-animation repairs or Android performance. No new game EBOOT is claimed.
