# Bully PSP experimental test 25

**Android 14 FPS remains unverified.** This build reuses skinning results from
whole-object validation during the immediately following draw. Build 24 remains
available for rollback.

## Install

Copy `test-build/` contents from the runtime ZIP into a backup of your complete
converted game folder. Includes EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, installation
instructions, checksums and licenses. Keep disc/, SLUS_212.69, discmap.txt,
iso_meta.bin, BULN.pmf, BULN.wav and memcard/. Fresh-boot; do not load a save
state from another build.

EBOOT: 16,500,196 bytes. SHA256:
`bf977b14ff796d75c28ea1ba113cc44ce143c8c5a1134ac9e37a7a8369fca317`.

Optional PPSSPP fragments are unchanged from build 24. Read CONFIG-TEST-18.md
before using them. Its measurements describe historical build 17. Experimental
virtual 2000 MHz exceeds PPSSPP 1.20.4's UI maximum of 1000; it changes the guest
instruction budget, not the phone's physical clock. Do not increase arbitrarily.
Restore Auto/0 if needed. The EBOOT does not apply the INI. Compare builds at
identical settings.

## Matched stationary-scene measurement

| Camera 120 to 360: 240 events | Build 24 | Build 25 |
| --- | ---: | ---: |
| First host seconds | 35.580043 | 35.095968 |
| Reverse-order repeat seconds | 35.578504 | 35.087746 |
| Mean seconds | 35.579273 | 35.091857 |
| Camera completions / host second | 6.7455 | 6.8392 |

**1.39% higher pooled camera throughput**, 480 events per build. Completed
run order: 24, 25, 25, 24. Mean saving 487.42 ms exceeds four times
the maximum within-build replicate spread or 20 ms polling floor
(20.00 ms). Both ordered pairs improve.

These camera completions are not Android gameplay FPS. All ten logged
WORLD_COMPLETE summaries through camera 360 match across all four runs,
including the initial 9809 draws and later object, triangle, lighting and draw
counts. All four scene PNGs are byte-identical.
Opening camera 8 to 80 seconds in run order:
13.412976, 13.379535, 13.374824, 13.466215.

Environment: PPSSPP 1.20.4/JIT, Mesa 26.0.8 llvmpipe LLVM 21.1.8, OpenGL 1x,
normal 100%, frameskip 0, sound enabled in config, private virtual CPU 2000 MHz /
bus 1000 MHz. Same media and settings. SDL cannot open an ALSA output device
here; audible playback was not checked. Actual unchanged frame/camera counters
polled at 10 ms with monotonic host time. Loaded ELF prologue verified, allowing
PPSSPP's first-word JIT patch. No concurrent compilers, tests or other emulator
in measurement windows.

Optional buffer allocation was observed in both candidate runs:

~~~text
WORLD: optional skin cache 136212 bytes; remaining user memory 4701440 bytes
WORLD: optional skin cache 136212 bytes; remaining user memory 4701440 bytes
~~~

## Optimization and preserved contract

Previously, native_object.c fully decoded and skinned every mesh to validate
the object. world_display.c then decoded and skinned the same meshes again to
draw. The new optional caller-owned buffer retains validated batches for this
immediate draw, including repeated seam vertices and every ADC skip byte.
Batch order and mesh boundaries are preserved.

Every mesh, count and declared triangle total must still validate before the
object output is committed or any draws are submitted. A malformed later mesh
invalidates the entire buffer and preserves the previous rejection. Buffer
capacity is 4096 vertices and 64 batches; overflow keeps the object valid and
uses normal decoding. NULL or unavailable storage also uses normal decoding.
The existing public bully_native_object API retains its signature, allocation-
free behavior, read-only RAM contract and untouched output on failure.
The additional cached API writes only caller-provided disjoint storage.

The renderer allocates one 136,212-byte buffer after the first valid skin object
and successful GU initialization. It makes one direct optional PSP partition
allocation, checking for the requested buffer size plus 1 MiB of free user
memory before the attempt. Allocation
failure or insufficient memory preserves the original path. It deliberately
avoids hle_plat_big_alloc, whose existing implementation exits on failure.
The first object draws normally; later objects reuse the same bounded buffer.
This is additional persistent memory until process exit, not a per-object
allocation. Cache reuse requires unchanged guest RAM and FPU mode; rendering
is synchronous and runs no guest code between validation and draw.

Changes are confined to native_object.c, native_object.h and psp/world_display.c.
Skinning results and palette policy remain exact. Topology, lighting, clipping,
textures, audio policy and guest execution are preserved. All 187 prepared
guest C units are byte-identical to 24. Previous unsafe native overrides remain
disabled. Compressed validation already skips expansion and is unchanged.

## Verification

Fresh host ASan/UBSan and separate PSP diagnostic EBOOT each passed 932 object
cases in all four rounding modes, PSP FTZ and varied initial status patterns:

- 549 objects accepted; 427 complete buffers, 84 capacity fallbacks and 4749
  mesh replays. Valid fixtures must succeed. NULL-buffer cases also fall back.
- 1, 8 and 64 bones; 1, 2, 8, 16 and 64 meshes; 3, 8, 64 and 256 vertices per
  batch; single and multiple batches, up to 49,152 decoded vertices per object.
- Exact capacity boundaries and both vertex/batch overflow paths; corrupted
  object fields, matrices, palette, weights, final mesh tags, vertex counts and
  triangle totals. Failure leaves object output unchanged and buffer unusable.
- Existing public API and cached API agree with frozen build 24 on complete
  object output, scratch bytes, return value, full PSP FCR31 and host status.
- Replayed visitor bytes, skip flags, batch boundaries and call order match
  normal decoding. Full validation/draw-cycle FP status agrees when retaining
  the status produced by validation, as the renderer does.
- Guards, periodic full RAM snapshots, null/invalid replay parameters and
  malformed replay metadata rejecting before any callback.
- Five paths through the actual extracted optional allocator passed ASan/UBSan:
  low total memory, low largest block, allocation failure, null block address
  with release, and success. Only one attempt is made.
- The portable generator reproduces all 18 fixture inputs exactly.
- Full game build succeeded without warnings. Runtime/source ZIP CRC and every
  payload checksum, source/engine/binary identity, unchanged generated code,
  patch dry-run, old versioned downloads and original configurations checked.

Unchanged prior math, VU, rendering and audio checks are reused by source
identity; they were not all rerun.

## Reproduce

Overlay targets PS2RC 0.1.1 revision 332a437f21f7ef694943caef885a7d28410cbc41,
PSP GCC 15.2.0 / SDK 20261001. From the supplied source root:

~~~sh
python3 tests/prepare_skin_replay.py --output /tmp/bully-skin-replay
make -C /tmp/bully-skin-replay
~~~

Boot that separate diagnostic EBOOT. skin-replay.log must end with
`COMPLETE cases=932 ... errors=0 size=136212`. Host checks, from its directory:

~~~sh
cc -O2 -g -std=gnu11 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fno-strict-aliasing -Icandidate main.c reference.c candidate.c candidate/native_skin.c candidate/native_mesh.c -lm -o test
./test
cc -O2 -g -std=gnu11 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer allocation-test.c -o allocation-test
./allocation-test
~~~

Android >=14 FPS, full gameplay, walking controls, saves and audible quality
remain unverified. This remains an incomplete gameplay port. Device acceptance
needs phone model, PPSSPP version/settings, session.log and a real-time FPS
recording of matching scenes.
