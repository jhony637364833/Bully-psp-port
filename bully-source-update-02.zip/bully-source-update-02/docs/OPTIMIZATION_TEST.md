# Optimization test update — 2026-10-25

The source baseline is the user's `bully-fps-optimization-source (2).zip`
from `My latest build` in the supplied Drive folder. Earlier reports in this
repository describe that supplied snapshot and are historical evidence.
The original repository root LICENSE is retained; PS2RC-derived files retain
`app/LICENSE` and `app/NOTICE.md`.

## Changes in this update

- Cache each current clipping polygon's side classifications. Evaluate software
  double distances only for edges that actually cross a plane. Intersections,
  vertex order, double interpolation, input checks and full guest RAM are preserved.
- Project and pack each clipped polygon vertex once before triangulating its fan.
  Screen-area rejection, perspective projection, alpha and submission order are
  preserved. All UV checks finish before any output is submitted.
- Add `WORLD_PERF` session-log reports at completed camera boundaries about every
  five seconds on the PSP monotonic clock. Reports group one camera identity and include elapsed time,
  completed passes, total camera time and longest camera duration. Camera changes
  reset the sample. Multiple cameras can belong to one gameplay frame; these
  numbers must not be described as gameplay FPS. Time between camera updates is
  included in the elapsed window. The field named `wall_us` uses
  `sceKernelGetSystemTimeWide`: PPSSPP emulates this clock and it may advance
  slower than host wall time. Use a real wall-clock recording to measure Android
  throughput; these log durations alone do not establish device performance. An unfinished/stalled camera cannot emit a report until
  it completes; the existing watchdog remains available during that interval.

## Fresh verification

- Host ASan/UBSan: 105,061 complete-polygon comparisons with the frozen immediately
  preceding clipper, including all alpha bytes; zero differences.
- Existing clip suite: 100,000 differential cases and 7,939,133 ordering/classifier
  checks; zero errors.
- Renderer differential: 1,000 synthetic strips, 11,213,104 identical output bytes
  across the original, two supplied prior renderers, and this update.
- Existing lighting (56 assertions), audio synchronization (1,500/1,500 synthetic
  audible hops after warmup), and alpha batching (10 assertions) checks passed.
  Synthetic audio does not establish audible gameplay.
- PSP GCC 15.2.0 clipping diagnostic in PPSSPP 1.20.4/OpenGL: 3,277 complete-polygon
  comparisons; zero errors. For 10,000 triangles per fixture, PSP clock timings:

| Fixture | Supplied clipper | New clipper |
| --- | ---: | ---: |
| Fully visible | 30,783 us | 31,229 us |
| One side crossing | 980,657 us | 964,620 us |
| Multiple planes | 3,027,410 us | 2,846,862 us |

These are synthetic emulated PSP timings with concurrent compilation, not
Android or physical PSP results or a whole-game speedup. The host CPU has native
doubles and its clipping microbenchmark became slower; PSP-specific measurement
is required. The later clipped-projection cache is covered by the output
comparison above but is not part of that isolated clipping benchmark.

## Build and test

Overlay `app/` onto PS2RC 0.1.1 commit
`332a437f21f7ef694943caef885a7d28410cbc41`. Use the matching NTSC-U SLUS-21269
v1.02 disc and PSP GCC 15.2.0. Retain the supplied build's strict FP flags.
Follow the source README for the converter command. The output requires the
complete converted disc data and both supplied intro media files.

For Android, copy the test update into a BACKUP COPY of the existing working
converted game folder. Keep its `disc/`, `SLUS_212.69`, `discmap.txt`,
`iso_meta.bin`, `BULN.pmf`, `BULN.wav` and saved games. Open the updated
`EBOOT.PBP` in PPSSPP with PSP-2000/3000 memory, OpenGL, buffered rendering,
1x resolution, sound on and frameskip 0 for comparison. Restart the application
from the EBOOT; old emulator save states contain the old executable.

Return `session.log`, phone model, PPSSPP version, the backend/settings used,
and a short recording of the same scene before/after. Compare completed camera
throughput and visible motion, not PPSSPP's emulated vblank counter alone.

**The 14 FPS target is not verified.** Existing translated game traversal and
geometry routines remain expensive. No routines, sound updates, collision work,
geometry validation or scheduler checkpoints are bypassed in this update.

## GPU material verification

The final renderer also passed all four expected material/color phases in
PPSSPP 1.20.4/OpenGL. A scratch copy of the existing synthetic fixture shortened
only phase dwell (600 total frames to 60); geometry, batch crossings, camera
mismatch/duplicate-end injection and expected RGB values were retained.
Screenshot assertions sampled away from the X cursor and verified blue/purple,
blue/red, cyan/mixed and cyan/white phases, with the green depth-check panel.

The full game EBOOT compiled and linked: **16,662,132 bytes**. Full-game runtime
results and the exact SHA256 are recorded in the generated test package.

## Full-game smoke check

The exact final EBOOT reached the Bullworth entrance scene in Linux PPSSPP
1.20.4 with software Mesa, 1x OpenGL, JIT and frameskip 0. A screen capture showed
the gate, road, environment and character. Completed supported camera passes
began at virtual frame 604; later timing windows reported 9 and 8 completed
camera passes. The process continued through virtual frame 648 before an
external timeout stopped the test (exit 124). No crash was observed before
cutoff. These counts and emulated timestamps do not establish gameplay FPS.
Startup and scene updates remained slow; existing unsupported-object messages
were still present. Physical audio used a dummy device. The optional exception
helper was copied after this boot, so its runtime handling was not exercised.
Android performance, sustained gameplay and the 14 FPS target remain unverified.
