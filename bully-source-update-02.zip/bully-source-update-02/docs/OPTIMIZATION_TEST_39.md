# Bully PSP test 39: reuse exact clipping intersections

Targets: **PSP-2000, PSP-3000 and Android PPSSPP only**.

The native renderer can reuse clipping intersections for unchanged geometry
and stable cameras. Each hit compares every endpoint byte, clipping plane,
near/far bits and complete floating-point control state. The result and full
floating-point state match the original calculation. Moving cameras and skin
objects retain the normal path. Precision, draw order and supported overlays
are preserved. No emulator speed or buffer overrides are required.

The optional cache uses **640 KiB**. It allocates once only when the partition
can still reserve the existing **192 KiB HUD texture arena plus 1 MiB free**.
Postallocation fragmentation and allocation failures use normal clipping.
An eight-entry miss history helps recurring intersections survive one-use edges.

## Validation and measurements

- Host ASan/UBSan and PSP executable: 2,048 clipping cases with three repeats,
  four rounding modes and two flush modes; exact polygons, tails, input and
  complete FCR31 state. Full-key mutations, collisions, trap bypass, incomplete
  commits, reset and epoch wrap pass against the frozen build38 math.
- Actual renderer: 256 strips with three repeats and all rounding/flush modes;
  exact vertices, triangles, flush sizes, input and FCR31 on host and PSP.
- Seven allocation/fallback cases and camera bounds/stability/change checks pass.
  Retention workload: 36 hits and two admissions with interleaved one-use edges.
- Five affected existing regression consumers pass: 512 GPU submission cases,
  1,000 historical renderer cases, 5,120 strip-rotation cases, and both complete
  finite/mask suites. Original expected outputs retained.
- Desktop PPSSPP normal automatic clock, runtime333MHz/bus166, virtual PSP2000,
  OpenGL1x buffered rendering, frameskip0: camera120→180 took
  **50.688s → 49.843s**
  (1.70% throughput gain); camera180→240 took
  **51.024s → 50.151s**
  (1.74% gain). These are two adjacent
  windows in one matched pair, **not gameplay FPS or a repeatability claim**.
  No compiler, sampler or second emulator overlapped the selected windows.
- All ten world summaries match build38. Start/menu and Select/map images,
  including paused repeats, match build38 byte-for-byte. Both controls resume
  camera progression. Desktop checks do not establish device compatibility.
- Unchanged generated guest C, config, PRX, media and earlier input identities
  were reused; original math and renderer PSP runs reused only after current
  portable generators emitted exactly the same tested C and headers.

## GTA SA reference

The supplied SLES-52541_v2.01 pack was briefly inspected. It demonstrates cached
GE mesh lists, larger asynchronous command lists, native sky/postfx and optional
quality policies. Its hardcoded game hooks/data layouts differ from Bully;
no GTA source or addresses were imported. Its FPS claims were not measured here.
These are useful design references for further Bully-specific work.

## Install and test

Back up your working game folder. Copy the contents of `test-build/` from the
runtime ZIP into that copy. Keep `disc/`, `SLUS_212.69`, `discmap.txt`,
`iso_meta.bin`, `BULN.pmf`, `BULN.wav` and `memcard/`. Unchanged disc/media files
are omitted. Start from a fresh boot; older emulator save states are unsuitable.
Build38 remains available for rollback. No PPSSPP settings files are included.

The separate source ZIP contains the complete source overlay and tests; the
patch is cumulative against the imported original source. Asset-free tests:

```
python3 tests/check_clip_memo.py
```

This requires host GCC. The generated math/renderer folders also contain PSP
Makefiles. Set PSPDEV/PATH for the toolchain, run `make -B` in each folder, and
run each resulting EBOOT on PSP/PPSSPP to check actual FCR31 behavior.

## Remaining issues

**14 FPS has not been achieved or verified.** Android and physical PSP devices
are unavailable here. Audio is configured but audible playback is unverified.
School-door entry, black sky, full HUD/tutorial/subtitle/combat overlays, saves
and complete gameplay remain unresolved or unverified. This optimization does
not claim to repair those issues. The renderer still supports a bounded subset
of PS2 commands. Return `session.log`, phone/PSP model, PPSSPP version and a
recording of the same scene to measure device performance and remaining bugs.

EBOOT.PBP: 16,992,260 bytes.
SHA256: a90c81e03d350a28fa883ab3ca848eafcfe1be4eee553605fa8beba1d7e54ab3
