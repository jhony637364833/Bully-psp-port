# Bully PSP test build 101 — direct compressed mesh inputs

## Result

Validated compressed strips can use their original fixed-point attributes in the existing GPU renderer, avoiding temporary 32-byte expanded vertex records. Bounds are computed from signed 16-bit extrema and converted exactly to the existing float units. Submitted GPU vertices, lighting, triangle order, projection and display settings stay equivalent to build 92. This adds no cache or allocation.

The fresh desktop comparison measured **6.30–6.54% higher camera throughput over build 92**. An earlier screening run also improved. **This is not gameplay FPS or a physical-device result. The 14 gameplay FPS target and the disappearing-overlay issue remain unresolved.**

|60-camera interval|Build 92 fresh baseline|Build 101|
|---|---:|---:|
|120–180|12.405320 s|11.643900 s|
|180–240|12.734885 s|11.980227 s|

PPSSPP 1.20.4 on Linux: normal 333 MHz, JIT, buffered OpenGL 1×, frameskip 0. No compiler, sampler or other heavy work during the timing windows. Five controlled gameplay/menu PNGs match byte for byte. Start and Select pause/resume passed in both runs. This comparison covers the controlled starting scene; it does not establish speed across the whole game or on Android/physical PSP.

## Compatibility

The original compressed-decoder API retains its expansion, callback and overlapping-buffer behavior. The renderer-only API tries the raw visitor only when the complete bounded input stream is disjoint from its scratch allocation. This includes DMA commands and later seam reads. An uncertain GPU bound, enabled FP trap, unsuitable batch or failed lighting calculation uses the existing expansion/renderer fallback. The validation-only pass never calls visitors or changes scratch.

The GPU keeps its existing float vertex representation. No packed GE-coordinate format, new simulation pacing, emulator overclock, lower-detail geometry or overlay persistence workaround is introduced.

## Verification

- Host ASan/UBSan and PSP executable: **8,192 raw-versus-expanded GPU cases each**, comparing bounds decisions, complete ordered GPU vertices, queue flushing, return values, source bytes and full restored floating-point state.
- Includes signed fixed-point extremes, all supported rounding modes, PSP flush-to-zero modes, degenerate triangles, repeated lighting inputs, transformed/crossing/outside bounds, exceptional material/transform values and trap bypass.
- Final host and PSP parser checks each pass **2,097,152 scalar cases, 80,000 parser cases, 1,024 original overlapping-buffer/mutating-callback cases, 512 raw visitor integration cases and 1,024 stream-overlap cases**, including scratch writes that collide with a later DMA command.
- GPU checks are reused for the final parser-only guard refinement because the GPU functions and fixture are byte-identical. The parser checks and gameplay comparison were rerun for the final binary.
- The public fixture generator reproduces the executed GPU and parser source files byte for byte. PSP GCC 15.2.0; host GCC 15.2.0.
- Focused game build compiled the mesh parser and world renderer, then linked and packaged the complete game EBOOT. Other guest/native object contents are verified against build 92.
- Runtime/source archive CRCs and every file hash, EBOOT ELF payload, source/build/runtime parity, configuration, memory-card files, previous build 92 downloads and cumulative patch applicability are checked before delivery.

## Reproduce

```sh
python3 tests/prepare_raw_mesh.py /tmp/bully-raw-mesh
# With PSPDEV/bin on PATH:
make -C /tmp/bully-raw-mesh/gpu
make -C /tmp/bully-raw-mesh/parser
```

Run those diagnostic EBOOTs separately on PSP/PPSSPP. Require `gpu-light.log` to end with `COMPLETE cases=8192 ... errors=0`, and `halfword.log` with `COMPLETE values=2097152 parser=80000 sideeffects=1024 raw=512 overlapbridge=1024 errors=0`. They use synthetic data and need no game assets. Host checks compile GPU main with game native_light.c and -lm; parser baseline/candidate source objects use -D__PSP__ -D__MIPSEL__ (main without), then -lm. Use -O2 -fsanitize=address,undefined -fno-omit-frame-pointer -fno-pie -no-pie -std=gnu11 -fno-fast-math -frounding-math -ffp-contract=off.

## Install and remaining work

Close PPSSPP, back up the game folder and memory card, and copy `test-build/` contents from the runtime ZIP into the converted game folder. Keep disc data, intro media and saves. Fresh boot the new EBOOT; old emulator save states contain the previous executable. Physical PSP/Android FPS, audible audio and normal device saves remain unverified. Build 92 downloads remain available.

The previous movement capture showed the HUD disappearing without parser errors or missing textures. Its cause is still under investigation; build 101 does not claim to repair it. A screenshot and the installed build number will help identify whether the reported overlay is HUD, sky or world geometry.
