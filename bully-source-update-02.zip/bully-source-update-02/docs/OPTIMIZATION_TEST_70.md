# Test build 70 — GPU lighting-result reuse

## Measured result

With normal 333 MHz PSP clock, JIT, OpenGL, buffered 1× rendering and frameskip 0, a candidate-first comparison against a fresh build-68 baseline measured:

| Camera interval | Build 68 | Build 70 | Throughput gain |
|---|---:|---:|---:|
| 120–180 | 14.495520 s | 14.190725 s | 2.15% |
| 180–240 | 14.874255 s | 14.554978 s | 2.19% |

These are desktop PPSSPP camera-completion timings, **not gameplay FPS or Android/physical PSP proof**. The **14 gameplay FPS goal remains unmet/unverified**. The reported disappearing overlay/HUD remains unresolved.

All five sampled gameplay and Start/Select menu images match the fresh baseline byte for byte. Both menus paused and resumed correctly. No clock, frameskip, gameplay, save or configuration changes were made for this optimization.

## Change

The GPU strip path now reuses the preceding vertex's packed color when both four-byte color banks match and a material light is active. Lighting depends only on these color banks and the immutable material. Position, UV and normals need not match. The existing prepared-vertex buffer supplies the cached value; no new allocation or persistent cache is used.

Build 68 already bypasses this GPU path with enabled FP traps and restores its private entry FCR on exit. The lighting functions do not change rounding mode. Reuse therefore needs no per-vertex FCR reads/writes. This differs from the earlier rejected CPU lighting-cache trial, whose FP bookkeeping outweighed its benefit. The CPU fallback and public lighting helpers are unchanged.

The original build-68 GPU transform rounding and private-FCR behavior remain; see TEST-RESULTS-68.md / docs/OPTIMIZATION_TEST_68.md. This change adds no further intended numerical difference.

## Checks

Fresh checks:

- 8,192 complete GPU-helper comparisons on host with ASan/UBSan and on PSP code under PPSSPP. Exact return value, ordered packed vertices, queue flushes, triangle count, input bytes and full outgoing FCR.
- Four rounding modes; PSP flush/condition state and enabled-trap bypass; repeated colors with different geometry; monochrome and unlit materials; triangle skips; exceptional light, UV and position inputs; inside, outside and CPU-fallback cases.
- Reuse exercised 399,152 times on host and 378,450 times on PSP. Platform counts differ because the PSP fixture also exercises its hardware trap-bypass state; each candidate matches its own reference.
- The public generator reproduces the executed C fixture byte for byte.
- Focused production compile/relink and fresh game comparison; five exact images and Start/Select pause/resume.
- Archive CRC/hash, source/build/runtime identity, unchanged other native/guest objects, configuration and memory-card checks. The cumulative source patch was dry-run against the original source snapshot.

Build-68 bounds, CPU fallback, model-state, GPU depth/image and movement checks remain relevant to the unchanged code. Their complete results are documented in build 68. This turn did not repeat that entire suite. No physical device, audible host audio or normal device-save verification was available.

## Reproduce the new asset-free fixture

From the source repository:

```sh
python3 tests/prepare_gpu_lighting_reuse.py /tmp/bully-gpu-light
make -C /tmp/bully-gpu-light
```

Run its EBOOT.PBP in PPSSPP or on PSP; check `gpu-light.log` for `COMPLETE cases=8192` and `errors=0`.

For the host comparison:

```sh
cc -O2 -frounding-math -fno-fast-math -ffp-contract=off \
  -fsanitize=address,undefined \
  -Iapp/games/SLUS-21269_v1.02/src \
  /tmp/bully-gpu-light/main.c \
  app/games/SLUS-21269_v1.02/src/native_light.c -lm \
  -o /tmp/bully-gpu-light/host
/tmp/bully-gpu-light/host
```

The runtime archive contains no game assets, memory-card data or diagnostic captures. Follow INSTALL.txt and retain your existing game files. Build-68 downloads remain available for comparison.
