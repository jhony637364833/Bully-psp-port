# Bully converter pack — graphics development build

Target: supplied PS2RC v0.1.1 converter, Bully NTSC-U SLUS-21269 v1.02.
This remains an experimental pack, not complete gameplay support.

## Install in your Windows converter

1. Close the converter and keep a backup of its whole folder.
2. Move the old `app/games/SLUS-21269_v1.02` folder outside `app/games/`.
   Also move any `SLUS-21269_av_probe` folder outside it: multiple packs with
   the same disc identity can make automatic detection select an older pack.
3. Extract this archive and copy its `app` contents into your converter's
   `app` directory, accepting replacements. The package contains the updated
   Bully pack AND the shared translator/runtime fixes it requires.
4. Open the converter, choose your matching Bully ISO, enable movie conversion,
   and choose a fresh output folder. Convert normally. The pack now declares
   both audio generators; no manual generation command is needed.
5. In PPSSPP, use OpenGL, PSP-2000/3000 memory, 1x resolution and buffered
   rendering. Press Cross to skip the intro if necessary. Allow several minutes
   to load. The diagnostic configuration stops at max_seconds=600.

The converter handles disc extraction, original program translation, audio-module
translation, intro media and EBOOT building. This archive contains no disc,
game-derived generated C, or EBOOT. Generators verify both IOP input hashes and
load SCREAM at 0x1000 and AUDVAG at 0x20000.

The pack preserves the full 32 MB EE RAM. Its movie-buffer memory repair requires
all included `app/hle/psp` files. Copying only the `games` folder into an unpatched
converter is insufficient. No other game's pack is included or replaced.

## Graphics scope

The renderer supports the verified float static pipeline and the compressed
static pipeline at 0x29ccc0: signed16-bit positions/UVs, packed prelight colors,
inline CNT batches, exact strip-seam validation and terminal RET. Positions and
UVs use Bully's 1/128 scale. Compressed DMA chains are recognized even when
the original setup changes the material-related geometry flag; this repairs the
17 static-object rejections found in the previous first-scene test.
Geometry is streamed through a 256-vertex working
buffer, so a mesh can exceed 256 total vertices without allocating a whole mesh.

Native material textures are now bound through PS2RC's raster converter, with
one reusable 64 KB buffer and a maximum texture size of 256x256 where the format fits the buffer,
with a128x128 fallback. Transparent
texels are rejected. UVs are clipped with geometry; projected triangles currently
use affine texture interpolation, so surfaces may warp. Material translucency,
UI and lighting-bank blending are not implemented. The first skinning path
uses the original game's current bone matrices (up to64 bones), bounded DMA
references for weights, and validated triangle-strip control flags. It uses
neutral vertex color; original character lighting is not implemented. Skinned
objects with unmatched triangle counts remain excluded, including one observed
11-bone geometry. Unsupported pipelines still execute original guest
code but are not drawn by this renderer. A successful conversion cannot create
those missing rendering implementations. See the repository investigation for
actual runtime results; Android and the Windows GUI remain untested here.

## Send back after testing

The generated game's `session.log`, a screenshot, your phone model and PPSSPP
version. Keep the original working intro build in a separate folder.

Based on PS2RC by SandstoneDev: https://github.com/SandstoneDev/PS2RC
License and third-party notices are retained alongside this file.

## Verification

71 affected sanitizer cases passed (24 skin decoder,43 object adapter,4 draw
integration);46 unchanged static decoder/texture/clipping cases retain their
earlier passes. Two captured skin meshes with current64-bone matrices were
checked against an independent transform calculation (2,734 batch vertices).
Converter backend and desktop runtime verification are recorded in the
accompanying investigation. Windows GUI and Android validation remain outstanding.

Fresh desktop PPSSPP1.20.4/OpenGL showed a textured character in the first scene:
121 object submissions,14 skinned-object submissions,24,722 triangles,
415 textured mesh submissions and zero texture conversion misses. Four cumulative
rejections were logged, including two earlier calls and the known11-bone object.
The previous static-only version submitted107 objects and15,415 triangles.
This is one rendered scene; sustained animation/gameplay, UI and audio fidelity
are not established by this check. Use the supplied screenshot for comparison.


## Batched rendering update

The renderer now groups up to32triangles per GPU submission, flushing before
changing materials or reusing the vertex buffer. This follows the batching
approach used by the GTA SA reference. Geometry order, clipping and skinning
remain unchanged. Textures may retain256-pixel detail within the existing64KB
scratch buffer; textures too large for it fall back to128pixels.

This is a first optimization pass. GTA SA's mesh cache, hardware transforms and
lighting pipeline are not yet ported. Dark/missing surfaces remain; higher
texture detail does not restore missing lighting. Boot memory is extremely tight,
so larger permanent buffers failed startup and were removed.

Live desktop PPSSPP1.20.4/OpenGL check passed: first scene121objects,
24,722triangles,415textured meshes,14skinned objects,0texture misses,939geometry
submissions. Earlier geometry counts match exactly. Subsequent frames through660
rendered. Coarse progress samples show frames652->662 taking12.1seconds versus
15.1seconds in the prior v3 extended run, same emulator/config and no fast-forward
in that comparison interval. This single short sample is not a reliable FPS
benchmark or Android result. The dominant guest backedge remains0x24dc78;
lighting still looks dark and full GTA SA optimization parity is not achieved.
