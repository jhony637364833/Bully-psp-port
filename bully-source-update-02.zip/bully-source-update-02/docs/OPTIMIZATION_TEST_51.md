# Test build 51 — checkpoint restore repair

Targets PSP-2000/3000 and Android PPSSPP. **14 FPS remains unmet/unverified. This build repairs a save-load stop; it claims no new FPS improvement.**

## Change

Build 50 repaired first-save folder setup and PSP icon filename case. Loading its controlled test checkpoint then stopped at guest function `00120928` during game reinitialization.

The original instructions read the PS2 performance-counter control register, clear its enable bit, and write it back. These control-register moves (`MFPS`/`MTPS`) were missing from the translator. Build 51 translates them through the existing COP0 register 25 HLE storage, preserving the original register writes and signed read. Selector aliases on reads and ignored nonzero write selectors follow the EE behavior. Register liveness/narrowing analysis now recognizes the moves.

This repairs previously unsupported instructions. It preserves the original save format, checksum, verifier and checkpoint application. It adds no restore suppression, game-speed multiplier or emulator setting override. Performance event counters (`MFPC`/`MTPC`) remain unsupported; this control-state repair does not implement PS2 event counting.

Only `main_004.o` changes from build 50. The other 170 guest objects and all native runtime, renderer, audio and memory-card objects are identical to build 50.

## Verification

- Traced the earlier failure: the script pointer and script data were valid at entry. The zero argument in the final error report was stale context and did not establish a null script pointer.
- Rebuilt the complete game translation and prepared it through the converter. Only the formerly unsupported function changes in the prepared game code; all 11 existing text patches still apply once.
- 69,940 register/context cases passed on the host with AddressSanitizer/UndefinedBehaviorSanitizer and in an Allegrex PSP executable under desktop PPSSPP 1.20.4. These cover four compiler modes, all 32 selectors, zero register, signed reads, wide arguments, preserved upper register halves, and the actual final prepared game function. The tests use the existing HLE move handlers and independent expected register values.
- Existing compiler regression tests: 57 passed; two decoder golden-fixture checks skipped because their preexisting generated fixtures are absent. The new instruction tests exercise the real game's opcodes and all control selectors.
- **Exact final EBOOT:** a cold launch reads the controlled 21,736-byte checkpoint and reaches gameplay through 80 camera passes without corruption or a fatal stop. A separate clean-card launch also reaches 80 camera passes. The test launches use normal PSP 333 MHz, JIT, OpenGL, 1x resolution, buffered rendering and no frameskip. These are smoke checks, not FPS measurements.
- Build 50's save-write, folder, filename, checksum and graphics checks remain applicable because their implementation objects and inputs are unchanged. Full archive checksums/CRC, source-to-engine equality and cumulative patch application pass for the delivered files.

## Limits

The checkpoint used here was created by a diagnostic invocation of the original save worker and finalizer in the initial school scene, before the normal save UI is available. Build 51 can now apply that checkpoint and return to gameplay. **A save made through a normal save point on the user's device has not yet been verified.** No diagnostic save or instrumentation is included in this update.

Existing files already written outside the correct folder by an earlier build are not automatically reconstructed or deleted. Keep a backup of the whole `memcard/slot1/` folder. A failing device save and its `session.log` are still needed to establish whether that particular slot can be recovered.

Android and physical PSP tests, actual 14 FPS, full sky/tutorial/combat/subtitle coverage, school entry and audible audio remain unverified or unresolved. The screenshot demonstrates only the tested initial scene. The earlier build 49 camera-throughput improvement remains included; it is not a gameplay FPS claim.

## Install and test

1. Back up the entire working game folder and its `memcard/slot1/` folder outside the live game directory.
2. Copy the contents of `test-build/` into that game folder. Keep the existing disc/media and saves. This ZIP supplies the EBOOT, helper, configuration, instructions and licenses.
3. Launch from a fresh boot, without an emulator save state from an older executable. Keep normal speed, frameskip 0 and Skip buffer effects disabled.
4. Try loading a backed-up slot. Then make a fresh save at a normal in-game save point, exit, restart and load it.
5. If either fails, provide the complete failing `memcard/slot1/`, `session.log`, build number and whether the slot was old or newly created. Preserve the original failing files.

The source ZIP is cumulative. Apply its `app/` overlay to PS2RC commit `332a437f21f7ef694943caef885a7d28410cbc41`. Regression script: `python tests/check_perf_control.py --engine /path/to/PS2RC --output /tmp/perf-control --elf /path/to/SLUS_212.69 --generated /path/to/build/gen`. Add `--psp` to build the PSP fixture with the PSP SDK.
