# Compressed lighting contract

Target executable SHA-256:
`597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc`.

The supplied v4 decoder preserved only VIF slot 2's packed prelight color. Slot 3
was checked at strip seams but discarded. The original compressed shader starts
at the VIF program packet at 0x00567170 (MPG at 0x0056717c).

Inspection of that shader establishes:

- Positions and UVs are signed fixed-point values scaled by 1/128.
- VU slot 973.x is the prelight blend; 973.w selects monochrome processing.
- Slots 2 and 3 in each vertex are the two prelight banks.
- With lighting enabled, monochrome processing uses each bank's red component
  for RGB and adds 12, then computes `bank0 + (bank1 - bank0) * blend`.
- The result is multiplied by ambient RGB, surface ambient times 255.000015,
  and 0.0039215. It is capped at 255 **before** material modulation.
- Material RGB modulation is the supplied byte color times 1/510. The existing
  display conversion multiplies GS color by two for the PSP's color range.

Object setup 0x0029ccc0 emits ambient light into the shared VIF constant packet
at 0x006d5270. The adapter requires the observed STCYCL and UNPACK destination
976 and a nonzero lighting type. It does not assume arbitrary packets are lights.

Material bridge 0x0029dc50 consumes globals at GP-7404 (blend) and GP-7496
(monochrome), uses pipe+60 for surface properties and pipe+68 for RGBA. The common
object dispatcher 0x0027c828 sets pipe+60 to material+12. The bridge is hooked
before execution so per-material values are captured before they are consumed.
All guest execution and return values remain intact.

The capture is bounded to 64 records, reset before each object, and keyed by
mesh stream plus material. Invalid or unsupported state retains v4's existing
color path. Geometry acceptance checks are unchanged. This repair adds the
previously documented missing lighting behavior, without expanding mesh support.

## Compressed vertex alpha

VU instructions06a and089 set alpha gain to one and add the two W banks.
Instructions0a0/0a4 cap that sum at255 before multiplying by material.W.
Bridge0029e038 supplies pipe+71 times0.001970011740922928. The adapter converts
the resulting GS alpha to the PSP range by multiplying by two and saturating.
Unlike RGB, alpha does not use the bank blend factor or monochrome offset.
Clipping interpolates alpha with the other attributes before GPU submission.
The renderer's opaque-texture shortcut additionally bounds the minimum vertex alpha against the captured comparison.

Tests cover full, half, zero material alpha, independence from RGB blend,
analytic near-plane interpolation, and actual PSP blending with opaque textures.
This mapping is limited to the validated compressed lighting path. It does not
add missing UI/pipelines or change rejected skin topology.
