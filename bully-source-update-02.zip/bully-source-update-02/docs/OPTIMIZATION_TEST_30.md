# Bully PSP experimental test 30

**Android 14 FPS remains unverified.** Build 30 removes repeated modulo-three
indexing from the triangle strip loop. Three rotating pointers reference the
same ring slots as before, preserving preparation, triangle order, skip bytes
and the clipping cache lifetime. Builds 29A/29B were rejected after measurement;
they are not included. Build 28 is retained for rollback.

## Install

Copy `test-build/` contents from the runtime ZIP into a backup of your complete
converted game folder. Included: EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, installation
instructions, checksums and licenses. Keep your existing disc/, SLUS_212.69,
discmap.txt, iso_meta.bin, BULN.pmf, BULN.wav and memcard/. Fresh-boot; do not load
another build's save state. Unchanged game assets and movies are not duplicated.

EBOOT: 17,158,948 bytes. SHA256:
`56587fcda3b5be4d12729273cb6518ac822cba1e53991eadeeb0b7166b125d00`.

Optional PPSSPP fragments are unchanged from build 28. Read CONFIG-TEST-18.md
before applying them; its measurements concern historical build 17. Virtual
2000 MHz changes the guest instruction budget, not the phone's physical clock.
It exceeds PPSSPP 1.20.4's UI maximum of 1000. The EBOOT does not apply this INI;
compare identical settings. Restore Auto/0 if needed.

## Matched stationary-scene measurement

| Camera 120 to 360: 240 events | Build 28 | Build 30 |
| --- | ---: | ---: |
| First host seconds | 34.252597 | 33.867275 |
| Reverse-order repeat seconds | 34.253251 | 33.869471 |
| Mean seconds | 34.252924 | 33.868373 |
| Camera completions / host second | 7.0067 | 7.0863 |

**1.14% higher pooled camera throughput**, 480 measured events per build.
Run order: 28, 30, 30, 28. Mean saving: 384.55 ms;
maximum within-build spread or 20 ms polling floor: 20.00 ms.
Both pairs improved; mean saving exceeds four times that value.
All ten WORLD_COMPLETE summaries through camera 360 and all four scene PNGs
match exactly. Loaded executable instructions and virtual 2000 CPU/1000 bus
clocks were checked. No compiler, tests or other emulator ran in timed windows.
This is Linux desktop PPSSPP 1.20.4/JIT, OpenGL 1x with frameskip 0 and sound
configured on. These camera completions are not Android gameplay FPS.

## Changes and verification

- One engine source file changes from build 28: `src/psp/world_display.c` in
  the SLUS-21269_v1.02 pack. Strict floating-point flags, graphics states,
  synchronous GPU waits, audio and guest scheduler checks stay the same.
- Actual PSP disassembly: draw_strip 3568 to 3268 bytes; three ring-index
  multiply/divide sites removed. The clipped triangle-count division remains.
  EBOOT is 304 bytes smaller. The saved-register vector optimization from
  build 28, including its approximately 0.63 MiB memory cost, is retained.
- Fresh host ASan/UBSan and actual PSP: 5120 strip comparisons each, covering
  all four rounding modes, empty/short/long strips, clipping, nonfinite inputs,
  lighting and skin skip patterns. Submitted vertex bytes, triangle counts,
  flush boundaries and source preservation match; full PSP FCR31 matches.
- Fresh complete-renderer host ASan/UBSan: 128 command/vertex/CLUT traces match,
  including assertions that queued GPU data is not overwritten before completion.
- Fresh PSP GPU: 65 exact color/depth-witness image pairs; 65 repeat checks and
  two depth positive controls per executable. Maximum SDK command list 6160
  bytes, below the 16384-byte capacity. Synthetic assets only.
- Full normal converter completed without warnings; one of 230 units rebuilt.
  All 187 prepared/final guest C units match build 28 exactly.
- Unaffected build 28 converter/runtime/config (78 passes, one Windows-only
  skip), saved-register, math, VU, skinning and audio checks carry forward by
  source identity. They were not all rerun for build 30.
- Runtime and source ZIP CRCs, every packaged checksum, source/engine overlays,
  exact EBOOT identity and patch application are checked after packaging.

## Reproduce the strip comparison

With PSPDEV on PATH:

~~~sh
python3 tests/prepare_strip_rotate.py /tmp/bully-strip-rotate
make -C /tmp/bully-strip-rotate
~~~

Boot that separate diagnostic EBOOT. strip-rotate.log must end with
`COMPLETE cases=5120 all_modes=4 vertex_bytes=exact triangles=exact flushes=exact source=unchanged fcr31=exact errors=0`.
The fixture needs no game assets. For a host sanitizer check, compile its main.c
with the pack's native_light.c and world_clip.c, include the pack src directory,
and use `-O2 -fno-fast-math -frounding-math -ffp-contract=off -fsanitize=address,undefined -lm`.

## Remaining acceptance

Android >=14 FPS, full gameplay, walking controls, saves and audible quality
remain unverified. ALSA output is unavailable in this sandbox, so sound enabled
in configuration does not establish audible playback. This remains an incomplete
port. Device acceptance needs your phone model, PPSSPP version/settings,
session.log and a real-time recording of matching scenes.
