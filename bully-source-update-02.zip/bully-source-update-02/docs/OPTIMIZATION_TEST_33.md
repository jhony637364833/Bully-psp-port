# Bully PSP test 33: movie display with Skip buffer effects

This build addresses the black intro when PPSSPP's **Skip buffer effects** is
on. It presents decoded pictures through the PSP GE rather than CPU-only VRAM
writes. Gameplay rendering and all build 31 optimizations remain unchanged.
**14 FPS on Android is not verified. No gameplay speed gain is claimed here.**

## Install and test

Copy the runtime ZIP's test-build/ contents over a BACKUP of your complete game
folder. Keep disc/, SLUS_212.69, discmap.txt, iso_meta.bin, BULN.pmf, BULN.wav and
memcard/. Fresh-boot; do not reuse another build's save state. EBOOT, PRX,
ps2rc.cfg, licenses, instructions and checksums are included. Unchanged disc and
movie assets are not duplicated. Build 31 remains the rollback.

For your reported faster PPSSPP setting, enable Graphics > Skip buffer effects.
An optional PPSSPP-FAST-33.ini fragment is included: back up and merge its two
keys into PSP/SYSTEM/PSRC21269_ppsspp.ini after creating a game configuration.
Keep your other settings and graphics backend. It selects SkipBufferEffects=True
and the previously tested virtual CPU budget CPUSpeed=2000. This is an emulator
instruction budget, NOT a physical phone/PSP overclock. PPSSPP 1.20.4's UI caps
this setting at1000; the optional file uses2000. If unavailable, compare1000 in
the UI; restoreAuto/0 if unsuitable. The EBOOT does not alter PPSSPP settings.
An alternate-speed toggle can lift emulator pacing; it does not make each game
frame require less work and does not establish a10x optimization on real PSP.

## Verification

- Synthetic PSP fixture: RGBA8888, RGB565, end clear, shutdown/reinitialization,
  buffered rendering and Skip buffer effects. The old CPU path stays black in
  direct mode; the new GE path is visible. Both targets are primed/cleared at
  initialization and end, preventing a stale final movie picture.
- Default RGBA8888 buffered pixels match the previous display exactly over
  the958x544 interior of the desktop2xwindow.112color witnesses perphase match
  between both modes. The modes use different final window filtering, so full
  screenshots across those settings are not expected to match.
- Optional RGB565 uses standard PSP GE texture expansion; tested color witnesses
  differ by at most1/255 perRGBchannel from the old CPU floor conversion. This
  is a deliberate minor display change in that optional format; default8888
  retains its colors. Decoder data stays alive until synchronous GE completion;
  nearest sampling reads only the480x272picture within512stride storage.
- Normal converter completed without warnings. All187generated/prepared guest C
  units match31. Onlymovie_display.c changes in the engine. EBOOT is
  17,159,348bytes,304bytes larger than31.
  No new heap allocation; bounded GE list/vertices add about1KiB static storage.
- Actual game booted with SkipBufferEffects=True, virtual2000CPU/1000bus,
  sound configured on and VFPU enabled. Intro screenshot contains decoded
  picture content; loading reaches gameplay and all first8WORLD_COMPLETE
  summaries match31. This is Linux PPSSPP1.20.4/OpenGL/JIT, not Android evidence.
- Earlier failed attempts found an uncleared direct-mode final picture; clearing
  both targets fixed it. One fixture run hit a PPSSPP hostGL initialization error;
  clearing only its scratch shader cache allowed a completed run. Final fixture
  and full-game checks passed. Original PPSSPP configuration remains unchanged.
- Packaging checks cover EBOOT/ELF/source identity, ZIP CRCs, everychecksum,
  portable fixture input equivalence, previous versioned downloads and patch
  application. Earlier unchanged31math/geometry/rendering/audio tests are reused
  by source identity; they were not all rerun for this display-only change.

## Remaining issues

Start was reproduced freezing at guest0x001f3ac4, waiting for the VBlank callback
counter atGP-10364. Virtual time advances while that counter wait persists.
That is not fixed in33. Select, school-door transitions and black sky remain
unresolved; their causes must not be inferred from the movie fix. The current
backend drops general GS DMA and does not yet implement every graphics path.
Full gameplay, indoor acceptance and audible quality remain unverified (the
sandbox has noALSAoutput). Please send build number, phone/PPSSPP settings and
session.log from the failing school-door/Start/Select run.

## Reproduce the synthetic test

~~~sh
python3 tests/prepare_movie_display.py --output /tmp/bully-movie
make -C /tmp/bully-movie/reference
make -C /tmp/bully-movie/candidate
~~~

Boot each diagnostic EBOOT separately with Skip buffer effects off/on. It writes
phase.txt for each stable display:1RGBA,2black,3RGB565,4black afterreinit. For an
automated desktop controller, capture the display then write that phase number
intoack.txt beside the diagnostic EBOOT to advance. It ends bywritingresult.txt
`COMPLETE phases=4 errors=0`. These diagnostics are separate from the game.

EBOOT SHA256: `8f7f252500b26b82ed6232af616c1ed940c5b274f38bd8909f22415ef472f09d`.
