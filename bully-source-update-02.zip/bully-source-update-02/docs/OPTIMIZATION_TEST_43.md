# Bully test build 43 — correct sky blending and restore its gradient

Targets: PSP-2000, PSP-3000 and Android PPSSPP.

## Changes

The original float sky pipeline uses additive blending and masks depth writes.
The native fallback used opaque blending and wrote depth, producing black
patches where original vertex colors are zero. This build captures the original
supported driver state after guest setup for SKY_high, SKY_tile and SKY_bot only.
It preserves guest calls and the existing compressed state capture contract.

The packet trace also identified actual colored sky triangles being discarded by the
native overlay depth restrictions. This build draws those original triangles
at the far GPU depth, fills the uncovered background after world geometry,
and preserves it when sky drawing occurs before the first world object. It
clears a new camera only once. It uses the game's coordinates and colors.
Only untextured, Z=0, GEQUAL, Z24 triangles are admitted to this sky path.
A real PSP GPU fixture verified 41,856 foreground pixels stay exact while
88,704 background pixels receive the sky color.
Arbitrary depth operations and unsupported framebuffer effects remain rejected.
Paused menus retain completed-world background composition.

The indexed rendering experiment was rejected: its two measured camera windows
were 1.50% and 1.51% slower than build 42. This release retains build 42's
renderer optimizations. **No new gameplay speedup is established by build 43.**

## Verification

- 20,000 original/shadow GS-state differential cases, material identity/bounds,
  stale-object reset, no RAM writes and unchanged outputs on failure under ASan/UBSan.
- GPU checks of all three float sky materials: additive color and masked depth;
  wrong material/object retain the original fallback.
- 2,192 synthetic admission cases and camera-clear state checks under ASan/UBSan.
- Actual GIF/GE test: pre/post-world sky, nearer foreground preservation, invalid
  nonzero-Z rejection, and paused-menu background composition.
- Fresh full-game boot on desktop PPSSPP 1.20.4, normal 333 MHz runtime,
  OpenGL buffered 1x, frameskip 0, without speed/buffer overrides.
- The updated sky was visually checked in the starting scene.
- Start/Select menus pause, remain stable in repeated captures, and resume.
- All 171 generated guest C units are unchanged from build 42/37.
- Runtime/source archive CRCs, packaged checksums, exact source/binary identity,
  previous downloads and original PPSSPP settings checked before release.

Reproduce the asset-free checks from the source root:

```sh
python3 tests/check_sky_underlay.py
python3 tests/check_float_sky_state.py
python3 tests/prepare_sky_gpu.py --output /tmp/bully-sky-gpu
# With PSPDEV/bin on PATH: make -C /tmp/bully-sky-gpu
# Launch its EBOOT.PBP; sky.log must end in COMPLETE.
```

The full-game check exercises the PSP GPU implementation in desktop PPSSPP.
There is no physical PSP or Android device in this sandbox, and audible sound
cannot be checked here.

## Install

Close PPSSPP. Back up the converted game folder and copy the contents of
`test-build/` from the runtime ZIP into it. Retain the original disc directory,
SLUS_212.69, disc map/metadata, intro media and saves. Fresh boot the EBOOT;
do not load an old emulator save state. Follow INSTALL.txt for the full steps.
The separate source ZIP contains all cumulative updated source and tests.

## Remaining work

**14 FPS is still unmet and unverified.** Complete tutorial/combat/subtitle/map
coverage, school-door entry, saves and complete gameplay remain unresolved or
unverified. This repairs the captured gradient and float sky material paths; complete sky effects and
all locations still require device testing. This build does not claim those
other bugs are fixed. Send session.log and screenshots of missing prompts.
