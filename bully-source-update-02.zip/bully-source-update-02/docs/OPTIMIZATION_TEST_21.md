# Bully PSP experimental test 21

**Android 14 FPS remains unverified.** Build 21 reuses coordinate values already
loaded by the hot normalizer. Build 20 remains for rollback/comparison.

## Install

The runtime ZIP includes EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, INSTALL.txt,
licenses and checksums. Copy test-build/ contents into a BACKUP of your complete
converted folder. Keep disc/, SLUS_212.69, discmap.txt, iso_meta.bin, BULN.pmf,
BULN.wav and memcard/. Fresh-boot; do not load a save state from another build.
Read INSTALL.txt. EBOOT: 16,498,820 bytes; SHA256: 4555c5f283cf9b4dc42c9b88df20fa1e0b7063a30920343caa9d0ff1b94e6ce2.

Optional ppsspp-settings/ includes the previously verified experimental 2000 MHz
virtual-clock and rollback fragments. Read CONFIG-TEST-18.md first: that report
describes historical build 17; this package's executable/source/results are 21.
The setting exceeds PPSSPP 1.20.4's UI maximum. It changes virtual instruction
budget, not phone physical clock. Do not increase it arbitrarily. Restore
Auto/0 if needed. Compare builds at IDENTICAL settings. EBOOT does not apply it.

Source targets PS2RC 0.1.1 revision 332a437f21f7ef694943caef885a7d28410cbc41,
PSP GCC 15.2.0 / SDK 20261001, Bully SLUS-21269 v1.02 ELF SHA256
597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc.

## Exact change and original contract

Generated fn_001860c0 clamps x/y/z into C locals f2/f3/f4, computes the original
squared sum and reciprocal square root, then reloads/clamps those coordinates
before scaling and storing x/y/z. The three reload assignments become f1=f2,
f1=f3, f1=f4 through the existing function-scoped text-patch mechanism. Each
original text must occur exactly once in that function, or conversion fails.

The leaf has no guest calls, yields, volatile or trapping accesses. No RAM write
intervenes before scaling x, and its x/y/z stores are distinct four-byte
locations. Earlier stores cannot alter later input coordinates. Reuse supplies
EXACTLY the same clamped bits to the same multiplications. Square root/division,
operation order, signed-zero/subnormal/nonfinite/overflow behavior, output stores
and complete context state remain. Context f2/f3/f4 and accumulator remain
untouched: these are C locals. All 192 preserved-state bytes retain their
contract. No simulation work or scheduler checkpoint is removed.

Only pack.toml and new lists/normalizer-reuse.tsv change in the engine overlay.
The runtime header/general math helpers are unchanged from build 20. All 187
prepared C units match baseline with ONLY three lines changed in main_014.c.
Other functions are unchanged; old v0 natives remain disabled. No ABI, memory
layout, rendering or audio policy changes. Probe size: 404 to 336 bytes;
actual full-game normalizer: 424 to 316 bytes.

## Matched opening-scene measurement

| Counter 8 to 80 | Build 20 | Build 21 |
| --- | ---: | ---: |
| First host seconds | 13.828298 | 13.622629 |
| Reverse-order repeat seconds | 13.824222 | 13.669206 |
| Mean seconds | 13.826260 | 13.645917 |
| Camera completions / host second | 5.2075 | 5.2763 |

**1.32% higher pooled camera throughput.** Each build completes 144 measured
camera events. All four first-eight scene summaries match, including 9,809 draws.
The later long gap remains. Camera completions are NOT gameplay FPS.

Sequential order 20,21,21,20. PPSSPP 1.20.4/JIT, Mesa26.0.8 llvmpipeLLVM21.1.8,
OpenGL1x, normal100%, frameskip0, soundon(dummyphysicalaudio), virtual2000MHz/
bus1000. Same media/private configs. Unchanged live camera/frame counters polled
every10ms with host monotonic time; loaded ELF prologue checked permitting only
PPSSPP's first-word JIT patch. No compiler/tests/other emulator in timed windows.

## Verification

- 95,296 full-context/RAM/guard comparisons on host ASan/UBSan, strict FP.
- Same 95,296 on PSP in PPSSPP, all four rounding modes and FTZ. Zero differences.
- All 24^3 edge-vector combinations plus 10,000 random vectors per mode:
  signedzero/subnormals/minnormal/overflow/Inf/quiet/signalingNaN, arbitrary
  virtual mirror bits/GPR upper lanes. All context bytes and 64KiB RAM compared.
- Independent guard sentinels check both functions stay in the supplied window.
- Portable generator's six inputs match the executed fixtures. Its frozen
  original function is independent of the patches.
- Full converter, strict three-line prepared-source identity, actual executable
  inspection, two ordered game comparisons, archive CRC/every checksum,
  source/engine/binary identity, patch dry-run and rollback preservation.

The first test EBOOT warned its module label exceeded the SDK limit. The
test-only label was shortened; fresh warning-free harness build and complete
PSP rerun passed. Host preprocessing was independently confirmed identical
after that PSP-only change, so its existing pass was reused.

Earlier renderer/clipping/general math/VU/alpha/depth/GPU/audio/converter/state
checks are reused for identical implementation inputs; those suites were not
all rerun. The normalizer has fresh coverage above. No correctness failure waived.

## Reproduce

From the source overlay root, app/ installed on the stated engine:

~~~sh
python3 tests/prepare_normalizer_reuse.py --output /tmp/bully-normalize-test
make -C /tmp/bully-normalize-test
~~~

Boot that separate test EBOOT. normalize-test.log must end with:
COMPLETE comparisons=95296 errors=0.

For host checks in the generated directory:

~~~sh
cc -O2 -g -std=gnu11 -fsanitize=address,undefined -fno-omit-frame-pointer -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off main.c reference.c candidate.c -lm -o test
./test
~~~

Android >=14FPS/fullgameplay/controls/saves/audible quality remain unverified.
Send phone model, PPSSPP version/settings, session.log and a real-time FPS
recording, comparing the same scene/settings, for device acceptance.
