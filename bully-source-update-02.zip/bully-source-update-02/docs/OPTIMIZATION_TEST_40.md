# Bully PSP test 40: reuse verified clipping classifications

Targets: **PSP-2000, PSP-3000 and Android PPSSPP only**.

The native renderer already classifies each shared strip vertex. Crossing
triangles now pass those exact classifications to the clipper, avoiding three
repeated vertex classifications per crossing triangle. The inputs and clipping
planes remain unchanged between classification and clipping. The ordinary APIs
retain complete validation. Negative classifications repeat their original
exception-producing path, preserving signaling-NaN behavior. Initial pointer
and plane checks, every clipping calculation, polygon order, draw order and
supported overlays remain unchanged. **No additional RAM allocation**.

## Validation

- Host ASan/UBSan and PSP executable: **32,768 math cases / 131,072 comparisons**,
  four rounding modes and two flush modes, against frozen build39. Exact output,
  polygon tails, input, local-cache behavior and complete FCR31 state, including
  random float bits/nonfinite values and invalid planes.
- Actual renderer, host and PSP: **1,280 strips with three repeats**, all four
  rounding modes and two flush modes. Exact vertices, triangle counts, flush
  sizes, input and complete floating-point state against build39. Skin skips,
  lights, disabled/absent memo, nonfinite attributes and long strips included.
- Existing memo math/renderer/retention/allocation tests and all five affected
  regression consumers pass: GPU submission, historical renderer, strip rotation,
  finite and mask suites. Existing expected outputs were retained. Only two
  older test generators needed namespace additions for the new entry point.
- An early broad test caught a lost nonfinite exception flag; the fallback above
  fixes it. Fresh host and PSP checks of the final implementation pass.
- Fresh normal333MHz/bus166 desktop PPSSPP game run: all ten logged world
  summaries, Start/menu and Select/map screenshots and paused repeats match
  build39 exactly. Both controls pause and resume camera progression.
- Emitted portable math/renderer C and headers are byte-identical to the clean
  PSP fixture inputs. Unchanged guest translation, PRX/config/media and original
  PPSSPP configuration retain their earlier validated identities.

## Timing

Same normal automatic-clock desktop PPSSPP, virtual PSP2000, OpenGL1x buffered,
frameskip0, no alt-speed/Skip buffer effects. Reused matching build39 baseline:

| Camera window | Build39 | Build40 | Throughput gain |
| --- | ---: | ---: | ---: |
| 120→180 | 49.843s | 49.600s | 0.49% |
| 180→240 | 50.151s | 49.922s | 0.46% |

These are two adjacent windows in one matched pair: **camera throughput, not
actual gameplay FPS or a repeatability claim**. No compiler, test, sampler or
second emulator overlapped the selected timing windows. Android and physical
PSP performance are unverified. The roughly 0.5% difference is too small to
establish a gameplay speedup from this comparison alone.

## Install

Back up your existing game folder. Copy the contents of `test-build/` from the
runtime ZIP into the copy. Keep your `disc/`, `SLUS_212.69`, `discmap.txt`,
`iso_meta.bin`, `BULN.pmf`, `BULN.wav` and `memcard/`. The update omits unchanged
disc/media files. Fresh boot only; older emulator save states are unsuitable.
Build39 remains available for rollback. No emulator settings files are included.

The source ZIP is the complete updated source overlay; the patch is cumulative
against the imported original source. Asset-free regression command (GCC):

```
python3 tests/check_classified_clip.py
```

Its generated math/renderer folders also contain PSP Makefiles. Configure
PSPDEV/PATH, run `make -B` in each, then run the EBOOT on PSP/PPSSPP to check
actual FCR31 behavior.

## Remaining work

**14 FPS has not been achieved or verified.** Door entry, black sky, full
HUD/tutorial/subtitle/combat overlays, saves and complete gameplay remain
unresolved or unverified. Audio is configured but audible playback is unverified.
The renderer still supports only a bounded subset of PS2 commands. No Android
or physical PSP is available here. Return `session.log`, your device and PPSSPP
version, and a recording of the same scene for device performance/bug evidence.

EBOOT.PBP: 16,992,356 bytes.
SHA256: 52ed2355a4850675c3350b90e8c5d2d812fb83060a81ae97fc02769c5d4cbc25
