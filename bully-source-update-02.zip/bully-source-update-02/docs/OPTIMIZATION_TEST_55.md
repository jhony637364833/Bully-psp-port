# Bully optimization test 55 — adjacent vertex reuse

Targets: PSP-2000/3000 and Android PPSSPP. **14 gameplay FPS remains unmet/unverified.**

## Change

The renderer reuses the previous prepared vertex when the next input repeats its position, UV and both color banks, and the full incoming FPU state matches. Transform, lighting, classification and projection work are avoided for that duplicate. The existing three-vertex ring supplies the result; no heap allocation or persistent cache is added.

Reuse is scoped to one synchronous strip with immutable input, view and lighting. Complete outgoing FPU state is restored. Enabled FP traps and unimplemented-operation causes use normal preparation. Invalid/near/far inputs preserve fields the original preparation leaves unwritten. Triangle ordering, skip handling, area tests, clipping, flush boundaries and all numerical formulas remain unchanged.

Only world_display.c and its object change runtime source. All 171 generated guest objects and other native objects remain build 54, including its halfword-load optimization and build 51 save repairs.

## Evidence and performance

A separate diagnostic captured 413,544 complete vertex inputs across six opening-scene camera passes. About 19.64% repeated the preceding input/context/FPU state; strip boundaries were not captured, so this was an upper bound for within-strip reuse. That instrumented run is not a performance measurement. A large-cache design was unnecessary.

Fresh sequential candidate-then-baseline desktop PPSSPP 1.20.4 runs: normal 333 MHz/bus 166 MHz, PSP-2000 memory profile, JIT/OpenGL, buffered rendering, 1x, frameskip 0. No other emulator, sampler or compiler ran during either timed window.

| Camera interval | Build 54 | Build 55 | Camera throughput gain |
|---|---:|---:|---:|
|120–180|16.265241s|15.759637s|3.21%|
|180–240|16.619341s|16.097879s|3.24%|

This is one matched desktop comparison of **camera completions, not gameplay FPS**. Android and physical PSP measurements remain unavailable; host audible output was unavailable.

## Checks

- Host ASan/UBSan and PSP: 2,560 complete strip comparisons against frozen build 54 renderer code. Exact vertex bytes, triangle/flush counts, source bytes and FCR state across all four rounding modes and flush/status settings. Cases include duplicate runs, skip flags, unused normals/padding mutations, near/far crossings, NaNs including signaling patterns, infinities, subnormals, signed zero and maximum floats. Host 118,812 and PSP 89,682 successful reuse events confirm the new path was exercised.
- The earlier 1,280-case pass also passed before expanding edge coverage. No correctness failure was observed in these passes.
- Host 512 renderer-submission cases preserve exact ordered commands, vertices, textures, buffer lifetimes and capacities. GPU-guard coverage passes 12,800 cases across four rounding modes. The latter retains previously authorized GE rounding behavior; its historical reference differences are not new55 changes.
- Five gameplay/Start/Select screenshots and all ten world summaries are byte-identical to the fresh54 baseline. Both menus pause and resume successfully in the tested opening scene.
- Extracted strip/classified/memo PSP fixture consumers compile with the new helper. Host fixtures now preserve FP state because adjacent reuse uses the callbacks even with the optional clipping cache disabled; existing geometry/lifetime assertions are unchanged.
- Public duplicate-vertex generator reproduces the executed fixture source and dependency bytes; only its source-root path changes. Existing unchanged decoder, save, compiler and GPU policy checks retain their earlier evidence.

Reproduce with `python3 tests/prepare_duplicate_vertices.py --output /tmp/bully-duplicate`, then `make -C /tmp/bully-duplicate` using PSP GCC 15.2.0. Run the EBOOT and expect `COMPLETE cases=2560 all_modes=4 vertex_bytes=exact triangles=exact flushes=exact source=unchanged fcr31=exact errors=0`, preceded by a positive reuse-hit count.

## Delivery and limits

The runtime ZIP contains EBOOT, unchanged plugin/config, licenses and installation instructions. Keep your existing converted disc/media and saves. Source ZIP and cumulative patch include implementation and reproducible checks. Build 54 versioned downloads remain intact; diagnostic captures and instrumentation are excluded.

EBOOT.PBP: 16996212 bytes; SHA256 `9ac316ba49b82bd63ecf09cde1fd7e99412bb440753f84d1fc224b5b05a78989`.

Full sky/combat/tutorial/subtitle coverage, school entry, physical-device controls/audio and normal device save-point round trips remain unresolved or unverified. No new gameplay fix or14 FPS claim is made. The next full converter run must reconcile older cache stamps; this tested build recompiles the affected native object and relinks existing validated guest objects.
