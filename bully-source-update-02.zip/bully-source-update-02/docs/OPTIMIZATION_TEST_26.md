# Bully PSP experimental test 26

**Android 14 FPS remains unverified.** Build 26 classifies finite vertex values
with integer exponent checks and retains the original nonfinite handling. Build 25 remains available for rollback.

## Install

Copy `test-build/` contents from the runtime ZIP into a backup of your complete
converted game folder. Included: EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, installation
instructions, checksums and licenses. Keep your existing disc/, SLUS_212.69,
discmap.txt, iso_meta.bin, BULN.pmf, BULN.wav and memcard/. Fresh-boot; do not load
another build's save state. Game assets and movies are not duplicated in this update.

EBOOT: 16,500,372 bytes. SHA256:
`860c8f30ee1c7888b2fff13d12535057262a27bd875ab6cc8ea8d5639a63c3b5`.

Optional PPSSPP fragments are unchanged from build 25. Read CONFIG-TEST-18.md
before applying them. Its measurements describe historical build 17. Experimental
virtual 2000 MHz exceeds PPSSPP 1.20.4's UI maximum of 1000; it changes the guest
instruction budget, not the phone's physical clock. Do not increase it arbitrarily.
Restore Auto/0 if needed. The EBOOT does not apply this INI. Compare identical settings.

## Matched stationary-scene measurement

| Camera 120 to 360: 240 events | Build 25 | Build 26 |
| --- | ---: | ---: |
| First host seconds | 35.083257 | 34.867723 |
| Reverse-order repeat seconds | 35.090782 | 34.855671 |
| Mean seconds | 35.087019 | 34.861697 |
| Camera completions / host second | 6.8401 | 6.8843 |

**0.65% higher pooled camera throughput**, 480 events per build.
Run order: 25, 26, 26, 25. Mean saving: 225.32 ms;
maximum within-build spread (or 20 ms polling floor): 20.00 ms.
Both pairs improved and mean saving exceeded four times that value.
These camera completions are not Android gameplay FPS. All ten WORLD_COMPLETE
summaries through camera 360 match across all four runs, including object,
triangle, draw and lighting counts. All four scene PNGs are byte-identical.

Opening camera 8 to 80 seconds, in run order:
13.361624, 13.318939, 13.307891, 13.343229.

Environment: PPSSPP 1.20.4/JIT, Mesa 26.0.8 llvmpipe LLVM 21.1.8, OpenGL 1x,
normal 100% speed, frameskip 0, sound enabled in config, private virtual
2000 MHz CPU / 1000 MHz bus. Same media and settings. SDL cannot open the ALSA
output device here; audible playback was not checked. Live unchanged game
frame/camera counters polled at 10 ms with monotonic host time; loaded ELF
prologue and actual guest clock verified. No concurrent compiler, tests or
other emulator in the measurement windows.

## Change and preserved contract

Finite vertex attributes are classified using their binary32 exponent bits.
Zero, subnormal and normal finite values all have an exponent below 255.
Infinities and NaNs use the original `isfinite` operation in a cold helper,
retaining the original rejection and floating point exception behavior.
The helper is kept out of line because GCC otherwise speculatively executes
some of those floating point comparisons on the finite path.

The public vertex-code entry retains its null, near and far checks. For valid
planes these leave the FP comparison condition clear, as the original finite
attribute checks do. This is why the integer shortcut can preserve full FCR31;
the host and PSP differential checks below verify that assumption. Classification
order for invalid attributes stays unchanged. Clip planes, intersection arithmetic,
polygon order, output/cache storage and public signatures remain intact.
The entire triangle clipper is byte-identical to 25. No allocation is added.
All 187 prepared guest C units are byte-identical to 25. Previous skin batch
reuse and rendering/audio policies remain intact.

## Verification

Fresh host ASan/UBSan strict floating point and a separate PSP diagnostic each passed:

- 160,000 vertex checks covering all attributes, valid/invalid planes, null
  vertices, signed zero, subnormals, extrema, infinities, quiet/signaling NaNs
  and random bit patterns.
- 72,064 polygon comparisons across all four rounding modes, PSP FTZ and varied
  initial flags; complete outputs, cache storage, guards, return values and
  full PSP FCR31 match frozen build 25. Host accepted 47,190 polygons and PSP
  47,196 due to platform FTZ differences; candidate/reference agree per platform.
- The existing fixture also compared 17,825,814 unchanged integer order keys.
- Portable generator reproduces all ten executed fixture inputs exactly.
- Full converter rebuilt one of 230 units without warnings.
- Runtime/source ZIP CRC, every payload checksum, source/engine/binary identity,
  prepared-code identity, patch dry-run, prior versioned downloads and original
  PPSSPP configurations checked before delivery.

The first shared-plane-validation prototype passed correctness checks but saved
only 3.83 ms in a 35-second window, below measurement uncertainty; it was not
adopted. The initial integer prototype allowed GCC to hoist floating point
checks, so the fallback was outlined. One PSP invocation then reused an older
object because the diagnostic Makefile omitted dependencies on included source.
That result was excluded; explicit dependencies were added and a fresh PSP
build completed all checks on the final code. No failed correctness check was
waived. Unchanged prior math, VU, skin, rendering and audio checks are reused by
source identity; they were not all rerun.

A separate 130-second diagnostic on frozen build 25 sampled 6,000 PCs each on the
main and emulation thread. It identified remaining guest geometry, clipping and
software double arithmetic costs. Attribution uses the nearest validated JIT
block and is approximate, with ptrace overhead; it supplies no FPS comparison.

## Reproduce

Overlay targets PS2RC 0.1.1 revision 332a437f21f7ef694943caef885a7d28410cbc41,
PSP GCC 15.2.0 / SDK 20261001. From the source root:

~~~sh
python3 tests/prepare_clip_finite.py --output /tmp/bully-clip-finite
make -C /tmp/bully-clip-finite
~~~

Boot that separate diagnostic EBOOT; clip-mask.log must end with
`COMPLETE keys=17825814 codes=160000 polygons=72064 ... errors=0`.
For the host check, from its generated directory:

~~~sh
cc -O2 -g -std=gnu11 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fno-strict-aliasing main.c reference.c candidate.c -lm -o test
./test
~~~

Android >=14 FPS, full gameplay, walking controls, saves and audible quality
remain unverified. This remains an incomplete gameplay port. Device acceptance
needs phone model, PPSSPP version/settings, session.log and a real-time FPS
recording of matching scenes.
