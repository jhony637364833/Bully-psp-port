# Bully R4: CPU-budget test iteration 02

The full game archive now boots. The low yard FPS is reproduced, and increasing
PPSSPP's emulated CPU budget raises rendered FPS without changing the R4 program.
The supplied file beside EBOOT.PBP is not PPSSPP's active game-specific settings
file. Profile installation in the actual configuration directory was verified.

**This is an experimental emulator profile, not a rebuilt game EBOOT or a completed
native optimization. 14 FPS throughout the game, normal cinematic timing and
mission-animation repairs are not established. Android performance needs testing.**

## Measured yard results

FPS cells show average (minimum–maximum sampled FPS). Game-clock ratios are
standing / walking / later view. 1.00× means approximately normal clock speed.

| Emulated MHz | Standing FPS | Walking FPS | Later view FPS | Game clock / wall time |
|---|---|---|---|---|
| 333 | 5.81 (3–6) | 4.88 (4–6) | 3.50 (3–4) | 0.96× / 1.01× / 1.00× |
| 1000 | 17.86 (17–19) | 15.00 (12–18) | 10.50 (10–11) | 0.99× / 0.99× / 0.98× |
| 1500 | 21.14 (18–23) | 18.75 (13–21) | 13.12 (12–14) | 0.78× / 0.84× / 0.79× |
| 2000 | 21.90 (19–24) | 20.38 (18–22) | 16.00 (15–17) | 0.70× / 0.68× / 0.70× |

At 333 MHz, the later view reproduces the reported 3–5 FPS. 1000 MHz improves
throughput while staying near full emulation speed, but misses 14 FPS in that
view. 2000 MHz exceeds 14 sampled FPS but slows the game clock to about 0.7× on
this sandbox; it is rejected as a complete fix. 1500 MHz also misses the minimum and slows the clock in this sandbox. The
main profile therefore uses 1000 MHz, the best tested budget for maintaining
normal timing. An optional 1500 MHz fragment is included solely for a phone
comparison; it is not a verified fix. Check both actual FPS and emulation speed before choosing a setting.

Office comparison: 10.8 FPS at 333 MHz versus 30.25 FPS at 1000 MHz. The latter
walking run averaged 30.375 FPS. Game-clock progression was approximately 0.99×.
In-game pause froze the clock and resume restored progression in the measured runs.

## Install the profile

1. Fully exit PPSSPP. Back up any existing `PSP/SYSTEM/PSRC21269_ppsspp.ini` in
   PPSSPP's currently selected memory-stick directory.
2. Copy the ZIP's `PSP/SYSTEM/PSRC21269_ppsspp.ini` there. If that file already
   exists, merge the supplied keys into their matching sections to retain your
   other game settings. Do not install this INI beside EBOOT.PBP.
3. Keep your R4 EBOOT.PBP, ps2rc.cfg, ps2rc_exc.prx, disc files, media and saves.
   The ZIP contains no replacement executable. It enables buffered rendering
   and disables frameskip; neither geometry nor textures are removed.
4. Cold boot at 1x resolution for comparison. The new game-folder `session.log`
   header must report `cpu_mhz=1000`. This is an emulated budget, not the phone's
   physical CPU frequency.
5. Optionally compare `CPUSpeed = 1500` using the optional fragment, only if your
   phone maintains full emulation speed. Revert to 1000 if motion slows. Restore
   your backed-up INI or use `CPUSpeed = 0` to restore the default budget.

## Test conditions and limits

Linux PPSSPP 1.20.4; JIT; PSP-2000/3000; system Mesa software OpenGL; 1x;
buffered rendering; frameskip 0; unchanged R4 timing and audio configuration.
The sandbox has no hardware GPU. This is not an Android benchmark.

Each yard run cold-boots with a fresh staged memory card, reaches approximately
(298.359, -72.23449, 5.803), stands for 30 seconds, applies the same forward input
for 8 seconds, pauses for 4 seconds and samples the later view for 8 seconds.
Frame counts are PPSSPP's actual rendered-FPS measurements, not VPS or guest
update counts. Sampling and debugger requests introduce endpoint uncertainty.
Actors and route endpoints vary slightly across runs; walking scenes are not
pixel-identical comparisons. Minimum samples do not prove a minimum for every
frame or for the rest of the game. Full mission progression, save compatibility,
audible output, Android background/resume and cinematic timing remain unverified.

The 2000 MHz run and the opening-scene samples show that extra emulated CPU
budget can exceed host capacity. A higher setting is not automatically better.
The later-view improvement may reduce visible stutter, but no mission-animation
code repair is claimed.

## Provenance and source

The new PBP includes different menu assets but its DATA.PSP program is
byte-identical to the earlier R4 replacement. ELF SHA256:
`0e653786e9cd667371575d2b5f50eecf39d7d749736a420140e0356429746511`.
All 355 ZIP entries passed CRC; all 248 discmap file sizes matched. The boot
executable matches the source pack's expected version.

The source ZIP includes the recovered source106 overlay, earlier diagnostic
repairs, this profile and documentation. It does **not** reconstruct R4's missing
timing/audio source. Rebuilding source106 alone would lose those R4 changes, so
no replacement game EBOOT was made. Previously tested native and host source
checks were reused because their code and fixtures are unchanged.

PPSSPP configuration and clock behavior were checked against its official
[v1.20.4 configuration source](https://github.com/hrydgard/ppsspp/blob/v1.20.4/Core/Config.cpp),
[path lookup](https://github.com/hrydgard/ppsspp/blob/v1.20.4/Core/Util/PathUtil.cpp), and
[clock override implementation](https://github.com/hrydgard/ppsspp/blob/v1.20.4/Core/HLE/scePower.cpp).
