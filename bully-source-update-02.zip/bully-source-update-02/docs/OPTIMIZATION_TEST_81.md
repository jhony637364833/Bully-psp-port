# Bully PSP test build 81

## Result

GPU vertex preparation now uses the existing four-byte vertex alignment for alias-safe integer loads. UV validity checks inspect exponent bits directly instead of using floating-point classification. The existing trap bypass and complete floating-point-state restoration remain. No new allocation or settings change.

Desktop PPSSPP camera throughput improved **1.28–1.54% over build 78**. The recent baseline from trial 80 is reused with the identical build 78 binary and unchanged runtime setup. This is not gameplay FPS or physical-device proof. **14 gameplay FPS remains unmet; the disappearing-overlay issue remains unresolved.**

|60-camera interval|Build 78 baseline|Build 81|
|---|---:|---:|
|120–180|12.731480 s|12.538826 s|
|180–240|13.079682 s|12.913930 s|

Runs used 333 MHz, JIT, OpenGL, buffered 1× rendering and frameskip 0, without concurrent heavy work during timing. Five gameplay/menu PNGs match byte for byte. Start and Select pause/resume passed.

## Validation

- Fresh host ASan/UBSan and PSP: **8,192 full GPU differential cases each**, comparing return values, vertices, triangle/submission order, flushes, input bytes and complete restored FCR. Expanded UV coverage includes both components, signed zero, subnormals, maximum finite values, infinities, quiet and signaling NaNs, plus existing rounding/trap/skip/lighting cases.
- **80,000 independent bounds cases on host and PSP reused from trial 80:** the entire bounds/helper prefix is byte-identical. Original per-vertex classification and guard-crossing assertions passed.
- Public generator reproduces the executed differential fixture byte for byte.
- Static assertions establish vertex alignment and color offsets; disassembly confirms single aligned loads replace unaligned load pairs in the inspected loop.
- CPU helpers, lighting arithmetic, texture conversion/cache and GPU submission logic remain unchanged. Their prior validation is reused.

Trial 80 alone measured only 0.98–1.14% and was not released. Build 81 combines that alignment work with the validated UV checks.

## Reproduce

```sh
python3 tests/prepare_gpu_uv.py /tmp/bully-gpu-uv
make -C /tmp/bully-gpu-uv
```

Run the fixture EBOOT on PSP/PPSSPP. For host validation, compile the generated `main.c` and game `native_light.c` with `-O2 -fsanitize=address,undefined -frounding-math -ffp-contract=off`, include the game source directory and link `-lm`. Existing `tests/prepare_gpu_bounds.py` generates the independent bounds fixture.

Physical PSP/Android FPS, audible audio and normal device saves remain unverified. Previous build 78 downloads remain available. Back up your memory card before testing.
