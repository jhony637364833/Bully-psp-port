# PSP audio output

Bully's translated SCREAM/AUDVAG drivers and SPU2-lite remain in lockstep with
virtual EE time. Their RPC replies, timers, sample generation and disc reads
are unchanged. The old output path submitted 1,024-frame blocks directly from
the game thread to the PSP SRC device. Long game work could starve the device;
PPSSPP reported channel-8 underruns during the baseline loading run.

The new output stage uses PS2RC 0.1.1's shared `audio/audio_stretch.c` and `.h`,
unchanged from commit `332a437f21f7ef694943caef885a7d28410cbc41`. This is generic
PSP audio synchronization, also used by the GTA SA reference. Bully retains its
own sound drivers, game data and SPU2 engine.

- Resample the generated 48 kHz stereo PCM to the regular PSP channel's 44.1 kHz.
- Place it in a bounded 16,384-frame single-producer/single-consumer ring.
- A dedicated output thread feeds 512-frame blocks, with a 4,096-frame (93 ms)
  buffering target and pitch-preserving synchronization from 1x to 4x duration.
- Output explicit silence while buffering or starved; fade out exhausted grains.
  Lost input frames, silent output blocks and device errors are reported at exit.
- Allocate 74,304 bytes of state and an 8,192-byte thread stack after the intro.
  The feeder does not execute the sound drivers or read guest RAM.

This intentionally adds output latency and adjusts tempo when the game runs
slowly. It does not change game simulation timing or promise continuous sound
when the producer falls below the synchronizer's supported range. Real PSP
hardware and long gameplay still need testing.

## Verification

`bash tests/run_audio_sync.sh` runs ASan/UBSan checks. Whole-buffer and chunked
48-to-44.1 kHz resampling agree. Half-speed burst input produces 1,500/1,500 audible
hops after warmup with synchronization, versus 757/1,500 using the gap mode.

`make -C tests/psp_audio_smoke` builds the actual output adapter with a synthetic
440 Hz half-speed producer. In PPSSPP 1.20.4 it completed 1,035 blocks, with 19
startup silent blocks, no lost queue samples and no output errors. Captured
mixer PCM measured 439.89 Hz and RMS 7,068.6 over seconds 1–10, preserving pitch.
The smoke EBOOT plays a tone; it is separate from the game EBOOT.

See the delivered test report for the full-game run's results and limitations.
