# Bully PSP experimental test 16

**The Android 14 FPS target remains unverified.** This is a further CPU optimization.
Build 15 remains available for rollback. Keep your existing converted disc/media/saves.

## Files and installation

EBOOT.PBP: 16,644,708 bytes. SHA256:
`5b3eea195fb6ace7248c24d20bb146120f793732320375b2836110f9497b40c8`

The runtime ZIP includes EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, instructions,
licenses/notices and SHA256SUMS.txt. Copy test-build/ contents into a BACKUP of
your existing complete converted game folder. Fresh-boot; do not load an old
emulator save state. Keep disc/, SLUS_212.69, discmap.txt, iso_meta.bin,
BULN.pmf, BULN.wav and memcard/. Follow INSTALL.txt.

The cumulative source overlay targets PS2RC 0.1.1 commit
332a437f21f7ef694943caef885a7d28410cbc41, PSP GCC 15.2.0 / SDK 20261001,
Bully SLUS-21269 v1.02 ELF SHA256
597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc.

## Optimization

A fresh build-15 later-scene profile again found repeated CPU context copies
in the two geometry callers. Four additional leaves use the scalar accumulator
and three reviewed value-only helpers: f_in5, fpu_rsqrt5 and fpu_sqrt_c.
The conservative classifier now recognizes these exact accesses. This removes
8 more preservation pairs around fn_003f6ff0, fn_001860c0, fn_00186240 and
fn_001294e0. Cumulative total: 35 pairs around 14 leaves relative to build 11.

The original nine 128-bit GPR / twelve FPR preservation requirement remains.
Unknown helper calls, member spellings, context aliases/address escapes,
saved-register accesses, dynamic indices, hooks/duplicates and scheduler
checkpoints retain protection. Helper implementations and every callee operation
are unchanged. The pass still requires the two explicitly selected callers and
final prepared C; linker wrapping remains rejected. The old v0 natives stay disabled.

## Measured opening-scene interval

| Counter 8 to 80 | Build 15 | Build 16 |
| --- | ---: | ---: |
| Camera completions | 72 | 72 |
| Host seconds | 32.603007 | 28.941592 |
| Camera completions / host second | 2.2084 | 2.4878 |

**12.65% higher camera throughput; 11.23% less elapsed time.**
The first eight logged camera summaries match exactly, including all geometry,
state/count fields and 9,809 draws. The later long gap still exists.

One sequential Linux PPSSPP 1.20.4/JIT pair, Mesa 26.0.8 llvmpipe LLVM 21.1.8,
OpenGL 1x, normal 100% speed, frameskip 0, sound enabled (dummy physical audio),
virtual PSP CPU 1000 MHz / bus 500. Private configuration copies; same media;
no compiler, tests or other emulator in measured windows. An observer reads
existing live camera/frame counters every 10 ms, validates ELF prologue bytes
(allowing only PPSSPP's first-word JIT entry patch), and uses host monotonic time.

Camera completions are not gameplay FPS. These results do not establish Android
performance, sustained gameplay, Auto/333 MHz performance or actual audible quality.
No graphics-quality, audio, simulation or approximate-math changes were made.

## Verification

- Host ASan/UBSan: 56,000 actual-leaf full CPU-context + 64 KiB RAM comparisons,
  four rounding modes, independent assertions on all 192 preserved bytes: zero errors.
- PSP EBOOT in PPSSPP: another 56,000 comparisons, four FPU modes with FTZ: zero errors.
- All 187 prepared units equal build 15 plus exactly the eight wrapper removals;
  every loop checkpoint and all other code remain unchanged.
- Portable classifier checks pass, including accumulator member-prefix/address
  escapes and full saved-register/unknown-call/hooked/duplicate/idempotence fallbacks.
- Full converter/build passes; only the two affected generated units recompile.
- Existing build-15 converter build/profile tests and build-11 renderer, math,
  alpha/depth/GPU/audio checks are reused for identical relevant inputs.
- Runtime/source ZIP CRCs, checksums, exact binary/source identities and original
  desktop configuration preservation are verified before delivery.

A scratch classifier test initially had a Python list-comprehension syntax error;
corrected before the passing check. No production behavior changed for that repair.

## Android comparison needed

Use the same scene and settings for builds 15 and 16: PSP-2000/3000, 1x,
frameskip 0, normal speed, sound enabled. The Linux comparison used the optional
per-game emulated PSP CPU clock 1000 MHz. PPSSPP labels this option unstable;
it changes the virtual instruction budget, not your phone's physical clock.
Restore Auto (0) and fresh-boot if pacing, controls or sound worsen. Test your
usual Auto setting separately.

Send phone model, PPSSPP version/settings, session.log and a real-time recording
with the FPS display. Sustained Android FPS, controls, saves, complete visual
correctness and audible quality remain outstanding.

## Reproduce leaf checks

Overlay app/ onto the engine revision above; build via its Python converter.
The legacy mk/build.sh does not run this optional preparation pass.

```sh
python3 tests/check_leaf_csave.py
python3 tests/prepare_leaf_runtime.py --prepared /path/to/work/build/gen_prep --output /tmp/bully-leaf-test
make -C /tmp/bully-leaf-test
```

Boot that separate test EBOOT in PPSSPP. leaf-test.log must end with
`COMPLETE comparisons=56000 errors=0`. The generator extracts actual leaves from
your own prepared translation; no generated guest code/media is bundled.
For host verification, from the generated directory:

```sh
cc -O2 -g -std=gnu11 -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fsanitize=address,undefined -fno-omit-frame-pointer main.c leaves.c reference.c candidate.c -lm -o test
./test
```
