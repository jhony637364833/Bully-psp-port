# Bully PSP test 42: native GPU screen-edge clipping

Targets: **PSP-2000, PSP-3000 and Android PPSSPP only**.

Safe screen-edge crossing triangles now go directly to the PSP geometry engine.
This avoids CPU software-double intersections and the extra triangles generated
by software clipping. The GPU already performs perspective projection and UV
interpolation in the renderer. Near/far crossings, large geometry, invalid
vertices and unusual camera ranges retain the original CPU clipping path.

The GPU path accepts only vertices inside a conservative projected guard band
(-480..960 horizontally, -272..544 vertically), with near >=0.0001 and
far <=65536. The viewport offset leaves a large margin from the GE's 12-bit
coordinate limits. The existing six-plane common-outside rejection remains.
No new allocation; executable text is 240 bytes larger, BSS unchanged.

## Intentional graphics precision change

Build40 retained software double-precision intersections for every crossing.
**Build42 intentionally uses GE edge/color/UV interpolation for safe screen-edge
crossings. It is not pixel-identical to build40.** You authorized small rounding
differences for this optimization. Simulation, generated guest C, clipping
fallback, textures, lighting inputs, ordered alpha/depth passes and overlay
implementation retain their earlier code. Exact software-triangulation tests
are not evidence for this new GE path; new image/safety checks cover it.

## Validation

- Host ASan/UBSan: **12,800 cases**, four rounding modes. **9,600** inside,
  near/far, large, invalid and extreme-camera cases produce exactly the same
  submitted vertices as build40. **3,200** GE cases check input preservation,
  vertex order, UV/color packing, coordinate margins and unchanged rounding mode.
- Actual PSP SDK / desktop PPSSPP: **65 renderer cases per version**, repeated
  color/depth-witness readbacks, two depth positive controls per version, both
  default and explicit game RTZ/flush modes. Includes direct/indexed textures,
  alpha/depth/blending, varying colors, viewport/guard-band/depth crossings.
  Largest command list 6,352 bytes, below its 16,384-byte capacity.
- In the game-mode fixture, **33/65 images differ**. Most differences are
  1–3 RGB levels; seven pixels across the cases exceed eight levels (maximum
  67). **No depth-witness coverage pixels differ.** Worst-case image comparisons
  were visually inspected. These fixtures do not prove all gameplay fidelity.
- Portable host checker passes; emitted portable PSP C is byte-identical to the
  executed fixtures. Original CPU math/memo/overlay checks are reused by exact
  unchanged source identities, alongside the fresh fallback checks above.
- Fresh normal333MHz/bus166 game run: ten logged world summaries match build40
  after removing only triangle/draw counts (the intended GE submission change).
  Start/menu, Select/map and paused repeat screenshots match build40 exactly.
  Both controls pause and resume camera progression. Game screenshots inspected
  separately: 15,699/522,240 pixels differ, maximum two RGB levels, mean RGB
  absolute error 0.01059 on the 0–255 scale. Geometry/textures remain visible
  in the captured scene; this does not prove all gameplay fidelity.
- All **171 generated guest C units** remain byte-identical to build40/37.
  Full converter passes. An initial rebuild enabled a default startup splash;
  that trial was stopped before timing and rebuilt with the matching no-splash
  option. Final runtime uses the corrected frozen EBOOT below.

## Timing

Same normal automatic-clock desktop PPSSPP, virtual PSP2000, OpenGL1x buffered,
frameskip0, no alt-speed/Skip buffer effects. Matching accepted build40 baseline:

| Camera window | Build40 | Build42 | Throughput gain |
| --- | ---: | ---: | ---: |
| 120→180 | 49.600s | 46.110s | 7.57% |
| 180→240 | 49.922s | 46.449s | 7.48% |

Two adjacent windows in one matched pair: **camera throughput, not actual
gameplay FPS or repeatability evidence**. No compiler, tests, sampler or second
emulator overlapped the selected windows. Android and physical PSP performance
remain unverified. The rejected build41 compiler experiment is not included.

## Install

Back up your game folder. Copy the contents of `test-build/` from the runtime ZIP
into the copy. Keep `disc/`, `SLUS_212.69`, `discmap.txt`, `iso_meta.bin`,
`BULN.pmf`, `BULN.wav` and `memcard/`. Unchanged disc/media files are omitted.
Fresh boot; older emulator save states are unsuitable. Build40 remains available
for rollback. No emulator settings files are included.

The source ZIP contains the complete updated source overlay; the patch is
cumulative against the imported original source. Asset-free host command (GCC):

```
python3 tests/check_gpu_guard.py
```

PSP fixture preparation and comparison:

```
python3 tests/prepare_gpu_guard.py /tmp/bully-gpu-guard
# Configure PSPDEV/PATH, then make -B in gpu-reference and gpu-candidate.
# Run both EBOOTs on PSP/PPSSPP; require COMPLETE and compare their pixels.bin:
python3 tests/compare_gpu_guard.py /tmp/bully-gpu-guard
```

## Remaining work

**14 FPS has not been achieved or verified.** School-door entry, black sky,
full HUD/tutorial/subtitle/combat overlays, saves and complete gameplay remain
unresolved or unverified. Audio is configured; audible playback is unverified.
The renderer supports only a bounded subset of PS2 commands. No Android or
physical PSP is available here. Return `session.log`, device/PPSSPP version and
a recording of the same scene to establish device performance and visual issues.

EBOOT.PBP: 16,992,596 bytes.
SHA256: b4c1aab673827620e3f4739f6fb7e9d2be26d49ef5516d1031b2c29845b871dc
