# Bully PSP test 35: skip empty counter polling

Build 35 accelerates two read-only waits for the game's VBlank counter. It
uses the scheduler's next event instead of executing empty polls, retaining
original 8192-cycle polling boundaries and observing interrupt delivery before
skipping again. It does not force the counter, omit game frames or lift the
emulator's speed limit. The build 33 intro fix for Skip buffer effects remains.
**Android 14 FPS has not been verified. Doors, sky and visible menus remain unresolved.**

## Install

Copy the runtime ZIP's test-build/ contents into a BACKUP of your complete game
folder. Keep disc/, SLUS_212.69, discmap.txt, iso_meta.bin, BULN.pmf, BULN.wav
and memcard/. Fresh-boot; do not load a save state from another executable.
EBOOT, PRX, config, licenses, instructions and checksums are included. Unchanged
disc/movie assets are not duplicated. Build 33 is retained for rollback.

Keep the same PPSSPP settings for comparisons. Optional PPSSPP-FAST-35.ini is
identical to 33: SkipBufferEffects=True and virtual CPUSpeed=2000. Merge only
those keys into your game INI after backing it up. This is a virtual instruction
budget, not a phone/PSP overclock; it exceeds PPSSPP 1.20.4's UI maximum of 1000.
Compare 1000 or restore Auto/0 if unsuitable. The EBOOT does not apply this INI.
To disable this wait optimization without replacing the EBOOT, add idle_skip=0
to ps2rc.cfg; remove that line to restore the default. Alt-speed can remove
emulator throttling but does not establish a 10x native optimization.

## Matched stationary-scene measurement

| 240 camera intervals, 120 to 360 | Build 33 seconds | Build 35 seconds |
| --- | ---: | ---: |
| First pair | 33.753463 | 32.996873 |
| Reverse-order repeat | 33.772182 | 33.000056 |
| Mean | 33.762822 | 32.998465 |

**2.32% higher pooled camera throughput** in Linux PPSSPP 1.20.4/JIT,
OpenGL 1x, buffered mode, frameskip 0, sound configured on, virtual 2000 CPU /
1000 bus. Camera completions are not gameplay FPS. There is no Android device
measurement. Order: 33, 35, 35, 33; 480 measured intervals per build. Mean saving
764.36 ms; largest within-build spread or 20 ms polling floor
20.00 ms. Both pairs improved; the saving exceeds four times that floor.
No compiler, tests or second emulator ran in timed windows. Actual loaded
executable instructions and clocks were checked. All ten WORLD_COMPLETE
summaries and all four scene PNGs match exactly.

## Validation and source changes

- Three engine files: the Bully pack declares the two waits and enables
  quantized_waits; ps2rc/pack.py emits the opt-in macro; hle/core/hle_sched.c
  preserves the original polling boundary and interrupt observation. Other
  packs default to the original scheduler C tokens, verified by preprocessing.
- Matching original PS2 ELF words confirm both loops only read gp-10364,
  compare and branch; no writes/calls. The first loop's reset remains outside.
- Actual original/candidate scheduler functions passed 20,000 host ASan/UBSan
  comparisons: virtual time, every callback delivery timestamp, counter and
  pending backedge state. Reproduce from source with:
  python3 tests/check_wait_scheduler.py --output /tmp/bully-wait-check
- All 187 prepared/final guest C units match 33. Existing unchanged math,
  texture, geometry and movie checks are reused by exact source identity.
- An earlier unquantized trial was rejected: one triangle-count difference and
  192 changed screenshot pixels. The retained polling boundaries address that
  timing drift; the adopted comparisons require exact summaries and images.
- Both fresh 33 and 35 buffered checks received Start/Select open and close
  presses and resumed camera updates after each pair. This does not accept
  visible menu rendering or Android freeze behavior as fixed.
- The new EBOOT also booted through the intro with Skip buffer effects and
  reached the world with the same first eight rendering summaries.
- Temporary menu/device captures are not included in this EBOOT. They showed
  paused display calls continuing without any of the four RenderWare 2D draw
  entries being called. Buffered Start allowed camera updates to resume;
  that does not prove visible menus or Android input are fixed. General PS2
  graphics DMA remains unsupported by this renderer. A door-specific save is
  needed to reproduce the reported indoor transition reliably.
- Audible audio, real PSP performance, Android FPS, walking/indoor transitions,
  full gameplay and saves remain unverified. Desktop audio output is unavailable.

EBOOT: 17,159,988 bytes; SHA256:
7814c1086279e01154d359991494e5635106ad94f667105acbbba139c38648ba
