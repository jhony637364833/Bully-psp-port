# Bully PSP experimental test 28

**Android 14 FPS remains unverified.** Build 28 copies saved guest GPRs with
PSP VFPU loads/stores while preserving their raw bits. Build 26 remains
available for rollback. The two build 27 trials were rejected and not released.

## Install

Copy `test-build/` contents from the runtime ZIP into a backup of your complete
converted game folder. Included: EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, installation
instructions, checksums and licenses. Keep your existing disc/, SLUS_212.69,
discmap.txt, iso_meta.bin, BULN.pmf, BULN.wav and memcard/. Fresh-boot; do not load
another build's save state. Game assets and movies are not duplicated in this update.

EBOOT: 17,159,252 bytes. SHA256:
`41d4a87c798478a87619459beed25e86eeb58970dcff374aa0aed8bd14ba9092`.

Optional PPSSPP fragments are unchanged from build 26. Read CONFIG-TEST-18.md
before applying them. Its measurements describe historical build 17. Experimental
virtual 2000 MHz exceeds PPSSPP 1.20.4's UI maximum of 1000; it changes the guest
instruction budget, not the phone's physical clock. Do not increase it arbitrarily.
Restore Auto/0 if needed. The EBOOT does not apply this INI. Compare identical settings.

## Matched stationary-scene measurement

| Camera 120 to 360: 240 events | Build 26 | Build 28 |
| --- | ---: | ---: |
| First host seconds | 34.867509 | 34.253076 |
| Reverse-order repeat seconds | 34.864246 | 34.251602 |
| Mean seconds | 34.865878 | 34.252339 |
| Camera completions / host second | 6.8835 | 7.0068 |

**1.79% higher pooled camera throughput**, 480 events per build.
Run order: 26, 28, 28, 26. Mean saving: 613.54 ms;
maximum within-build spread (or 20 ms polling floor): 20.00 ms.
Both pairs improved and mean saving exceeded four times that value.
These camera completions are not Android gameplay FPS. All ten WORLD_COMPLETE
summaries through camera 360 match across all four runs, including object,
triangle, draw and lighting counts. All four scene PNGs are byte-identical.

Opening camera 8 to 80 seconds, in run order:
13.317730, 13.047003,
13.043020, 13.304449.

Environment: PPSSPP 1.20.4/JIT, Mesa 26.0.8 llvmpipe LLVM 21.1.8, OpenGL 1x,
normal 100% speed, frameskip 0, sound enabled in config, private virtual
2000 MHz CPU / 1000 MHz bus. Same media and settings. SDL cannot open the ALSA
output device in this sandbox, so audible playback remains unverified.

## Implementation and checks

The EBOOT grows by 658,880 bytes versus build 26 and uses about 0.63 MiB more
emulated PSP user memory. The tested scene still allocated its optional
136,212-byte skin cache with 4,042,496 bytes left. Later gameplay memory use
remains unverified.

- Preserve the original snapshot contract: all 128 bits of r16..r23 and r30,
  plus f20..f31; snapshot size 192 bytes and alignment 16 unchanged.
- The 144 GPR bytes use aligned VFPU loads/stores without arithmetic. Save and
  restore the scratch physical quad around each batch. Prefixes and FPU flags
  are not consumed or changed. FPRs remain word copies because their source
  is only four-byte aligned.
- Enable VFPU on the actual `hle_game` PSP thread. Guest coroutines run inside
  that thread. If its creation with VFPU fails, retry the original thread
  attributes and use scalar copies. Other packs default to the original path;
  only Bully generated units opt in. HLE and Media Engine code stay scalar.
- Actual staged runtime header: 16,000 PSP save/restore differential cases
  (8,000 feature off, 8,000 on), all four rounding modes, full FCR31 with FTZ,
  initial flags/condition, full contexts, snapshot guards, all 128 physical VFPU
  registers and five control registers (prefixes, condition, RNG seed).
  Zero differences, including NaN payloads, infinities, zeros and subnormals.
- Independent frozen original helpers and portable fixture: another 16,000 PSP
  comparisons passed. Host ASan/UBSan checked the scalar fallback with 16,000
  comparisons in each fixture. These host runs do not exercise VFPU assembly.
- Actual extracted thread-creation code passed default, success, fallback and
  both-fail paths under host ASan/UBSan. Pack header absent/false defaults
  stayed byte-identical; true adds only its feature macro.
- Converter/runtime/config suite: 78 passed; one Windows code-page test skipped.
  Full game rebuild completed without warnings. All 187 prepared guest C units
  match build 26. Strict floating-point compiler flags are unchanged.
- Prior unaffected math, VU, skinning, clipping, rendering and audio checks
  carry forward by source identity; they were not all rerun for this iteration.

## Reproduce preservation checks

With PSPDEV on PATH:

~~~sh
python3 tests/prepare_context_copy.py --output /tmp/bully-context-copy
make -C /tmp/bully-context-copy
~~~

Boot that separate diagnostic EBOOT; context-vfpu.log must end with
`COMPLETE comparisons=16000 errors=0`.
For the host fallback check, from the generated directory:

~~~sh
cc -O2 -std=gnu11 -fno-strict-aliasing -frounding-math -ffp-contract=off -fsanitize=address,undefined -fno-omit-frame-pointer main.c candidate.c -lm -o test
./test
~~~

Android >=14 FPS, full gameplay, walking controls, saves and audible quality
remain unverified. This remains an incomplete gameplay port. Device acceptance
needs phone model, PPSSPP version/settings, session.log and a real-time FPS
recording of matching scenes.
