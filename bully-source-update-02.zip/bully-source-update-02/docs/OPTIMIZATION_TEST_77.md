# Bully PSP test build 77

## Result

A 128-byte command-class lookup table selects the existing VIF handlers, removing repeated command classification branches. Fragment handling, payload processing, callbacks, counters and error returns are preserved. No new allocation or settings changes.

Fresh desktop PPSSPP comparison measured **1.07–1.19% higher camera throughput over build 76**. This is a small improvement, not proof of gameplay FPS. **14 gameplay FPS remains unmet, and the reported disappearing overlay remains unresolved.**

|60-camera interval|Fresh build 76|Build 77|
|---|---:|---:|
|120–180|13.106950 s|12.967700 s|
|180–240|13.455317 s|13.297466 s|

Both runs used 333 MHz, JIT, OpenGL, buffered 1× rendering and frameskip 0, with no concurrent heavy work during timing. Five gameplay/menu PNGs match byte for byte. Start and Select pause/resume passed.

## Validation

- Host ASan/UBSan and PSP: **1,212,144 differential parser comparisons each** against the frozen build 76 implementation. Every command byte/count combination across four cycle patterns, plus 50,000 fragmented streams, unaligned input, partial DIRECT/skips, callback failure/mutation, counter wraparound and invalid address/size cases. Return values, full parser/GIF state, callback traces and input integrity matched.
- Integrated overlay suite: 50,000 bounded fuzz cases, 15 actual DMA helper boundary/chain/TTE/IRQ/wrap/stack/loop cases, and 19 ordered geometry/upload replays passed.
- Public fixture generator reproduces the executed test sources and Makefile byte for byte.
- Only `native_vif.c` changes in the runtime. Renderer, texture cache, guest code and other native objects remain build 76. Their prior validation is reused.

## Reproduce

From the source root with PSP SDK available:

```sh
python3 tests/prepare_vif_dispatch.py /tmp/bully-vif-dispatch
make -C /tmp/bully-vif-dispatch
python3 tests/check_native_overlay.py
```

Run the fixture EBOOT on PSP/PPSSPP. For host differential checks, compile generated `main.c`, `baseline.c` and `candidate.c` together with `-O2 -fsanitize=address,undefined`, including the fixture directory, then run the executable.

Physical PSP/Android FPS, audible audio and normal device saves remain unverified. Previous build 76 downloads remain available. Back up your memory card before testing.
