# Bully PSP optimization test 05

**Android 14 FPS is not verified.** This update targets the supplied converted
Bully NTSC-U SLUS-21269 v1.02 folder.

## Exact build

EBOOT: **16,656,468 bytes**

SHA256: `927addbfe791672534acb93877a71b1c819ae0b1dd95c149a59766da4f97868e`

The update ZIP includes EBOOT, exception helper, config, INSTALL, notices and
checksums. Keep your existing unchanged disc/media/saves. The source ZIP contains
the complete cumulative source overlay and tests; the patch applies to your
supplied latest source. Build: PS2RC 0.1.1 commit
332a437f21f7ef694943caef885a7d28410cbc41, PSP GCC 15.2.0, matching guest ELF
597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc.

## Optimization and reason

Actual opening-scene diagnostic timings attributed 68.24% of camera PSP-clock
time to strip rendering, 5.93% to object validation and 6.15% to material/texture
work. GPU flush timing was 2.15%, partly nested in strip time. These counters
overlap and do not add to 100%. They include instrumentation overhead and are not
host or Android FPS.

Captured-strip replay identified vertex preparation as the next target.
PSP libc's general `fminf` classifies both arguments on every lighting clamp.
The upper argument here is always finite 255. Selecting `lit < 255 ? lit : 255`
retains its result for finite values, infinities, signed zeros and NaN
intermediates. The alpha sum is an exact integer in 0..510. Material modulation
and all arithmetic order after saturation remain the same. Only these fixed
upper clamps changed; shader saturation still occurs before material tint.

## Correctness

- 1,000,000 bit-exact RGB/alpha comparisons against the frozen test04 helper,
 four host rounding modes, ASan/UBSan. Random finite light parameters plus
 explicit saturation boundaries, signed zero, subnormal gains, overflow and
 zero-gain NaN intermediates.
- 100,000 bit-exact PSP comparisons with FTZ in all four PSP rounding modes.
- Existing native lighting tests: 56 assertions pass.
- Renderer regression: 1,000 strips and 11,213,104 identical submitted vertex bytes.
- Unchanged clipping/cache, projection, decoding, audio, material and MMI checks
 retain their earlier results. The current full converter build passed.

## Captured-geometry diagnostic

A coherent 32 MB guest RAM capture now supports repeatable renderer experiments.
The adapter accepted 40 objects / 86 meshes. Decoding yielded 929 batches / 40,896 vertices
including seam duplicates. This snapshot is partial, has no captured light
state, contains many objects outside the camera, and uses the current captured
skin palette. It is not a complete visible frame. RAM and commercial geometry
fixtures are kept in task inputs, excluded from source and update downloads.

The comparison replays the original ring renderer and a diagnostic that prepares
all batch vertices before processing triangles. Exact output bytes/counts match
under 4 host modes and PSP RZ/FTZ, including a synthetic lighting fixture. The
phase-reordered renderer remains diagnostic-only; production retains its ring.

| PSP replay | Test04 ring | Candidate diagnostic |
| --- | ---: | ---: |
| Unlit captured geometry | 76,599 µs | 77,917 µs |
| Captured geometry with synthetic lighting | 136,945 µs | 100,013 µs |

The synthetic-lit strip CPU measurement is 27% lower, including diagnostic and
recorder overhead. Unlit timings show phase overhead. This is a component test,
excludes real GU execution, and does not establish a 27% game speedup.

## Fresh game comparison

The prior test04 candidate is reused as baseline after verifying unchanged
runtime assets/config/helper/guest ELF/PPSSPP settings and no save files. Test05
uses a new fresh boot. No compiler or other emulator ran during its samples.
Startup camera timing is excluded; observations poll every 50 ms.

| Measurement | Test04 (reused baseline) | Test05 |
| --- | ---: | ---: |
| Completed camera passes | 25 | 27 |
| Host elapsed seconds | 11.7543 | 12.5142 |
| Camera passes per host second | 2.1269 | 2.1576 |
| Average emulated camera µs | 371,971 | 338,580 |

Host-observed camera throughput is only 1.4% higher, **essentially flat within
ordinary variation**. The emulated camera clock is 9% lower; that local-clock
improvement does not establish actual FPS. This is one short run per build,
nearby different windows and a reused baseline, without confidence intervals.
No meaningful sustained whole-game speedup is established.

The first 8 complete camera summaries match exactly in every field, including
objects, triangles, material/lighting and draw counts. The screenshot shows the
entrance, road/ground and character. No fatal/deadlock was reported, and the
controller deliberately stopped the emulator after three timing windows. Later
stall/full-game equivalence remain untested.


Desktop Linux PPSSPP 1.20.4/JIT, PSP-2000/3000,1× OpenGL/software Mesa,
frameskip 0, audio enabled with dummy physical audio. Host monotonic completion
timestamps are independent of the emulated PSP clock. A camera pass can share a
gameplay frame with another camera; camera throughput is not gameplay FPS.

Android performance, sustained gameplay, the later historical guest stall,
controls, saves, complete visuals and audible quality remain unverified.
Existing unsupported graphics/audio pipelines remain.

## Install and test

Copy the contents of `test-build/` into a BACKUP of your complete converted game
folder. Retain disc/, SLUS_212.69, discmap.txt, iso_meta.bin, BULN.pmf, BULN.wav and
memcard/ saves. Follow INSTALL.txt and fresh-boot the new EBOOT.

Please send phone model, PPSSPP version/settings, session.log and a real-time
recording of the same scene before/after with frameskip 0. The requested 14 FPS
needs independent Android evidence.
