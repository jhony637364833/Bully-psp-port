# Lighting experiment results — 2026-10-28

## Fresh checks

| Check | Result |
|---|---|
| Host lighting differential, GCC 15.2.0, ASan/UBSan | 2,048,576 comparisons passed across four rounding modes |
| Current CPU renderer, original versus candidate lighting | 1,000 strips; 10,323,184 identical recorded output bytes; ASan/UBSan passed |
| Overlay installer | Copy preserves original; rejects existing/nested output and mismatched source; passed |
| Application to actual source 106 | Passed |
| PSP GCC 15.2.0 compile, warnings as errors | Candidate and lighting fixture compiled to objects |
| Full game link / boot / Windows converter | Not performed |
| Android / sustained gameplay / 30–40 FPS | Not tested or achieved |

The current-renderer comparison exercises RGB and monochrome, blends 0, 0.35
and 1, lit/unlit, clipped and skinned strips. It records submitted vertices
using host stubs; it does not run the PSP GPU or prove full-game equivalence.

Run it with the unchanged extracted source 106 folder:

```sh
python tests/renderer_light_differential.py /path/to/bully-optimization-source-106
```

The supplied `tests/renderer_differential.py` failed its historical-renderer
comparison on **both unchanged source 106 and the candidate** (`Submitted GPU
vertices changed`). That failure remains unresolved; it is not reported as a
passing gate. The focused comparison above holds the current renderer fixed
and varies only lighting, isolating this experiment from that existing failure.

## Host microbenchmark, not gameplay FPS

Three samples per blend and color mode, ten million calls each, alternating
old/new execution order, GCC `-O2 -frounding-math -ffp-contract=off`:

- Monochrome baseline/candidate time ratios: **1.314–1.898**.
- RGB ratios: **0.803–1.337**, with noisy samples including regressions.

This supports the reduced monochrome work in isolation, not an overall game
speedup. Target measurements are required before promoting the experiment.
The frequency of this path in the reported Android slowdown is unknown.
Two earlier zero-blend variants were rejected after benchmarks showed overhead
on blended inputs; neither is included.

PSP cross-compilation used the official pspdev `v20261001` Ubuntu x86_64 archive,
verified against the SHA-256 digest in its release metadata. GCC is 15.2.0.
The candidate object contains 1,384 bytes of text and no static data/BSS.
The test first lacked the PSPSDK include path; adding `psp/sdk/include` fixed
compilation. Compiling an object does not establish linkability or execution.

## Supplied inputs and compatibility

- [Source pack 106](https://drive.google.com/file/d/1GuPK75_oWFyQED3Uoh5AMf-TANGvhzpE/view)
- [PS2RC Converter 0.2.0](https://drive.google.com/file/d/1SYIJlTpLgB2YQE6L4A_C4OLZEd5ljD38/view)

Downloaded and inspected both archives. The converter download contained
another ZIP, which was extracted before inspection. The pack overlay has 65
files absent from that converter, 19 differing shared files (including license
and notice files), and six identical shared files. Differences cover the
translator, build pipeline, runtime, scheduler, memory-card and movie handling.
These counts establish a migration surface, not incompatibility of every file.

The game Drive page was accessible; the ISO was not downloaded. No game build
or disc-identity verification was attempted. Source 106 expects the boot ELF
SHA-256 recorded in its `pack.toml`; that still needs checking during conversion.

## Remaining work

Reconcile the source 106 core changes with PS2RC 0.2.0, build the matching game,
resolve the existing renderer regression fixture, and collect controlled
Android profiles. The supplied pack's historical reports point to guest
geometry/traversal as well as rendering; those reports are not new measurements.
A complete compatible pack and the requested performance target remain open.
