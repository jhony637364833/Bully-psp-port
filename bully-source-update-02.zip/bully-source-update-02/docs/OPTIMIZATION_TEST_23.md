# Bully PSP experimental test 23

**Android 14 FPS remains unverified.** This build reduces repeated bone-matrix
reads during character skinning. Build 22 remains available for rollback.

## Install

Copy test-build/ contents from the runtime ZIP into a BACKUP of your complete
converted game folder. Included:EBOOT.PBP,ps2rc_exc.prx,ps2rc.cfg,INSTALL.txt,
checksums and licenses. Keep disc/,SLUS_212.69,discmap.txt,iso_meta.bin,BULN.pmf,
BULN.wav and memcard/. Fresh-boot; do not load another build's save state.
EBOOT: 16,499,332bytes SHA256:93ceaf2c3230a80c9311b95eb036327e6ef068a90eeefb3fcebac98561ec0232.

Optional ppsspp-settings/ is unchanged from 22. Read CONFIG-TEST-18.md before
using it; its measurements describe historical build 17. The virtual 2000 MHz
setting exceeds PPSSPP1.20.4's UI maximum 1000 and changes the guest instruction
budget, not the phone's physical clock. Do not increase it arbitrarily. Restore
Auto/0 if needed. EBOOT does not apply this INI. Compare at IDENTICAL settings.

## Matched stationary-scene measurement

| Actual camera 120->360, 240 events | Build 22 | Build 23 |
| --- | ---: | ---: |
| First host seconds | 36.249167 | 35.743351 |
| Reverse-order repeat seconds | 36.242352 | 35.734816 |
| Mean seconds | 36.245759 | 35.739084 |
| Camera completions/host second | 6.6215 | 6.7153 |

**1.42% higher pooled camera throughput.** 480 events per build, sequential
order 22,23,23,22. One final-baseline attempt ended with SIGTERM before a result;
it is excluded and was repeated. Camera completions are NOT Android gameplay FPS. Every logged
WORLD_COMPLETE summary through camera 360 matches exactly across all 4 runs,
including initial 9809 draws and later object/triangle/draw/lighting counts.
Opening 8->80 hostseconds, in order 22,23,23,22:
13.602889,13.477178,13.475679,13.614700.

PPSSPP1.20.4/JIT,Mesa26.0.8llvmpipeLLVM21.1.8,OpenGL1x,normal100%,frameskip0,
sound enabled in config,privatevirtual 2000 MHz/bus1000. Same media/config.
SDL could not open an ALSA output device in these runs; audible playback was
not checked. Earlier reports describing dummy physical audio are inaccurate
for this controller. This limits performance comparisons to this same host setup.
Actual live frame/camera counters polled10ms with monotonic host time; loaded
ELF prologue verified, allowing PPSSPP's first-word JIT patch. No concurrent
compilers/tests/other emulator during measurement. All 4 scene PNGs are byte-identical.

## Change and preserved contract

Build 22 validates every bone matrix, then repeatedly reconstructs the same
12 float values for every weighted vertex. Build 23 reuses the values from
validation in a bounded, call-local 64-bone array. A matrix is reloaded on demand
after each visitor callback. No heap allocation, persistent cache or new API.

The original API permits scratch memory to overlap the palette. A conservative
full 256-vertex scratch-window overlap check selects the original live-read path
in that case. Callback mutations remain visible to the next batch, including
nonfinite values: lazy reload adds no new finite-value rejection. Validation,
weight decoding, accumulation order, output bits, triangle counts and failure
behavior are preserved. Native stack frame is 3576 bytes; function code grows
2524 to 2944 bytes. The existing worker coroutine stack is 128 KiB (main 512 KiB).

Only games/SLUS-21269_v1.02/src/native_skin.c changes in the engine overlay.
All 187 prepared guest C units are byte-identical to 22. No rendering omissions,
approximate math, frame skipping, resolution change or audio-policy change.
Older unsafe native overrides remain disabled.

## Correctness checks

Host ASan/UBSan and a separate PSP test EBOOT each passed 26,896 differential
cases against the frozen build 22 source. Coverage includes 1..64 bones,
1..4 influences,3..256 vertices, unaligned RAM bases, multibatch seams, callback
mutations, scratch/palette overlap and boundaries, corrupted tags/weights/data,
invalid parameters, zeros/subnormals/Inf/NaNs/overflow values and all 4 rounding
modes. PSP checks include FTZ and full FCR31; both compare complete RAM/scratch
arenas and guards, callback records, counts and return values. Host 23,397 and
PSP 23,370 successful decodes differ because FTZ differs between platforms;
reference and candidate agree within each platform. 3,180 alias cases and 4,008
callback cases per platform. Known valid fixtures are required to succeed.
The portable generator reproduces all 10 executed fixture inputs exactly.

## Diagnostic correction

The 130-second build 22 diagnostic found its largest observed camera gap,
5.632 seconds at camera 34->35 / guest frame 670->807, INSIDE the older 8->80
benchmark. Build22's report incorrectly called that gap later and outside the
bounded comparison. Afterward, the largest observed gap was0.191 seconds.
The stationary Linux test did not reproduce the reported 10 seconds/frame.
This correction does not establish Android performance or explain that device's
slowdown. The new 120->360 comparison measures steady scene work separately.

## Reproduce

Overlay targets PS2RC0.1.1 revision332a437f21f7ef694943caef885a7d28410cbc41,
PSPGCC15.2.0/SDK20261001. From the supplied source root:

~~~sh
python3 tests/prepare_skin_palette.py --output /tmp/bully-skin-test
make -C /tmp/bully-skin-test
~~~

Boot that separate diagnostic EBOOT; skin-test.log must end with
COMPLETE cases=26896 ... errors=0. Host check in the generated directory:

~~~sh
cc -O2 -g -std=gnu11 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fno-strict-aliasing main.c reference.c candidate.c -lm -o test
./test
~~~

Android >=14 FPS, complete gameplay, walking controls, saves and audible quality
remain unverified. This remains an incomplete gameplay port. Phone model,
PPSSPP version/settings,session.log and matching real-time FPS video are needed
for device acceptance. Unchanged earlier math/render/audio checks are reused by
source identity; they were not all rerun for 23.
