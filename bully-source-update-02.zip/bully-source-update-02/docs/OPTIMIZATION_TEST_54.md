# Bully optimization test 54 — native compressed vertex loads

Targets: PSP-2000/3000 and Android PPSSPP. **14 gameplay FPS remains unmet/unverified.**

## Change

Compressed vertex expansion now uses native signed/unsigned halfword loads on aligned PSP input. The parser checks alignment once per batch. Unaligned buffers retain the original byte decoder. Each vertex is still completely cleared before reading attributes, including overlapping-input behavior. Float conversion, scaling, colors, geometry, materials and draw order are unchanged.

Only native_mesh.c and its object change. All 171 generated guest objects and other native objects remain build 51. There is no new allocation or persistent cache. Build 51 checkpoint repairs remain included. The rejected larger-batch and parser-cache experiments are excluded.

## Measured result

Fresh sequential candidate-then-baseline desktop PPSSPP 1.20.4 runs: normal 333 MHz/bus166 MHz, PSP-2000 memory profile, JIT/OpenGL, buffered rendering,1x,frameskip0. No other compiler, emulator or sampler ran during the timed intervals.

| Camera interval | Build 51 | Build 54 | Camera throughput gain |
|---|---:|---:|---:|
|120–180|16.550244s|16.272765s|1.71%|
|180–240|16.902154s|16.613978s|1.73%|

This is one matched desktop comparison of **camera completions, not gameplay FPS**. The improvement is modest. Android and physical PSP measurements are unavailable; host audio output was unavailable. Earlier unchanged-build51 baseline timings also agree closely, but are not presented as another matched pair.

## Validation

- Host ASan/UBSan and PSP: 2,097,152 value/alignment comparisons covering every signed16 bit pattern, four pointer offsets, four rounding modes and both flush settings. Exact float bytes and full PSP FCR status match.
- 80,000 parser comparisons include malformed/truncated inputs and aligned/unaligned RAM. Another1,024 cases compare complete RAM, scratch effects, counters, callbacks and FPU state with overlapping buffers and input-mutating callbacks.
- Final PSP disassembly confirms native `lh`/`lhu` loads and one alignment dispatch per batch. The first per-attribute-dispatch prototype also passed correctness tests; it was refined before gameplay measurement.
- Five gameplay/Start/Select screenshots and all ten world summaries are byte-identical to the fresh build51 baseline. Both menus pause and resume successfully in the tested opening scene.
- Published fixture generator reproduces all six executed fixture input files byte-for-byte. Existing unchanged renderer/skin/save/compiler results are reused only for their unchanged code; no new complete-game or device-save claim is made.

Reproduce PSP checks with `python3 tests/prepare_halfword_loads.py --output /tmp/bully-halfword`, then `make -C /tmp/bully-halfword` using PSP GCC15.2.0. Run the generated EBOOT and expect `COMPLETE values=2097152 parser=80000 sideeffects=1024 errors=0`. For host checks, compile only candidate.c with `-D__PSP__ -D__MIPSEL__` to exercise aligned loads on a little-endian host; compile main/reference normally, with strict FP and ASan/UBSan.

## Delivery and limits

The runtime ZIP contains EBOOT, the unchanged plugin/config, licenses and installation instructions. Keep your existing converted disc/media and saves. The source ZIP and cumulative patch contain the implementation and reproducible checks. Build51 versioned downloads remain available.

EBOOT.PBP: 16995844 bytes; SHA256 `cc2d2d5672554c1b5b7060fa849ba63477f706e92603788394e2451f4d9690bc`.

Full sky/combat/tutorial/subtitle coverage, school entry, physical-device controls/audio and normal device save-point round trips remain unresolved or unverified. No visual/gameplay fixes are claimed in this optimization. The next full converter run must reconcile older build-cache stamps; this tested delivery rebuilds the affected native object and relinks the existing validated guest objects.
