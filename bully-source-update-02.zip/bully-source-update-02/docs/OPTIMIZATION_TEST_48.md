# Bully test build 48 — restore collision bounds rejection

Targets: PSP-2000, PSP-3000 and Android PPSSPP.

## Change

A gameplay census recorded 153,204 collision bounds calls over four camera
updates; 153,170 used the sphere test. The original game executes two
`vsub.xyz` instructions to VF00 at 0x0013142c and 0x00131430, then reads their
sticky sign flag to reject separated bounds. The converter dropped those
instructions because VF00 is read-only and its general FMAC flag model is
incomplete. The translated sphere test consequently always accepted bounds.

This build restores the six subtraction lanes and the specific sticky sign
bit consumed by that test. It rejects distant collision branches using the
original game's predicate. It changes collision results compared with build
46 to repair the missing behavior. General VU flag emulation remains partial.
No approximate physics, simulation-speed multiplier, emulator alt-speed,
Skip buffer effects, frameskip or physical overclock is introduced.

## Measured improvement

Desktop PPSSPP 1.20.4, normal 333 MHz / 166 MHz bus, PSP-2000 model, JIT,
buffered OpenGL 1x, sound enabled, frameskip 0, Skip buffer effects disabled:

| Steady window | Build 46 | Build 48 | Camera throughput |
| --- | ---: | ---: | ---: |
| Camera 120–180 | 45.970 s | 17.264 s | 2.66x |
| Camera 180–240 | 46.303 s | 17.622 s | 2.63x |

One new gameplay run compared with the equivalent recorded build 46 baseline.
No compiler, tests, sampler or second emulator ran during either window.
These are camera completions, **not gameplay FPS**. This does not establish
14 FPS, Android performance or physical PSP performance.

## Verification

- 32,768 whole-function cases on the desktop with ASan/UBSan, and 32,768
  on the PSP build under PPSSPP. An independent scalar interpretation checks
  the original six-lane predicate, complete CPU/VU state, RAM and floating-point
  status. Includes four rounding modes, PSP flush-to-zero on/off, normal and
  unusual float values, and explicit inside/outside controls.
- Published fixture regenerated and checked separately; no game function
  bodies or game assets are distributed in the tests.
- Actual converter preparation applies the one rule exactly once and emits
  the tested function. Only one generated guest unit/object changes.
- 240 gameplay camera completions; Start and Select pause and resume.
  Repeated menu screenshots are identical. All five gameplay/menu screenshots
  also match build 46 byte for byte. One final world summary reports one fewer
  triangle (20,402 vs 20,403); object, skin, draw and texture counts match.
- Renderer, sky material and HUD composition code is unchanged from build 46;
  its existing GPU/geometry checks carry forward by source identity.
- Runtime archive checksums/CRC, source archive, cumulative patch and frozen
  EBOOT/ELF/object identities are checked before delivery.

## Remaining work

14 FPS remains unmet/unverified. Complete sky appearance, every combat/tutorial
prompt and subtitle, school entry, walking/physics across the full game, saves,
Android, physical PSP and audible audio quality still require testing. This
build preserves the starting tutorial/objective/radar elements verified in
build 46; it does not claim a new sky or complete-overlay repair.

## Install

Back up your existing test folder. Extract `bully-optimization-test-48.zip` and
copy the contents of `test-build/` into that folder, replacing the matching
files. Keep your existing game data, guest executable, disc image and movie
files. The ZIP contains EBOOT.PBP, the exception helper, configuration, notices,
installation instructions, this report and SHA256SUMS.txt.

Use normal speed and buffered rendering for the comparison. Please report your
Android device, PPSSPP version/backend, gameplay FPS and whether school entry
and combat prompts work with build 48.

## Reproduce the focused checks

After conversion of the matching user disc:

```sh
python3 tests/prepare_sphere_rejection.py --build /path/to/build --output /tmp/bully-sphere-test
python3 tests/check_sphere_rejection.py --fixtures /tmp/bully-sphere-test
make -C /tmp/bully-sphere-test
```

For the last command, PSPDEV/PSPSDK must be available. Run that fixture's
EBOOT.PBP on PSP/PPSSPP and inspect `sphere.log`. The expected completion is
32,768 cases, zero errors. It is a correctness fixture, not an FPS benchmark.
