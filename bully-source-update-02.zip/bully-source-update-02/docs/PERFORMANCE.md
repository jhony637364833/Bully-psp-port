# Renderer optimization follow-up

This build preserves full 32 MB guest RAM and the 96-vertex submission buffer.
It makes three bounded CPU changes:

- Each strip vertex is transformed and lit once, using a three-vertex stack
  ring. Previously each triangle transformed and lit all three vertices. For
  a 256-vertex strip this reduces preparations from 762 to 256. Skin skip flags
  and strip restart boundaries retain their original behavior.
- Six-plane outcodes accept fully visible triangles and reject triangles fully
  outside a common plane. Crossing triangles use the original double-precision
  intersections. Non-finite input checks still run before classification.
- Removes a CPU depth calculation whose result was overwritten before submission.
  The GPU projection still computes perspective depth and texture interpolation.

No additional permanent geometry/texture buffers or geometry reductions were
introduced. Texture conversion and synchronous GPU submissions still cost time;
this does not promise a particular gameplay FPS.

## Verification

`bash tests/run_clip_differential.sh` compares 100,000 seeded triangles with
`tests/clip_reference.c`, the frozen original clipping routine, under ASan/UBSan.
`python3 tests/renderer_differential.py` compares the actual old/new triangle and
strip bodies for 1,000 strips (0..256 vertices, lighting on/off, skin skips,
clipping and buffer flushes). All 13,159,192 output bytes match.
The PSP GPU perspective smoke still produces center RGB (48,0,0).

An optional host microbenchmark uses two million fully visible triangles:

```sh
src=app/games/SLUS-21269_v1.02/src
cc -O2 -I"$src" -Dbully_clip_triangle=baseline_clip \
  -c tests/clip_reference.c -o /tmp/bully-clip-reference.o
cc -O2 -I"$src" tests/clip_benchmark.c /tmp/bully-clip-reference.o \
  "$src/world_clip.c" -o /tmp/bully-clip-benchmark
/tmp/bully-clip-benchmark
```

Measured host CPU times were 0.223–0.274 seconds before and 0.049–0.110 after
across three runs. These are an isolated fully-visible clipping workload on the
sandbox host, with a concurrent emulator. They are **not PSP or gameplay FPS**.
Crossing triangles also pay the new classification cost; sustained game FPS
requires a controlled scene benchmark on the intended device.

## 2026-10-25: target the measured CPU cost

The current ordered submission work uses a 384-vertex buffer and a bounded
4096-word command list. The 96-vertex description above records the earlier
optimization. Full guest RAM and per-triangle alpha pass order are preserved.

A scratch timing build of that renderer measured camera `018b1a60` with roughly
15,000 output triangles: about 1.70 seconds per pass, including 1.68 seconds
inside the native CPU renderer. Texture conversion took about 19 milliseconds
and GPU waits about 7 milliseconds. These are PSP clock timings under desktop
PPSSPP, with texture/wait time included in renderer time. They are not additive
categories or measurements from an Android phone or physical PSP.

The clipper's trivial visibility checks had been subtracting doubles to test
which side of each plane a float coordinate occupied. PSP implements that
arithmetic in software. The new version uses ordered binary32 integer keys:
negative values sort before zero, positive values after zero, and signed zeros
compare equal. This also preserves subnormal ordering without depending on
hardware float arithmetic. Finiteness validation still runs first.

For crossing triangles, each plane first checks the CURRENT polygon. A plane
containing every current vertex would only copy it and is skipped. Classification
is repeated after intersections, so rounded vertices are still checked against
later planes. All actual intersections retain the original double arithmetic,
attribute interpolation and plane order. No global fast-math flag was added.

Checks:

- 100,000 differential output cases against the frozen original, ASan/UBSan.
- 6,946,723 ordering/plane comparisons against double subtraction, including
  signed zero, subnormals and finite extremes; zero errors on host and PPSSPP.
- PSP synthetic benchmark, 10,000 triangles per sample, two samples each:
  fully visible 262.9–263.0 ms -> 27.6–27.7 ms (about 9.5x);
  side crossing 1822.6–1823.9 ms -> 969.9–974.1 ms (about 1.88x).
  Both benchmark fixtures produced identical complete output bytes. These are
  clipping throughput results, not complete-game speedups.

### Next optimization priorities

1. Address measured guest geometry/traversal stalls first. Samples identify
   `fn_0012a5c0` and `fn_0037eeb0`; capture complete RAM, register and VU effects,
   guest calls and scheduler boundaries before replacing any part with native
   code. These functions mutate guest state and cannot safely be bypassed.
2. Profile remaining native intersections, projection, lighting, skinning and
   copies. Shared-vertex clip/projection reuse is now implemented below.
   Measure complete camera boundaries including stalls; backedge counts and
   emulator vblank rates are not gameplay FPS.
3. Evaluate VFPU transforms/lighting and strip/index submission with numerical
   and image comparisons. The GE clipping prototype below was rejected;
   PSP clipping/range limits require CPU fallback.
4. Add bounded decoded-mesh/texture caches only with verified mutation and
   streaming invalidation. Pointer-only keys can display stale resources.

A 15 FPS budget is 66.7 ms for the WHOLE frame; 30 FPS is 33.3 ms. The measured
1.70-second camera pass needs about a 25x reduction to meet even the former
budget, and simulation/other cameras still need time. Texture-resolution changes
alone cannot remove the measured CPU geometry cost. Playable FPS is not yet
established.

### Controlled game check

Same desktop PPSSPP 1.20.4, OpenGL software rendering, 1x, PSP-2000/3000,
JIT, no frame skipping, dummy audio. Both builds use the same O2 translation,
384-vertex batching, full guest RAM and scratch timing counters. No compilation
or debugger sampling was active during the timed intervals.

| Metric | Batch only | With exact clip optimization |
| --- | ---: | ---: |
| Completed camera passes / 20-second sample | 11 / 20.114 s | 24 / 20.139 s |
| Camera passes per wall second | 0.547 | 1.192 |
| Median complete pass, PSP clock, reports 15–26 | 1737 ms | 715 ms |
| Median CPU renderer, same reports | 1714 ms | 691 ms |
| Median texture conversion, included in renderer | 19.0 ms | 19.3 ms |
| Median GPU waits, included in renderer | 6.7 ms | 6.6 ms |

The 20-second completed-pass rate improved about 2.18x. The first eight camera
summaries match exactly, including frame, object/triangle counts, texture misses,
skinned objects, draw calls and lighting counts. This does not prove identical
pixels for the whole game; the host differential and PSP fixtures cover the
changed math. The final sample included a pause in camera completions near
virtual frame 675. Input responsiveness and long-session stability have not
passed a new acceptance check. Multiple cameras can occur in one gameplay frame.
**This remains unplayable; 1.192 camera passes/s is not a playable FPS claim.**

The regular source build with diagnostic timers removed also compiled/linked
successfully (16,664,052-byte EBOOT). The timed game check above used the instrumented
candidate, not that final binary. Neither physical PSP nor Android was tested.

## Continued work: still unplayable

The next compatible source change caches validated vertex outcodes, projected
screen coordinates and packed submission data in the existing three-vertex
strip ring. Fully visible triangles reuse those results. Crossing triangles
retain the exact CPU clipper; invalid vertices, common-plane rejection, the
area threshold, vertex order and ordered alpha passes retain their behavior.
The cache is local to each strip, so no streaming-resource invalidation is needed.

The host suite now also compares against the frozen immediately preceding
renderer, with fully visible, trivially outside and NaN-containing strips.
All submitted output bytes match. Classifier tests cover every finite plane
predicate and public-helper invalid inputs. PSP build and material diagnostic
are checked separately from gameplay speed.

A scratch GPU-side-clipping experiment retained CPU fallback for depth crossings
and PSP coordinate limits. Inspection of PPSSPP's PSP clipper shows that PSP
only automatically clips negative Z and may discard entire out-of-range
primitives. Thus the earlier GPU recommendation needs this fallback; it cannot
simply remove all CPU clipping. The experiment also changed quantization at
clipped edges and tiny-triangle rejection, unlike the exact production path.

The experiment reached about 2.03 completed camera passes/s in a stable
14.27-second interval, then encountered the same long completion pause.
It was rejected for adoption: this is still far below playable speed and image
equivalence was not established. No experimental GE source is in the source ZIP.

During the pause, 34 samples had the game thread actually running: 18 were in
`fn_0012a5c0`, 8 in `fn_0037eeb0`, and 3 in `fn_001860c0`. Saved PCs from ready
threads are excluded. These limited samples locate expensive guest work; they
do not establish exact CPU-time percentages or justify skipping those routines.
The next substantial step is exact native equivalents for the measured guest
geometry/traversal routines, validated against complete RAM/register effects and
scheduler boundaries. Further renderer changes alone do not resolve that pause.

### Shared-vertex game check

The regular production build compiled/linked (16,665,652-byte EBOOT), booted
with full guest RAM and completed the opening scene. Its first eight camera
summaries match the preceding clip-optimized build in every logged field.
The four-phase PSP material/camera/batch diagnostic also passes.

The wall sample completed 19 passes in 21.097 seconds (0.901 passes/s), including
an extended pause after report 34. Restricting both recordings to reports 15–34
shows 13.042 seconds for the shared cache versus 14.076 seconds previously.
These endpoints are polled about every two seconds, and the previous build
included timers; this small difference does not establish a reliable speedup.
The two whole-sample rates use different windows and must not be treated as a
regression or improvement comparison. **Playable acceptance still fails.**

Current host coverage: 100,000 differential clipping cases; 7,939,133 ordering,
plane and public-classifier checks with zero errors under ASan/UBSan; 1,000
renderer strips producing 11,213,104 identical bytes across the original,
immediate preceding and current implementations. No new Android, physical PSP,
audible-gameplay or long-session result is established.
