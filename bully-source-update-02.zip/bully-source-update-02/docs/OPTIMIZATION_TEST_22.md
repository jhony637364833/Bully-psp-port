# Bully PSP experimental test 22

**Android 14 FPS remains unverified.** Build 22 reduces register/stack moves
around the exact numerator-one reciprocal square root. Build 21 remains available
for rollback. No approximate math or graphics/audio reductions are introduced.

## Install

Copy test-build/ contents from the runtime ZIP into a BACKUP of your existing
complete converted game folder. It includes EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg,
INSTALL.txt, checksums and licenses. Keep disc/, SLUS_212.69, discmap.txt,
iso_meta.bin, BULN.pmf, BULN.wav and memcard/. Fresh-boot; do not load another
build's save state. EBOOT: 16,498,916 bytes; SHA256: 0b2f92a76d41cbabe537aaf585f0f3f19d697313c0a94715edd70efd341410fc.

Optional ppsspp-settings/ includes the previous experimental virtual2000MHz and
rollback fragments. Read CONFIG-TEST-18.md before using them. That document
reports historical build17; this package's executable/source/results are22.
2000 exceeds PPSSPP1.20.4's UI maximum and changes its virtual instruction budget,
not the phone physical clock. Do not increase it arbitrarily. Restore Auto/0 if
needed. EBOOT does not apply the INI. Compare builds at IDENTICAL settings.

## Change and preserved contract

The baseline numerator-one path returns an integer bit pattern through both the
zero-exponent and square-root/division branches. GCC15.2 spills that merged value
to the stack and reloads it repeatedly in the hot normalizer. The new private
float helper uses an empty Allegrex FPR input/output constraint in EACH branch.
These constraints emit no instruction and leave every bit unchanged. They keep
both branch results in a floating-point register. The public fpu_rsqrt5 signature
and returned integer bits remain unchanged.

The same zero/subnormal branch, signed result, input clamp, sqrt and division
remain. The unknown-numerator path is unchanged: all43 PSP instruction words in
the generic probe match exactly. No floating-point mode, FCR31 policy, context
layout, guest work, scheduler safe point, rendering or audio policy changes.
Only runtime/r5900_rt.h changes in the engine overlay. All187 prepared C units
are byte-identical to21, including its three coordinate-reuse replacements and
35 earlier proven leaf save removals. Old unsafe native overrides stay disabled.
Normalizing probe:336 to312bytes; actual game function:316 to344bytes.
The standalone numerator-one probe grows84 to112bytes; the game comparison below
checks whether the tradeoff helps the actual workload.

## Matched opening-scene measurement

| Counter8 to80, 72 events | Build21 | Build22 |
| --- | ---: | ---: |
| First host seconds | 13.662252 | 13.563314 |
| Reverse-order repeat seconds | 13.655282 | 13.609175 |
| Mean seconds | 13.658767 | 13.586245 |
| Camera completions / host second | 5.2713 | 5.2995 |

**0.53% higher pooled camera throughput.** 144 measured camera events per
build, sequential order21,22,22,21. All four first-eight summaries match,
including9809 draw calls. These camera completions are NOT Android gameplay FPS.
The later long gap remains outside this bounded comparison.

PPSSPP1.20.4/JIT, Mesa26.0.8 llvmpipeLLVM21.1.8, OpenGL1x, normal100%, frameskip0,
soundon(dummyphysicalaudio), privatevirtual2000MHz/bus1000. Same media/config.
Actual unchanged live camera/frame counters polled10ms with monotonic host time;
loaded ELF prologue verified, permitting only PPSSPP's first-word JIT patch.
No concurrent compilers/tests/other emulator in the measurement windows.

## Verification and rejected experiment

- Host ASan/UBSan strictFP:4016384 denominator cases each comparing known-one
  and generic numerators; all modes and exponent/mantissa edges plus random.
- PSP executable in PPSSPP: same4016384 cases, including full hardwareFCR31
  comparisons, FTZ and varied initial condition/sticky/cause patterns.
- Each platform also passed128064 full-context/64KiB RAM/guard comparisons:
  24^3 edge-vector combinations,10000random and8192actual traced vectors per mode.
- No differences. Input/output bits and complete preserved state are checked.
- Portable generator reproduces all7 test inputs. Test-only format casts removed
  warnings; all3 PSP objects were byte-identical to the executed passing fixture.
  The separately relinked wrapper differs, so no wrapper identity is claimed.
- Full230unit rebuild, prepared-source identity, actual ELF inspection, two
  ordered game comparisons, archive CRC/every checksum, source/engine/binary
  identity, patch dry-run and preservation of previous downloads/config.
- Prior unchanged renderer/clipping/general math/VU/audio/converter/state checks
  are reused for identical implementations; those suites were not all rerun.

Before this change,8192diagnostic calls showed potential math reuse. A separate
exact64entry cache passed800000 value/FCR31 checks, but four ordered input-replay
microtests were11.63% slower. That cache and diagnostic instrumentation were
REJECTED and are absent from this release. Microtimings are not gameplay FPS.

## Reproduce

Source overlay targets PS2RC0.1.1 revision332a437f21f7ef694943caef885a7d28410cbc41,
PSPGCC15.2.0/SDK20261001, BullySLUS-21269v1.02 ELF SHA256
597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc.
From the source overlay root, app/ installed on that engine:

~~~sh
python3 tests/prepare_fpr_rsqrt.py --output /tmp/bully-fpr-test
make -C /tmp/bully-fpr-test
~~~

Boot this separate test EBOOT. normalize-test.log must end with:
COMPLETE comparisons=128064 scalars=4016384 errors=0.
Host check from its generated directory:

~~~sh
cc -O2 -g -std=gnu11 -fsanitize=address,undefined -fno-omit-frame-pointer -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off main.c reference.c candidate.c -lm -o test
./test
~~~

Android>=14FPS, full gameplay, controls, saves and audible quality remain
unverified. Device acceptance requires phone model, PPSSPPversion/settings,
session.log and a real-time FPS recording of matching scenes.
