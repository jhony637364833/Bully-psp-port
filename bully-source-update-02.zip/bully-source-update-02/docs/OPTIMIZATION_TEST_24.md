# Bully PSP experimental test 24

**Android 14 FPS remains unverified.** Build 24 reduces branches in clipping
coordinate ordering. Build 23 remains available for rollback.

## Install

Copy `test-build/` contents from the runtime ZIP into a backup of your complete
converted game folder. Included: EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, installation
instructions, checksums and licenses. Keep your existing disc/, SLUS_212.69,
discmap.txt, iso_meta.bin, BULN.pmf, BULN.wav and memcard/. Fresh-boot; do not load
another build's save state.

EBOOT: 16,498,756 bytes. SHA256:
`ba4d6bab4ffabfa849cbdd6afb1bec9e6bbbf8fcc64ffa896cafa3f1155e2e2f`.

Optional PPSSPP fragments are unchanged from build 23. Read CONFIG-TEST-18.md
before applying them. That document's measurements describe historical build 17.
The experimental virtual 2000 MHz exceeds PPSSPP 1.20.4's UI maximum of 1000;
it changes the guest instruction budget, not the phone's physical clock.
Do not increase it arbitrarily. Restore Auto/0 if needed. The EBOOT does not
apply this INI. Compare builds at identical settings.

## Matched stationary-scene measurement

| Camera 120 to 360: 240 events | Build 23 | Build 24 |
| --- | ---: | ---: |
| First host seconds | 35.750988 | 35.582496 |
| Reverse-order repeat seconds | 35.726035 | 35.586510 |
| Mean seconds | 35.738511 | 35.584503 |
| Camera completions / host second | 6.7154 | 6.7445 |

**0.43% higher pooled camera throughput**, with 480 events per build.
Completed run order: 23, 24, 24, 23. Mean saving: 154.01 ms;
maximum within-build replicate spread (or 20 ms polling floor): 24.95 ms.
Both pairs must improve and mean saving must exceed four times that value for
adoption. This is a small measured improvement. Camera completions are not Android gameplay
FPS. All logged WORLD_COMPLETE summaries through camera 360 match across all
four runs, including the initial 9809 draws and later object, triangle, draw
and lighting counts. All four scene PNGs are byte-identical.

Opening camera 8 to 80 seconds, in run order:
13.477920, 13.436223, 13.429576, 13.428827.

Environment: PPSSPP 1.20.4/JIT, Mesa 26.0.8 llvmpipe LLVM 21.1.8, OpenGL 1x,
normal 100% speed, frameskip 0, sound enabled in config, private virtual
2000 MHz CPU / 1000 MHz bus. Same media and settings. SDL cannot open the ALSA
output device here; audible playback was not checked. These results apply to
this matched host setup. Actual unchanged live frame/camera counters polled
at 10 ms with monotonic host time. Loaded ELF prologue verified, allowing
PPSSPP's first-word JIT patch. No concurrent compilers, tests or other emulator
in the measurement windows.

## Change and preserved contract

Only the private `order_key` helper in world_clip.c changes. The former signed
zero and sign branches produced a large branch tree when inlined repeatedly
into vertex outcodes and polygon side checks. Unsigned integer masks now:

1. Clear the sign bit only when the magnitude is zero.
2. Flip the sign bit for nonnegative values, or complement negative values.

For zero magnitude, `0 - (magnitude != 0)` is zero; for all other values it is
all ones. After that canonicalization, `0 - (bits >> 31)` is all ones for a
negative value and zero otherwise. OR with 0x80000000 gives the exact former
complement/sign-flip mask. This proves the same key for every 32-bit pattern.
The finite-input callers and their contracts remain unchanged.

The PSP key probe falls from 10 to 7 instructions, with no conditional branch.
Full game vertex-code total (including the former split implementation):
820 to 516 bytes.
Full game clip_triangle: 4460 to 4180 bytes.
Public APIs, finite validation, floating-point comparisons, clipping planes,
interpolation arithmetic, ordered-edge caching, output ordering, rendering
and audio policy remain intact. No approximate math, omitted draws, frame skip
or resolution changes. All 187 prepared guest C units are byte-identical to 23;
its skinning change and earlier proven leaf save removals remain intact.

## Verification

Host ASan/UBSan strict floating-point checks and a separate PSP EBOOT each passed:

- 17,825,814 integer ordering comparisons: every mantissa at both signs with a
  rotating sweep through five boundary exponents, edge patterns and 1,048,576
  random 32-bit patterns. The algebra above covers all 32-bit patterns.
- 160,000 vertex checks: valid/invalid planes, null vertices, all attributes,
  zeros, subnormals, extrema, infinity, quiet/signaling NaNs and random bits.
- 72,064 polygon comparisons, all four rounding modes, PSP FTZ and varied
  initial condition/status flags. Entire output arrays, guards, cache storage,
  return values and full PSP FCR31 agree with frozen build 23.
- Host accepted 47,190 polygons; PSP accepted 47,196 due to platform FTZ effects.
  Reference and candidate agree independently on each platform.
- The portable generator reproduces all ten executed fixture inputs exactly.
  An initial PSP test module label exceeded its 27-character metadata limit;
  it was shortened. Host preprocessing was byte-identical after that change.
  The corrected PSP build was warning-free and its tests completed.
- Runtime/source ZIP CRC, every payload checksum, source/engine/binary identity,
  generated-code identity, patch dry-run, old versioned downloads and original
  PPSSPP configuration preservation checked before delivery.

Unchanged prior math, VU, rendering and audio checks are reused by source
identity; they were not all rerun for this release.

## Reproduce

Overlay targets PS2RC 0.1.1 revision 332a437f21f7ef694943caef885a7d28410cbc41,
PSP GCC 15.2.0 / SDK 20261001. From the supplied source root:

~~~sh
python3 tests/prepare_clip_mask.py --output /tmp/bully-clip-mask
make -C /tmp/bully-clip-mask
~~~

Boot that separate diagnostic EBOOT. clip-mask.log must end with
`COMPLETE keys=17825814 codes=160000 polygons=72064 ... errors=0`.
For the host check, from its generated directory:

~~~sh
cc -O2 -g -std=gnu11 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fno-strict-aliasing main.c reference.c candidate.c -lm -o test
./test
~~~

Android >=14 FPS, complete gameplay, walking controls, saves and audible quality
remain unverified. This remains an incomplete gameplay port. Device acceptance
needs the phone model, PPSSPP version/settings, session.log and a real-time FPS
recording of matching scenes. Build 23 also corrects older reports: the observed
5.632-second camera gap was inside camera 8 to 80, and this controller did not
use a dummy physical audio device. No Android conclusion follows from either.
