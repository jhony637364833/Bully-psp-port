# Bully PSP experimental test 17

**Android 14 FPS remains unverified.** This release optimizes the CPU state
copies that remain necessary after build 16. Build 16 is retained for rollback.

## Download and install

EBOOT.PBP: 16,501,540 bytes. SHA256:
`5a119db2ec12ec2279e6cc517b99af1aa14d515d8c5a0b119d2c157b1d2d203a`

The runtime ZIP contains EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, INSTALL.txt,
licenses/notices and SHA256SUMS.txt. Copy test-build/ contents into a BACKUP of
your complete converted Bully folder. Keep disc/, SLUS_212.69, discmap.txt,
iso_meta.bin, BULN.pmf, BULN.wav and memcard/. Fresh-boot the EBOOT; do not load
an emulator save state made with another executable. Follow INSTALL.txt.

The cumulative source overlay targets PS2RC 0.1.1 revision
332a437f21f7ef694943caef885a7d28410cbc41, PSP GCC 15.2.0 / SDK 20261001,
Bully SLUS-21269 v1.02 ELF SHA256
597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc.

## Change and original contract

The original rt_cs_save/restore contract preserves nine full 128-bit GPRs
(r16-r23 and r30) and twelve FPR words (f20-f31): all 192 bytes. That requirement
remains. No additional save/restore pairs are removed in this release.

The structs already inherit 16-byte alignment from R5900Reg128. The FPR union
array has contiguous 4-byte elements. The two helpers now expose these existing
alignment guarantees to memcpy. The twelve FPR copies become one aligned
48-byte memcpy. The GPR copy remains 128 bytes plus the original full r30 copy.
PSP disassembly replaces unaligned load/store pairs with aligned lw/sw and
copies the FPR block in groups of four words. This preserves every bit,
including upper GPR lanes and special floating-point bit patterns.

Static thread/interrupt contexts and the PSP coroutine stack initialization
satisfy the required alignment. There is no struct layout, interface, preserved
register, arithmetic, graphics, audio or simulation change. Every character in
the runtime header outside these two helpers and their comment is unchanged.
All 187 prepared game C units are byte-identical to build 16. The shared header
requires all 230 units to recompile. Old v0 native replacements remain disabled.

## Matched game measurement

| Counter 8 to 80 | Build 16 | Build 17 |
| --- | ---: | ---: |
| Camera completions | 72 | 72 |
| First run host seconds | 28.939456 | 28.419173 |
| Reverse-order repeat host seconds | 28.939787 | 28.428255 |
| Mean host seconds | 28.939622 | 28.423714 |
| Camera completions / host second | 2.4879 | 2.5331 |

**1.82% higher pooled camera throughput; 1.78% less elapsed time.**
The two individual pair gains are 1.83% and 1.80%.
Each build completes 144 measured camera events across its two runs.
First eight scene summaries match exactly, including all geometry/state/count
fields and 9,809 draws. The later long gap remains. Both runs complete the
interval without a fatal/deadlock report before intentional termination.

Two sequential pairs, first 16 then 17, followed by 17 then 16. Linux PPSSPP
1.20.4/JIT, Mesa 26.0.8 llvmpipe LLVM 21.1.8,
OpenGL 1x, normal 100% speed, frameskip 0, sound enabled with dummy physical
audio, virtual PSP CPU 1000 MHz / bus 500. Same media and private configuration
copies; no compiler/tests/other emulator in measured windows. Live existing
camera/frame counters are read every 10 ms using a monotonic host clock;
loaded ELF prologue bytes are checked, allowing only PPSSPP's first-word JIT patch.

Camera completions are not gameplay FPS. These two short desktop comparisons do
not verify Android FPS, sustained gameplay or performance at Auto/333 MHz.

## Verification

Fresh checks:

- 40,000 host ASan/UBSan full-context/save/guard comparisons against both the
  original helpers and an independent register-by-register byte oracle.
- Another 40,000 on PSP in PPSSPP. Zero errors in both runs.
- Zero, all-one, walking-bit and random data cover all 192 preserved bytes,
  special floating-point representations and untouched context fields.
- Sixteen combinations of legal context/save positions test alignment and
  guard bytes before/after both objects. Stack-allocated save/restore is also
  tested across an opaque callee that changes every context byte.
- Static assertions check GPR/context/save alignment, offsets, FPR stride and
  the full 192-byte save size. Save leaves its source unchanged; restore
  leaves the save buffer and all unpreserved context bytes unchanged.
- The portable generator reproduces the executed test inputs exactly.
- Full converter/build; all 187 prepared units match build 16 byte for byte.
- Runtime/source ZIP CRCs, checksums, matching binary/source, patch application,
  original emulator configuration and previous rollback artifacts checked.

Earlier converter, leaf, renderer, clipping, math, alpha/depth/GPU and audio
results are reused for identical implementation inputs. Those complete suites
were not all rerun. The changed preservation operations have the fresh oracle,
guard/stack, PSP and full-game coverage above. A first converter invocation
used the wrong directory and failed to import ps2rc; the corrected engine
invocation built successfully. No failing correctness checks were waived.

## Reproduce copy checks

Overlay app/ onto the stated engine revision and build through its Python
converter. From the source overlay root:

```sh
python3 tests/prepare_csave_copies.py --output /tmp/bully-copy-test
make -C /tmp/bully-copy-test
```

Boot this separate test EBOOT in PPSSPP. copy-test.log must end with
`COMPLETE comparisons=40000 errors=0`. It is not the game EBOOT.
For host checks, from that generated directory:

```sh
cc -O2 -g -std=gnu11 -fsanitize=address,undefined -fno-omit-frame-pointer -fno-fast-math main.c reference.c candidate.c -lm -o test
./test
```

## Android comparison

Use the same scene/settings for builds 16 and 17: PSP-2000/3000, 1x, frameskip 0,
normal speed, sound enabled. The desktop comparison uses optional per-game
virtual PSP CPU clock 1000 MHz. PPSSPP labels this option unstable; it changes
the emulated instruction budget, not your phone physical clock. Restore Auto (0)
and fresh-boot if pacing, controls or sound worsen. Test your usual Auto setting
separately. Send phone model, PPSSPP version/settings, session.log and a real-time
recording with the FPS display. Sustained Android FPS, full gameplay/controls/
saves, complete visual correctness and audible quality remain outstanding.
