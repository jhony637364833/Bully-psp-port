# Bully PSP experimental test 11

**14 FPS on Android remains unverified. This build reduces draw submissions;
no complete-scene FPS improvement was demonstrated in the desktop test.**
Build 08 remains available for rollback and Android comparison.

## Exact download

EBOOT: **16,657,892 bytes**

SHA256: `d0e2ece4640b962da4ea4f26d7c100577b76449cc03e8efe4299a38ec2076a55`

The runtime update includes EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, installation
instructions, notices/licenses and SHA256SUMS.txt. Retain your existing complete
converted disc/media folder and saves. The separate source ZIP is the cumulative
overlay with portable host/PSP regression tests and build instructions.

PS2RC 0.1.1 at `332a437f21f7ef694943caef885a7d28410cbc41`, PSP GCC 15.2.0,
SDK 20261001, matching SLUS-21269 v1.02 guest ELF
`597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc`.

## Optimization

Source palette metadata can conservatively mark a texture as mixed-alpha even
when its converted image uses only opaque palette entries. Other converted
textures have a partial-alpha minimum already above the passing threshold.
Build 11 computes a conservative minimum from converted T4/T8 indices and their
8888 palette, once per material binding when needed. It includes stored padding,
so padding can only lower the bound. Swizzling permutes those same index bytes.
Original texture metadata and texels remain unchanged.

A proven opaque minimum preserves vertex alpha. Otherwise, integer division by
256 supplies a conservative lower modulation bound. GEQUAL, GREATER and NOTEQUAL
skip fail draws only when that lower bound proves every fragment passes. ALWAYS
also needs no fail draw. Unknown formats/layouts use a zero lower bound and retain
the original conservative behavior. Build 06's all-fail shortcut remains.

The remaining primitives keep the original order. Material state, final alpha/
depth state, geometry, lighting, clipping, simulation and audio are unchanged.
Texture memory is read only after conversion and the minimum is invalidated at
every bind. Existing bounded buffers and synchronization before reuse remain;
there are no new allocations or frame-skipping/approximate-math settings.

## Correctness and regression checks

- Independent converted-image oracle: 30,000 T4/T8 linear/swizzled textures under
  ASan/UBSan: 20,572 exact unpadded minima and 9,428 conservative padded minima;
  6,857 unused-transparent-palette opaque witnesses and 6,857 partial-alpha
  witnesses. 210,000 malformed layout/range checks; 65,536 modulation pairs.
- Actual renderer helper: 50,331,648 pass decisions, 6,276,307 certifications,
  six guards and 256 cached texture minima under ASan/UBSan.
- Original alpha suite: all 10 boundary assertions pass unchanged. Existing
  all-fail suite: 7,137,920 bounds and 20,000 command/state comparisons pass;
  2,134 certified cases and 17,866 unchanged fallbacks. Harness additions supply
  the new helper/cache dependencies; original expected assertions remain.
- Real PSP captured/derived workload: 24 exact pixel/self comparisons with
  far-depth witnesses for every case, plus 10 nonempty all-fail witnesses and
  10 deliberately incorrect foreground-depth-write positive controls.
- Asset-free complete-world PSP tests: 65 exact color/depth-witness image pairs
  (67,891,200 identical bytes) against Build 08; 65 self checks, two all-fail
  depth witnesses and two positive controls per version. Twenty cases submit
  fewer draws. Covers RGBA/T4/T8, opaque/partial/mixed used palettes, unused
  palette entries, swizzle/linear, filters, empty/multiple batches, cache reloads,
  all alpha comparisons and default/disabled material states. Maximum actual
  SDK command list remains 6,160 bytes in a 16,384-byte buffer.
- Existing portable PSP GPU suite: 108 synthetic cases with exact color/self
  comparisons and nonempty all-fail depth witnesses/positive controls passes.
- Portable generators build successfully; generated 65-case sources match the
  executed private harnesses. No commercial assets are needed for these tests.
- Complete converter and fresh game boot pass. No fatal/deadlock report before
  intentional termination after three windows. First eight scene summaries
  match Build 08 in every field except the intended draw-call reduction.
  Screenshot inspected: entrance, road, ground and character render.
- Unchanged geometry/projection/lighting/clip/audio/MMI checks retain their
  previous valid results; they were not all rerun. Geometry renderer bodies
  after channel() are byte-identical to Build 08.

Color uses explicit GE transfer/readback. Raw depth bytes are auxiliary, because
prior emulator tests did not reproduce a known depth clear value reliably.
Observable depth is checked through far-depth witnesses with positive controls.

## Measured component result

The eight captured batches submit **732 → 142 draws** with identical output.
Three alternating sections per version, 30 repeats of the eight batches and a
final GPU readback barrier gave median host time **0.198290 → 0.093330 seconds**,
about **53% less**. Individual baseline sections were 0.226560/0.198290/0.193757 s;
candidate sections 0.093602/0.087381/0.093330 s. The small sample and component
workload do not establish an Android or whole-game FPS improvement.

## Fresh complete-scene comparison

| Opening scene | Build 08 | Build 11 |
| --- | ---: | ---: |
| Draws across first eight summaries | 20,848 | 9,809 |
| Completed camera passes | 28 | 28 |
| Host measurement seconds | 10.254214 | 10.264452 |
| Camera passes / host second | 2.7306 | 2.7279 |
| Average emulated camera microseconds | 323229.11 | 322944.57 |

Submitted draws fell **53%**. Host camera throughput changed **−0.10%**,
effectively unchanged. This experimental iteration is supplied for Android
comparison because it removes demonstrated GPU work with matching output;
it is not advertised as a verified gameplay FPS increase.

One short Linux PPSSPP 1.20.4/JIT run per version, Mesa 26.0.8 llvmpipe LLVM
21.1.8, PSP-2000/3000, 1× OpenGL, frameskip 0, sound enabled with dummy physical
audio. Matching configuration, runtime/media and empty test memory cards.
Host timestamps are independent of the PSP clock, with 50 ms observer polling.
No concurrent tests/compiler/emulator in the candidate measurement windows.
Camera passes can share a gameplay frame and are not gameplay FPS.

Android performance, sustained gameplay, the historical later guest stall,
controls, saves, full visual equivalence and audible quality remain unverified.
Existing unsupported graphics/audio pipelines remain.

## Install and test

Close PPSSPP. Copy the CONTENTS of test-build/ into a backup of your complete
converted game folder. Keep disc/, SLUS_212.69, discmap.txt, iso_meta.bin,
BULN.pmf, BULN.wav and memcard/. Follow INSTALL.txt and fresh-boot this EBOOT;
do not load an emulator save state made with an older executable.

Use the same Android scene/settings for Build 08 and Build 11, frameskip 0.
Send phone model, PPSSPP version/settings, session.log and a real-time recording
so progress toward the 14 FPS target can be measured independently.
