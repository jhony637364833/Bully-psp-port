# Bully PSP optimization test 06

**Android 14 FPS remains unverified.** This update is for the supplied converted
Bully NTSC-U SLUS-21269 v1.02 folder.

## Exact build

EBOOT: **16,656,900 bytes**

SHA256: `459857f265f681d51acfe98d499d5271da775625525348243bdeeb1ec6809cc0`

Built with PS2RC 0.1.1 commit `332a437f21f7ef694943caef885a7d28410cbc41`,
PSP GCC 15.2.0 and the matching guest ELF
`597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc`.
The ZIP contains EBOOT, exception helper, config, INSTALL, notices and checksums.
The separate source ZIP contains the cumulative overlay and portable tests.
Keep your unchanged disc/media and saves.

## Rendering optimization

The original FB_ONLY path performs adjacent pass/fail draws for every triangle
to preserve overlapping color and depth behavior. Build 06 recognizes only
batches proven to fail: NEVER, or GEQUAL/GREATER with the entire submitted
vertex-alpha upper bound below the passing threshold. Texture modulation cannot
increase that bound. Passing draws then produce no fragments. One ordered
color-only fail draw replaces those empty passes and repeated fail draws.
The original alpha test and depth-write mask are restored afterward.

Mixed and unproven batches retain the original per-triangle path. Geometry,
lighting, clipping, simulation and primitive/color order remain the same.
The bounded buffers/command list and runtime memory allocation are unchanged.
`draw_calls` intentionally decreases; it counts submitted draws, not geometry.

## Correctness

- 7,137,920 exhaustive alpha/reference/modulation checks under ASan/UBSan.
- 20,000 command/state comparisons: 2,134 certified batches and 17,866 unchanged
  fallbacks. Input vertices, final alpha/depth state, buffer reset and bounded
  command traces checked against the frozen build 05 implementation.
- Original alpha boundary suite: 10 assertions. Native material-state sanitizer
  fixtures pass. Renderer: 1,000 strips / 11,213,104 identical submitted vertex bytes.
- Portable PSP GPU differential: 108 synthetic cases, exact original/candidate color
  pixels and repeated-original self-checks. All 27 nonempty all-fail depth witnesses
  and 27 positive controls that deliberately write depth pass. No game assets needed.
- Reused verified private GPU tests: 24 captured/derived cases, 10 depth witnesses and
  10 positive controls, with the exact integrated candidate. The two real all-fail
  batches reduced 110 → 1 and 256 → 1 draws, preserving their visible output.
- Unchanged lighting, clipping, decoding, projection, audio and MMI checks retain
  earlier valid results. Current complete converter build passed.

Color comparison uses explicit GE transfer/readback. Direct CPU VRAM loads were
stale in this emulator. Raw depth transfer did not reproduce a known clear value,
so raw depth bytes are not a correctness oracle. A full-screen far-depth witness
checks observable depth preservation; deliberate foreground-depth writes prove
that the witness detects errors.

## Measured component improvement

Previously verified actual-host profiling found 31% wall residence inside buffer
swap in this desktop environment. The main PPSSPP thread used substantially more
CPU than EmuThread. These samples include waiting; they are not exclusive per-stage
CPU costs or Android evidence. See HOST-PROFILE-06.md in the separate investigation
report for that measurement.

The captured eight-batch workload was repeated 30 times per section, with three
sections per version in alternating order and an explicit final GPU readback barrier.
Median host time fell 2.2969 → 2.1486 seconds (**6.5% less**). The first baseline
section was slower; only three sections per version were collected. This is a
component benchmark, not a full-game or Android FPS increase.

## Fresh complete-game comparison

The fresh production EBOOT reached three camera measurement windows with no
fatal/deadlock report before the controller deliberately terminated the emulator.
The first eight complete scene summaries match build 05 in every field except
`draw_calls`, as intended. Across those summaries, submitted draws fell
44,190 → 20,848 (52.8% fewer). This is not a geometry or FPS count.
The screenshot shows the entrance, road, ground and character rendering.

| Opening-scene measurement | Build 05 (reused baseline) | Build 06 |
| --- | ---: | ---: |
| Completed camera passes | 27 | 27 |
| Host measurement seconds | 12.514152 | 12.213938 |
| Camera passes / host second | 2.1576 | 2.2106 |
| Average emulated camera time (µs) | 338579.74 | 337367.07 |

Observed host camera rate increased **2.5%** in this short sample.
This is a small difference with one run per version and ordinary run variation;
it does not establish a sustained gain. The valid build 05 baseline was reused
with matching runtime assets/configuration. Intro skip timing differed; only
post-startup windows are compared. Observer polling is 50 ms.

Desktop Linux PPSSPP 1.20.4/JIT, PSP-2000/3000, 1× OpenGL/software Mesa,
frameskip 0, sound enabled with dummy physical audio. Host monotonic completion
timestamps are independent of emulated PSP time. Camera passes can share a game
frame, so camera throughput is not gameplay FPS. Global PPSSPP settings remain
identical to the baseline, including its saved presentation settings.

Android performance, sustained gameplay, the historical later guest stall,
controls, saves, complete visual equivalence and audible quality remain unverified.
The existing unsupported graphics/audio pipelines remain.

## Install

Close PPSSPP. Copy the CONTENTS of `test-build/` into a BACKUP of your complete
converted game folder. Retain disc/, SLUS_212.69, discmap.txt, iso_meta.bin,
BULN.pmf, BULN.wav and memcard/ saves. Follow INSTALL.txt and fresh-boot the EBOOT;
do not load an old emulator save state.

Please send phone model, PPSSPP version/settings, session.log and a real-time
recording of the same scene with frameskip 0. The 14 FPS target needs independent
Android evidence.
