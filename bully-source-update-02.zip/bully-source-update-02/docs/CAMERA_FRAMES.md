> Historical camera-boundary notes: subsequent builds separate camera completion
> from display presentation. Current camera_end captures the completed background;
> the guest flip hook presents it. See OPTIMIZATION_TEST_46.md and INVESTIGATION.md.
> The native diagnostics have been updated to invoke that flip presentation hook.

# Complete camera passes, not virtual-clock swaps

The supplied renderer used `hle_frame` in `bully_world_draw` to decide when to
swap and clear buffers. That counter advances with emulated time, including
while a single scene is still being drawn. Splitting a scene there presents
partial geometry and makes swap counts an invalid gameplay-FPS measurement.
The earlier task report's 0.53 "rendered FPS" was such a swap rate, not proven
complete gameplay frames per second.

For the exact verified SLUS-21269 v1.02 ELF:

- Function00223ad0 stores the camera argument at006cf898, calls the driver begin
  function, and returns the camera on success or zero on failure.
- Function00223a78 calls the driver end function and, on success, clears006cf898
  and returns the camera; on failure it returns zero.

The new hooks call the original functions first and retain all return values and
guest side effects. A successful begin opens/clears a scene. Object drawing does
not clear or present based on virtual time. A successful matching end presents
once. Duplicate or mismatched end calls do not present. Empty/unsupported passes
do not count as displayed geometry. `WORLD_COMPLETE` reports the camera identity
and counters for a completed pass. Multiple cameras may be used in one gameplay
frame; a completed camera pass alone must not be called gameplay FPS without
checking which camera and scene it represents.

The PSP material diagnostic advances the emulated clock between objects, then
ends a mismatched camera and ends the valid camera twice. All four expected
color phases passed in PPSSPP OpenGL, demonstrating retained scene contents and
no duplicate presentation. This does not establish complete game graphics or
playable performance. Game integration testing remains necessary.
