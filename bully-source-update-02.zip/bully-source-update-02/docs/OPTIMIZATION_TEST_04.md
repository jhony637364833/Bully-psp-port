# Optimization test 04 — exact shared-edge clipping cache

Android 14 FPS remains unverified. This iteration reduces repeated renderer
work; game simulation and quality settings remain as in test03.

## Change and contract

Adjacent triangles in a strip share an ordered edge. The new cache keeps two
intersections per clipping plane, comparing both complete ordered vertices:
position, color, UV and alpha. Both near/far plane bit patterns are tagged;
changing either clears the cache. Signed zero and all attribute bits participate
in matching. Reversing an edge never uses the forward result.

Cache misses use the exact test03 distance, weight and interpolation code.
Results for the current plane are collected separately and committed after
processing it, so an early miss cannot evict the second edge's reusable result.
The original polygon/plane order, invalid-input checks, output geometry and
attribute bits are retained. The original uncached API remains available.

A cache is reset for each synchronous renderer strip. It uses 1,316 bytes on
the stack, with no heap allocation or global cache lifetime. The compiled strip
frame is 3,016 bytes. Callers of the new cached API must keep FPU control fixed
for its lifetime and reset after a mode change; the renderer already keeps the
game's RZ/FTZ mode fixed during strip processing.

## Checks

- 9,744,248 exact cached/reference polygon comparisons, including all four host
  rounding modes, ASan/UBSan. Includes shared strips, reversed edges, attribute
  changes at identical coordinates, invalid data, near/far drift, signed zero,
  extreme finite/subnormal attributes, cache boundaries and null-cache fallback.
- Existing complete polygon suite: 105,061 comparisons; 100,000 original-reference
  cases and 7,939,133 classifier checks pass.
- Renderer: 1,000 strips, 11,213,104 identical vertex submission bytes across four
  reference bodies and the cached renderer.
- PSP and full-game results are recorded in TEST-RESULTS-04.md supplied with the
  runtime update. Camera passes are not gameplay frames.

Reproduce host checks with `bash tests/run_clip_cache.sh`,
`bash tests/run_clip_edges.sh`, `bash tests/run_clip_differential.sh` and
`python3 tests/renderer_differential.py`. With PSPDEV/bin in PATH,
`make -C tests/psp_clip_cache` builds the isolated PSP diagnostic, not the game.

The earlier vector-local and bound-selection collision experiments passed their
synthetic state checks but benchmarked slower; neither is part of this build.

## Final binary and measurements

EBOOT 16,656,548 bytes, SHA256
`3f22d7637a14ef0cdba2eb334e183b58743561598aca22b187ef1cfd2778d2bf`.
PSP 54,495 exact comparisons pass. For 8,064 triangles: side-strip
1,018,433→609,408µs (40% less), mostly-inside 46,510→43,741µs,
random 534,370→404,074µs (24% less); checksums match.

The recorded test03 camera baseline is reused after runtime identity checks:
2.1021→2.1269 passes per host second (+1.2%, within ordinary variation).
Emulated camera work 412,866→371,971µs, but actual Android FPS remains unknown.
First 8 camera summaries match and entrance/road/ground/character render.
The short desktop sample does not establish a sustained whole-game speedup.
