# Bully PSP test 38: fewer native GPU submissions

Targets: **PSP-2000, PSP-3000 and Android PPSSPP only**.

Projection and material setup now share the first geometry command list.
Every geometry flush still waits before reusing vertex memory, and every mesh
boundary finishes its list, including empty or fully rejected meshes. Texture
storage stays valid until its GPU reads finish. Triangle order, clipping,
precision, material/alpha/depth state and the supported overlays are preserved.
No extra geometry cache or RAM allocation was added.

## Measured work

- Host regression: **5,429 → 3,768 command lists** across 512 cases, with exact
  ordered commands, vertices, textures, CLUTs and draw counts (ASan/UBSan).
- Actual PSP executable GPU fixture: **1,351 → 933 command lists** across 65
  cases, with byte-identical color/depth witness images and repeat renders.
  Largest candidate command list: 6,352 bytes of its 16,384-byte capacity.
- Desktop PPSSPP, normal automatic clock (runtime **333 MHz**, bus166), buffered
  OpenGL 1x, no frameskip: camera passes 8→80 took **75.887s before** and
  **75.639s after** in a single comparison. The baseline timing window ended
  before its profiler started. This is camera throughput, **not gameplay FPS**;
  it is not an Android or physical PSP benchmark or a repeatability claim.
  The difference is about 0.3%, too small to establish a gameplay speedup.
- Fresh final executable: Start and Select pause/resume checks pass. Their menu
  and map screenshots match build37 byte-for-byte, including paused repeats.
- Unchanged CPU/math/skin/texture/movie/overlay tests retain their earlier input
  identities; these were reused, not all rerun this iteration.

No emulator alt-speed, Skip buffer effects, emulator CPU override or physical
overclock is required. Use buffered rendering at normal speed. No emulator
settings files are included in the update.

## Install

Back up your existing working game folder. Copy the contents of `test-build/`
from the runtime ZIP into that copy. Keep `disc/`, `SLUS_212.69`, `discmap.txt`,
`iso_meta.bin`, `BULN.pmf`, `BULN.wav` and `memcard/`. Unchanged disc/media files
are omitted. Start from a fresh boot; emulator save states from older executables
are unsuitable. Build37 remains available for rollback.

The separate source ZIP contains the complete updated source overlay. The
patch is cumulative against the imported original source. Regression command,
with GCC and PSP SDK headers installed:

```
python3 tests/check_world_submission.py --sdk-include /path/to/pspsdk/include
```

## Remaining issues

**14 FPS has not been achieved or verified.** Android and physical PSP hardware
are unavailable here. Audio is configured but audible playback is unverified.
School-door entry, the black sky, complete HUD/tutorial/subtitle/combat prompts,
save behavior and full gameplay remain unresolved or unverified. The native
renderer supports a bounded subset of PS2 commands; these checks do not establish
compatibility with every scene. Return `session.log`, your device/PPSSPP version,
and a recording of the same problem scene after testing.

EBOOT.PBP: 16,988,532 bytes.
SHA256: 30124f184a7ba6961ce185ad5a0bb8a863b9558e11487c84139cc80c8cd1f639
