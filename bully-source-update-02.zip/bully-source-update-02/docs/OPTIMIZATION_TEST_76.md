# Bully PSP test build 76

## Result

The GPU bounds scan uses explicit coordinate bounds and exact integer exponent checks to remove repeated stack traffic and floating-point classification work. No new allocation. Original CPU helpers, texture handling, lighting and submission order are unchanged from build 73.

Measured desktop PPSSPP camera throughput improved **3.61% / 3.42% over build 73**. This is not gameplay FPS or physical-device proof. **14 gameplay FPS remains unmet; the disappearing-overlay issue remains unresolved.**

|60-camera interval|Fresh build 73|Build 76|
|---|---:|---:|
|120–180|13.571915 s|13.098428 s|
|180–240|13.923833 s|13.464002 s|

Both runs used 333 MHz, JIT, OpenGL, buffered 1× rendering and frameskip 0, without concurrent heavy work during timing. The baseline was collected immediately before this refinement, with unchanged settings and binary. Preliminary trial 75 improved throughput 1.76–1.84%; build 76 includes the additional finite-check optimization.

## Validation

- Fresh host ASan/UBSan and PSP differential tests: **8,192 cases each**, exact return values, vertices, triangle/submission order, flushes, source bytes and complete restored floating-point state. Coverage includes four rounding modes, trap bypass, skips, exceptional lighting and NaN/infinite/subnormal coordinate inputs.
- Fresh independent bounds checks: **80,000 cases each on host and PSP**, including nonidentity transforms, exceptional coordinates and screen-guard crossings. Counts: 38,796 outside, 21,856 fallback, 19,348 inside. Original per-vertex classification assertions passed.
- Public fixture generator reproduces the executed differential fixture byte for byte.
- Five gameplay/menu PNGs byte-identical to the fresh baseline. Start and Select pause/resume passed. A sixth, post-resume screenshot differs because it is captured at different camera counts (260 versus 259); both were visually inspected. That uncontrolled capture is not used as exact-image proof.
- Source comparison confirms only `gpu_strip_bounds` changed in the runtime renderer. Unchanged CPU/GPU submission, lighting and texture code retains prior validation from build 73; those suites were not rerun.

Finite classification uses alias-safe integer loads and checks the exponent bits. It preserves the GPU path's existing enabled-trap bypass and full FCR restoration. Public CPU behavior is unchanged. Existing GPU rounding differences, documented in earlier releases, remain.

## Reproduce

From the source root with PSP SDK and a host C compiler available:

```sh
python3 tests/prepare_gpu_scan.py /tmp/bully-gpu-scan
python3 tests/prepare_gpu_bounds.py /tmp/bully-gpu-bounds
make -C /tmp/bully-gpu-scan
make -C /tmp/bully-gpu-bounds
```

Run the resulting EBOOTs on PSP/PPSSPP. For host checks, compile generated `main.c` with `-O2 -fsanitize=address,undefined -frounding-math -ffp-contract=off`, include the game source directory, link `-lm`, and additionally link `native_light.c` for the GPU scan fixture.

Physical PSP/Android FPS, audible audio and normal device saves remain unverified. Build 73's optional 1.5 MiB texture cache remains included. Back up your memory card before testing. Previous build 73 downloads remain available.
