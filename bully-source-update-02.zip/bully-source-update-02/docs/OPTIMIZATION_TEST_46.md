# Bully test build 46 — preserve gameplay tutorials and minimap

Targets: PSP-2000, PSP-3000 and Android PPSSPP.

## What changed

The gameplay packet trace found that the guest submits HUD DMA before the next
native world camera. The bridge drew that HUD and then cleared the same buffer
for the next camera. The visible result was a world without its tutorials/map.

Build 46 presents the completed world/HUD composition before that clear and
retains the next world for its HUD. UI-only menus continue to present at the
guest flip. This adjusts native display timing by one camera to match the
observed guest DMA ordering. Guest execution, simulation speed, vertex/texture
conversion, sky material rules and memory allocations are unchanged.

The starting scene now visibly contains:

- Movement/camera tutorial and “Welcome to Bullworth” title.
- Minimap, destination marker and mission objective text.
- The later tutorial explaining the destination marker.

Heavy unsupported framebuffer effects remain rejected. No emulator alt-speed,
Skip buffer effects, or frameskip is required. Combat prompts and subtitles
have not all been exercised; this is not a claim that every overlay is fixed.

## Verification

- Original build fails a regression assertion for preserving early HUD;
  build 46 passes the actual composition functions under ASan/UBSan.
- Real PSP GE fixture passes early HUD preservation across the next world clear,
  deferred world-only flip and ordinary UI-only presentation.
- All existing sky/depth fixture assertions pass, including foreground depth,
  invalid sky Z rejection, additive sky materials and masked depth writes.
- 512 renderer cases preserve ordered commands/vertices/textures, GPU buffer
  lifetimes and command capacity under ASan/UBSan.
- Camera timing windows, switches and duplicate/mismatched ends pass.
- Desktop PPSSPP 1.20.4: normal 333 MHz, buffered OpenGL 1x, frameskip 0;
  240 camera completions followed by Start/Select pause and resume.
  Repeated menu captures are byte-identical.
- All 171 generated guest C files and their objects remain build 43 equivalents.
- EBOOT, source/runtime ZIP bytes, CRCs and checksums verified before delivery.

The old camera timing fixture was updated for the camera/flip separation already
present in build 43. Its timing expectations remain unchanged and pass against
both build 43 and 46; new composition coverage checks presentation separately.

Reproduce the new asset-free checks from the source root:

```sh
python3 tests/check_overlay_composition.py --source app/games/SLUS-21269_v1.02/src/psp/world_display.c
python3 tests/check_camera_perf.py
python3 tests/prepare_composition_gpu.py --output /tmp/bully-composition-gpu
# With PSPDEV/bin on PATH: make -C /tmp/bully-composition-gpu
# Launch its EBOOT.PBP; sky.log must finish with COMPLETE.
```

## Performance and remaining issues

**14 FPS remains unmet. No meaningful new gameplay speed gain is established.**
Matched camera windows changed from 46.130/46.442 seconds to 45.970/46.303
seconds (about 0.3%). That small difference does not establish a useful speedup;
camera counts are not gameplay FPS. A separately tested NOP decoding optimization
is still experimental and is not included in this EBOOT.

The captured starting sky is visible, but complete sky appearance, school-door
entry, combat/tutorial coverage, saves, audible audio, Android performance and
physical PSP behavior remain unverified or unresolved. The sandbox has no
Android or physical PSP device. Test the reported broken sky location again.

## Install

Close PPSSPP and back up the converted game folder. Copy the contents of
`test-build/` from the runtime ZIP into it. Keep the original disc data, boot
program, disc map/metadata, intro media and saves. Fresh boot the new EBOOT;
do not load an emulator save state from the old executable. See INSTALL.txt.
The separate source ZIP contains the cumulative updated source and tests.
