# Bully PSP test 37: native menus and GPU batching

Target: **PSP-2000, PSP-3000 and Android PPSSPP**.

This build adds a native PSP GE path for supported GIF/VIF DIRECT 2D commands.
The tested Start menu and Select map are now visible, including their text,
backgrounds, icons and controls. Both close and resume world camera updates
in desktop PPSSPP. This does not establish that Android freezes are resolved.

## Native optimization

| Same captured paused frame | Before batching | After batching |
| --- | ---: | ---: |
| Start menu: 170 triangles | 85 GPU batches | 13 GPU batches |
| Select map: 695 triangles | 97 GPU batches | 26 GPU batches |

These counts come from the running PSP executable. Menu and map screenshots
are byte-identical between the two versions; repeated paused screenshots also
match exactly. The comparison measures GPU submission work, **not gameplay FPS**.
The reference here is the new unbatched native renderer; build 36 did not
render these menus. No claim of a frame-rate improvement over 36 is made.

The renderer batches consecutive primitives with unchanged state, keeps draw
order, resolves supported indexed textures from observed upload packets, and
uses bounded storage. Native clearing waits for the first supported 3D object,
so empty paused cameras cannot erase menus. Presentation follows the original
guest flip. A spare VRAM buffer restores the world background for paused frames.
The alpha-fail/framebuffer-only path preserves color writes with masked depth.
Guest DMA completion, guest camera calls and the guest flip still execute.

No PPSSPP alt-speed, Skip buffer effects, frame skipping, speed-setting files,
or physical overclock is needed. The port requests the normal PSP 333 MHz.

## Install

Back up your game folder. Copy the contents of test-build/ into that copy.
Retain disc/, SLUS_212.69, discmap.txt, iso_meta.bin, BULN.pmf, BULN.wav and
memcard/. The update contains EBOOT.PBP, the existing helper PRX/configuration,
licenses, instructions and checksums. Unchanged disc and movie data is omitted.
Use a fresh boot, with buffered rendering and normal speed for PPSSPP testing;
do not load an emulator save state from a different executable. Build 36 remains
available for rollback. The separate source ZIP contains the complete updated
overlay; the patch is cumulative against the imported original source.

## Validation

- Full PSP conversion, compile, link and EBOOT packaging with PSP GCC 15.2.0.
- Actual final executable fresh-booted at automatic PPSSPP clock settings;
  the runtime reports 333 MHz. Start and Select display, pause and resume.
- Paired rendering comparison used desktop PPSSPP 1.20.4, JIT/OpenGL 1x,
  buffered rendering, frameskip 0, sound configured; earlier diagnostic runs
  used virtual CPU2000/bus1000 for investigation, never a shipped setting.
- Portable ASan/UBSan tests: 50,000 bounded malformed/valid packet cases,
  19 synthetic ordered GIF/VIF/geometry/upload replays, and 15 actual DMA-helper
  boundary/chain/TTE/IRQ/SPR/VU/loop/stack cases. No original game assets needed.
- Captured-menu checks: 169 primitive callbacks/170 triangles, exact active
  texture, positions, UVs and colors; eight mapped texture conversions match
  previous raster-based bytes, plus 40 invalid-input rejection checks.
- Host compilation checks the shared original-preserving flip wrapper.
- Reproduce portable checks: `python3 tests/check_native_overlay.py` from the
  source folder with GCC available. PSP backend and final game tests remain
  separate checks; host sanitizers do not prove PSP hardware behavior.
- Earlier unchanged CPU/math/skin/texture/movie tests retain their source
  identities. Archive CRC/checksums, source/binary identities and patch application
  are checked separately after packaging.

## Remaining issues

**The 14 FPS goal is not met or verified.** No Android device or physical PSP
was available. No audible audio device is available in this sandbox. School-door
entry, the reported black-sky issue, complete gameplay/saves and all tutorial,
subtitle, combat-prompt and in-game HUD cases remain unresolved or unverified.
This is a bounded native renderer for supported packets, not complete PS2 GS/VU
emulation. Unsupported pixel modes/states/textures can still be omitted; the
opening scene alone does not prove all game areas work. Test your reported
problem locations and return session.log and a short recording.

EBOOT.PBP: 16,988,100 bytes (verify against archive SHA256SUMS).
SHA256: 49dfc8b1df3dc740407181c8a01758dab0c67461704c83e10fa85f18200b1ad8
