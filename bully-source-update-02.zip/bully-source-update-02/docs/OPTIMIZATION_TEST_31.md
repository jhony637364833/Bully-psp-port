# Bully PSP experimental test 31

**Android 14 FPS remains unverified.** Build 31 uses sequential raw vector
transfers for two adjacent loads and four adjacent stores in the geometry
function 0x0037eeb0. Each quad is aligned/masked separately, read, then written
before the next read. Aliases and guest address wrapping retain that order.
Build 30 is retained for rollback. The measured improvement is small.

## Install

Copy `test-build/` contents from the runtime ZIP into a backup of your complete
converted game folder. Included: EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, installation
instructions, checksums and licenses. Keep disc/, SLUS_212.69, discmap.txt,
iso_meta.bin, BULN.pmf, BULN.wav and memcard/. Fresh-boot; do not load another
build's save state. Unchanged game assets and movies are not duplicated.

EBOOT: 17,159,044 bytes. SHA256:
`e38c870b991cde670953e155145475f4a748fffa0b3fd429f73c3da9c06d5531`.

Optional PPSSPP fragments are unchanged from build 30. Read CONFIG-TEST-18.md
before applying them; its measurements concern historical build 17. Virtual
2000 MHz changes the guest instruction budget, not the phone's physical clock.
It exceeds PPSSPP 1.20.4's UI maximum of 1000. The EBOOT does not apply this INI;
compare identical settings. Restore Auto/0 if needed.

## Matched stationary-scene measurement

| Camera 120 to 360: 240 events | Build 30 | Build 31 |
| --- | ---: | ---: |
| First host seconds | 33.861669 | 33.780614 |
| Reverse-order repeat seconds | 33.864761 | 33.772674 |
| Mean seconds | 33.863215 | 33.776644 |
| Camera completions / host second | 7.0873 | 7.1055 |

**0.26% higher pooled camera throughput**, 480 measured events per build.
Run order: 30, 31, 31, 30. Mean saving: 86.57 ms;
maximum within-build spread or 20 ms polling floor: 20.00 ms.
Both pairs improved; mean saving exceeds four times that value.
All ten WORLD_COMPLETE summaries through camera 360 and all four scene PNGs
match exactly. Loaded executable instructions and virtual 2000 CPU/1000 bus
clocks were checked. No compiler, tests or other emulator ran in timed windows.
This is Linux desktop PPSSPP 1.20.4/JIT, OpenGL 1x, frameskip 0 and sound
configured on. These camera completions are not Android gameplay FPS.

## Changes and verification

- Two engine files change from build 30: runtime/r5900_rt.h adds rm_lq2/rm_sq4;
  the pack's existing normalizer-reuse.tsv applies six line replacements to
  the geometry function. Other memory operations and their ordering remain.
  Each vector helper preserves the physical C000 quad without arithmetic or
  prefix consumption. It runs only with the existing guest-thread VFPU flag;
  the scalar fallback executes the original individual transfers in order.
- All existing runtime helper bodies remain unchanged. Strict floating-point
  flags, register layouts, graphics states, GPU waits, audio, guest calls and
  scheduler checks are unchanged. Build 30's strip optimization is retained.
- Fresh host ASan/UBSan and actual PSP: 8000 complete geometry function
  comparisons plus 15463 direct-copy comparisons each. The direct cases include
  6231 wrapping transfers and 2722 cross-quad alias observations. Both feature
  flags, all four rounding modes, FTZ, initial exception/condition flags,
  complete CPU context/RAM, full PSP FCR31, all 128 VFPU registers and five
  prefix/condition/random controls match. The generator reproduces all eleven
  executed fixture inputs byte-for-byte; generated game bodies are not bundled.
- Full normal converter completed without warnings; 230 units rebuilt. All
  186 other prepared guest C units match build 30. main_070.c differs only by
  the six intended line replacements; every final unit matches its prepared
  source. Actual built helper bodies match the tested PSP header exactly.
- Native geometry function grows from 6720 to 6808 bytes; EBOOT grows 96 bytes.
  It retains build 28's approximately 0.63 MiB memory cost. No new heap allocation.
- Unaffected build 30 rendering tests (5120 strip cases on host and PSP,
  128 host command traces, 65 exact GPU image/depth-witness pairs), and earlier
  converter/runtime/config, saved-register, math, skinning and audio checks
  carry forward by source identity. They were not all rerun for build 31.
- Runtime/source ZIP CRCs, every packaged checksum, source/engine overlays,
  EBOOT/ELF identity, prior downloads/configuration and patch application are
  checked after packaging.

## Reproduce the preservation comparison

With PSPDEV on PATH, after conversion of your matching game disc:

~~~sh
python3 tests/prepare_quad_copy.py --build /path/to/build --output /tmp/bully-quad-copy
make -C /tmp/bully-quad-copy
~~~

Boot that separate diagnostic EBOOT. quad-copy.log must end with
`COMPLETE function=8000 direct=15463 wraps=6231 aliases=2722 errors=0`.
For the host check, run in the generated directory:

~~~sh
cc -O2 -std=gnu11 -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off -fno-strict-aliasing -fsanitize=address,undefined main.c leaves.c reference.c candidate.c -lm -o host-test
./host-test
~~~

## Remaining acceptance

Android >=14 FPS, full gameplay, walking controls, saves and audible quality
remain unverified. ALSA output is unavailable here, so sound enabled in the
configuration does not establish audible playback. This remains an incomplete
port. Device acceptance needs your phone model, PPSSPP version/settings,
session.log and a real-time recording of matching scenes.
