# Current repairs and limits

## Provenance

The GitHub repository at `1ae37e3d4fbb2d92f72ed7bb592b930c75b81db6` contained
only LICENSE. This working tree imports the user's latest source archive from
Google Drive, preserving the existing root license and the PS2RC licenses in
`app/`. `VALIDATION.md` is the supplied historical report, not a new benchmark.
The unmodified decoder is frozen in `tests/native_mesh_reference.c` for comparison.

## Changes

- Compressed static geometry validation no longer expands all vertices into
  scratch before the drawing pass expands them again. Packet bounds, opcodes,
  batch limits, seam equality, vertex totals and whole-object validation remain
  in place. Integer attributes cannot encode NaN/Inf. Skin and float validation
  are unchanged. The callback path produces identical vertex data; the existing
  contract allowed scratch to change during validation but did not require it.
- Routine audio RPC request/reply logs and per-sample diagnostic scans now run
  only with `verbose=1`. Driver servicing, PCM production, resampling and the
  output thread are unchanged. Fatal diagnostic paths remain. This reduces work
  on the game thread; it does not repair missing sound-driver imports.
- Stage defaults now use watchdog-buffered logging (`log_sync=2`) and a ten-hour
  session limit (`max_seconds=36000`). The supplied defaults flushed every log
  line and exited after 600 seconds. This intentionally extends that diagnostic
  session limit; it is not a fix for every crash. The stuck watchdog is retained.
  **Do not set max_seconds=0**: upstream PS2RC 0.1.1 treats zero as an immediate
  timeout, not an unlimited run.

## Existing-build configuration

Back up `ps2rc.cfg` beside EBOOT.PBP. For the supplied matching Bully build, merge
`log_sync=2` and `max_seconds=36000` into that file. Preserve other custom settings.
`config/ps2rc.cfg` is a complete example for the supplied flat movie layout.
These settings work without recompilation; source optimizations require a rebuild.
For diagnosis, temporarily use `verbose=1` and preserve the resulting session.log.

## Fresh checks in this task

With Ubuntu cc 15.2.0 and Python 3.14.4:

- `bash tests/run_compressed_validation.sh`: 10,000 cases matched the supplied
  decoder, including 3,930 accepted cases, truncation, mutations, two-batch seams,
  callback output, failure counters and untouched validation scratch; ASan/UBSan.
- `bash tests/run_native_light.sh`: 56 assertions passed; ASan/UBSan.
- `bash tests/run_audio_sync.sh`: passed; 1,500/1,500 audible synthetic hops with
  synchronization, versus 757 with gaps. This checks the existing synchronizer,
  not new gameplay audio behavior.
- `bash tests/run_clip_differential.sh`: 100,000 cases passed.
- `python3 tests/renderer_differential.py`: 1,000 cases, 13,159,192 identical bytes.
- Host syntax check of audio_probe.c against PS2RC commit
  `332a437f21f7ef694943caef885a7d28410cbc41` passed.

## Current backend and frame-boundary repair

The current pack uses the GTA-family v5s4y3 backend with strict floating-point
flags and -O2 helper inlining. Automatic non-ABI analysis runs as a declared
converter step. Every HLE hook is an exact boundary, because hooks can observe
RA/saved registers beyond ordinary ABI arguments. Four previously specialized
functions also remain exact. The old v0 native specializations are not selected:
they lack the context protection needed when calling ABI-mode functions.
The earlier source files remain for reference and v0 tests.

The first v5 build failed overlay loading because the loader's caller had not
synchronized RA/s18/s19. The corrected generated code passes a regression check
for both loader call sites, and overlay loading/intro playback pass in PPSSPP.
The current inlined EBOOT is 16,662,500 bytes, versus the previous 20,076,932-byte
build. Full 32 MB game RAM is retained. Exact-cache v1 was rejected because its
21.3 MB EBOOT failed memory admission.

The renderer now clears/presents at verified successful camera update boundaries,
not when virtual time advances during object drawing. See CAMERA_FRAMES.md.
All four material smoke-test phases passed while advancing virtual time between
objects and injecting mismatched/duplicate camera end calls. Hook tests preserve
original calls, return values and side effects.

## Measurement correction and remaining limits

The earlier reported 0.53 FPS counted buffer swaps triggered by virtual time.
Those swaps could present partial scenes and were not a validated count of
complete gameplay frames. That measurement must not be used as gameplay FPS.
The new WORLD_COMPLETE counter counts completed supported camera passes; multiple
cameras can occur in one gameplay frame, so camera identity is logged too.

Backend tests passed: 2 exact-cache control/memory tests, 1 VU test, and 45
ABI/exemption/optimization tests. Decoder/audio math sources are unchanged from
the earlier passing checks above. Final game checks measured 25 completed camera passes in 60.318 seconds
(0.414/s including a stall). After the camera transition, forward input visibly
made Jimmy run, but only 10 passes completed in 30.159 seconds (0.332/s).
PPSSPP maintained its target vblank rate. No claim of 14–20 FPS, playable
responsiveness, complete UI, audible gameplay, Android performance or long-term
stability is established.

## Exact PSP clipping optimization

The follow-up removes software double arithmetic from trivial clipping-plane
classification and bypasses planes containing every current polygon vertex.
Actual crossing intersections keep double precision. Signed zeros and subnormals
retain exact finite-value ordering. See PERFORMANCE.md for PSP benchmark results
and the remaining optimization priorities. Full-game acceptance is separate
from the isolated clipping throughput result.

## Shared-vertex follow-up

Visibility, screen projection and packed vertex submission data are now reused
within each three-vertex strip ring. The crossing-triangle path retains the
reference clipper. Stronger host output comparisons and the four-phase PSP
material diagnostic pass. A separate GE clipping prototype was rejected: it
remained far below playable speed and its image compatibility was unproven.
The long pause also samples expensive guest geometry/traversal routines. This
source remains an unplayable development build; a renderer benchmark does not
establish responsive gameplay.

The final shared-cache game check completed 19 camera passes in 21.097 seconds,
including the same extended pause after report 34. First-eight scene summaries
match exactly. A shorter active interval suggests only a small difference,
within the limitations of two-second polling and unequal instrumentation; no
reliable gameplay speedup or playable acceptance is established.
