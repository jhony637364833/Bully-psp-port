# Optimization test 03 — packed collision bounds

Target: at least 14 FPS in Android PPSSPP. That target remains unverified.

## Implementation

`app/runtime/r5900_rt.h` replaces the generic byte loop for R5900 PEXTLB
with unsigned 32-bit masks and shifts. All 128 output bits are preserved for
arbitrary source operands. Each pair of input halfwords produces one output
word; no pointer cache, geometry approximation or floating-point change is used.

`app/ps2rc/backend_c.py` emits the architectural 128-bit zero constant for
binary packed operations that read register zero. The original scalar backend
already treats this register as immutable and suppresses writes. Valid guest
contexts keep all stored zero-register bits zero. The compiler can now fold
successive byte-to-halfword-to-word expansions used in the collision function
at guest address `0037eeb0`. No collision tests, guest calls, scheduler boundaries,
register outputs or memory writes are removed.

The generated collision body differs from test02 only in its four constant-zero
operands. Its other instructions and call boundaries match the frozen original.
The change applies to the translator/runtime, so rebuild the entire EBOOT;
copying source files into an existing PSP game folder does not enable it.

## Validation

- Host sanitizer: 4,131,072 packed interleave/expansion comparisons, zero errors.
- Compiled code generation: 174,000 complete-context comparisons across all 29
  binary packed operations, including aliases and zero destinations, zero errors.
- Engine backend/runtime tests: 31 passed.
- Synthetic complete collision-body replay: 10,000 comparisons of full context,
  RAM, call order and call-boundary state, zero errors. Callees were deterministic
  test substitutes; this does not establish full-game collision acceptance.
- Existing test02 clip/renderer/light/audio checks remain valid for their
  unchanged sources. New full-game integration results are in TEST-RESULTS-03.md.

Reproduce host helper/code generation checks after applying the app overlay:

```sh
bash tests/run_mmi_unpack.sh
python tests/mmi_zero_codegen.py /path/to/PS2RC
```

Build the PSP instruction diagnostic using the same compiler as the game:

```sh
make -C tests/psp_mmi_unpack
```

The diagnostic's EBOOT is separate from the game EBOOT. Its packed-bounds
microbenchmark is not a measurement of gameplay FPS. Android gameplay, later
stalls, controls, saves and audible quality need testing on the user's device.

## Measured final build

EBOOT 16,655,828 bytes, SHA256
`d7786c00be473d027ea28a6a3dd9d1fa913b6c2b6d8b1acc041ef9236f5f5af5`.

Fresh desktop samples: test02 camera rate 1.9200 passes/host second;
test03 rate 2.1021 (+9.5%). The first 8 camera summaries match exactly and both
render the opening entrance scene. One short run per build, different nearby
windows and ordinary variation limit this comparison; it is not sustained
performance or Android gameplay FPS.

Isolated PPSSPP diagnostic: 231,072 comparisons, zero errors. 200,000 repeated
bound expansions 247,835→42,387 emulated PSP microseconds (about 5.8× faster),
identical checksums. This is an instruction microbenchmark. 14 FPS remains unverified.
