# Bully PSP test 36: saved floating-point register copies

Build 36 reduces the CPU work for preserving twelve guest floating-point
registers across function calls. It uses raw scalar VFPU loads/stores with
aligned quad transfers, retaining the context layout, every register bit,
physical scratch registers, VFPU prefixes/controls and FCR31. The existing
scalar fallback remains when the guest thread has not enabled the VFPU.
Build 35's quantized waits and build 33's Skip buffer effects movie fix remain.

**Android 14 FPS is unverified. School doors, black sky and usable Start/Select
menus remain unresolved.** Alt-speed removes emulator throttling; it is not a
native PSP optimization. No physical PSP speedup is claimed.

## Install

Back up the complete game folder. Copy test-build/ contents from the runtime
ZIP into that folder. Keep the original disc/, SLUS_212.69, discmap.txt,
iso_meta.bin, BULN.pmf, BULN.wav and memcard/. Fresh-boot the game; do not use a
save state from another executable. The ZIP contains EBOOT, PRX, configuration,
licenses, instructions and checksums. Unchanged disc/movie assets are omitted.
Build 35 remains available for rollback.

This runtime ZIP contains no PPSSPP speed/buffer setting overrides. The changes
are compiled into the PSP executable. Use identical normal settings for your
own comparison; no alt-speed toggle is required. The runtime starts at the
normal 333 MHz on PSP. Current engine memory layout targets PSP-2000 and PSP-3000, as requested; PSP-1000 and PSP Go are outside this test target. Hardware throughput
and gameplay still require testing on your device.

## Measurement

| 240 camera intervals, 120 to 360 | Build 35 seconds | Build 36 seconds |
| --- | ---: | ---: |
| First pair | 32.995728 | 32.704021 |
| Reverse-order repeat | 32.998594 | 32.693721 |
| Mean | 32.997161 | 32.698871 |

**0.91% higher desktop camera throughput** in the stationary opening
scene. This is not gameplay FPS or an Android result. Linux PPSSPP 1.20.4/JIT,
OpenGL 1x, buffered mode, frameskip 0, virtual CPU2000/bus1000, sound configured
on (physical output unavailable). Order 35/36/36/35, 480 measured intervals per
build. No compiler/test/second emulator ran during measurement. Loaded
executable instructions, clocks and VFPU flag were checked. All ten rendering
summaries and all four scene PNGs matched exactly. Both pairs improved and the
mean saving exceeded four times the largest within-build spread/20ms floor.

## Validation

- Full PSP conversion/build completed. All 187 prepared and final guest C
  files match 35; the runtime header is the sole engine source change.
- Host ASan/UBSan and PSP differential harness: 16,000 comparisons each, flag
  off/on, all four rounding modes, random complete contexts, guarded snapshots,
  explicit signed-zero/subnormal/infinity/NaN FPR payloads, all 128 physical
  VFPU registers, five VFPU controls and FCR31 preserved.
- Reproducible fixture: python3 tests/prepare_context_fpr.py --output /tmp/fpr
  followed by make -C /tmp/fpr with PSPDEV/bin on PATH. Run its EBOOT and inspect
  context-vfpu.log for COMPLETE comparisons=16000 errors=0.
- The portable fixture was compiled and run in PPSSPP with the actual candidate
  header before publication. Its independent reference uses original scalar
  copies. PSP assembly contains lv.s/sv.s with aligned lv.q/sv.q; no arithmetic.
- An unaligned transfer trial failed under a nondefault destination mask.
  Clearing/restoring that mask passed, but PPSSPP interprets these operations.
  That trial was discarded; it is absent from this EBOOT.
- Prior unchanged renderer/math/texture/movie fixtures are reused by source
  identity; this iteration's fresh game comparisons use buffered mode. Build
  35's Skip intro and paired Start/Select camera-resumption evidence is prior
  evidence, not a new 36 menu acceptance test.
- Android FPS, audible sound, physical PSP behavior, indoor transitions, black
  sky, visible menus, full gameplay and saves remain unverified/unresolved.

EBOOT: 16,975,460 bytes
SHA256: c419256a1bb98a1dd619a6075e5a5e519b14a58e5a64ccd78074b379ca8d8586
