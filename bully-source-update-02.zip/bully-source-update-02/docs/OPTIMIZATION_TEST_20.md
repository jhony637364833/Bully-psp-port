# Bully PSP experimental test 20

**Android 14 FPS remains unverified.** Build 20 reduces exact coordinate
conversion work in the hot geometry code. Graphics, audio and simulation work
remain. Build 19 is retained for comparison/rollback.

## Download and install

The runtime ZIP includes EBOOT.PBP, ps2rc_exc.prx, ps2rc.cfg, INSTALL.txt,
licenses and checksums. Copy test-build/ contents into a BACKUP of your complete
converted Bully folder. Keep disc/, SLUS_212.69, discmap.txt, iso_meta.bin,
BULN.pmf, BULN.wav and memcard/. Fresh-boot the executable; do not load an
emulator save state from a different build. Read INSTALL.txt.

EBOOT.PBP: 16,498,916 bytes. SHA256: `ec206c4c192f59868b3d3835a3bc9f32793976a73aadde1e90ec36ac2615b984`.

Optional ppsspp-settings/ contains the previously verified experimental
2000 MHz virtual-clock fragment and rollback fragments. Read CONFIG-TEST-18.md
before manually merging it. That historical report describes build 17; this
package's current executable/source/results are build 20. The virtual setting
exceeds PPSSPP 1.20.4's UI slider maximum. It changes the virtual PSP instruction
budget, not the phone physical clock. Do not increase it arbitrarily. Roll back
to Auto/0 if needed. Compare both builds at identical settings. EBOOT does not
automatically apply the setting.

The matching cumulative source overlay targets PS2RC 0.1.1 revision
332a437f21f7ef694943caef885a7d28410cbc41, PSP GCC 15.2.0 / SDK 20261001,
Bully SLUS-21269 v1.02 ELF SHA256
597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc.

## Exact optimization and original contract

The original vu0_itof1 performs signed-32 to binary32 conversion rounded toward
zero, independently of the hardware rounding mode, followed by a power-of-two
scale. It leaves guest VU MAC/status flags unchanged. That contract remains.

When the compiler proves that the input's top eight bits are zero and that
shift is zero, the value is a nonnegative 24-bit integer. EVERY such integer
is exactly representable in binary32 in every rounding mode. The helper can
therefore use the hardware conversion for that proven range without changing
any result. It uses compile-time proofs only: no runtime range branch is added.
Unknown ranges and nonzero shifts retain the original integer implementation.
The four-lane vu0_itof loop is written as four x/y/z/w statements in the same
order, with the same masks and destination-zero guard. This exposes each lane
to constant propagation inside large functions while preserving alias behavior.
In particular, arbitrary signed-32 inputs still use rounding toward zero.

The scalar byte wrapper shrinks from 48 to 28 bytes. The generic wrapper's 23
PSP instruction words remain identical. The extracted original geometry fixture
shrinks from 7,168 to 6,860 bytes; the full-game fn_0037eeb0 shrinks from
7,104 to 6,720 bytes. All 187 prepared game C units match build 19.
All 230 compilation units were rebuilt. The runtime header outside the added
specialization/comment and equivalent four-lane expansion is unchanged. Old v0 native replacements stay disabled.
No preserved register, guest-memory, layout, arithmetic precision or public
interface contract is relaxed.

## Matched opening-scene timing

| Counter 8 to 80 | Build 19 | Build 20 |
| --- | ---: | ---: |
| First run host seconds | 14.089724 | 13.831562 |
| Reverse-order repeat seconds | 14.111106 | 13.822751 |
| Mean seconds | 14.100415 | 13.827156 |
| Camera completions / host second | 5.1062 | 5.2071 |

**1.98% higher pooled camera throughput.** Each build completes 144
measured camera events. First eight scene summaries match exactly, including
9,809 draws. The later long gap remains.

Sequential order: 19, 20, 20, 19. Linux PPSSPP 1.20.4/JIT, Mesa 26.0.8 llvmpipe
LLVM 21.1.8, OpenGL 1x, normal 100% speed, frameskip 0, sound enabled with dummy
physical audio, virtual PSP CPU 2000 MHz/bus 1000. Same media/private config.
Live existing camera/frame counters polled every 10 ms using a monotonic host
clock; loaded ELF prologue checked allowing only PPSSPP's first-word JIT patch.
No compiler/tests/other emulator during measured windows.

Camera completions are not gameplay FPS. Desktop results do not verify Android
14 FPS, sustained motion, full gameplay/controls/saves or audible quality.

## Verification and corrected fixture

Fresh checks on EACH of host ASan/UBSan and PSP in PPSSPP:

- 67,108,864 exhaustive scalar cases: EVERY 24-bit integer under all four
  rounding modes. Each case checks both the 24-bit and byte wrappers.
- 4,000,000 general random input/shift comparisons.
- 40,000 full-context/64 KiB RAM comparisons of the ORIGINAL generated geometry
  prefix through both VITOF0 conversions. All scalar locals are also flushed
  at the test boundary, and raw GPR upper lanes, VU w lanes and flags are checked.
- 278,528 full-context VU instruction cases cover all 16 destination masks,
  all 32 destination registers, all 34 sources (VF0/VF1-31/I/Q), all four legal
  shifts, source/destination aliasing, ignored mask bits and unchanged flags.
- PSP uses all four hardware rounding modes with flush-to-zero. Zero errors
  with the corrected fixture on both platforms.
- Portable generator reproduces the six executed test inputs exactly.
- Full converter/build, prepared-code identity, two ordered game comparisons,
  archive CRC/every checksum, engine/source/binary identity and patch dry-run.

The first PSP prefix fixture failed. Investigation identified a random guest
pointer causing a four-byte read at 0xfffe in a 64 KiB test window; stack/global
pointers were also misaligned. This violated the pre-existing runtime memory
contract (naturally aligned LH/LW/LD and a valid host window), and the mismatch
was the two bytes read past the buffer. The invalid fixture/logs were retained.
The corrected fixture supplies aligned, disjoint stack/global/object/table
windows, random virtual mirror bits and arbitrary packed coordinate bytes.
All original comparisons remain; complete host/PSP checks were rerun. No
production correctness failure was waived.

An initial full-game candidate without explicit lane expansion showed no
throughput gain. Its executable still contained the general lane loop, hiding
the proven range from the compiler. It was not delivered. The final candidate
adds the equivalent lane expansion and repeats the full correctness checks.

Earlier renderer, clipping, math, alpha/depth/GPU, audio, converter and register
preservation results are reused for unchanged implementation inputs. Those
suites were not all rerun. The changed helper has the fresh checks above.

## Reproduce

From the source overlay root with app/ installed on the stated engine:

```sh
python3 tests/prepare_itof_range.py --output /tmp/bully-itof-test
make -C /tmp/bully-itof-test
```

Boot the separate test EBOOT. itof-test.log must end with
`COMPLETE scalars=67108864 vectors=40000 lanes=278528 errors=0`.
For host checks, in the generated directory:

```sh
cc -O2 -g -std=gnu11 -fsanitize=address,undefined -fno-omit-frame-pointer -fno-fast-math -fno-math-errno -frounding-math -ffp-contract=off main.c reference_test.c candidate_test.c -lm -o test
./test
```

For Android acceptance send phone model, PPSSPP version/settings, session.log
and a real-time FPS recording in the same scene with identical settings.
The requested >=14 FPS remains outstanding.
