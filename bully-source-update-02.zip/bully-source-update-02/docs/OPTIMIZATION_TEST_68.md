# Test build 68 — GPU transforms and queued submissions

## Result and limits

This build reduces native rendering work. In the same desktop PPSSPP setup (333 MHz PSP clock, JIT, OpenGL, buffered 1× rendering, frameskip 0), two 60-camera intervals improved over a fresh build-55 baseline:

| Camera interval | Build 55 | Build 68 | Throughput gain |
|---|---:|---:|---:|
| 120–180 | 15.764685 s | 14.501074 s | 8.71% |
| 180–240 | 16.101401 s | 14.863449 s | 8.33% |

These are camera-completion timings, **not gameplay FPS**. They do not establish Android or physical PSP performance. **The 14 gameplay FPS target remains unmet/unverified. The reported disappearing overlay/HUD remains unresolved.** No frameskip or clock-setting change produced this improvement.

## Implementation

Conservative padded bounds reject wholly offscreen strips or select the GPU for strips inside the renderer's existing safe screen-coordinate range. Eligible static and skinned strips use the GE model matrix, original lighting, triangle-skip flags, and the existing bounded vertex queue. Unsafe bounds, exceptional inputs, near/far crossings and enabled floating-point traps retain the CPU path. Model state returns to identity at object boundaries; buffers finish GPU reads before reuse. No new persistent allocation or cache was added.

The CPU helper block is byte-identical to build 55. Its original exact arithmetic tests remain applicable. The GPU path intentionally uses GE transform rounding and does not reproduce every CPU subpixel-degenerate rejection or intermediate floating-point status flag; it restores the private entry FCR. It therefore is not a bit-exact replacement for CPU arithmetic. Public math helpers retain their contracts. The wider GPU path was tested separately rather than relaxing CPU assertions.

## Verification

Fresh checks for the final build:

- 512 complete-renderer host cases with ASan/UBSan: ordered draws, vertices, textures, read lifetimes and command-list capacity. Only verified redundant identity MODEL commands are excluded from the semantic hash; their capacity still counts.
- 12,800 CPU fallback guard cases, all four rounding modes, with the original assertions.
- 65 PSP GPU cases against build 55: color and depth-witness captures exactly match; repeated renders and positive depth controls pass.
- Another 65 GPU cases with nonidentity object transforms, mixed static/skinned meshes and triangle skips: five differing color pixels across three cases, maximum channel difference 2, and one differing depth-witness pixel. Existing comparison thresholds are unchanged.
- Final game startup, both timed windows, Start/Select pause and resume passed. All four menu screenshots match build 55 exactly. The sampled gameplay image differs in 2.24% of RGB channels (mean absolute error 0.0368/255, maximum 80); it was visually inspected.

Reused checks with explicit equivalence:

- 80,000 conservative-bounds cases on host and PSP, including screen-edge crossings, exceptional values, transforms and four rounding modes. The public generator reproduces the executed C fixture byte for byte; the predicate is unchanged.
- 2,560 exact adjacent-vertex/FCR cases on host and PSP. The generated fixture and CPU source block match build 55 byte for byte. Strip-rotation, classified-clip and memo fixture C sources also match their prior versions.
- The preceding prototype's four-direction movement run covered 480 camera completions without fatal errors; scene captures were inspected. The final refactor preserves its GPU algorithm and produces byte-identical GPU fixture pixels. Missing HUD behavior also occurred in baseline 55 and is not claimed fixed.

No physical PSP or Android device was available. Audible host audio and normal device saves remain unverified. Earlier build-51 save repairs and build-54/55 optimizations remain included.

## Reproduce asset-free checks

Run from the source repository with PSP SDK headers and host GCC available:

```sh
python3 tests/check_world_submission.py --output /tmp/bully-submission
python3 tests/check_gpu_guard.py --output /tmp/bully-cpu-guard
python3 tests/prepare_gpu_bounds.py /tmp/bully-bounds
make -C /tmp/bully-bounds
python3 tests/prepare_gpu_transform.py /tmp/bully-gpu
make -C /tmp/bully-gpu/gpu-reference
make -C /tmp/bully-gpu/gpu-candidate
python3 tests/prepare_gpu_transform.py /tmp/bully-gpu-extended --extended
make -C /tmp/bully-gpu-extended/gpu-reference
make -C /tmp/bully-gpu-extended/gpu-candidate
```

Run each generated EBOOT in PPSSPP or on PSP. The bounds fixture writes `bounds.log`; GPU fixtures write `submission.log` and `pixels.bin`. Keep these outputs beside their respective EBOOT files, then run:

```sh
python3 tests/compare_gpu_guard.py /tmp/bully-gpu
python3 tests/compare_gpu_guard.py /tmp/bully-gpu-extended
```

CPU helper fixture generators now stop before GPU dispatch; their assertions are unchanged. Full GPU tests above cover the accelerated path. This source package includes the frozen build-55 reference.

The runtime archive contains no game assets, memory-card contents, or diagnostic captures. Install using INSTALL.txt and retain your existing game files. Build-55 downloads are preserved for comparison.
