# Imported lighting experiment

The user supplied the lighting optimization in
https://drive.google.com/file/d/12vWkSh9H0k6s23BZ7BLiTxgW6dZquVoc/view.
Its prerequisite source106 archive was retrieved from the link in its RESULTS.md;
the archive and three baseline source hashes matched its baseline.json.

The imported native_light.c computes shared monochrome interpolation once per
vertex and selects color mode outside the per-channel loop. Gain, saturation,
material order, alpha and signed-zero behavior are retained. Host and native
checks are listed in INVESTIGATION.md. Original host measurements are retained
in LIGHTING_PRIOR_RESULTS.md as historical context, not game FPS evidence.

Run `bash tests/run_light_clamp.sh` for the exact lighting comparison and
`bash tests/run_light_benchmark.sh` for the host microbenchmark. Native comparison
build: `make -C tests/psp_light_clamp` with PSPDEV/bin on PATH.

The standalone installer mentioned in the original overlay README is not needed
here: this repository already contains the integrated source.
