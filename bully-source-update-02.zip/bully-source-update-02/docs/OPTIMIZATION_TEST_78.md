# Bully PSP test build 78

## Result

Texture-cache source validation compares four aligned words per iteration. It still compares every byte exactly; unaligned buffers and short tails use the existing library comparison. No new allocation, conversion changes or settings changes.

Fresh desktop PPSSPP comparison measured **1.70–1.79% higher camera throughput over build 77**. This is not gameplay FPS or physical-device evidence. **14 gameplay FPS remains unmet; the reported disappearing overlay remains unresolved.**

|60-camera interval|Fresh build 77|Build 78|
|---|---:|---:|
|120–180|12.960899 s|12.733372 s|
|180–240|13.305830 s|13.083570 s|

Both runs used 333 MHz, JIT, OpenGL, buffered 1× rendering and frameskip 0. No concurrent heavy work ran during the timing intervals. Five gameplay/menu PNGs match byte for byte; Start and Select pause/resume passed.

## Validation

- Host ASan/UBSan and PSP: 3,072 copied-cache plus 3,072 borrowed-view differential cases on each platform. Exact reference results with source/palette/mip/header mutations, malformed metadata, capacities, aliases and eviction.
- Host ASan/UBSan: 394,241 equality cases covering every pair of offsets 0–15, lengths 0–512, mismatches, and buffers ending at inaccessible guard pages. No overread observed. Public test runner also passed.
- Existing public cache generators reproduce the executed test sources byte for byte.
- Only `native_texture.c` changes in the runtime. Cache allocation, metadata checks, eviction, conversion, renderer submission and borrowed-buffer lifetimes remain unchanged. Their existing build 73/77 validation is reused; lifetime and renderer suites were not rerun.

## Reproduce

From the source root:

```sh
python3 tests/check_texture_compare.py
python3 tests/prepare_native_texture_cache.py /tmp/bully-texture-cache
make -C /tmp/bully-texture-cache/copied
make -C /tmp/bully-texture-cache/view
```

The comparison check uses a host C compiler with ASan/UBSan and POSIX guard pages. PSP fixtures require the PSP SDK; run their EBOOTs on PSP/PPSSPP. Host cache compilation instructions remain in the build 73 report.

Physical PSP/Android FPS, audible audio and normal device saves remain unverified. Previous build 77 downloads remain available. Back up your memory card before testing.
