# Supplied source106 README (historical)

This is historical context; see INVESTIGATION.md for fresh results.

# Test build 106 — original startup screen

Original Bully title/copyright UI can render before the first world camera. The overlay arena now holds its 512×512 indexed texture. See [checks and limits](OPTIMIZATION_TEST_106.md). Outdoor minimap/text disappearance and 14 gameplay FPS remain unresolved.

# Test build 101 — direct compressed mesh inputs

Validated compressed strips can reach the existing GPU renderer without expanding temporary vertices. The original decoder and CPU fallback remain. See [measurements and checks](OPTIMIZATION_TEST_101.md). The disappearing overlay and 14 gameplay FPS target remain unresolved.

# Test build 92 — Zero-blend GPU lighting reuse

Skip zero-blend interpolation and reuse adjacent packed lighting using only consumed color inputs. No new allocation. See [measurements and checks](OPTIMIZATION_TEST_92.md). The 14 FPS target remains unmet/unverified.

# Test build 81 — GPU input validation optimization

Use the existing vertex alignment for integer loads and exact exponent checks for UV validity. No new allocation. See [measurements and checks](OPTIMIZATION_TEST_81.md). The 14 FPS target remains unmet/unverified.

# Test build 78 — Exact texture source comparison

Compare aligned texture source snapshots four words at a time, preserving exact equality and unaligned fallbacks. See [measurements and checks](OPTIMIZATION_TEST_78.md). The 14 FPS target remains unmet/unverified.

# Test build 77 — VIF command dispatch

A 128-byte lookup table selects existing VIF command handlers. Parsing, counters and callback behavior are preserved. See [measurements and checks](OPTIMIZATION_TEST_77.md). The 14 FPS target remains unmet/unverified.

# Test build 76 — GPU bounds scan optimization

Keep coordinate bounds in registers and check finite coordinates using exact exponent bits. No new allocation. See [measurements and checks](OPTIMIZATION_TEST_76.md). The 14 FPS target remains unmet/unverified.

# Test build 73 — bounded texture cache and direct GPU reads

An optional 1.5 MiB cache avoids repeated texture conversion and lets the GPU read cached pixels directly. Inputs are revalidated and compared byte for byte; allocation failure uses normal conversion. See [measurements and checks](OPTIMIZATION_TEST_73.md). The 14 FPS target remains unmet/unverified.

# Test build 70 — GPU lighting-result reuse

Reuse packed lighting results for adjacent vertices with identical color banks in the GPU path. No new allocation or per-vertex FCR bookkeeping. See [measurements and checks](OPTIMIZATION_TEST_70.md). The 14 FPS target remains unmet/unverified.

# Test build 68 — GPU transforms and queued submissions

Eligible strips use GPU transforms, conservative bounds rejection, and the existing vertex queue. CPU fallback remains available; GPU rounding differs slightly. See [measurements and checks](OPTIMIZATION_TEST_68.md). The 14 FPS target remains unmet/unverified.

# Test build 55 — adjacent vertex reuse

Reuse of identical adjacent vertices reduces transform, lighting and clipping-classification work without extra allocation. See [measurements and checks](OPTIMIZATION_TEST_55.md). The 14 FPS target remains unmet/unverified.

# Test build 54 — faster compressed vertex loads

Native halfword loads reduce vertex-decoding work with exact output and an unaligned-input fallback. See [measurements and checks](OPTIMIZATION_TEST_54.md). The 14 FPS target remains unmet/unverified.

# Test build 51 — checkpoint restore repair

The controlled checkpoint now loads into gameplay after a cold launch. Normal device saves and 14 FPS remain unverified. Back up your saves. See [results and limits](OPTIMIZATION_TEST_51.md).

# Test build 50 — save handling repairs

Experimental: first-save folder and PSP icon filename fixes. Full gameplay restoration remains unresolved; 14 FPS remains unmet. Back up your saves before testing. See [results and limitations](OPTIMIZATION_TEST_50.md).

# Test build 49

Targets PSP-2000/3000 and Android PPSSPP. See [results](OPTIMIZATION_TEST_49.md) for the measured vertex-processing improvement. 14 FPS, complete sky/combat overlays and school entry remain unmet/unverified.

# Test build 48

Targets: PSP-2000, PSP-3000 and Android PPSSPP only.
[Restore original collision bounds rejection](OPTIMIZATION_TEST_48.md).
About 2.6x higher desktop camera throughput in the recorded comparison.
This is not a gameplay FPS measurement; 14 FPS remains unmet/unverified.
Complete sky/combat overlays and school entry still require work.

# Test build 46

Targets: PSP-2000, PSP-3000 and Android PPSSPP only.
[Preserve gameplay HUD before the next world clear](OPTIMIZATION_TEST_46.md).
Movement tutorial, welcome title and minimap now visible in the captured starting scene.
No new gameplay FPS gain established. 14 FPS, combat prompts and complete sky remain unverified.

# Test build 43

Targets: PSP-2000, PSP-3000 and Android PPSSPP only.
[Sky blending and original gradient](OPTIMIZATION_TEST_43.md) with original additive/depth state. Build 42 performance optimizations retained; indexed experiment rejected.
No new FPS gain established. 14 FPS and complete tutorial/combat HUD remain unmet.

# Test build 42

Targets: PSP-2000, PSP-3000 and Android PPSSPP only.
[Native GPU screen-edge clipping](OPTIMIZATION_TEST_42.md) reduces CPU work
with a conservative software fallback. Small GE edge/color rounding differences
are intentional. No emulator speed/buffer overrides. 14 FPS remains unverified.

# Test build 40

Targets: PSP-2000, PSP-3000 and Android PPSSPP only.
[Reuse verified vertex classifications](OPTIMIZATION_TEST_40.md) removes
repeated clipping checks with exact geometry/FPU behavior and no extra RAM.
No emulator speed/buffer overrides. 14 FPS and full gameplay remain unverified.

# Test build 39

Targets: PSP-2000, PSP-3000 and Android PPSSPP only.
[Exact clipping reuse](OPTIMIZATION_TEST_39.md) adds an optional 640 KiB cache
with preserved HUD memory reserve, exact vertices/FPU state and normal fallback.
No emulator speed/buffer overrides. 14 FPS and full gameplay remain unverified.

# Test build 38

Targets: PSP-2000, PSP-3000 and Android PPSSPP only.
[Native GPU submission optimization](OPTIMIZATION_TEST_38.md): projection,
material setup and first draw share a command list; exact color/depth tests pass.
No emulator speed/buffer overrides. 14 FPS and full device/gameplay coverage
remain unverified or unresolved.

# Test build 37

Target: PSP-2000, PSP-3000, and Android PPSSPP.
[Native menus and GPU batching](OPTIMIZATION_TEST_37.md): Start menu and
Select map restored in desktop testing; their GPU batches reduced 85 to 13 and
97 to 26 respectively, with matching pixels. No emulator speed/buffer overrides.
14 FPS, physical PSP/Android behavior, school doors, sky and complete HUD/gameplay
remain unverified or unresolved.

# Test build 36

Target: PSP-2000, PSP-3000, and Android PPSSPP.
The native optimization does not require emulator speed/buffer overrides.

Latest: [raw saved-FPR copies](OPTIMIZATION_TEST_36.md).
Matched desktop camera throughput increased 0.91% over 35.
Android 14 FPS and reported gameplay bugs remain unverified/unresolved.

# Test build 35

Latest: [skip empty counter polling](OPTIMIZATION_TEST_35.md).
Matched desktop camera throughput increased 2.32% over 33.
Android 14 FPS and the reported gameplay bugs remain unverified/unresolved.

# Test build 33

Latest: [movie display with Skip buffer effects](OPTIMIZATION_TEST_33.md).
Android14FPS and reported gameplay bugs remain unverified/unresolved.

# Optimization test 31

Latest: [sequential geometry quad transfers](OPTIMIZATION_TEST_31.md).
Matched Linux steady-scene camera throughput increased 0.26% over build 30.
Android 14 FPS remains unverified.

# Optimization test 30

Latest: [triangle strip pointer rotation](OPTIMIZATION_TEST_30.md).
Matched Linux steady-scene camera throughput increased 1.14% over build 28.
Android 14 FPS remains unverified.

# Optimization test 28

Latest: [raw saved-register vector copies](OPTIMIZATION_TEST_28.md).
Matched Linux steady-scene camera throughput increased 1.79% over build 26.
Android 14 FPS remains unverified.

# Optimization test 26

Latest: [classify finite vertex values](OPTIMIZATION_TEST_26.md).
Matched Linux steady-scene camera throughput increased 0.65% over build 25.
Android 14 FPS remains unverified.

# Optimization test 25

Latest: [reuse validated skin batches](OPTIMIZATION_TEST_25.md).
Matched Linux steady-scene camera throughput increased 1.39% over build 24.
Android 14 FPS remains unverified.

# Optimization test 24

Latest: [reduce clipping coordinate branches](OPTIMIZATION_TEST_24.md).
Matched Linux steady-scene camera throughput increased 0.43% over build 23.
Android 14 FPS remains unverified.

# Optimization test 23

Latest: [reuse validated bone matrices](OPTIMIZATION_TEST_23.md).
Matched Linux steady-scene camera throughput increased 1.42% over22.
Android14FPS remains unverified.

# Optimization test 22

Latest: [keep exact reciprocal square root in FPR](OPTIMIZATION_TEST_22.md).
Matched Linux camera throughput increased 0.53% over21 at virtual2000MHz.
Android14FPS remains unverified.

# Optimization test 21

Latest: [reuse exact normalizer coordinates](OPTIMIZATION_TEST_21.md).
Matched Linux camera throughput increased 1.32% over build 20 at virtual
2000 MHz. Android 14 FPS remains unverified.

# Optimization test 20

Latest work: [exact conversion of known coordinate ranges](OPTIMIZATION_TEST_20.md).
Matched Linux camera throughput increased 1.98% over build 19 at the same
virtual 2000 MHz setting. Android 14 FPS remains unverified.

# Optimization test 19

Latest work: [exact unity reciprocal square root](OPTIMIZATION_TEST_19.md).
Matched Linux camera throughput increased 1.14% over build 17 at the same
virtual 2000 MHz setting. Android 14 FPS remains unverified.

# Optimization test 17

Latest work: [aligned copies of required preserved CPU state](OPTIMIZATION_TEST_17.md).
Matched Linux camera throughput increased 1.82% over build 16 at virtual
1000 MHz. Android 14 FPS remains unverified.

# Optimization test 16

Latest work: [eight further geometry preservation removals](OPTIMIZATION_TEST_16.md).
The matched Linux camera interval improved 12.65% over build 15 at virtual
1000 MHz. Android 14 FPS remains unverified.

# Optimization test 15

Latest work: [remove proven redundant geometry register copies](OPTIMIZATION_TEST_15.md).
A matching Linux camera interval completed in 32.60 s versus 44.06 s for build 11
(35.16% higher camera throughput at virtual 1000 MHz). Android 14 FPS is unverified.

# Earlier optimization test 06

Latest work: [proven alpha-failure batching](OPTIMIZATION_TEST_06.md).
Batches that cannot pass their alpha test use one ordered color-only draw.
Mixed batches keep their original adjacent pass/fail draws. See TEST-RESULTS-06.md
in the runtime update for checks on the exact EBOOT and measured results.
Android 14 FPS remains unverified.

# Previous iteration: optimization test 05

Latest work: [exact lighting clamp specialization](OPTIMIZATION_TEST_05.md).
Fixed-upper light clamps avoid general libc classification calls while preserving
RGB/alpha output bits. See TEST-RESULTS-05.md in the runtime update for measurements.
Android 14 FPS remains unverified.

# Previous iteration: optimization test 04

Latest work: [exact shared-edge clipping cache](OPTIMIZATION_TEST_04.md).
The renderer reuses bit-identical intersections across adjacent strip triangles.
See TEST-RESULTS-04.md in the runtime update for measured results. The requested
Android 14 FPS still needs independent device measurement.

# Previous iteration: optimization test 03

Latest work: [packed collision bounds](OPTIMIZATION_TEST_03.md).
The rebuilt EBOOT accelerates exact packed-byte expansion and exposes the
architectural zero register to the compiler. See TEST-RESULTS-03.md in the
runtime update for measured results. Android 14 FPS remains unverified.

# Previous iteration: optimization test 02

Latest work: [bounded integer clipping interpolation](OPTIMIZATION_TEST_02.md).
The opening-scene camera rate increased 26.3% in one desktop PPSSPP sample.
This is not Android FPS; the 14 FPS target remains unmet. See the delivered test report.

# Bully PSP optimization test update

Latest changes and fresh test results: [OPTIMIZATION_TEST.md](OPTIMIZATION_TEST.md).
This update removes repeated clipping and clipped-vertex preparation work and adds
camera timing reports. The requested 14 FPS is not yet verified on Android.

## Supplied source snapshot (historical notes below)

# Current repair work — 2026-10-25

Imported the user's `Bully-render-state-source.zip` from the Drive folder's
`My latest build/Bully-render-state-update (1).zip`. The original GitHub
checkout contained only LICENSE. Source licenses and notices are retained.
The imported `VALIDATION.md` and historical documentation describe earlier
work, not checks performed in this task. See `docs/CURRENT_REPAIRS.md`.

# Bully PSP rendering repair

Based on PS2RC by SandstoneDev
https://github.com/SandstoneDev/PS2RC
Community: https://discord.gg/wV8x46ZTDu

Experimental support for **Bully NTSC-U SLUS-21269 v1.02** and **PS2RC Converter 0.1.1**.
This repository imports the user's graphics pack v4 and adds compressed-mesh lighting, perspective-correct textures and captured material render states.
It is not a complete gameplay port.

## Changes

- Preserve both packed prelight color banks in compressed static meshes.
- Capture the original material bridge's blend, ambient light, surface ambient,
  material tint and monochrome state before the guest consumes those values.
- Blend the banks and apply the original shader's saturation order before clipping.
- Match captured state to both the mesh stream and material, and reset it per object.
- Use GPU projection with W=depth to correct affine texture warping.
- Reuse camera transforms and lighting across shared strip vertices.
- Skip full polygon clipping for triangles fully inside or outside one clip plane.
- Buffer PSP audio on a dedicated feeder thread, with bounded pitch-preserving synchronization.
- Restore captured alpha tests, blending and depth writes for supported compressed materials.
- Restore compressed vertex/material alpha and interpolate it through clipping.
- Avoid redundant alpha-fail draws for provably passing batches or depth-masked materials.
- Keep texture-cache registers local between synchronized guest/scheduler boundaries.
- Use the GTA-family v5 backend with analyzed exact boundaries and strict floating-point rules.
- Present completed camera passes instead of splitting scenes at virtual-clock ticks.
- Allocate existing renderer mesh and texture scratch after the intro to preserve startup memory.
- Keep original guest execution, mesh validation and bounded GPU batches.

`lit_meshes` in WORLD log lines counts meshes using the captured lighting path.
A zero count means the new path has not been verified in that scene.

The float/skin paths retain their existing lighting. Unsupported pipelines,
unsupported blend modes and UI remain limitations. No global brightness
boost or fabricated geometry is applied. The source files in `app/` retain their
PS2RC license; the root license does not relicense those files.

## Test and build

Run the focused decoder/lighting checks with a C compiler supporting ASan/UBSan:

```sh
bash tests/run_native_light.sh
bash tests/run_audio_sync.sh
bash tests/run_clip_differential.sh
python3 tests/renderer_differential.py
```

Use a separate PS2RC checkout at `332a437f21f7ef694943caef885a7d28410cbc41`
(version 0.1.1), then merge this repository's `app/` contents into that checkout.
Use Python 3.11+, pyelftools, Pillow, and PSP GCC 15.2.0 with PSPSDK.
Build from your matching disc using the converter's normal workflow. For the CLI:

```sh
python -m ps2rc.convert /path/to/Bully.iso --pack SLUS-21269_v1.02 \
  --out /path/to/output --work /path/to/work --movies convert \
  --toolchain /path/to/pspdev --no-splash --jobs 6
```

The test build omits the optional startup splash to leave more memory available;
credits and notices remain in the package. Keep full 32 MB EE RAM and select
PSP-2000/3000 in PPSSPP. Movie conversion requires the converter's media tools.
If reusing the supplied intro files, put BULN.pmf and BULN.wav beside EBOOT.PBP,
set `movies=1`, `audio=1`, `movie_dir=./`, and `movie_mem=hole` in ps2rc.cfg.
`--movies skip` alone disables playback and this pack treats that as a boot error.

See `docs/LIGHTING.md` for the source of the lighting behavior.
The statements in `docs/V4_INSTALL_REFERENCE.md` describe the supplied v4 pack's
historical checks, not fresh verification of this repair.

A PSP GPU smoke test uses the actual world renderer with a synthetic depth-slanted
textured quad. Build it with `make -C tests/psp_projection_smoke` after adding
pspdev/bin to PATH. Its EBOOT is a diagnostic gradient, not the game. At the
screen center, the red channel is approximately 48 (perspective), versus about
127 with affine interpolation. It needs no game assets.

See `docs/AUDIO_OUTPUT.md` for audio timing, memory limits and verification.

See [material-state repair](MATERIAL_STATES.md) for supported states and verification.


## Build 08: screen clamp optimization

See [Build 08 measurements and limits](OPTIMIZATION_08.md). Android 14 FPS
remains unverified. The positive-coordinate clamp preserves the original float
results, including the fallback for zero, negative and nonfinite inputs.

```sh
python3 tests/check_screen_clamp.py
python3 tests/check_screen_clamp.py --psp-dir /tmp/bully-clamp-test
# With pspdev/bin on PATH:
make -C /tmp/bully-clamp-test
```

Launch the generated diagnostic EBOOT separately; clamp-test.log must end with
`COMPLETE errors=0`. It uses synthetic inputs and needs no game data.

## Experimental Build 11: converted texture alpha bounds

See [results, limits and installation](OPTIMIZATION_TEST_11.md). Submitted
draws are reduced with matching GPU output; desktop scene throughput stayed
flat and Android 14 FPS remains unverified. Build 08 is retained for rollback.

```sh
python3 tests/check_texture_alpha.py
python3 tests/check_alpha_batch.py
python3 tests/check_alpha_fail.py
python3 tests/prepare_texture_alpha_gpu.py /tmp/bully-texture-alpha-gpu
# With pspdev/bin on PATH:
make -C /tmp/bully-texture-alpha-gpu/reference
make -C /tmp/bully-texture-alpha-gpu/candidate
```

Run those two diagnostic EBOOTs separately, require a `COMPLETE` summary with `errors=0` in
submission.log, and compare their pixels.bin
files byte-for-byte. They are asset-free tests, separate from the game.
