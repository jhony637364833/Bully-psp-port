# Test build 106 — original startup screen

## Changed

- Restore the game's original title/copyright screen before the first 3D camera. The previous compositor refused this early UI.
- Increase the shared overlay arena from 192 to 264 KiB. The observed 512×512 indexed texture needs **263,168 bytes**, including its palette, and exceeded the old arena.
- Preserve movie GU ownership, camera-in-progress refusal, original world/HUD presentation and the one-MiB memory reserve. Allocation failures retain the existing fallback.
- Retain build 101's direct compressed mesh inputs and earlier repairs. No diagnostic counters or tables are included.

This intentionally extends the old restriction that overlays require an existing 3D background. It does not override the game's fades or prove every later loading screen is supported.

## Verified

- A clean linked build displays the original title/copyright screen at guest frame 56. The diagnostic boot also recorded zero overlay texture misses and early-background refusals.
- Actual composition functions passed host ASan/UBSan checks: startup UI, repeated clean backgrounds, movie ownership, early/late HUD, menus and empty/nested cameras.
- Actual PSP GE composition/sky/depth tests passed.
- The actual overlay allocator passed low-total-memory, fragmentation, allocation failure, null block and successful-allocation checks. The full 512×512 texture converts within the new arena; a 192 KiB destination is rejected without writes. Cache reuse, malformed inputs and bounds checks passed ASan/UBSan.
- Actual optional clip-cache allocator passed seven allocation/boundary cases and retained the one-MiB-plus-overlay reserve.
- The game reached 240 camera completions. Start and Select pause/resume passed. First eight camera summaries exactly match build 101.
- Five game/menu images match build 101 outside the two X11 cursor locations. Each image differs by exactly 220 cursor pixels; this is **not** full-image byte equality.
- Build 101's 8,192-case host/PSP raw-GPU comparisons and decoder/overlap checks are reused: their production functions are unchanged.

The first clean test caught a build dependency omission: the unchanged overlay source also needed recompiling against the larger shared header. Both consumers were rebuilt, and the final boot/game/menu checks passed. An unused-variable error in the new host fixture was also corrected before its successful run.

## Still unresolved

- Outdoor minimap/text disappearance remains reproducible. In eight cameras after the disappearance, the captured GIF paths contain sky/depth-clear draws and no HUD texture draws; neither GIF path reports unsupported encodings. This narrows the investigation and does not establish a fix.
- **14 gameplay FPS is not achieved or verified.** User-reported performance remains 4–5 FPS outdoors and 7–9 FPS indoors. This build makes no additional performance-gain claim.
- The retained build 101 optimization improved controlled desktop camera throughput by about 6.3–6.5% over build 92. Camera throughput is not physical-device gameplay FPS.
- Physical PSP/Android validation, all areas, combat HUD, school entry and every loading screen remain outstanding.

## Test environment and delivery

PSP GCC 15.2.0, host GCC 15.2.0, PPSSPP 1.20.4, 333 MHz JIT, buffered OpenGL 1×, frameskip 0. No emulator speed/buffer overrides were added. Test captures are saved emulator output, not a live browser game.

Install the complete test ZIP together with the original game assets and existing layout. Keep a backup of saves. The ZIP includes SHA256SUMS.txt; original configuration and exception PRX are preserved. Source ZIP and cumulative patch accompany the test build. The repository still contains the imported untracked source tree; no commit or push was performed.
