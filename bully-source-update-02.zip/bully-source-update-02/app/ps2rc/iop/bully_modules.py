"""Converter generator for the two verified SLUS-21269 v1.02 IOP modules."""
import hashlib
from pathlib import Path
from .irx import load
from .gen_c import generate as generate_c

MODULES = {
    'soundlib': ('87a969e317d72199f2a459bf586a772c9a83d66febe0dcd6db2cc4d95d5981a1',
                 0x1000, 'soundlib_irx'),
    'soundrpc': ('697a02999c031213464f82311e74ce3ace479e2d96011ac0dbd006c70cbb7fd3',
                 0x20000, 'soundrpc_irx'),
}

def generate(input_path, out_path, log=print, module=None):
    """Use the converter's Python generator interface; no private C in the pack."""
    if module not in MODULES:
        raise ValueError('unknown Bully IOP module')
    expected, base, symbol = MODULES[module]
    data = Path(input_path).read_bytes()
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError('requires the matching Bully NTSC-U v1.02 IOP module')
    text, analysis = generate_c(load(data, base), symbol)
    if analysis.errors():
        raise ValueError('IOP translation errors')
    Path(out_path).write_text(text, encoding='utf-8', newline='\n')
    log('Bully: generated %s at load address 0x%x' % (module, base))
