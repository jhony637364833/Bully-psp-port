"""Generate selected exact Bully bodies for the runtime's normal -O2 compilation.

Like the GTA SA pack's native fast-path selection, this keeps the rest of the
translation compact. No game code is embedded here: require the user's exact ELF.
Calls, floating-point operations and scheduler checkpoints remain unchanged.
"""
import hashlib
from pathlib import Path
from ps2rc.image import load_elf
from ps2rc.analysis.functions import discover_functions
from ps2rc.backend_c import translate_function
from ps2rc.pipeline.prepare_gen import instrument_backedges

ELF_SHA256 = "597d7816d922cf371d757e653368488c1983f95dcdea0dd70a733650727f52fc"
# Loops observed in the supplied scene profile; none is in the MMIO trap set.
HOT = (0x0037EDB0, 0x0037EEB0)


def generate(input_path, out_path, log=print):
    if hashlib.sha256(Path(input_path).read_bytes()).hexdigest() != ELF_SHA256:
        raise ValueError("requires Bully NTSC-U SLUS-21269 v1.02")
    img = load_elf(input_path).stripped()
    funcs = discover_functions(img, [(0x00100000, 0x0053EC00),
                                     (0x005CA700, 0x005D29B0)],
                               extra_seeds=[img.entry]).functions
    bodies = ['/* Generated locally from the matching disc. */', '#include "main.h"']
    for address in HOT:
        fn = funcs[address]
        jumps = {jr: targets for jr, _table, targets in fn.jump_tables}
        text = translate_function(img, address, fn.addrs, jumps, set(funcs))
        text, edges = instrument_backedges(text)
        text = text.replace("void fn_%08x(" % address, "void y_nat_%08x(" % address, 1)
        bodies.append(text)
        log("Bully hot body %08x: exact v0, %d scheduler checkpoints" % (address, edges))
    Path(out_path).write_text("\n\n".join(bodies) + "\n", encoding="utf-8")
