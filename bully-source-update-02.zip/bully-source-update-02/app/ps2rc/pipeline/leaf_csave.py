"""Conservative removal of redundant preservation around selected generated calls.

Only generated leaf bodies with no access to preserved context registers qualify.
Unknown context uses, helpers, aliases, calls, or duplicate definitions retain the
original save/restore. This is intentionally narrower than a C clobber analysis.
"""
from pathlib import Path
import re
from collections import Counter

DEF = re.compile(r'^void (fn_[0-9a-f]{8})\(R5900Ctx \*c\)\n\{\n(.*?)^\}', re.M | re.S)
CALL = re.compile(r'\{ R5900CSave cs_; rt_cs_save\(c, &cs_\); (fn_[0-9a-f]{8})\(c\); rt_cs_restore\(c, &cs_\); \}')
REG = r'(?:[0-9]|[12][0-9]|3[01])'
LANE = r'[0-3]'
# Reviewed value-only arithmetic/MMI helpers and plain guest-memory accesses.
# Trapping memory, scheduler, dispatch, and unrecognized calls are excluded.
PURE_CALLS = frozenset(('F5', 'SX32', 'f2u', 'f_in5', 'fpu_rsqrt5', 'fpu_sqrt_c', 'fpu_cvt_s', 'if', 'u2f',
    'mmi_pcpyld', 'mmi_pcpyud', 'mmi_pextlw', 'mmi_pextuw', 'mmi_prot3w',
    'rmb_lh', 'rmb_lq', 'rmb_lw', 'rmb_sb', 'rmb_sq', 'rmb_sw',
    'vu0_cfc2', 'vu0_ctc2', 'vu0_fmac1'))

def leaf_preserves_context(body):
    if set(re.findall(r'\b([A-Za-z_]\w*)\s*\(', body)) - PURE_CALLS:
        return False
    # Reject even reads of saved registers: the common small leaves need none.
    if re.search(r'c->r\[(?:1[6-9]|2[0-3]|30)\]|c->fpr\[(?:2[0-9]|3[01])\]', body):
        return False
    # No context member's address may escape into memory/another helper.
    if re.search(r'&\s*(?:\(\s*)*c\s*->', body):
        return False
    text = body.replace('const R5900Mem m_ = {c->ram, c->ram_mask};', '')
    # Only the generated typed scalar member syntax is understood. Dynamic
    # indexing, pointer aliases, or changed generator syntax keep protection.
    scalar = r'c->(?:r\[' + REG + r'\](?:\.(?:s?d\[[01]\]|[s]?w\[' + LANE + r'\])|(?!\s*[.\[]))|fpr\[' + REG + r'\]\.u|fcr31|acc\.u|vu0\.(?:vf\[' + REG + r'\]\.w\[' + LANE + r'\]|acc\.w\[' + LANE + r'\]|vi\[' + REG + r'\]))'
    text = re.sub(scalar + r'(?!\w)(?!\s*[.\[])', 'context_scalar', text)
    # These exact VU status operations touch only vi[16], never saved GPR/FPR.
    text = re.sub(r'\bvu0_ctc2\(c, 16, ', 'vu0_ctc2(context, 16, ', text)
    text = text.replace('vu0_cfc2(c, 16)', 'vu0_cfc2(context, 16)')
    return re.search(r'\bc\b', text) is None

def optimize_units(units, callers):
    """Return transformed units and counts; only requested callers are changed.

    Units must be the final prepared translation, after hook/native/site/zone
    substitution. Names without exactly one plain definition are ineligible.
    Do not use with linker function wrapping or additional symbol overrides.
    """
    callers = set(callers)
    if any(re.fullmatch(r'fn_[0-9a-f]{8}', x) is None for x in callers):
        raise ValueError('leaf_csave_callers requires generated function names')
    defs = {}
    for text in units.values():
        for m in DEF.finditer(text):
            defs.setdefault(m[1], []).append(m[2])
    missing = callers - defs.keys()
    if missing:
        raise ValueError('leaf csave callers missing: ' + ', '.join(sorted(missing)))
    eligible = {name for name, bodies in defs.items() if len(bodies) == 1 and leaf_preserves_context(bodies[0])}
    counts = Counter()
    result = {}
    for path, text in units.items():
        def change(m):
            if m[1] not in callers or len(defs[m[1]]) != 1:
                return m[0]
            def call(c):
                if c[1] not in eligible:
                    return c[0]
                counts[(m[1], c[1])] += 1
                return c[1] + '(c);'
            return m[0].replace(m[2], CALL.sub(call, m[2]), 1)
        result[path] = DEF.sub(change, text)
    return result, dict(counts)

def optimize_directory(directory, callers):
    paths = sorted(Path(directory).glob('*.c'))
    original = {str(p): p.read_text(encoding='ascii') for p in paths}
    updated, counts = optimize_units(original, callers)
    for name, text in updated.items():
        if text != original[name]:
            Path(name).write_text(text, encoding='ascii')
    return counts
