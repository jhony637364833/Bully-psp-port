/* Release an explicitly owned tail allocation; never rewind over another block. */
#ifndef HLE_HOLE_RELEASE_H
#define HLE_HOLE_RELEASE_H
#include <stddef.h>
#include <stdint.h>
static inline int hle_hole_release(uint8_t *begin, uint8_t **cursor,
                                   void *block, size_t size)
{
    if (!begin || !cursor || !*cursor || !block || !size) return 0;
    uintptr_t lo = (uintptr_t)begin, top = (uintptr_t)*cursor;
    uintptr_t p = (uintptr_t)block;
    if (p < lo || p > top || size != top - p) return 0;
    *cursor = block;
    return 1;
}
#endif
