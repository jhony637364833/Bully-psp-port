"""Discover Bully functions and preserve non-ABI boundaries for the v5 backend.

Uses the same generic ABI analysis as the GTA SA conversion recipe. Inputs are
read from the verified user disc; generated function bodies are not stored here.
"""
import hashlib
import json
import pickle
import sys
from pathlib import Path

PACK_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACK_DIR.parents[1]))
from ps2rc import pack
from ps2rc.image import load_elf
from ps2rc.analysis.functions import discover_functions
from ps2rc.analysis.abi import Unit, analyse
from ps2rc.pipeline.translate import overlay_unit, hooked_addresses


def main():
    p = pack.load(str(PACK_DIR))
    disc = Path(p.disc())
    elf = disc / p.get('id.boot_elf')
    digest = hashlib.sha256(elf.read_bytes()).hexdigest()
    if digest != p.get('verify.elf_sha256'):
        raise ValueError('Bully ABI analysis requires the matching verified ELF')
    img = load_elf(str(elf)).stripped()
    ranges = [tuple(p.get('memory.code')), tuple(p.get('memory.ctor_code'))]
    funcs = discover_functions(img, ranges, extra_seeds=[img.entry]).functions
    units = [Unit('main', img, funcs)]
    for name in p.get('overlays.files'):
        _, oimg, ofs, _ = overlay_unit(img, str(disc / name))
        units.append(Unit(name, oimg, ofs.functions))
    result = analyse(units, window=tuple(p.get('overlays.window')))
    exact = {u.name: set() for u in units}
    for (unit, address), verdict in result.items():
        if verdict.exact:
            exact[unit].add(address)
    # HLE code can observe RA, saved registers and other non-argument state.
    # The ordinary ABI liveness rule supplies only argument registers.
    hooks = hooked_addresses(p.path('build.hooks'))
    for unit in units:
        exact[unit.name].update(hooks & set(unit.functions))
    # Native C bodies read/write full contexts. Their callers must synchronize
    # complete boundaries even when analysis considers the guest ABI-conforming.
    for line in Path(p.path('build.natives')).read_text().splitlines():
        line = line.split('#', 1)[0].strip()
        if line:
            address = int(line.split()[0], 16)
            if address not in funcs:
                raise ValueError('Native address absent from discovered program')
            exact['main'].add(address)
    # Keep previously specialized functions exact while using the backend's
    # own save/restore protection across calls into ABI-mode functions.
    exact['main'].update((0x0024d848, 0x0012a5c0, 0x0037edb0, 0x0037eeb0))
    functions = Path(p.path('translate.functions'))
    functions.parent.mkdir(parents=True, exist_ok=True)
    functions.write_bytes(pickle.dumps(funcs))
    out = Path(p.path('translate.non_abi'))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({'elf_sha256': digest,
        'exact_starts': {u: sorted('%08x' % a for a in values)
                         for u, values in exact.items()}}, indent=2) + '\n')
    print('Bully exact boundaries:', {u: len(v) for u, v in exact.items()})


if __name__ == '__main__':
    main()
