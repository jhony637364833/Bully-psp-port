#include "hle.h"
void GUEST(00432590)(R5900Ctx *c);
void GUEST(001d2710)(R5900Ctx *c);
HLE(00432590) {
 static uint32_t last=~0u; uint32_t p=ARG(0), s=gw(p+1664);
 if(s!=last) {LOG("DIALOG state %u at %08x vtime %.3f\n",s,p,(double)hle_vtime/EE_HZ);last=s;}
 GUEST(00432590)(c);
}
HLE(001d2710) {
 static uint32_t last; static unsigned count; uint32_t p=ARG(1);
 if(count++<40 && p!=last && p && p<hle_ram_end-64) {LOG("DIALOG text %.64s\n",(char*)gptr(p,64));last=p;}
 GUEST(001d2710)(c);
}
