/* NTSC-U v1.02 probes plus the first PSP static-geometry draw path. */
#include "hle.h"
#ifdef HLE_PSP
#include <pspkernel.h>
#endif
void GUEST(0027c828)(R5900Ctx *c);
void GUEST(002812b8)(R5900Ctx *c);
static void sample(const char *name, R5900Ctx *c, unsigned *count)
{
    if (*count >= 12) return;
    ++*count;
    uint32_t a = ARG(0), b = ARG(1);
    LOG("RENDER_PROBE %s sample=%u frame=%u a0=%08x a1=%08x\n",
        name, *count, (unsigned)hle_frame, a, b);
    uint32_t ptrs[3] = {a, b, 0};
    if (b >= 4 && !(b & 3) && b <= hle_ram_end - 4) ptrs[2] = gw(b);
    for (unsigned i=0; i<3; ++i) {
        uint32_t p=ptrs[i];
        if (p < 4 || (p & 3) || p > hle_ram_end - 64) continue;
        LOG("RENDER_PROBE %s block%u=%08x", name, i, p);
        for (unsigned j=0; j<64; j+=4) LOG(" %08x", gw(p+j));
        LOG("\n");
    }
}
HLE(0027c828) {
    static unsigned count;
#ifndef HLE_PSP
    static int captured;
    if (!captured && hle_frame >= 650) {
        captured = 1;
        FILE *f = fopen("/home/vercel-sandbox/workspace/inputs/bully/camera-boundary-ram.bin", "wb");
        if (f) {
            size_t n = fwrite(hle_ram, 1, hle_ram_end, f);
            int rc = fclose(f);
            LOG("RENDER_SNAPSHOT frame=%u a0=%08x a1=%08x bytes=%u close=%d\n",
                (unsigned)hle_frame, ARG(0), ARG(1), (unsigned)n, rc);
        } else LOG("RENDER_SNAPSHOT open failed\n");
    }
#endif
    sample("ps2all", c, &count);
#ifdef HLE_PSP
    uint32_t param=ARG(1), node=ARG(0), obj=0;
    if(param>=4 && !(param&3) && param<=hle_ram_end-4 &&
       node>=4 && !(node&3) && node<=hle_ram_end-24) {
        uint32_t methods=gw(node+20);
        if(methods>=4 && !(methods&3) && methods<=hle_ram_end-20 && (gw(methods+16)==0x0016ce40 || gw(methods+16)==0x0029ccc0 || gw(methods+16)==0x0025f118))
            obj=gw(param);
    }
#endif
#ifdef HLE_PSP
    void bully_world_begin(void);
    bully_world_begin();
    uint64_t guest_start=sceKernelGetSystemTimeWide();
#endif
    GUEST(0027c828)(c);
#ifdef HLE_PSP
    uint64_t native_start=sceKernelGetSystemTimeWide();
#endif
#ifdef HLE_PSP
    /* Original setup ran first, including frame synchronization. Preserve its state. */
    void bully_world_draw(uint32_t object,uint32_t camera);
    if(obj && hle_ram_end>=0x006cf89c) {
        void bully_world_capture_float_state(uint32_t object,uint32_t gp);
        bully_world_capture_float_state(obj,(uint32_t)c->r[28].d[0]);
        bully_world_draw(obj,gw(0x006cf898));
    }
    /* Wall-time attribution, unlike watchdog samples of the last guest PC. */
    static uint64_t guest_us,native_us;
    static unsigned timed_calls;
    guest_us+=native_start-guest_start;
    native_us+=sceKernelGetSystemTimeWide()-native_start;
    if(++timed_calls==64) {
        LOG("RENDER_TIME: calls=64 guest_us=%llu native_us=%llu\n",
            (unsigned long long)guest_us,(unsigned long long)native_us);
        timed_calls=0;guest_us=native_us=0;
    }
#endif
}
HLE(002812b8) {
    static unsigned count;
    sample("material_candidate", c, &count);
    GUEST(002812b8)(c);
}

/* Observe the real mesh setup output; retain all guest side effects. */
void GUEST(0016ce40)(R5900Ctx *c);
HLE(0016ce40) {
    static unsigned samples;
    uint32_t arg = ARG(1), out = 0;
    int take = hle_frame >= 650 && samples < 3;
    if (take && arg >= 4 && !(arg & 3) && arg <= hle_ram_end - 4) out = gw(arg);
    GUEST(0016ce40)(c);
    if (take && out >= 4 && !(out & 3) && out <= hle_ram_end - 64) {
        ++samples;
        LOG("CAMERA_MATRIX frame=%u out=%08x", (unsigned)hle_frame, out);
        for (unsigned i=0;i<16;i++) LOG(" %08x",gw(out+i*4));
        LOG("\n");
    }
}

/* Capture consumed per-material lighting globals before the original bridge.
 * Keep every guest side effect and the original return value. */
void GUEST(0029dc50)(R5900Ctx *c);
HLE(0029dc50) {
    uint32_t pipe=ARG(0),gp=(uint32_t)c->r[28].d[0];
#ifdef HLE_PSP
    void bully_world_capture_light(uint32_t pipe,uint32_t gp);
    bully_world_capture_light(ARG(0),(uint32_t)c->r[28].d[0]);
#endif
    GUEST(0029dc50)(c);
#ifdef HLE_PSP
    void bully_world_capture_state(uint32_t pipe,uint32_t gp);
    bully_world_capture_state(pipe,gp);
#else
    (void)pipe;(void)gp;
#endif
}

/* Current-camera global writes identify the RenderWare camera update pair:
 * 00223ad0 installs a0 at 006cf898; 00223a78 clears it on successful end.
 * Keep both guest calls and their return values intact. */
void GUEST(00223ad0)(R5900Ctx *c);
HLE(00223ad0) {
    GUEST(00223ad0)(c);
#ifdef HLE_PSP
    void bully_world_camera_begin(uint32_t camera);
    if((uint32_t)c->r[2].d[0])bully_world_camera_begin((uint32_t)c->r[2].d[0]);
#endif
}
void GUEST(00223a78)(R5900Ctx *c);
HLE(00223a78) {
    GUEST(00223a78)(c);
#ifdef HLE_PSP
    void bully_world_camera_end(uint32_t camera);
    if((uint32_t)c->r[2].d[0])bully_world_camera_end((uint32_t)c->r[2].d[0]);
#endif
}

/* The guest flip completes after DIRECT overlay packets, including paused UI.
 * Keep the original call/return state on both host and PSP. */
void GUEST(00240c00)(R5900Ctx *c);
HLE(00240c00) {
    GUEST(00240c00)(c);
#ifdef HLE_PSP
    void bully_overlay_flush(void);
    void bully_world_overlay_present(void);
    bully_overlay_flush();
    bully_world_overlay_present();
#endif
}
