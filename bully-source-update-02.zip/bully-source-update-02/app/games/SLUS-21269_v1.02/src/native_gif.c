#include "native_gif.h"
#include <string.h>
static uint64_t u64(const unsigned char*p){uint64_t v;memcpy(&v,p,8);return v;}
void bully_gif_init(BullyGif*p,BullyGifRegister r,BullyGifUpload u,void*o){memset(p,0,sizeof *p);p->reg=r;p->upload=u;p->opaque=o;}
static void regwrite(BullyGif*p,unsigned reg,uint64_t v){if(reg==0x50)p->bitblt=v;if(p->reg)p->reg(p->opaque,reg,v);}
int bully_gif_feed(BullyGif*p,const void*data,size_t bytes,uint32_t addr){
 if(!p||(!data&&bytes)||(bytes&15)||bytes>UINT32_MAX||bytes>UINT32_MAX-addr)return 0;
 const unsigned char*s=data;
 while(bytes){
  if(!p->left){
   uint64_t lo=u64(s),hi=u64(s+8);unsigned n=lo&0x7fff;
   if((lo&UINT64_C(0x00003fffffff0000)) || ((lo>>58)&3)==3){p->upload_ok=0;p->unsupported++;return 0;}
   p->flag=(lo>>58)&3;p->nreg=(lo>>60)&15;if(!p->nreg)p->nreg=16;
   for(unsigned i=0;i<p->nreg;i++)p->regs[i]=(hi>>(4*i))&15;
   p->index=0;p->left=p->flag==2?n:n*p->nreg;p->tags++;
   if(p->flag==2){
    /* upload_start tracks an A+D header with exactly three setup writes. */
    p->upload_ok=p->upload_ok && addr==p->upload_start+64;
    p->image_next=addr+16;p->upload_bytes=n*16+80;
    if(!n)p->upload_ok=0;
   }else{
    p->upload_ok=p->flag==0 && n==3 && p->nreg==1 && p->regs[0]==14;
    p->upload_start=addr;
   }
   s+=16;addr+=16;bytes-=16;
   if(p->flag==0 && ((lo>>46)&1))regwrite(p,0,(lo>>47)&0x7ff);
   continue;
  }
  if(p->flag==2){
   size_t n=bytes/16;if(n>p->left)n=p->left;
   if(addr!=p->image_next)p->upload_ok=0;
   p->image_next=addr+(uint32_t)n*16;p->left-=(uint32_t)n;
   s+=n*16;addr+=(uint32_t)n*16;bytes-=n*16;
   if(!p->left && p->upload_ok && p->upload)p->upload(p->opaque,p->bitblt,p->upload_start,p->upload_bytes);
   continue;
  }
  unsigned words=p->flag==1?2:1;
  for(unsigned w=0;w<words && p->left;w++){
   unsigned reg=p->regs[p->index%p->nreg];
   if(p->flag==0){
    if(reg==14){
     uint64_t r=u64(s+8),v=u64(s);
     static const unsigned setup[3]={0x51,0x52,0x53};
     if(p->upload_ok && (p->index>=3 || r!=setup[p->index] || addr!=p->upload_start+16*(p->index+1)))p->upload_ok=0;
     regwrite(p,(unsigned)(r&255),v);
    }else if(reg!=15){p->unsupported++;p->upload_ok=0;}
   }else if(reg!=15){
    /* REGLIST stores the ordinary 64-bit register layouts, never A+D. */
    if(reg!=14)regwrite(p,reg,u64(s+w*8));else p->unsupported++;
    p->upload_ok=0;
   }
   p->left--;p->index++;
  }
  s+=16;addr+=16;bytes-=16;
 }
 return 1;
}
