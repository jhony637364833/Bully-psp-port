/* Private audio/video startup experiment: output enabled; no gameplay success asserted. */
#include "hle.h"
#include "spu2_lite.h"
#include <stdlib.h>
#include "iop_rt.h"
#include "iop_rt_ucontext.h"
#include <stdarg.h>
#include <stdio.h>
#include <unistd.h>
#if defined(HLE_PSP) && !defined(BULLY_SILENT_STARTUP)
int bully_audio_output_push(const int16_t *,uint32_t);
void bully_audio_output_shutdown(void);
static void psp_pcm(const int16_t *pcm,uint32_t n) {
 int rc=bully_audio_output_push(pcm,n);
 if(rc<0)hle_die(NULL,"audio output failed %08x",(unsigned)rc);
}
#endif
#ifdef HLE_PSP
static void *probe_alloc(void *u,size_t n){(void)u;return hle_plat_big_alloc(n);}
#endif
extern const IopModule soundlib_irx,soundrpc_irx;
int bully_ee_rpc_bind(void*,uint32_t,uint32_t*,uint32_t*,uint32_t*);
int bully_ee_rpc_call(void*,uint32_t,uint32_t,const void*,uint32_t,void*,uint32_t);
void probe_cd_read(IopCpu*);void probe_cd_status(IopCpu*);void probe_cd_sync(IopCpu*);void probe_cd_position(IopCpu*);
static IopRt *rt;
static Spu2 spu;
static uint64_t sample_clock, pcm_frames, pcm_nonzero;
static int pcm_peak;
static void pcm_stats(void *u,const int16_t *pcm,uint32_t n) {
 (void)u; pcm_frames+=n;
#if defined(HLE_PSP) && !defined(BULLY_SILENT_STARTUP)
 psp_pcm(pcm,n);
#endif
 if(hle_verbose)for(uint32_t i=0;i<n*2;i++){int v=pcm[i];if(v)pcm_nonzero++;if(v<0)v=-v;if(v>pcm_peak)pcm_peak=v;}
}
static void report_pcm(void) {if(!hle_verbose)return;fprintf(stderr,"PCM DIAGNOSTIC frames=%llu nonzero=%llu peak=%d\n",(unsigned long long)pcm_frames,(unsigned long long)pcm_nonzero,pcm_peak);}

/* Diagnostic error decoding only; stop instead of pretending vsprintf succeeded. */
int iop_rt_format(IopCpu*,uint32_t,int,char*,size_t);
static void probe_error_format(IopCpu *c) {
 IopCpu args=*c; char message[1024];
 args.r[29]=c->r[6]-16;
 iop_rt_format(&args,c->r[5],4,message,sizeof message);
 fprintf(stderr,"AUDIO ERROR FORMAT: %s\n",message); report_pcm(); fflush(stderr); _exit(3);
}

static int disc_lookup(void *u,const char *p,uint32_t *lsn,uint32_t *size){(void)u;return hle_disc_lookup(p,lsn,size) ? 0 : -1;}
static int disc_read(void *u,uint32_t lsn,uint32_t count,void *dst){(void)u;return hle_disc_read_lsn(lsn,count,dst);}
static void logger(void *u,int level,const char *fmt,...){(void)u;(void)level;va_list ap;va_start(ap,fmt);vfprintf(stderr,fmt,ap);va_end(ap);}
static void bank_load_trace(IopCpu *c) {
 uint32_t p=c->r[4];fprintf(stderr,"BANK LOAD input=%x header=%08x %08x %08x\n",p,IOP_LW(c->mem,p),IOP_LW(c->mem,p+4),IOP_LW(c->mem,p+8));
 soundlib_irx.fn_at(0x8f3c)(c);
 fprintf(stderr,"BANK LOAD result=%08x dma_count=%llu bytes=%llu\n",c->r[2],(unsigned long long)iop_rt_stats(rt)->sd_dmas,(unsigned long long)iop_rt_stats(rt)->sd_dma_bytes);
}
static int load(void){IopRtConfig cfg={0};cfg.log=logger;iop_rt_coro_ucontext(&cfg.coro);
#ifdef HLE_PSP
cfg.alloc=probe_alloc;
uint8_t *ram=hle_plat_big_alloc(SPU2_RAM_SIZE);
#else
uint8_t *ram=calloc(1,SPU2_RAM_SIZE);
#endif
if(!ram)return -1;
spu2_init(&spu,ram);spu.sink=pcm_stats;Spu2Ops ops={0};spu2_bind_ops(&spu,&ops,0,0,1);
cfg.sd=(IopSdOps){.user=ops.user,.ram=ram,.ram_size=SPU2_RAM_SIZE,.set_param=ops.set_param,.set_addr=ops.set_addr,.get_envx=ops.get_envx,.get_nax=ops.get_nax,.key_on=ops.key_on,.key_off=ops.key_off,.set_irq=ops.set_irq};
atexit(report_pcm);
cfg.disc.lookup=disc_lookup;cfg.disc.read=disc_read;
cfg.ee_rpc.bind=bully_ee_rpc_bind;cfg.ee_rpc.call=bully_ee_rpc_call;
rt=iop_rt_create(&cfg);if(!rt)return -1;
iop_rt_bind(rt,"sysclib",42,probe_error_format);
iop_rt_bind(rt,"cdstream",5,probe_cd_read);iop_rt_bind(rt,"cdstream",6,probe_cd_status);iop_rt_bind(rt,"cdstream",7,probe_cd_sync);iop_rt_bind(rt,"cdstream",8,probe_cd_position);
const char *argv[]={"soundlib"};
int rc=iop_rt_load(rt,&soundlib_irx,1,argv,8);if(rc<0)return rc;
if(iop_rt_bind(rt,"scream",4,soundlib_irx.fn_at(0x7780))<0)return 2;
if(iop_rt_bind(rt,"scream",5,soundlib_irx.fn_at(0x7af4))<0)return 2;
if(iop_rt_bind(rt,"scream",11,soundlib_irx.fn_at(0x8f9c))<0)return 2;
if(iop_rt_bind(rt,"scream",12,soundlib_irx.fn_at(0x97bc))<0)return 2;
if(iop_rt_bind(rt,"scream",13,soundlib_irx.fn_at(0xf358))<0)return 2;
if(iop_rt_bind(rt,"scream",15,soundlib_irx.fn_at(0xf48c))<0)return 2;
if(iop_rt_bind(rt,"scream",17,soundlib_irx.fn_at(0xb028))<0)return 2;
if(iop_rt_bind(rt,"scream",22,soundlib_irx.fn_at(0xa584))<0)return 2;
if(iop_rt_bind(rt,"scream",23,soundlib_irx.fn_at(0xa9b8))<0)return 2;
if(iop_rt_bind(rt,"scream",24,soundlib_irx.fn_at(0xa9fc))<0)return 2;
if(iop_rt_bind(rt,"scream",25,soundlib_irx.fn_at(0xa4f0))<0)return 2;
if(iop_rt_bind(rt,"scream",27,soundlib_irx.fn_at(0xbf90))<0)return 2;
if(iop_rt_bind(rt,"scream",28,soundlib_irx.fn_at(0xa5a4))<0)return 2;
if(iop_rt_bind(rt,"scream",34,soundlib_irx.fn_at(0xa854))<0)return 2;
if(iop_rt_bind(rt,"scream",36,soundlib_irx.fn_at(0x41e0))<0)return 2;
if(iop_rt_bind(rt,"scream",44,soundlib_irx.fn_at(0xe5fc))<0)return 2;
if(iop_rt_bind(rt,"scream",46,soundlib_irx.fn_at(0xd528))<0)return 2;
if(iop_rt_bind(rt,"scream",47,soundlib_irx.fn_at(0xd614))<0)return 2;
if(iop_rt_bind(rt,"scream",49,soundlib_irx.fn_at(0xd5e8))<0)return 2;
if(iop_rt_bind(rt,"scream",51,soundlib_irx.fn_at(0x75d4))<0)return 2;
if(iop_rt_bind(rt,"scream",53,soundlib_irx.fn_at(0x76d0))<0)return 2;
if(iop_rt_bind(rt,"scream",54,soundlib_irx.fn_at(0x771c))<0)return 2;
if(iop_rt_bind(rt,"scream",57,soundlib_irx.fn_at(0x9d54))<0)return 2;
if(iop_rt_bind(rt,"scream",58,soundlib_irx.fn_at(0x9e10))<0)return 2;
if(iop_rt_bind(rt,"scream",65,soundlib_irx.fn_at(0xd498))<0)return 2;
if(iop_rt_bind(rt,"scream",66,soundlib_irx.fn_at(0x7e78))<0)return 2;
if(iop_rt_bind(rt,"scream",69,soundlib_irx.fn_at(0xada4))<0)return 2;
if(iop_rt_bind(rt,"scream",70,soundlib_irx.fn_at(0x81fc))<0)return 2;
if(iop_rt_bind(rt,"scream",79,bank_load_trace)<0)return 2;
if(iop_rt_bind(rt,"scream",80,soundlib_irx.fn_at(0xa378))<0)return 2;
if(iop_rt_bind(rt,"scream",86,soundlib_irx.fn_at(0xad4c))<0)return 2;
if(iop_rt_bind(rt,"scream",87,soundlib_irx.fn_at(0x4b78))<0)return 2;
if(iop_rt_bind(rt,"scream",89,soundlib_irx.fn_at(0xe164))<0)return 2;
if(iop_rt_bind(rt,"scream",90,soundlib_irx.fn_at(0xd4cc))<0)return 2;
if(iop_rt_bind(rt,"scream",95,soundlib_irx.fn_at(0xa06c))<0)return 2;
rc=iop_rt_load(rt,&soundrpc_irx,1,argv,8);return rc;}
void probe_run_slice(IopRt*,unsigned);
static uint64_t serviced_us, timer_us[16], serviced_frame;
static void probe_service(void) {
 uint64_t now=(hle_vtime/EE_HZ)*1000000u+(hle_vtime%EE_HZ)*1000000u/EE_HZ;
 if(!serviced_us){sample_clock=now*48/1000;serviced_us=now;serviced_frame=hle_frame;for(int i=0;i<16;i++)timer_us[i]=now;}
 if(now>serviced_us){iop_rt_advance_us(rt,now-serviced_us);serviced_us=now;}
 while(serviced_frame<hle_frame){++serviced_frame;iop_rt_vblank(rt);probe_run_slice(rt,32);}
 uint64_t sample_now=now*48/1000;
 while(sample_clock<sample_now){unsigned n=sample_now-sample_clock>256?256:(unsigned)(sample_now-sample_clock);spu2_advance(&spu,n);sample_clock+=n;if(spu2_irq_take(&spu))iop_rt_spu_irq(rt,3);}
 for(int i=0;i<iop_rt_timer_count(rt)&&i<16;i++) {
  uint64_t p=iop_rt_timer_period_ns(rt,i)/1000;
  if(!p || !iop_rt_timer_active(rt,i)){timer_us[i]=now;continue;}
  for(int j=0;now-timer_us[i]>=p && j<1000;j++) {
   timer_us[i]+=p;iop_rt_timer_expire(rt,i);probe_run_slice(rt,32);
  }
 }
 probe_run_slice(rt,32);
 static uint64_t next_report;
 if(hle_verbose && pcm_frames>=next_report){report_pcm();next_report=pcm_frames+48000;}
}
int probe_sif_call(IopRt*,uint32_t,uint32_t,const void*,uint32_t,void*,uint32_t,void(*)(void*),void*);
static void probe_rpc_wait(void *ctx) {
 hle_safe_point((R5900Ctx*)ctx, EE_HZ/10000); /* experimental 100 us service quantum */
 probe_service();
}
static int audio_probe_id(uint32_t sid,R5900Ctx *c,uint32_t fno,uint32_t mode,uint32_t send,uint32_t ssize,uint32_t recv,uint32_t rsize){
(void)mode;if(!rt){int r=load();if(r<0)hle_die(c,"audio diagnostic load failed %d",r);}
probe_service();
if(hle_verbose)LOG("AUDIO REQUEST sid=%x fno=%x mode=%x ssize=%u word=%08x allow=%u\n",sid,fno,mode,ssize,ssize>=4?gw(send):0,IOP_LW(iop_rt_mem(rt),0x37a84));
int r=probe_sif_call(rt,sid,fno,ssize?gptr(send,ssize):NULL,ssize,rsize?gptr(recv,rsize):NULL,rsize,probe_rpc_wait,c);
if(r<0)hle_die(c,"experimental audio RPC failed %d",r);
if(hle_verbose || r<0 || iop_rt_stats(rt)->unimpl_calls)LOG("AUDIO DIAGNOSTIC call result %d unresolved %u unimplemented %u\n",r,iop_rt_stats(rt)->imports_unresolved,iop_rt_stats(rt)->unimpl_calls);
if(iop_rt_stats(rt)->unimpl_calls) hle_die(c,"audio diagnostic reached unimplemented import"); return r;}

int bully_audio_probe(R5900Ctx *c,uint32_t f,uint32_t m,uint32_t s,uint32_t ns,uint32_t r,uint32_t nr){return audio_probe_id(0xbcff,c,f,m,s,ns,r,nr);}

int bully_scream_probe(R5900Ctx *c,uint32_t f,uint32_t m,uint32_t s,uint32_t ns,uint32_t r,uint32_t nr){return audio_probe_id(0x123456,c,f,m,s,ns,r,nr);}

int bully_scream_load_probe(R5900Ctx *c,uint32_t f,uint32_t m,uint32_t s,uint32_t ns,uint32_t r,uint32_t nr){return audio_probe_id(0x123457,c,f,m,s,ns,r,nr);}

void hle_pack_iop_report(void) {
#if defined(HLE_PSP) && !defined(BULLY_SILENT_STARTUP)
 bully_audio_output_shutdown();
#endif
 report_pcm();
}
