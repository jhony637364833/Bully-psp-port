/* Based on PS2RC by SandstoneDev: https://github.com/SandstoneDev/PS2RC */
#ifndef BULLY_NATIVE_LIGHT_H
#define BULLY_NATIVE_LIGHT_H
#include "native_mesh.h"
typedef struct {
    uint32_t stream, material_id;
    float blend, gain[3], material[3], material_alpha;
    int monochrome;
} BullyNativeLight;
/* Snapshot the verified compressed material bridge BEFORE it consumes globals.
 * Failure leaves out untouched. No guest execution or memory mutation. */
int bully_native_light(const uint8_t *ram, size_t bytes, uint32_t pipe,
                       uint32_t gp, BullyNativeLight *out);
void bully_light_color(const BullyNativeVertex *v, const BullyNativeLight *light,
                       float rgb[3]);
float bully_light_alpha(const BullyNativeVertex *v, const BullyNativeLight *light);
#endif
