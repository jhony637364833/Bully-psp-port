#ifndef BULLY_NATIVE_GIF_H
#define BULLY_NATIVE_GIF_H
#include <stddef.h>
#include <stdint.h>
typedef void (*BullyGifRegister)(void *,unsigned,uint64_t);
typedef void (*BullyGifUpload)(void *,uint64_t,uint32_t,uint32_t);
typedef struct {
 uint64_t bitblt;
 uint32_t left,index,image_next,upload_start,upload_bytes;
 uint8_t regs[16],nreg,flag,upload_ok;
 BullyGifRegister reg;
 BullyGifUpload upload;
 void *opaque;
 uint64_t tags,unsupported;
} BullyGif;
/* Consume complete DMA quadwords without reading beyond data+bytes. IMAGE
 * payloads advance in O(1), without copies. Upload callbacks require the exact
 * contiguous TRXPOS/TRXREG/TRXDIR/IMAGE layout accepted by texconv. */
void bully_gif_init(BullyGif *,BullyGifRegister,BullyGifUpload,void *);
int bully_gif_feed(BullyGif *,const void *,size_t,uint32_t);
#endif
