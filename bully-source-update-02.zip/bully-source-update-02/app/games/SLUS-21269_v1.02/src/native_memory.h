/* Shared budget for the supported native overlay texture arena. */
#ifndef BULLY_NATIVE_MEMORY_H
#define BULLY_NATIVE_MEMORY_H
#define BULLY_OVERLAY_ARENA_BYTES (264u*1024u)
#endif
