/* PS2RC raster conversion adapter for observed Bully native materials. */
#ifndef BULLY_NATIVE_TEXTURE_H
#define BULLY_NATIVE_TEXTURE_H
#include "texconv.h"
typedef struct {
    TcPspTex texture;
    unsigned filter, wrap_u, wrap_v;
} BullyNativeTexture;
/* No allocation or RAM writes. dst must be16-byte aligned; it may change on
 * failure. out is committed only on success. At most256x256, one mip level; retries128x128 if capacity is smaller. */
int bully_native_texture(const uint8_t *ram,size_t bytes,uint32_t material,
                         void *dst,size_t capacity,BullyNativeTexture *out);
/* Optional caller-owned cache. Allocate cache_bytes() bytes at 16-byte alignment,
 * initialize once, and keep its storage exclusive (no overlap with arguments,
 * no external mutation). NULL preserves the ordinary uncached behavior.
 * Metadata is revalidated and relevant source bytes compared on every hit.
 * Overlapping RAM/output arguments bypass reuse and preserve the old path. */
typedef struct BullyNativeTextureCache BullyNativeTextureCache;
size_t bully_native_texture_cache_bytes(void);
void bully_native_texture_cache_init(BullyNativeTextureCache *cache);
int bully_native_texture_cached(const uint8_t *ram,size_t bytes,uint32_t material,
                               void *dst,size_t capacity,BullyNativeTexture *out,BullyNativeTextureCache *cache);
/* Borrow pixels until the next operation on this cache (including init/free),
 * or the next write to dst when *view == dst. Finish GPU reads first. On a hit,
 * dst is not written. On failure *view is unchanged. view must point to its own
 * pointer object, disjoint from all other arguments and cache storage. */
int bully_native_texture_view(const uint8_t *ram,size_t bytes,uint32_t material,
                             void *dst,size_t capacity,BullyNativeTexture *out,
                             BullyNativeTextureCache *cache,const void **view);
#endif
