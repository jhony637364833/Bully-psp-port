/* Experimental native FST overlay bridge. Guest DMA still executes once. */
#include "hle.h"
#include "native_gif.h"
#include "native_vif.h"
#include "overlay_geometry.h"
#include "texconv.h"
#include "overlay_texture.h"
#include "native_memory.h"
#include <pspgu.h>
#include <pspkernel.h>
static BullyGif paths[2];static BullyVif vif;static BullyOverlayGeometry geom;
static int initialized,blocked;
static uint64_t transfer_destination;
typedef struct{uint32_t addr,bytes,serial;} Upload;
static Upload uploads[16384];static uint32_t serial;
uint64_t bully_overlay_stats[10];
static unsigned list[2048] __attribute__((aligned(16)));
static BullyOverlayVertex verts[384] __attribute__((aligned(16)));
static unsigned queued,queued_prim;static int queued_underlay;static BullyOverlayContext queued_state;
#define ARENA_BYTES BULLY_OVERLAY_ARENA_BYTES
typedef struct{uint64_t tex0;uint32_t pix,pal,offset;TcPspTex tex;} Cache;
static Cache cache[16];static unsigned caches,arena_used;static unsigned char *arena;static int attempted;
int bully_world_overlay_begin(void);
void bully_world_overlay_present(void);
int bully_world_underlay_begin(void);
static void start(void){sceGuStart(GU_DIRECT,list);}
static void finish(void){sceGuFinish();sceGuSync(0,0);}
static Cache *texture(uint64_t t){
 unsigned ps=(t>>20)&63,w=1u<<((t>>26)&15),h=1u<<((t>>30)&15),cps=(t>>51)&15;
 if((ps!=TC_GS_PSMT4 && ps!=TC_GS_PSMT8) || cps!=0 || (t&(UINT64_C(1)<<55)) || ((t>>56)&31) || w>512 || h>512)return 0;
 Upload p=uploads[t&16383],c=uploads[(t>>37)&16383];
 if(!p.serial || !c.serial || p.addr>hle_ram_end || p.bytes>hle_ram_end-p.addr || c.addr>hle_ram_end || c.bytes>hle_ram_end-c.addr)return 0;
 for(unsigned i=0;i<caches;i++)if(cache[i].tex0==t && cache[i].pix==p.serial && cache[i].pal==c.serial){bully_overlay_stats[6]++;return &cache[i];}
 if(!attempted){attempted=1;if(sceKernelTotalFreeMemSize()>=ARENA_BYTES+1024u*1024u && sceKernelMaxFreeMemSize()>=ARENA_BYTES){SceUID id=sceKernelAllocPartitionMemory(2,"overlay_tex",PSP_SMEM_High,ARENA_BYTES,0);if(id>=0){arena=sceKernelGetBlockHeadAddr(id);if(!arena)sceKernelFreePartitionMemory(id);}}}
 if(!arena)return 0;
 TcPs2Info info;TcPolicy pol;TcPspTex plan;
 if(!bully_overlay_texture_plan(hle_ram,hle_ram_end,t,p.addr,p.bytes,c.addr,c.bytes,&info,&pol,&plan) || plan.total_bytes>ARENA_BYTES)return 0;
 if(caches==16 || plan.total_bytes>ARENA_BYTES-arena_used){caches=arena_used=0;}
 Cache *out=&cache[caches];
 if(tc_convert(&info,&pol,&plan,arena+arena_used,ARENA_BYTES-arena_used))return 0;
 *out=(Cache){t,p.serial,c.serial,arena_used,plan};arena_used+=plan.total_bytes;caches++;
 sceKernelDcacheWritebackRange(arena+out->offset,plan.total_bytes);bully_overlay_stats[7]++;return out;
}
void bully_overlay_flush(void){
 if(!queued)return;
 unsigned n=queued;queued=0;const BullyOverlayContext*s=&queued_state;unsigned prim=queued_prim;
 Cache *tex=0;if(prim&16){tex=texture(s->tex0);if(!tex){bully_overlay_stats[3]+=n/3;return;}}
 if(!(queued_underlay?bully_world_underlay_begin():bully_world_overlay_begin())){bully_overlay_stats[4]+=n/3;return;}
 for(unsigned i=0;i<n;i++){
  unsigned a=verts[i].color>>24;a=a>=128?255:a*2;verts[i].color=(verts[i].color&0xffffff)|(a<<24);verts[i].x*=.75f;verts[i].y*=272.0f/448.0f;verts[i].z=queued_underlay?65535.0f:0;
 }
 sceKernelDcacheWritebackRange(verts,n*sizeof *verts);start();
 if(queued_underlay){sceGuEnable(GU_DEPTH_TEST);sceGuDepthFunc(GU_LEQUAL);sceGuDepthMask(GU_FALSE);}else{sceGuDisable(GU_DEPTH_TEST);sceGuDepthMask(GU_TRUE);}sceGuDisable(GU_CULL_FACE);sceGuDisable(GU_LIGHTING);sceGuDisable(GU_FOG);
 unsigned x0=s->scissor&2047,x1=((s->scissor>>16)&2047)+1,y0=(s->scissor>>32)&2047,y1=((s->scissor>>48)&2047)+1;
 if(x0>640)x0=640;if(x1>640)x1=640;if(y0>448)y0=448;if(y1>448)y1=448;
 sceGuScissor(x0*480/640,y0*272/448,(x1*480+639)/640,(y1*272+447)/448);sceGuEnable(GU_SCISSOR_TEST);
 if(prim&64){sceGuEnable(GU_BLEND);sceGuBlendFunc(GU_ADD,GU_SRC_ALPHA,GU_ONE_MINUS_SRC_ALPHA,0,0);}else sceGuDisable(GU_BLEND);
 if((s->test&1) && !(((s->test>>12)&3)==1 && (s->zbuf&(UINT64_C(1)<<32)))){static const int funcs[]={GU_NEVER,GU_ALWAYS,GU_LESS,GU_LEQUAL,GU_EQUAL,GU_GEQUAL,GU_GREATER,GU_NOTEQUAL};unsigned ref=(s->test>>4)&255;sceGuEnable(GU_ALPHA_TEST);sceGuAlphaFunc(funcs[(s->test>>1)&7],ref>=128?255:ref*2,255);}else sceGuDisable(GU_ALPHA_TEST);
 if(tex){
  TcPspTex*t=&tex->tex;unsigned char*base=arena+tex->offset;
  sceGuTexMode(t->psm,0,0,t->swizzled);sceGuTexImage(0,t->level[0].width,t->level[0].height,t->level[0].bufw,base+t->level[0].offset);
  sceGuClutMode(t->clut_psm,0,t->clut_entries-1,0);sceGuClutLoad(t->clut_bytes/32,base+t->clut_offset);sceGuTexFlush();
  sceGuTexFunc(GU_TFX_MODULATE|(1<<16),(s->tex0&(UINT64_C(1)<<34))?GU_TCC_RGBA:GU_TCC_RGB);
  int filter=((s->tex1>>5)&1)?GU_LINEAR:GU_NEAREST;sceGuTexFilter(filter,filter);
  sceGuTexWrap((s->clamp&3)==1?GU_CLAMP:GU_REPEAT,((s->clamp>>2)&3)==1?GU_CLAMP:GU_REPEAT);
  sceGuTexScale(1,1);sceGuTexOffset(0,0);sceGuEnable(GU_TEXTURE_2D);
 }else sceGuDisable(GU_TEXTURE_2D);
 sceGuPixelMask((uint32_t)(s->frame>>32));sceGuShadeModel(GU_SMOOTH);
 sceGuDrawArray(GU_TRIANGLES,GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_2D,n,0,verts);
 sceGuPixelMask(0);sceGuScissor(0,0,480,272);sceGuTexFunc(GU_TFX_MODULATE,GU_TCC_RGBA);finish();bully_overlay_stats[0]+=n/3;bully_overlay_stats[1]++;
}
void bully_overlay_underlay_flush(void){if(queued_underlay)bully_overlay_flush();}
/* Accept only the observed far-plane sky case. No depth approximation for
 * arbitrary world primitives or framebuffer feedback effects. */
static int sky_underlay(unsigned prim,const BullyOverlayContext*s,const BullyOverlayVertex*v,unsigned n){
 if(n!=3 || (prim&16) || ((prim&7)!=3 && (prim&7)!=4) || (s->test&0x4001) ||
    !(s->test&(1u<<16)) || ((s->test>>17)&3)!=2 ||
    (s->zbuf&(UINT64_C(1)<<32)) || ((s->zbuf>>24)&15)!=1 ||
    ((s->frame>>24)&63)!=0)return 0;
 for(unsigned i=0;i<n;i++)if(v[i].z!=0)return 0;
 return 1;
}
static void state(void*o){(void)o;bully_overlay_flush();}
static void draw(void*o,unsigned prim,const BullyOverlayContext*s,const BullyOverlayVertex*v,unsigned n){
 (void)o;bully_overlay_stats[8]++;
 int underlay=sky_underlay(prim,s,v,n);
 /* Fixed-UV overlays plus untextured far-plane sky triangles. */
 if((prim&0xa0) || ((prim&16)&&(!(prim&256)||((s->tex0>>35)&3))) || (prim&64 && s->alpha!=0x44) || (s->test&(1u<<14)) || ((s->test&1) && ((s->test>>12)&3) && !(((s->test>>12)&3)==1 && (s->zbuf&(UINT64_C(1)<<32)))) || (!underlay && (s->test&(1u<<16)) && ((s->test>>17)&3)!=1) || (s->clamp&10) || (!underlay && (s->test&(1u<<16)) && !(s->zbuf&(UINT64_C(1)<<32)))){bully_overlay_stats[2]++;return;}
 if(queued && queued_underlay!=underlay)bully_overlay_flush();
 queued_underlay=underlay;
 unsigned add=n==2?6:3;if(queued+add>384)bully_overlay_flush();
 queued_prim=prim;queued_state=*s;
 if(n==2){
  BullyOverlayVertex q[4]={v[0],v[0],v[0],v[1]};q[1].x=v[1].x;q[1].u=v[1].u;q[2].y=v[1].y;q[2].v=v[1].v;
  /* Sprite color and Z are from the second vertex. */
  for(unsigned i=0;i<4;i++){q[i].color=v[1].color;q[i].z=v[1].z;}
  verts[queued++]=q[0];verts[queued++]=q[1];verts[queued++]=q[2];verts[queued++]=q[2];verts[queued++]=q[1];verts[queued++]=q[3];
 }else for(unsigned i=0;i<3;i++)verts[queued++]=v[i];
}
static void upload(void*o,uint64_t b,uint32_t a,uint32_t n){
 (void)o;if(a>hle_ram_end || n>hle_ram_end-a || n<80)return;
 uint64_t pos,dir;memcpy(&pos,hle_ram+a+16,8);memcpy(&dir,hle_ram+a+48,8);if(pos||dir)return;
 bully_overlay_flush();uploads[(b>>32)&16383]=(Upload){a,n,++serial};bully_overlay_stats[9]++;
}
static void reg(void*o,unsigned r,uint64_t v){
 (void)o;
 if(r==0x50)transfer_destination=v;
 if(r==0x53 && (v&3)!=1 && (v&3)!=3){
  /* A partial/unsupported write must never retain an older native upload. */
  bully_overlay_flush();uploads[(transfer_destination>>32)&16383]=(Upload){0};
 }
 bully_overlay_geometry_reg(&geom,r,v);
}
void bully_overlay_dma_begin(void){
 blocked=0;if(initialized)return;initialized=1;bully_gif_init(&paths[0],reg,upload,0);bully_gif_init(&paths[1],reg,upload,0);bully_vif_init(&vif,&paths[1]);bully_overlay_geometry_init(&geom,state,draw,0);
}
void bully_overlay_dma_feed(unsigned ch,const void*p,unsigned n,uint32_t addr){
 if(!initialized)bully_overlay_dma_begin();if(blocked)return;
 int ok=ch==2?bully_gif_feed(&paths[0],p,n,addr):ch==1?bully_vif_feed(&vif,p,n,addr):1;
 if(!ok){bully_overlay_flush();blocked=1;geom.count=0;bully_overlay_stats[5]++;if(ch==1)vif.skip=vif.direct=vif.used=0;}
}
