/* Bounded PSP output for Bully. The IOP/SPU2 remains on the game thread;
 * only resampled PCM crosses to the audio thread. Shared PS2RC synchronizer:
 * 0.1.1 / 332a437f21f7ef694943caef885a7d28410cbc41, audio/audio_stretch.*. */
#include "hle.h"
#include "audio_stretch.h"
#include <pspaudio.h>
#include <pspkernel.h>

#define RING_FRAMES 16384u
struct Output {
    AsRing ring;
    AsResampler resampler;
    AudioStretch stretch;
    int16_t pcm[RING_FRAMES*2];
    int16_t block[2][AS_HOP*2] __attribute__((aligned(64)));
    SceUID thread;
    int channel;
    volatile int quit, error;
    uint32_t blocks, silent_blocks;
};
static struct Output *output;

static int feeder(SceSize size,void *arg) {
    (void)size;(void)arg;
    struct Output *o=output;
    uint64_t last=sceKernelGetSystemTimeWide(),carry=0;
    unsigned bank=0;
    while(!o->quit) {
        uint64_t now=sceKernelGetSystemTimeWide();
        uint64_t frames=(now-last)*AS_RATE+carry;
        last=now;carry=frames%1000000u;
        int sound=as_hop(&o->stretch,o->block[bank],(uint32_t)(frames/1000000u));
        if(!sound)o->silent_blocks++;
        /* Silence is explicit during prebuffering/starvation; keep the device
         * clock running. The synchronizer fades the last grain on underrun. */
        sceKernelDcacheWritebackRange(o->block[bank],sizeof(o->block[bank]));
        int rc=sceAudioOutputPannedBlocking(o->channel,PSP_AUDIO_VOLUME_MAX,
                                            PSP_AUDIO_VOLUME_MAX,o->block[bank]);
        if(rc<0){o->error=rc;break;}
        o->blocks++;bank^=1;
    }
    return 0;
}

static int init(void) {
    struct Output *o=hle_plat_big_alloc(sizeof(*o));
    o->channel=-1;o->thread=-1;
    as_ring_init(&o->ring,o->pcm,RING_FRAMES);
    as_init(&o->stretch,&o->ring,AS_STRETCH,4096,4u*AS_ONE);
    o->stretch.smin=AS_ONE;
    /* Regular PSP channels run at 44.1 kHz; movie SRC owns its own rate. */
    o->channel=sceAudioChReserve(PSP_AUDIO_NEXT_CHANNEL,AS_HOP,PSP_AUDIO_FORMAT_STEREO);
    if(o->channel<0)return o->channel;
    o->thread=sceKernelCreateThread("bully_audio_out",feeder,0x12,8192,THREAD_ATTR_USER,NULL);
    if(o->thread<0){sceAudioChRelease(o->channel);return o->thread;}
    output=o; /* Publish initialized state before the thread starts. */
    int rc=sceKernelStartThread(o->thread,0,NULL);
    if(rc<0){output=NULL;sceKernelDeleteThread(o->thread);sceAudioChRelease(o->channel);return rc;}
    LOG("AUDIO PSP: buffered 44100 Hz stereo; %u byte state, 8192 byte stack, 93 ms target, 1x..4x stretch\n",(unsigned)sizeof(*o));
    return 0;
}

int bully_audio_output_push(const int16_t *pcm,uint32_t frames) {
    if(!output){int rc=init();if(rc<0)return rc;}
    if(output->error)return output->error;
    int16_t resampled[2*65];
    while(frames) {
        uint32_t n=frames<64?frames:64;
        uint32_t count=as_resample48(&output->resampler,pcm,n,resampled);
        as_ring_write(&output->ring,resampled,count);
        pcm+=n*2;frames-=n;
    }
    return 0;
}

void bully_audio_output_shutdown(void) {
    struct Output *o=output;
    if(!o)return;
    o->quit=1;
    sceKernelWaitThreadEnd(o->thread,NULL);
    sceKernelDeleteThread(o->thread);
    sceAudioChRelease(o->channel);
    LOG("AUDIO PSP: output blocks=%u silent_blocks=%u dropped_frames=%u error=%08x\n",
        o->blocks,o->silent_blocks,o->ring.lost,(unsigned)o->error);
    output=NULL; /* State belongs to the bounded runtime arena, freed at exit. */
}
