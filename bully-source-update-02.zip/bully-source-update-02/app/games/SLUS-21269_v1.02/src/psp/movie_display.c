/* Native movie presentation. Submit pictures through GE so PPSSPP's direct
 * rendering (Skip buffer effects) sees an actual draw, rather than a CPU-only
 * VRAM update. Decoder storage remains owned until the synchronous draw ends.
 */
#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspge.h>
#include <pspdebug.h>
#include <pspgu.h>
#include "hle.h"

#define STRIDE 512u
#define WIDTH 480u
#define HEIGHT 272u
#define FB_BYTES (STRIDE * HEIGHT * 4u)
int hle_ge_on;
static unsigned pictures;
static unsigned movie_list[256] __attribute__((aligned(16)));
typedef struct { float u,v; float x,y,z; } MovieVertex;
static MovieVertex movie_vertices[2] __attribute__((aligned(16))) = {
    {0,0,0,0,0}, {480,272,480,272,0}
};

void hle_ge_movie_frame(const void *pic,int rgba8888,uint32_t dump);

int bully_movie_display_init(void)
{
    void bully_world_shutdown(void);
    bully_world_shutdown();
    if (hle_ge_on) return 1;
    if (sceGeEdramGetSize() < 2 * FB_BYTES || sceDisplaySetMode(0, WIDTH, HEIGHT) < 0) return 0;
    if (sceGuInit() < 0) return 0;
    sceGuStart(GU_DIRECT,movie_list);
    sceGuDrawBuffer(GU_PSM_8888,(void *)0,STRIDE);
    sceGuDispBuffer(WIDTH,HEIGHT,(void *)(uintptr_t)FB_BYTES,STRIDE);
    sceGuOffset(2048-WIDTH/2,2048-HEIGHT/2);
    sceGuViewport(2048,2048,WIDTH,HEIGHT);
    sceGuScissor(0,0,WIDTH,HEIGHT);sceGuEnable(GU_SCISSOR_TEST);
    sceGuDisable(GU_DEPTH_TEST);sceGuDisable(GU_CULL_FACE);
    sceGuDisable(GU_BLEND);sceGuDisable(GU_ALPHA_TEST);sceGuDisable(GU_LIGHTING);
    sceGuTexFilter(GU_NEAREST,GU_NEAREST);sceGuTexWrap(GU_CLAMP,GU_CLAMP);
    sceGuTexFunc(GU_TFX_REPLACE,GU_TCC_RGB);
    sceGuTexScale(1.0f,1.0f);sceGuTexOffset(0.0f,0.0f);
    sceGuClearColor(0xff000000u);sceGuClear(GU_COLOR_BUFFER_BIT);
    sceGuFinish();sceGuSync(0,0);sceGuDisplay(GU_TRUE);
    pictures = 0;
    hle_ge_on = 1;
    hle_ge_movie_frame(NULL,1,0); /* Prime both display targets before decoding. */
    return 1;
}

int hle_ge_movie_begin(void) { return hle_ge_on; }

void hle_ge_movie_frame(const void *pic, int rgba8888, uint32_t dump)
{
    (void)dump; /* Frame dumps are a developer option of the full GE backend. */
    if (!hle_ge_on) return;
    /* Black both targets at initialization/end; neither can retain a picture. */
    for(unsigned pass=0;pass<(pic?1u:2u);pass++) {
    sceGuStart(GU_DIRECT,movie_list);
    if (!pic) sceGuClear(GU_COLOR_BUFFER_BIT);
    else {
        /* MPEG DMA owns the decoder output. Invalidate the CPU view as before;
         * do not write stale cached lines over it. GE sync protects its reuse. */
        sceKernelDcacheInvalidateRange(pic,STRIDE*HEIGHT*(rgba8888?4u:2u));
        sceKernelDcacheWritebackRange(movie_vertices,sizeof(movie_vertices));
        sceGuEnable(GU_TEXTURE_2D);
        sceGuTexMode(rgba8888?GU_PSM_8888:GU_PSM_5650,0,0,0);
        sceGuTexImage(0,512,512,STRIDE,pic);
        sceGuTexFlush();
        sceGuDrawArray(GU_SPRITES,GU_TEXTURE_32BITF|GU_VERTEX_32BITF|GU_TRANSFORM_2D,
                       2,0,movie_vertices);
        pictures++;
    }
    sceGuFinish();sceGuSync(0,0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
    }
}

void hle_ge_movie_end(void) { hle_ge_movie_frame(NULL, 1, 0); }

void bully_movie_display_shutdown(void)
{
    if (!hle_ge_on) return;
    sceGuSync(0,0);sceGuDisplay(GU_FALSE);sceGuTerm();
    hle_ge_on = 0;
    pspDebugScreenInit();
    LOG("Bully movie display: %u pictures presented; GE movie path ended\n", pictures);
}
