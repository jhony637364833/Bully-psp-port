#ifndef BULLY_NATIVE_VIF_H
#define BULLY_NATIVE_VIF_H
#include "native_gif.h"
typedef struct {
 BullyGif *gif;
 uint32_t direct,skip;
 unsigned cl,wl,used,quad_linear;
 unsigned char quad[16];
 uint32_t quad_addr;
 uint64_t commands,unsupported;
} BullyVif;
void bully_vif_init(BullyVif *,BullyGif *);
int bully_vif_feed(BullyVif *,const void *,size_t,uint32_t);
#endif
