#include "native_light.h"
#include <math.h>
#include <string.h>
static int range(size_t bytes, uint32_t at, size_t n) {
    return at >= 4 && !(at & 3) && at <= bytes && n <= bytes-at;
}
static uint32_t word(const uint8_t *p) {
    return (uint32_t)p[0] | (uint32_t)p[1]<<8 | (uint32_t)p[2]<<16 | (uint32_t)p[3]<<24;
}
static float scalar(const uint8_t *p) {
    uint32_t u=word(p);float f;memcpy(&f,&u,4);return f;
}
int bully_native_light(const uint8_t *ram,size_t bytes,uint32_t pipe,
                       uint32_t gp,BullyNativeLight *out) {
    BullyNativeLight result={0};
    if(!ram || !out || !range(bytes,pipe,72) || gp<7496 ||
       !range(bytes,gp-7496,96) || !range(bytes,0x6d5270,32))return 0;
    uint32_t slot=word(ram+pipe+48),props=word(ram+pipe+60);
    if(!range(bytes,slot,4) || props<16 || !range(bytes,props-12,24))return 0;
    result.material_id=props-12;
    uint32_t entry=word(ram+slot);
    if(!range(bytes,entry,36))return 0;
    result.stream=word(ram+entry+32);
    if((result.stream&15) || !range(bytes,result.stream,16) ||
       (word(ram+result.stream)&0xffff0000u)!=0x10000000u)return 0;
    /* Original object setup emits STCYCL(4,4), UNPACK V4-32 at VU slot 976.
     * The first vector is ambient RGB with a nonzero lighting type in W. */
    if(word(ram+0x6d5278)!=0x01000404u ||
       (word(ram+0x6d527c)&0xff00ffffu)!=0x6c0003d0u ||
       !((word(ram+0x6d527c)>>16)&255) || !word(ram+0x6d528c))return 0;
    result.blend=scalar(ram+gp-7404);
    result.monochrome=word(ram+gp-7496)!=0;
    float ambient=scalar(ram+props);
    if(!isfinite(result.blend) ||
       !isfinite(ambient) || ambient<0)return 0;
    for(unsigned k=0;k<3;k++) {
        float light=scalar(ram+0x6d5280+4*k);
        /* VU program 0x567170: ambient * surface ambient * 255.000015,
         * then 0.0039215, followed by material RGB * 1/510.
         * world_display converts GS's 128-neutral color to PSP's 255 range. */
        result.gain[k]=light*(ambient*255.00001525878906f)*0.0039215f;
        result.material[k]=ram[pipe+68+k]*0.0019607844296842813f;
        if(!isfinite(light) || light<0 || !isfinite(result.gain[k]))return 0;
    }
    result.material_alpha=ram[pipe+71]*0.001970011740922928f;
    *out=result;return 1;
}
void bully_light_color(const BullyNativeVertex *v,const BullyNativeLight *light,float rgb[3]) {
    /* Monochrome uses the same prelight channel for all three outputs.
     * Compute its interpolation once; keep gain, clamp and material per RGB.
     * Retain the original arithmetic even for zero blend and signed zeros. */
    if(light->monochrome) {
        float a=(float)v->color[0]+12.0f;
        float b=(float)v->color_secondary[0]+12.0f;
        float mixed=a+(b-a)*light->blend;
        for(unsigned k=0;k<3;k++) {
            float lit=mixed*light->gain[k];
            rgb[k]=(lit<255.0f?lit:255.0f)*light->material[k]*2.0f;
        }
    } else {
        for(unsigned k=0;k<3;k++) {
            float a=v->color[k],b=v->color_secondary[k];
            float lit=(a+(b-a)*light->blend)*light->gain[k];
            rgb[k]=(lit<255.0f?lit:255.0f)*light->material[k]*2.0f;
        }
    }
}

/* VU 0x56717c: W banks add (089), gain.W is one (06a), clamp to255
 * before material.W (0a0/0a4). GS alpha128 maps to PSP alpha255. */
float bully_light_alpha(const BullyNativeVertex *v,const BullyNativeLight *light) {
    float alpha=(float)v->color[3]+v->color_secondary[3];
    return (alpha<255.0f?alpha:255.0f)*
           light->material_alpha*2.0f;
}
