#ifndef BULLY_OVERLAY_TEXTURE_H
#define BULLY_OVERLAY_TEXTURE_H
#include "texconv.h"
int bully_overlay_texture_plan(const uint8_t*,size_t,uint64_t,uint32_t,uint32_t,uint32_t,uint32_t,TcPs2Info*,TcPolicy*,TcPspTex*);
#endif
