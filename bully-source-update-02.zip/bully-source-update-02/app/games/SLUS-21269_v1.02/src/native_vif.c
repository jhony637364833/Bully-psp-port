#include "native_vif.h"
#include <string.h>
/* Command classes select existing handlers; unsupported encodings stay rejected. */
static const unsigned char command_class[128]={
 0,3,0,0,0,0,0,0,1,1,1,1,1,1,1,1,
 0,0,1,0,0,0,1,0,1,1,1,1,1,1,1,1,
 4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
 5,5,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
 1,1,1,1,1,1,1,1,1,1,6,1,1,1,1,1,
 2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
 7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
 7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
};
void bully_vif_init(BullyVif*p,BullyGif*g){memset(p,0,sizeof *p);p->gif=g;p->cl=p->wl=1;}
int bully_vif_feed(BullyVif*p,const void*data,size_t bytes,uint32_t addr){
 if(!p||!p->gif||(!data&&bytes)||(bytes&3)||bytes>UINT32_MAX||bytes>UINT32_MAX-addr)return 0;
 const unsigned char*s=data;
 while(bytes){
  if(p->skip){size_t n=bytes<p->skip?bytes:p->skip;s+=n;addr+=(uint32_t)n;bytes-=n;p->skip-=(uint32_t)n;continue;}
  if(p->direct){
   size_t n=bytes<p->direct?bytes:p->direct;
   if(p->used || n<16){
    size_t take=16-p->used;if(take>n)take=n;if(!p->used){p->quad_addr=addr;p->quad_linear=1;}
    /* Noncontiguous fragments still render, but cannot establish a native
     * upload header/source: invalidate that optimization conservatively. */
    if(addr!=p->quad_addr+p->used)p->quad_linear=0;
    memcpy(p->quad+p->used,s,take);p->used+=(unsigned)take;s+=take;addr+=(uint32_t)take;bytes-=take;p->direct-=(uint32_t)take;
    if(p->used==16){if(!p->quad_linear)p->gif->upload_ok=0;if(!bully_gif_feed(p->gif,p->quad,16,p->quad_addr))return 0;if(!p->quad_linear)p->gif->upload_ok=0;p->used=0;}
   }else{
    n&=~(size_t)15;if(!bully_gif_feed(p->gif,s,n,addr))return 0;s+=n;addr+=(uint32_t)n;bytes-=n;p->direct-=(uint32_t)n;
   }
   continue;
  }
  uint32_t code;memcpy(&code,s,4);s+=4;addr+=4;bytes-=4;p->commands++;
  unsigned cmd=(code>>24)&127,num=(code>>16)&255,imm=code&65535;
  switch(command_class[cmd]) {
  case 0:continue;
  case 2:{p->direct=imm*16u;p->skip=(16-(addr&15))&15;continue;}
  case 3:{p->cl=imm&255;p->wl=imm>>8;if(!p->cl)p->cl=256;if(!p->wl)p->wl=256;continue;}
  case 4:{p->skip=4;continue;}
  case 5:{p->skip=16;continue;}
  case 6:{p->skip=(num?num:256)*8;continue;}
  case 7:{
   unsigned count=num?num:256,components=((cmd>>2)&3)+1,vl=cmd&3;
   if(p->wl>p->cl)count=count/p->wl*p->cl+(count%p->wl<p->cl?count%p->wl:p->cl);
   if(vl==3){if(components!=4){p->unsupported++;return 0;}p->skip=(count*16+31)/32*4;}
   else p->skip=(count*components*(32>>vl)+31)/32*4;
   continue;
  }
  default:p->unsupported++;return 0;
  }
 }
 return 1;
}
