#ifndef BULLY_CLIP_LERP_H
#define BULLY_CLIP_LERP_H
#include <stdint.h>
#include <string.h>

/* Exact binary32 result of the reference double interpolation. Allegrex has
 * no hardware doubles. For nearby, same-sign normal endpoints, use a Q32
 * weight and integer magnitudes, then prove that its error interval lies in
 * one binary32 rounding cell. Near a rounding boundary, or outside this
 * bounded domain, retain the original double expression.
 *
 * A and B are exact endpoint significands on a common power-of-two scale,
 * at most 31 bits (exponents differ by at most 7). Truncating t to Q32 adds
 * less than |B-A| units of error. The reference's subtraction, two products
 * and sum add less than max(A,B)*2^-16 units on this scale: each operation
 * has at most 2^-52 relative error, and the final scale factor is 2^32.
 * We conservatively reserve max(A,B)*2^-15 + 4, including integer rounding.
 * Accept only if this entire interval stays strictly on one side of the
 * nearest half-ULP boundary. Also require error < quarter ULP, protecting
 * the smaller rounding cell immediately below a power of two.
 * Integer arithmetic also avoids PSP FTZ effects.
 * No assumptions about scene ranges, UVs or color uniformity are required.
 */
typedef struct {
    double t,complement;
    uint32_t q32;
    int bounded;
} BullyClipWeight;

static inline BullyClipWeight bully_clip_weight(double t)
{
    BullyClipWeight w={t,1-t,0,0};
    uint64_t bits;
    memcpy(&bits,&t,sizeof(bits));
    unsigned exponent=(unsigned)(bits>>52);
    /* Positive, finite t strictly below 1. t==0/1 use the reference path. */
    if(!exponent || exponent>=1023)return w;
    w.bounded=1;
    if(exponent>=991) {
        uint64_t significand=(bits&UINT64_C(0xfffffffffffff))|UINT64_C(0x10000000000000);
        w.q32=(uint32_t)(significand>>(1043-exponent));
    }
    return w;
}
static inline float bully_clip_lerp(float u,float v,const BullyClipWeight *w)
{
    uint32_t ub,vb;
    memcpy(&ub,&u,sizeof(ub));memcpy(&vb,&v,sizeof(vb));
    /* With identical finite endpoints, the convex double expression differs
     * by at most a few binary64 ULPs, far less than half a binary32 ULP.
     * Signed zero is retained because both products have the same sign. */
    if(w->bounded && ub==vb && (ub&0x7f800000u)!=0x7f800000u)return u;
    /* A single zero term cannot change a nonzero double product. Restrict
     * tiny t for the zero-u case so the product cannot underflow in double;
     * 1-t is at least 2^-53 throughout the bounded domain. Opposite signed
     * zero endpoints keep the reference's zero-addition sign rule. */
    if(w->bounded) {
        if(!(ub&0x7fffffffu) && (vb&0x7fffffffu) &&
           (vb&0x7f800000u)!=0x7f800000u && w->q32)
            return (float)(w->t*(double)v);
        if(!(vb&0x7fffffffu) && (ub&0x7fffffffu) &&
           (ub&0x7f800000u)!=0x7f800000u)
            return (float)(w->complement*(double)u);
    }
    if(w->bounded && !((ub^vb)&0x80000000u)) {
        unsigned ue=(ub>>23)&255,ve=(vb>>23)&255;
        unsigned difference=ue>ve?ue-ve:ve-ue;
        if(ue && ve && ue<255 && ve<255 && difference<=7) {
            uint32_t a=(ub&0x7fffffu)|0x800000u,b=(vb&0x7fffffu)|0x800000u;
            unsigned base=ue<ve?ue:ve;
            if(ue>ve)a<<=difference;else b<<=difference;
            uint32_t delta=a>b?a-b:b-a,maximum=a>b?a:b;
            uint64_t q=(uint64_t)a<<32;
            uint64_t product=(uint64_t)delta*w->q32;
            if(b>=a)q+=product;else q-=product;
            uint64_t error=(uint64_t)delta+(maximum>>15)+4;
            unsigned leading=__builtin_clz((uint32_t)(q>>32));
            unsigned shift=40-leading;
            uint64_t half=UINT64_C(1)<<(shift-1);
            uint64_t remainder=q&((UINT64_C(1)<<shift)-1);
            uint64_t gap=remainder>half?remainder-half:half-remainder;
            if(error<(half>>1) && gap>error) {
                uint32_t significand=(uint32_t)(q>>shift)+(remainder>half);
                unsigned exponent=base+8-leading;
                if(significand==0x1000000u) {significand>>=1;exponent++;}
                uint32_t result=(ub&0x80000000u)|(exponent<<23)|(significand&0x7fffffu);
                float f;memcpy(&f,&result,sizeof(f));return f;
            }
        }
    }
    return (float)(w->complement*u+w->t*v);
}
#endif
