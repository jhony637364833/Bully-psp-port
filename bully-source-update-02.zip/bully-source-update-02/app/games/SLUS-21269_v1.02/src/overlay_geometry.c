#include "overlay_geometry.h"
#include <string.h>
void bully_overlay_geometry_init(BullyOverlayGeometry*p,void(*state)(void*),void(*draw)(void*,unsigned,const BullyOverlayContext*,const BullyOverlayVertex*,unsigned),void*o){
 memset(p,0,sizeof *p);p->state=state;p->draw=draw;p->opaque=o;p->prmodecont=1;
}
void bully_overlay_geometry_reg(BullyOverlayGeometry*p,unsigned r,uint64_t v){
 if(r==1){p->rgba=v;return;}if(r==3){p->uv=v;return;}
 unsigned prim=(unsigned)(p->prmodecont?p->prim:(p->prim&7)|(p->prmode&~UINT64_C(7))),type=prim&7;
 const BullyOverlayContext *s=&p->ctx[(prim>>9)&1];
 if(r==5 || r==13){
  BullyOverlayVertex a={(p->uv&0x3fff)/16.0f,((p->uv>>16)&0x3fff)/16.0f,(uint32_t)p->rgba,((int)(v&65535)-(int)(s->offset&65535))/16.0f,((int)((v>>16)&65535)-(int)((s->offset>>32)&65535))/16.0f,(float)(uint32_t)(v>>32)};
  if(type!=3 && type!=4 && type!=6){p->count=0;return;}
  if((type==6 && p->count==1) || (type!=6 && p->count==2)){
   BullyOverlayVertex out[3]={p->history[0],p->history[1],a};unsigned n=3;
   if(type==6){out[1]=a;n=2;}
   if(!(prim&8))for(unsigned i=0;i<n;i++)out[i].color=a.color;
   if(r==5 && p->draw)p->draw(p->opaque,prim,s,out,n);
   if(type==4){p->history[0]=p->history[1];p->history[1]=a;}else p->count=0;
  }else p->history[p->count++]=a;
  return;
 }
 if(r==0){if(p->prim!=v && p->state)p->state(p->opaque);p->prim=v;p->count=0;return;}
 if(r==0x1a || r==0x1b){if(p->state)p->state(p->opaque);if(r==0x1a)p->prmodecont=v&1;else p->prmode=v;p->count=0;return;}
 uint64_t *dst=0;
 switch(r){
 case 6:case 7:dst=&p->ctx[r-6].tex0;break;
 case 8:case 9:dst=&p->ctx[r-8].clamp;break;
 case 0x14:case 0x15:dst=&p->ctx[r-0x14].tex1;break;
 case 0x18:case 0x19:dst=&p->ctx[r-0x18].offset;break;
 case 0x40:case 0x41:dst=&p->ctx[r-0x40].scissor;break;
 case 0x42:case 0x43:dst=&p->ctx[r-0x42].alpha;break;
 case 0x47:case 0x48:dst=&p->ctx[r-0x47].test;break;
 case 0x4c:case 0x4d:dst=&p->ctx[r-0x4c].frame;break;
 case 0x4e:case 0x4f:dst=&p->ctx[r-0x4e].zbuf;break;
 default:break;
 }
 if(dst && *dst!=v){if(p->state)p->state(p->opaque);*dst=v;}
}
