#include "world_clip.h"
#include "clip_lerp.h"
#include "clip_memo.h"
#include <math.h>
#include <string.h>
#include <stdint.h>
/* Order finite binary32 values using integer comparisons. Canonicalize signed
 * zero so this also matches double subtraction at zero. Integer ordering keeps
 * subnormal inputs exact on PSP, where arithmetic may flush them.
 * Callers validate finiteness before using this helper. */
static uint32_t order_key(float value)
{
    uint32_t bits;
    memcpy(&bits,&value,sizeof(bits));
    /* Clear only negative zero, then flip positive sign bits or complement
     * negative values. Unsigned masks keep the PSP ordering path branchless. */
    bits&=0u-(uint32_t)((bits&0x7fffffffu)!=0);
    return bits^((0u-(bits>>31))|0x80000000u);
}
static int outside(const BullyClipVertex *v,int plane,uint32_t near,uint32_t far)
{
    switch(plane) {
    case 0:return order_key(v->p[2])<near;
    case 1:return order_key(v->p[2])>far;
    case 2:return order_key(v->p[0])<0x80000000u;
    case 3:return order_key(v->p[0])>order_key(v->p[2]);
    case 4:return order_key(v->p[1])<0x80000000u;
    default:return order_key(v->p[1])>order_key(v->p[2]);
    }
}
static double distance_to(const BullyClipVertex *v, int plane, double near, double far)
{
    switch(plane) {
    case 0:return (double)v->p[2]-near;
    case 1:return far-v->p[2];
    case 2:return v->p[0];
    case 3:return (double)v->p[2]-v->p[0];
    case 4:return v->p[1];
    default:return (double)v->p[2]-v->p[1];
    }
}
/* Public plane validation leaves the FP comparison condition clear for finite
 * planes. Finite vertex classification needs no FP comparison; retain the
 * original isfinite operation for nonfinite inputs and their exception state. */
static __attribute__((noinline,cold)) int vertex_nonfinite(float value)
{
    return isfinite(value);
}
static int vertex_finite(float value)
{
    uint32_t bits;
    memcpy(&bits,&value,sizeof(bits));
    if((bits&0x7f800000u)!=0x7f800000u)return 1;
    return vertex_nonfinite(value);
}
int bully_clip_vertex_code(const BullyClipVertex *v,float near,float far)
{
    if(!v || !isfinite(near) || !isfinite(far) || near<=0 || far<=near)return -1;
    for(int k=0;k<3;k++)if(!vertex_finite(v->p[k]) || !vertex_finite(v->color[k]))return -1;
    if(!vertex_finite(v->uv[0]) || !vertex_finite(v->uv[1]) || !vertex_finite(v->alpha))return -1;
    uint32_t x=order_key(v->p[0]),y=order_key(v->p[1]),z=order_key(v->p[2]);
    return (z<order_key(near)) | ((z>order_key(far))<<1) |
           ((x<0x80000000u)<<2) | ((x>z)<<3) |
           ((y<0x80000000u)<<4) | ((y>z)<<5);
}
static int clip_triangle(const BullyClipVertex input[3], float near, float far,
                         BullyClipVertex output[10],BullyClipCache *cache,BullyClipMemo *memo,const int codes[3])
{
    BullyClipVertex a[10],b[10];
    if(!input || !output || !isfinite(near) || !isfinite(far) || near<=0 || far<=near) return 0;
    if(cache) {
        uint32_t nb,fb;memcpy(&nb,&near,4);memcpy(&fb,&far,4);
        if(!cache->initialized || cache->near_bits!=nb || cache->far_bits!=fb) {
            memset(cache->count,0,sizeof(cache->count));
            cache->near_bits=nb;cache->far_bits=fb;cache->initialized=1;
        }
    }
    /* Share finite-input validation and outcodes with the strip vertex cache. */
    unsigned any=0,common=63;
    uint32_t near_key=order_key(near),far_key=order_key(far);
    for(int i=0;i<3;i++) {
        /* Negative classifications may have raised an FP exception (for a
         * signaling NaN). Re-run that case to preserve its original state. */
        int code=codes && codes[i]>=0?codes[i]:bully_clip_vertex_code(&input[i],near,far);
        if(code<0)return 0;
        any|=(unsigned)code;common&=(unsigned)code;
    }
    if(common)return 0;
    if(!any) { memcpy(output,input,3*sizeof(*output));return 3; }
    memcpy(a,input,3*sizeof(*a));
    int n=3;
    for(int plane=0;plane<6 && n;plane++) {
        /* A plane containing every current vertex only copies the polygon.
         * Check again after each intersection, retaining any rounded boundary
         * vertices that a later plane must clip. */
        unsigned char side[10];
        int crosses=0,all_outside=1;
        for(int i=0;i<n;i++) {
            side[i]=(unsigned char)outside(&a[i],plane,near_key,far_key);
            crosses|=side[i];all_outside&=side[i];
        }
        if(!crosses)continue;
        if(all_outside)return 0;
        int m=0;
        BullyClipEdge next[2];unsigned next_count=0;
        for(int i=0;i<n;i++) {
            const BullyClipVertex *u=&a[i],*v=&a[(i+1)%n];
            if(!side[i]) { if(m==10)return 0; b[m++]=*u; }
            if(side[i]!=side[(i+1)%n]) {
                if(m==10)return 0;
                /* PSP doubles are software operations. Only actual crossings
                 * need distances; side[] already gives the exact signs for
                 * every finite binary32 coordinate, including signed zero.
                 * Preserve intersection arithmetic and polygon order. */
                int hit=0;
                if(cache)for(unsigned e=0;e<cache->count[plane];e++) {
                    const BullyClipEdge *edge=&cache->edge[plane][e];
                    if(!memcmp(u,&edge->u,sizeof(*u)) && !memcmp(v,&edge->v,sizeof(*v))) {
                        b[m]=edge->result;hit=1;break;
                    }
                }
                BullyClipMemoEntry *pending=0;
                if(!hit && memo)hit=bully_clip_memo_lookup(memo,u,v,(unsigned)plane,near,far,&b[m],&pending);
                if(!hit) {
                    double du=distance_to(u,plane,near,far),dv=distance_to(v,plane,near,far);
                    double t=du/(du-dv);
                    BullyClipWeight weight=bully_clip_weight(t);
                    for(int k=0;k<3;k++) {
                        b[m].p[k]=bully_clip_lerp(u->p[k],v->p[k],&weight);
                        b[m].color[k]=bully_clip_lerp(u->color[k],v->color[k],&weight);
                    }
                    for(int k=0;k<2;k++)
                        b[m].uv[k]=bully_clip_lerp(u->uv[k],v->uv[k],&weight);
                    b[m].alpha=bully_clip_lerp(u->alpha,v->alpha,&weight);
                    bully_clip_memo_commit(memo,pending,&b[m]);
                }
                if(cache && next_count<2) {
                    next[next_count].u=*u;next[next_count].v=*v;
                    next[next_count].result=b[m];next_count++;
                }
                m++;
            }
        }
        if(cache) {
            /* Commit only after the whole plane: a first miss must not evict
             * a previous edge that the second crossing can still reuse. */
            memcpy(cache->edge[plane],next,next_count*sizeof(*next));
            cache->count[plane]=(unsigned char)next_count;
        }
        n=m;memcpy(a,b,(size_t)n*sizeof(*a));
    }
    if(n<3)return 0;
    memcpy(output,a,(size_t)n*sizeof(*a));return n;
}

void bully_clip_cache_reset(BullyClipCache *cache) {
    if(cache)cache->initialized=0;
}
int bully_clip_triangle(const BullyClipVertex input[3],float near,float far,
                        BullyClipVertex output[10]) {
    return clip_triangle(input,near,far,output,0,0,0);
}
int bully_clip_triangle_cached(const BullyClipVertex input[3],float near,float far,
                               BullyClipVertex output[10],BullyClipCache *cache) {
    return clip_triangle(input,near,far,output,cache,0,0);
}

int bully_clip_triangle_memoized(const BullyClipVertex input[3],float near,float far,
    BullyClipVertex output[10],BullyClipCache *cache,BullyClipMemo *memo) {
    return clip_triangle(input,near,far,output,cache,memo,0);
}

/* Renderer-private fast entry: codes must be the exact results for the three
 * current, unmodified vertices and the SAME near/far planes. The ordinary
 * public entries above retain their complete input classification. */
int bully_clip_triangle_classified(const BullyClipVertex input[3],float near,float far,
    const int codes[3],BullyClipVertex output[10],BullyClipCache *cache,BullyClipMemo *memo) {
    return clip_triangle(input,near,far,output,cache,memo,codes);
}
