#ifndef BULLY_NATIVE_STATE_H
#define BULLY_NATIVE_STATE_H
#include <stdint.h>
#include <stddef.h>
typedef struct {
    uint32_t stream, material;
    uint32_t test, alpha, alpha_fixed, zmask, blend;
} BullyNativeState;
/* Capture the compressed bridge's completed GS shadow registers. No RAM writes.
 * Keep unsupported blend equations/alpha-fail modes out of this adapter. */
int bully_native_state(const uint8_t *ram,size_t bytes,uint32_t pipe,
                       uint32_t gp,BullyNativeState *out);
/* Read the same supported GS shadow values without a compressed-stream identity. */
int bully_native_state_shadow(const uint8_t*,size_t,uint32_t,BullyNativeState*);
#endif
