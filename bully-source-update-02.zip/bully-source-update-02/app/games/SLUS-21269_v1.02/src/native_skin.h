#ifndef BULLY_NATIVE_SKIN_H
#define BULLY_NATIVE_SKIN_H
#include "native_mesh.h"
typedef void (*BullySkinVisit)(const BullyNativeVertex *, const uint8_t *, size_t, void *);
/* Observed0x25f118 skin format: REF weights, inline CNT/RET attributes.
 * Matrices are the original setup's current atomic-space palette,64 bytes/bone.
 * No allocation or guest execution. Scratch holds256 vertices. Validate with
 * visit=NULL before drawing; failure may change scratch but zeroes all counts.
 * skip[i] suppresses the triangle ending at vertex i (PS2 ADC bit).
 * Lighting is not reconstructed: output colors are neutral128.
 */
int bully_skin_chain(const uint8_t *ram,size_t bytes,uint32_t chain,
                     uint32_t palette,unsigned bones,BullyNativeVertex *scratch,
                     BullySkinVisit visit,void *context,size_t *count,
                     size_t *used,size_t *triangles);
#endif
