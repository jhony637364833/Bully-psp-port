/* Optional bounded, exact clipping-intersection memo. No allocation here.
 * Based on PS2RC by SandstoneDev: https://github.com/SandstoneDev/PS2RC */
#ifndef BULLY_CLIP_MEMO_H
#define BULLY_CLIP_MEMO_H
#include "world_clip.h"
#include <stdint.h>
#include <stddef.h>
#include <string.h>
typedef struct {
    BullyClipVertex u,v,result;
    uint32_t hash,near_bits,far_bits,before,after,plane,epoch;
} BullyClipMemoEntry;
typedef struct {
    BullyClipMemoEntry entry[2];unsigned replace;
    uint32_t seen[8],seen_epoch;
    unsigned seen_count,seen_replace;
} BullyClipMemoSet;
struct BullyClipMemo {
    BullyClipMemoSet *set;
    size_t sets;
    uint32_t epoch,bypass_mask;
    uint32_t (*read_fpu)(void);
    void (*write_fpu)(uint32_t);
    unsigned hits,misses,bypasses,admissions;
};
/* Storage is separate from all polygon/strip-cache/input/output buffers and
 * remains owned by this non-reentrant caller. sets must be a power of two;
 * initialized storage and both callbacks must remain valid while used. The
 * callbacks read/restore the SAME complete 32-bit FPU state without changing
 * any other state. For PSP, bypass_mask includes all exception-enable bits and the unimplemented-operation cause:
 * a cached result must never suppress an enabled floating-point trap.
 * Hashes select candidates ONLY: every key bit is compared before reuse. */
static inline int bully_clip_memo_init(BullyClipMemo *m,BullyClipMemoSet *storage,
    size_t sets,uint32_t (*read_fpu)(void),void (*write_fpu)(uint32_t),uint32_t bypass_mask)
{
    if(!m || !storage || !sets || (sets&(sets-1)) ||
       sets>SIZE_MAX/sizeof(*storage) || !read_fpu || !write_fpu)return 0;
    memset(storage,0,sets*sizeof(*storage));
    *m=(BullyClipMemo){.set=storage,.sets=sets,.epoch=1,.bypass_mask=bypass_mask,
        .read_fpu=read_fpu,.write_fpu=write_fpu};return 1;
}
/* O(1) invalidation while a camera changes. Only epoch wrap clears storage. */
static inline void bully_clip_memo_reset(BullyClipMemo *m)
{
    if(!m || !m->set)return;
    if(++m->epoch==0){memset(m->set,0,m->sets*sizeof(*m->set));m->epoch=1;}
}
static inline uint32_t bully_clip_memo_hash(const BullyClipVertex *u,
    const BullyClipVertex *v,uint32_t near,uint32_t far,uint32_t plane,uint32_t fpu)
{
    uint32_t h=near^(far*0x9e3779b9u)^(plane*0x85ebca6bu)^fpu;
    const unsigned char *p=(const unsigned char *)u;
    for(unsigned part=0;part<2;part++,p=(const unsigned char *)v)
        for(unsigned i=0;i<sizeof(*u);i+=4) {
            uint32_t x;memcpy(&x,p+i,4);h=((h<<5)|(h>>27))^x;
        }
    h^=h>>16;h*=0x85ebca6bu;h^=h>>13;return h;
}
/* Only admit a repeated hash to keep one-use edges from evicting useful
 * intersections. Admission is a performance heuristic: collisions can cause
 * extra admissions, but NEVER a hit without all key bytes matching.
 * An admitted miss reserves an invalid entry; other misses leave pending=NULL.
 * Commit only after the reference math
 * completes. No guest execution, callback re-entry or storage mutation may
 * occur between lookup and commit. Output stays untouched on a miss. */
static inline int bully_clip_memo_lookup(BullyClipMemo *m,const BullyClipVertex *u,
    const BullyClipVertex *v,unsigned plane,float near,float far,
    BullyClipVertex *out,BullyClipMemoEntry **pending)
{
    *pending=0;
    if(!m || !m->set)return 0;
    uint32_t fpu=m->read_fpu();
    if(fpu&m->bypass_mask){m->bypasses++;return 0;}
    uint32_t nb,fb;memcpy(&nb,&near,4);memcpy(&fb,&far,4);
    uint32_t hash=bully_clip_memo_hash(u,v,nb,fb,plane,fpu);
    BullyClipMemoSet *s=&m->set[hash&(m->sets-1)];
    for(unsigned i=0;i<2;i++) {
        BullyClipMemoEntry *e=&s->entry[i];
        if(e->epoch==m->epoch && e->hash==hash && e->plane==plane &&
           e->near_bits==nb && e->far_bits==fb && e->before==fpu &&
           !memcmp(u,&e->u,sizeof(*u)) && !memcmp(v,&e->v,sizeof(*v))) {
            memcpy(out,&e->result,sizeof(*out));s->replace=i^1u;
            m->write_fpu(e->after);m->hits++;return 1;
        }
    }
    m->misses++;
    if(s->seen_epoch!=m->epoch) {
        s->seen_epoch=m->epoch;s->seen_count=s->seen_replace=0;
    }
    int seen=0;
    for(unsigned i=0;i<s->seen_count;i++)if(s->seen[i]==hash){seen=1;break;}
    if(!seen) {
        s->seen[s->seen_replace]=hash;s->seen_replace=(s->seen_replace+1u)&7u;
        if(s->seen_count<8)s->seen_count++;
        return 0;
    }
    m->admissions++;
    unsigned which=s->replace&1u;
    if(s->entry[0].epoch!=m->epoch)which=0;
    else if(s->entry[1].epoch!=m->epoch)which=1;
    BullyClipMemoEntry *e=&s->entry[which];e->epoch=0;
    e->u=*u;e->v=*v;e->hash=hash;e->near_bits=nb;e->far_bits=fb;e->plane=plane;e->before=fpu;
    s->replace=which^1u;*pending=e;return 0;
}
static inline void bully_clip_memo_commit(BullyClipMemo *m,BullyClipMemoEntry *pending,
                                         const BullyClipVertex *result)
{
    if(!pending)return;
    pending->after=m->read_fpu();
    if(pending->after&m->bypass_mask){m->bypasses++;return;}
    memcpy(&pending->result,result,sizeof(*result));pending->epoch=m->epoch;
}
#endif
