#include "overlay_texture.h"
int bully_overlay_texture_plan(const uint8_t*ram,size_t bytes,uint64_t t,uint32_t pix,uint32_t pixbytes,uint32_t pal,uint32_t palbytes,TcPs2Info*info,TcPolicy*pol,TcPspTex*plan){
 unsigned ps=(t>>20)&63,w=1u<<((t>>26)&15),h=1u<<((t>>30)&15),cps=(t>>51)&15;
 if(!ram || !info || !pol || !plan || pix>bytes || pixbytes>bytes-pix || pal>bytes || palbytes>bytes-pal ||
    (ps!=TC_GS_PSMT4 && ps!=TC_GS_PSMT8) || cps!=0 || (t&(UINT64_C(1)<<55)) || ((t>>56)&31) || w>512 || h>512)return 0;
 TcPs2Raster r={0};r.width=w;r.height=h;r.depth=ps==TC_GS_PSMT4?4:8;r.format=TC_PF_8888|(ps==TC_GS_PSMT4?TC_PF_PAL4:TC_PF_PAL8);r.version=2;r.nlevels=1;r.tex0=t;r.pix=ram+pix;r.pix_size=pixbytes;r.pal=ram+pal;r.pal_size=palbytes;
 if(tc_ps2_inspect(&r,info))return 0;
 tc_policy_default(pol);pol->max_levels=1;pol->max_dim=512;pol->cache_bytes=0;pol->decimate=0;
 return tc_plan(info,pol,plan)==TC_OK;
}
