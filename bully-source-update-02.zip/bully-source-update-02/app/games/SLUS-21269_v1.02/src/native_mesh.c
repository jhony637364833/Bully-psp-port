#include "native_mesh.h"
#include <string.h>

static uint32_t word(const uint8_t *p)
{
    return (uint32_t)p[0] | (uint32_t)p[1]<<8 | (uint32_t)p[2]<<16 | (uint32_t)p[3]<<24;
}
static float number(const uint8_t *p)
{
    uint32_t bits = word(p);
    float f;
    memcpy(&f, &bits, 4);
    return f;
}
int bully_native_decode(const uint8_t *s, size_t bytes,
                        BullyNativeVertex *out, size_t capacity, size_t *count)
{
    const uint8_t *attrs[4] = {0};
    static const unsigned commands[4] = {0x68, 0x64, 0x6e, 0x6a};
    static const unsigned immediates[4] = {0x8000, 0x8001, 0xc002, 0x8003};
    static const unsigned widths[4] = {12, 8, 4, 3};
    struct Batch { const uint8_t *a[4]; size_t n; } batches[8];
    size_t at=0, n=0, total=0;
    unsigned cycle=0, mode=0, closed=0, launched=0, seen=0;
    if (!count) return 0;
    *count=0;
    if (!s || !out || bytes%4) return 0;
    while (at < bytes) {
        uint32_t code=word(s+at);
        unsigned cmd=code>>24, num=(code>>16)&255, imm=code&65535;
        at+=4;
        /* IRQ and reserved command bits are not part of this observed format. */
        if (cmd==0 || cmd==0x11) {
            if (num || imm) return 0;
        } else if (cmd==1) {
            if (num || imm!=0x104 || closed) return 0;
            cycle=1;
        } else if (cmd==5) {
            if (num || imm || closed) return 0;
            mode=1;
        } else if (cmd==4) {
            if (num || seen!=15 || closed || imm!=n) return 0;
            closed=1;
        } else if (cmd==0x15 || cmd==0x17) {
            if (num || imm || !closed || launched==8 ||
                (cmd==0x15 ? launched!=0 : launched==0)) return 0;
            /* MSCNT continues the same strip; the observed batches repeat two
             * vertices. Verify every attribute before discarding the overlap. */
            if (launched) {
                struct Batch *previous=&batches[launched-1];
                if (n<=2 || previous->n<2) return 0;
                for (unsigned k=0;k<4;k++)
                    if (memcmp(previous->a[k]+(previous->n-2)*widths[k],attrs[k],2*widths[k])) return 0;
            }
            total+=n-(launched?2:0);
            if (total>capacity) return 0;
            memcpy(batches[launched].a,attrs,sizeof(attrs));
            batches[launched++].n=n;
            memset(attrs,0,sizeof(attrs));
            n=0;seen=closed=cycle=mode=0;
        } else {
            unsigned slot;
            for (slot=0; slot<4; ++slot)
                if (cmd==commands[slot] && imm==immediates[slot]) break;
            if (slot==4 || !cycle || !mode || closed || (seen&(1u<<slot))) return 0;
            size_t items=num ? num : 256;
            size_t payload=(items*widths[slot]+3)&~(size_t)3;
            if (payload>bytes-at || (n && n!=items)) return 0;
            n=items;
            attrs[slot]=s+at;
            /* Reject NaN/Inf in positions and UVs before writing any output. */
            if (slot<2)
                for (size_t j=0; j<items*widths[slot]; j+=4)
                    if ((word(s+at+j)&0x7f800000u)==0x7f800000u) return 0;
            at+=payload;
            seen|=1u<<slot;
        }
    }
    if (!launched || closed || seen) return 0;
    size_t dest=0;
    for (unsigned batch=0;batch<launched;batch++) {
        const struct Batch *b=&batches[batch];
        for (size_t i=batch?2:0;i<b->n;i++,dest++) {
            for (unsigned j=0;j<3;j++) out[dest].position[j]=number(b->a[0]+i*12+j*4);
            for (unsigned j=0;j<2;j++) out[dest].uv[j]=number(b->a[1]+i*8+j*4);
            memcpy(out[dest].color,b->a[2]+i*4,4);
            memset(out[dest].color_secondary,0,4);
            memcpy(out[dest].normal,b->a[3]+i*3,3);
        }
    }
    *count=total;
    return 1;
}

/* Each observed compressed CNT contains one complete VIF batch. Reject split
 * commands, address-bearing DMA and nonzero terminal payloads explicitly. */
static unsigned half(const uint8_t *p) { return p[0] | (unsigned)p[1]<<8; }
static float fixed128(const uint8_t *p) {
    unsigned v=half(p);
    return (v<32768 ? (int)v : (int)v-65536)*(1.0f/128.0f);
}
#if defined(__PSP__) && defined(__MIPSEL__)
/* The parser proves every attribute begins on a word boundary relative to
 * RAM; position strides are six bytes. Check the RAM alignment once per batch.
 * memcpy expresses alias-safe native loads without changing vertex math. */
static unsigned half_aligned(const uint8_t *p) {
    uint16_t value;
    memcpy(&value,__builtin_assume_aligned(p,2),sizeof(value));
    return value;
}
static float fixed128_aligned(const uint8_t *p) {
    int16_t value;
    memcpy(&value,__builtin_assume_aligned(p,2),sizeof(value));
    return value*(1.0f/128.0f);
}
static __attribute__((noinline)) void compressed_expand_aligned(
    const uint8_t *const attrs[4],size_t n,BullyNativeVertex *scratch) {
    for(size_t i=0;i<n;i++) {
            BullyNativeVertex *v=&scratch[i];
            bully_native_vertex_clear(v);
            for(unsigned k=0;k<3;k++)v->position[k]=fixed128_aligned(attrs[0]+i*6+k*2);
            for(unsigned k=0;k<2;k++)v->uv[k]=fixed128_aligned(attrs[1]+i*4+k*2);
            unsigned packed=half_aligned(attrs[2]+i*2);
            for(unsigned k=0;k<3;k++)v->color[k]=((packed>>(k*5))&31)<<3;
            v->color[3]=(packed&0x8000)?128:0;
            packed=half_aligned(attrs[3]+i*2);
            for(unsigned k=0;k<3;k++)v->color_secondary[k]=((packed>>(k*5))&31)<<3;
            v->color_secondary[3]=(packed&0x8000)?128:0;
        }
}
#endif
int bully_compressed_chain_raw(const uint8_t *ram, size_t bytes, uint32_t chain,
                           BullyNativeVertex *scratch, BullyNativeVisit visit,
                           BullyNativeRawVisit raw_visit, void *context, size_t *count, size_t *used)
{
    static const unsigned commands[4]={0x69,0x65,0x6f,0x6f};
    static const unsigned immediates[4]={0x8000,0x8001,0xc002,0xc003};
    static const unsigned widths[4]={6,4,2,2};
    const uint8_t *previous[4]={0};
    size_t previous_n=0, at=chain, total=0;
    if(!count || !used)return 0;
    *count=*used=0;
    if(!ram || !scratch || !chain || (chain&15))return 0;
    if(visit && raw_visit) {
        if(chain>bytes)return 0;
        uintptr_t input=(uintptr_t)(ram+chain),out=(uintptr_t)scratch;
        /* Expansion can overwrite commands or later seam data as well as
         * current attributes. Require disjointness from the entire bounded
         * stream before skipping any scratch writes. */
        if(input>=out ? input-out<256*sizeof(*scratch) : out-input<bytes-chain)
            raw_visit=0;
    }
    for(unsigned batch=0;batch<=2048;batch++) {
        if(at>bytes || bytes-at<16)return 0;
        uint32_t tag=word(ram+at);
        size_t payload=(tag&65535)*16u;
        if(word(ram+at+4) || payload>bytes-at-16)return 0;
        if(tag==0x60000000u) {
            if(!batch || word(ram+at+8) || word(ram+at+12)!=0x11000000u)return 0;
            *count=total;*used=at+16-chain;return 1;
        }
        if(batch==2048 || (tag&0xffff0000u)!=0x10000000u)return 0;
        const uint8_t *attrs[4]={0};
        size_t n=0, cursor=at+8, end=at+16+payload;
        unsigned cycle=0, mode=0, seen=0, closed=0, launched=0;
        while(cursor<end) {
            uint32_t code=word(ram+cursor);cursor+=4;
            unsigned cmd=code>>24,num=(code>>16)&255,imm=code&65535;
            if(!cmd) { if(num || imm)return 0; }
            else if(cmd==1) {
                if(num || imm!=0x104 || closed || launched)return 0;
                cycle=1;
            } else if(cmd==5) {
                if(num || imm || closed || launched)return 0;
                mode=1;
            } else if(cmd==4) {
                if(num || seen!=15 || closed || launched || imm!=n)return 0;
                closed=1;
            } else if(cmd==(batch?0x17u:0x15u)) {
                if(num || imm || !closed || launched)return 0;
                launched=1;
            } else {
                unsigned k;
                for(k=0;k<4;k++)if(cmd==commands[k] && imm==immediates[k])break;
                if(k==4 || !cycle || !mode || closed || launched || (seen&(1u<<k)))return 0;
                size_t items=num?num:256, length=(items*widths[k]+3)&~(size_t)3;
                if(length>end-cursor || (n && n!=items))return 0;
                n=items;attrs[k]=ram+cursor;cursor+=length;seen|=1u<<k;
            }
        }
        if(!launched || n<3)return 0;
        if(batch)for(unsigned k=0;k<4;k++)
            if(memcmp(previous[k]+(previous_n-2)*widths[k],attrs[k],2*widths[k]))return 0;
        /* The validation pass needs packet shape and seam checks only. All
         * compressed attributes are finite fixed-width integers. Decode on
         * the submission pass, after the entire object has been validated. */
        int handled=visit && raw_visit && raw_visit(attrs,n,context);
        if(visit && !handled) {
#if defined(__PSP__) && defined(__MIPSEL__)
            if(!((uintptr_t)ram&1u))compressed_expand_aligned(attrs,n,scratch);
            else
#endif
            for(size_t i=0;i<n;i++) {
            BullyNativeVertex *v=&scratch[i];
            bully_native_vertex_clear(v);
            for(unsigned k=0;k<3;k++)v->position[k]=fixed128(attrs[0]+i*6+k*2);
            for(unsigned k=0;k<2;k++)v->uv[k]=fixed128(attrs[1]+i*4+k*2);
            unsigned packed=half(attrs[2]+i*2);
            for(unsigned k=0;k<3;k++)v->color[k]=((packed>>(k*5))&31)<<3;
            v->color[3]=(packed&0x8000)?128:0;
            packed=half(attrs[3]+i*2);
            for(unsigned k=0;k<3;k++)v->color_secondary[k]=((packed>>(k*5))&31)<<3;
            v->color_secondary[3]=(packed&0x8000)?128:0;
        }
        }
        if(visit && !handled)visit(scratch,n,context);
        total+=n-(batch?2:0);
        memcpy(previous,attrs,sizeof(attrs));previous_n=n;at=end;
    }
    return 0;
}

int bully_compressed_chain(const uint8_t *ram,size_t bytes,uint32_t chain,
    BullyNativeVertex *scratch,BullyNativeVisit visit,void *context,size_t *count,size_t *used) {
    return bully_compressed_chain_raw(ram,bytes,chain,scratch,visit,0,context,count,used);
}
