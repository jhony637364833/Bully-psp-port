/* MPEG overlay 2: replace the PS2 IPU/SPU2 player with native PSP playback.
 * Verified against the supplied v1.02 ELF/overlay; see docs/MOVIE_STATUS.md.
 * Main startup ignores these return values. Missing playback is an error, not a skip.
 */
#include "hle.h"
#ifdef HLE_PSP
#include "hle_movie.h"
int bully_movie_display_init(void);
void bully_movie_display_shutdown(void);
static int ready;
#endif

HLE_OV(2, 007583d0)
{
#ifdef HLE_PSP
    if (!bully_movie_display_init()) hle_die(c, "Bully: cannot initialize PSP movie display");
    ready = 1;
    LOG("Bully MPEG overlay: native PSP movie player initialized\n");
    RET(0);
#else
    LOG("DIAGNOSTIC ONLY: host skips native PSP intro for post-intro analysis\n"); RET(0);
#endif
}

HLE_OV(2, 00758340)
{
#ifdef HLE_PSP
    if (!ready) hle_die(c, "Bully: movie playback without initialization");
    const char *path = gstr(ARG(0));
    /* a1 permits immediate skipping; a2 is the unskippable portion in original PSS bytes. */
    LOG("Bully intro: %s, skippable=%u, unskip_bytes=%u\n", path, ARG(1), ARG(2));
    if (!hle_movie_play(path, ARG(1), ARG(2))) {
        bully_movie_display_shutdown();
        ready = 0;
        hle_die(c, "Bully intro: %s", hle_movie_last_error());
    }
    RET(0);
#else
    RET(0);
#endif
}

HLE_OV(2, 007583c0)
{
#ifdef HLE_PSP
    if (ready) bully_movie_display_shutdown();
    ready = 0;
    if (!hle_movie_release_buffers()) LOG("Bully movie: retained buffers (still owned or not at arena tail)\n");
    void bully_world_enable(void);
    bully_world_enable();
    LOG("Bully MPEG overlay: native PSP movie player shut down\n");
    RET(0);
#else
    RET(0);
#endif
}
