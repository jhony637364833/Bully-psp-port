#ifndef BULLY_WORLD_PROJECTION_H
#define BULLY_WORLD_PROJECTION_H
#include <math.h>
/* Column-major GU matrix for the camera space used by world_clip:
 * screen x/width = x/z, screen y/height = y/z, near -> depth 0.
 * Keep W=z so the GPU interpolates texture coordinates with perspective. */
static inline int bully_projection_matrix(float near_plane,float far_plane,float m[16]) {
    if(!m || !isfinite(near_plane) || !isfinite(far_plane) ||
       near_plane<=0 || far_plane<=near_plane)return 0;
    double span=(double)far_plane-near_plane;
    float a=(float)(((double)far_plane+near_plane)/span);
    float b=(float)(-2.0*far_plane*near_plane/span);
    if(!isfinite(a) || !isfinite(b))return 0;
    const float matrix[16]={2,0,0,0, 0,-2,0,0, -1,1,a,1, 0,0,b,0};
    for(unsigned i=0;i<16;i++)m[i]=matrix[i];
    return 1;
}
#endif
