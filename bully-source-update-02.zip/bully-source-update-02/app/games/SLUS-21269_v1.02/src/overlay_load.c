#include "hle.h"

void GUEST_FN(bully_initialize_tables)(R5900Ctx *c);

HLE_FN(bully_initialize_tables)
{
    uint32_t caller = (uint32_t)c->r[31].d[0];
    /* 0x122900 loads a file; 0x122a00 initializes an image already in memory.
       Both clear BSS then call this constructor walker. Select before its JALRs. */
    if (caller == 0x001229d0u || caller == 0x00122a5cu) {
        uint32_t addr = (uint32_t)c->r[caller == 0x001229d0u ? 19 : 18].d[0];
        if (addr != 0x00756880u || memcmp(gptr(addr, 0x40), "MWo3", 4) ||
            gw(addr + 8) != addr || gw(addr + 24) != ARG(0) || gw(addr + 28) != ARG(1))
            hle_die(c, "Bully overlay: unexpected loader header at %08x", addr);
        uint32_t id = gw(addr + 4);
        uint64_t end = (uint64_t)addr + 0x40 + gw(addr + 12) + gw(addr + 16) + gw(addr + 20);
        if (!id || id > 17 || !rc_overlay_lookup[id] || end > 0x00769400u)
            hle_die(c, "Bully overlay: invalid id or extent at %08x", addr);
        hle_overlay_loaded(addr);
    }
    GUEST_FN(bully_initialize_tables)(c);
}
