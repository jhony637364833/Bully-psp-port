/* Based on PS2RC by SandstoneDev: https://github.com/SandstoneDev/PS2RC
 * Bounded decoder for the native streams observed in SLUS-21269 v1.02.
 * This extracts attributes only; topology, VU execution and drawing are separate.
 */
#ifndef BULLY_NATIVE_MESH_H
#define BULLY_NATIVE_MESH_H
#include <stddef.h>
#include <stdint.h>
#include <string.h>

typedef struct {
    float position[3], uv[2];
    uint8_t color[4];
    uint8_t color_secondary[4]; /* Compressed pipeline second prelight bank. */
    int8_t normal[3]; /* Raw signed components; normalization is not established. */
} BullyNativeVertex;

/* Every byte, including normal/padding, is zero before source attributes are
 * read. Preserve overlapping scratch/input behavior and avoid a library call
 * plus register spills for each vertex on Allegrex. No FPU/VFPU state changes. */
static inline void bully_native_vertex_clear(BullyNativeVertex *v) {
#if defined(__PSP__) && defined(__mips__)
    _Static_assert(sizeof(*v)==32 && _Alignof(BullyNativeVertex)>=4,
                   "Allegrex vertex clear requires eight aligned words");
    __asm__ volatile("sw $0,0(%0)\n\t"
                     "sw $0,4(%0)\n\t"
                     "sw $0,8(%0)\n\t"
                     "sw $0,12(%0)\n\t"
                     "sw $0,16(%0)\n\t"
                     "sw $0,20(%0)\n\t"
                     "sw $0,24(%0)\n\t"
                     "sw $0,28(%0)" :: "r"(v) : "memory");
#else
    memset(v,0,sizeof(*v));
#endif
}

/* stream begins at the DMA tag's two VIF words, followed by inline payload.
 * Caller must first validate the DMA chain and supply exactly its bounded bytes.
 * Supports up to eight observed STCYCL(4,1), STMOD(0) batches with four attributes,
 * MSCALF(0) then MSCNT(0). Continuations must repeat both strip-tail vertices
 * exactly across every attribute; those duplicates are removed in the output.
 * Returns 1 on success. Failure sets *count=0 and leaves vertices untouched.
 * No guest pointers are dereferenced; buffers must not overlap.
 */
int bully_native_decode(const uint8_t *stream, size_t bytes,
                        BullyNativeVertex *vertices, size_t capacity, size_t *count);
/* Compressed static pipeline 0x29ccc0: bounded inline CNT batches followed by
 * an empty RET. Positions and UVs use signed 1/128 units (Bully, not GTA).
 * Slots 2 and 3 are packed prelight banks; both are preserved.
 * The material bridge supplies their blend and lighting state separately.
 * scratch holds 256 vertices. visit receives each strip batch including its
 * two repeated seam vertices. Validate with visit=NULL before submitting draws:
 * a malformed later packet can otherwise fail after earlier visits.
 * With visit=NULL, validate without expanding vertices; scratch is untouched.
 * Failure leaves *count and *used zero; scratch may change with a visitor.
 * No allocation.
 */
typedef void (*BullyNativeVisit)(const BullyNativeVertex *, size_t, void *);
int bully_compressed_chain(const uint8_t *ram, size_t bytes, uint32_t chain,
                           BullyNativeVertex *scratch, BullyNativeVisit visit,
                           void *context, size_t *count, size_t *used);
/* Renderer-only raw bridge. Overlapping stream/scratch use the original
 * expansion. Neither visitor may mutate RAM. raw_visit returns one if it handled a batch,
 * or zero without effects to request the original expansion and visitor.
 * Validation (visit=NULL) never calls raw_visit or touches scratch. */
typedef int (*BullyNativeRawVisit)(const uint8_t *const[4],size_t,void *);
int bully_compressed_chain_raw(const uint8_t *,size_t,uint32_t,
    BullyNativeVertex *,BullyNativeVisit,BullyNativeRawVisit,void *,size_t *,size_t *);
#endif
