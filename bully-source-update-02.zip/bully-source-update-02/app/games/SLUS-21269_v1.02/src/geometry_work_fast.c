/* Prepared SLUS-21269 v1.02 body, compiled with native -O2/inlining.
 * No algorithm, floating-point or scheduler changes. See body checker. */
#include "main.h"
void y_nat_0012a5c0(R5900Ctx *c)
{
    c->r[29].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)-1152);
    rt_sd(c, (uint32_t)(c->r[29].d[0] + 176), c->r[31].d[0]);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 160), &c->r[30]);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 144), &c->r[23]);
    c->r[30].d[0] = (c->r[4].d[0] + 0ull);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 128), &c->r[22]);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 112), &c->r[21]);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 96), &c->r[20]);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 80), &c->r[19]);
    c->r[20].d[0] = (c->r[7].d[0] + 0ull);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 64), &c->r[18]);
    c->r[19].d[0] = (c->r[10].d[0] + 0ull);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 48), &c->r[17]);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 32), &c->r[16]);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 16), c->fpr[20].u);
    c->r[18].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1192)));
    c->r[21].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[6].d[0] + 56)));
    c->r[16].d[0] = (c->r[11].d[0] + 0ull);
    c->r[17].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[9].d[0] + 56)));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 348), c->r[5].d[0]);
    { int t_ = (c->r[21].d[0] == 0ull); rt_sw(c, (uint32_t)(c->r[29].d[0] + 344), c->r[9].d[0]); if (t_) goto L_0012a620; }
    if (c->r[17].d[0] != 0ull) { rt_sw(c, (uint32_t)(c->r[29].d[0] + 880), 0ull); goto L_0012a628; }
L_0012a620:;
    { c->r[2].d[0] = (0ull + 0ull); goto L_0012b740; }
L_0012a628:;
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[28].d[0] + -32552));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 884), 0ull);
    c->r[2].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)880);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 888), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 892), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 896), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 900), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 904), 0ull);
    { int t_ = (c->r[19].d[0] != 0ull); rt_sw(c, (uint32_t)(c->r[29].d[0] + 916), c->fpr[0].u); if (t_) goto L_0012a654; }
    c->r[19].d[0] = (c->r[2].d[0] + 0ull);
L_0012a654:;
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 348)));
    c->r[4].d[0] = (c->r[20].d[0] + 0ull);
    rt_lq(c, (uint32_t)(c->r[30].d[0] + 48), &c->vu0.vf[10]);
    c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)816);
    rt_lq(c, (uint32_t)(c->r[2].d[0] + 48), &c->vu0.vf[12]);
    vu0_fmac(c, VU0_SUB, 14, 0xe, 12, 10, -1, 0, 0);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 512), &c->vu0.vf[14]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 512));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 516));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 520));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1128), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1132), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1136), c->fpr[0].u);
    rt_lq(c, (uint32_t)(c->r[8].d[0] + 48), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 48), &c->vu0.vf[10]);
    vu0_fmac(c, VU0_SUB, 13, 0xe, 12, 10, -1, 0, 0);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 828), 0ull);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 496), &c->vu0.vf[13]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 496));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 500));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 504));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1112), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1116), c->fpr[1].u);
    c->r[31].d[0] = 0x0012a6b8ull; rt_sw(c, (uint32_t)(c->r[29].d[0] + 1120), c->fpr[0].u); fn_00184850(c);
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)752);
    c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)816);
    c->r[31].d[0] = 0x0012a6c8ull; c->r[6].d[0] = (c->r[30].d[0] + 0ull); fn_001847c0(c);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[28].d[0] + -32552));
    c->r[22].d[0] = (0ull + 0ull);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 36), c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1096), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1100), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1104), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 736), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 740), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 744), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 720), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 724), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 728), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1080), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1084), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1088), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1064), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1068), 0ull);
    { int t_ = (c->r[16].d[0] == 0ull); rt_sw(c, (uint32_t)(c->r[29].d[0] + 1072), 0ull); if (t_) goto L_0012a720; }
    c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1);
    { rt_sq(c, (uint32_t)(c->r[29].d[0] + 304), &c->r[2]); goto L_0012a728; }
L_0012a720:;
    c->r[2].d[0] = (uint64_t)(int64_t)(int8_t)rt_lb(c, (uint32_t)(c->r[21].d[0] + 30));
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 304), &c->r[2]);
L_0012a728:;
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1184)));
    c->r[16].d[0] = (0ull + 0ull);
    c->r[2].d[0] = (c->r[3].d[0] & 0x1ull);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 288), &c->r[2]);
    c->r[2].d[0] = (c->r[3].d[0] & 0x2ull);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 272), &c->r[2]);
    c->r[2].d[0] = (c->r[3].d[0] & 0x8ull);
    { rt_sq(c, (uint32_t)(c->r[29].d[0] + 256), &c->r[2]); goto L_0012b6ec; }
L_0012a74c:;
    if (c->r[2].d[0] == 0ull) { c->r[2].d[0] = SX32((uint32_t)c->r[16].d[0] << 2); goto L_0012a778; }
    c->r[3].d[0] = SX32((uint32_t)c->r[16].d[0] << 2);
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[21].d[0] + 0)));
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[16].d[0]);
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] << 2);
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] + (uint32_t)c->r[3].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[2].d[0] + 17));
    if (c->r[2].d[0] != 0ull) { c->r[16].d[0] = SX32((uint32_t)c->r[16].d[0] + (uint32_t)1); goto L_0012b6ec; }
    c->r[2].d[0] = SX32((uint32_t)c->r[16].d[0] << 2);
L_0012a778:;
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[21].d[0] + 0)));
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] + (uint32_t)c->r[16].d[0]);
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] << 2);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 240), &c->r[2]);
    c->r[2].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[2].d[0] + 0)));
    c->r[5].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[2].d[0] + 4)));
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[2].d[0] + 8)));
    
    
    c->r[4] = mmi_pextlw(c->r[5], c->r[4]);
    
    rt_lq(c, (uint32_t)(c->r[30].d[0] + 48), &c->vu0.vf[14]);
    c->r[4] = mmi_pcpyld(c->r[3], c->r[4]);
    rt_lq(c, (uint32_t)(c->r[30].d[0] + 0), &c->vu0.vf[13]);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 640), &c->r[4]);
    rt_lq(c, (uint32_t)(c->r[30].d[0] + 16), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[30].d[0] + 32), &c->vu0.vf[10]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 14, 0, 3, 0, 0);
    c->vu0.vf[16] = c->r[4];
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 13, 16, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 16, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 6, 0xe, 10, 16, 2, 0, 0);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 704), &c->vu0.vf[6]);
    c->fpr[5].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 704));
    c->fpr[4].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 708));
    c->fpr[3].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 712));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 736), c->fpr[5].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 740), c->fpr[4].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 744), c->fpr[3].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[2].d[0] + 12));
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1152));
    { int t_ = (c->r[2].d[0] == 0ull); rt_sw(c, (uint32_t)(c->r[29].d[0] + 748), c->fpr[0].u); if (t_) goto L_0012a84c; }
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 348)));
    rt_lq(c, (uint32_t)(c->r[2].d[0] + 48), &c->vu0.vf[14]);
    rt_lq(c, (uint32_t)(c->r[2].d[0] + 0), &c->vu0.vf[13]);
    rt_lq(c, (uint32_t)(c->r[2].d[0] + 16), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[2].d[0] + 32), &c->vu0.vf[10]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 14, 0, 3, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 13, 16, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 16, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 5, 0xe, 10, 16, 2, 0, 0);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 624), &c->vu0.vf[5]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 632));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 628));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 624));
    c->fpr[2].u = fpu_sub(c->fpr[2].u, c->fpr[3].u);
    c->fpr[1].u = fpu_sub(c->fpr[1].u, c->fpr[4].u);
    c->fpr[0].u = fpu_sub(c->fpr[0].u, c->fpr[5].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1136), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1132), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1128), c->fpr[0].u);
L_0012a84c:;
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 288), &c->r[2]);
    if (c->r[2].d[0] == 0ull) { rt_lq(c, (uint32_t)(c->r[29].d[0] + 800), &c->vu0.vf[16]); goto L_0012aad0; }
    { c->r[23].d[0] = (0ull + 0ull); goto L_0012aa5c; }
L_0012a860:;
    if (c->r[2].d[0] == 0ull) { c->r[2].d[0] = SX32((uint32_t)c->r[23].d[0] << 2); goto L_0012a88c; }
    c->r[3].d[0] = SX32((uint32_t)c->r[23].d[0] << 2);
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 0)));
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[23].d[0]);
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] << 2);
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] + (uint32_t)c->r[3].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[2].d[0] + 17));
    if (c->r[2].d[0] != 0ull) { c->r[23].d[0] = SX32((uint32_t)c->r[23].d[0] + (uint32_t)1); goto L_0012aa5c; }
    c->r[2].d[0] = SX32((uint32_t)c->r[23].d[0] << 2);
L_0012a88c:;
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 0)));
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] + (uint32_t)c->r[23].d[0]);
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] << 2);
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 224), &c->r[2]);
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[3].d[0] + 0)));
    c->r[5].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[3].d[0] + 4)));
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[3].d[0] + 8)));
    
    
    c->r[4] = mmi_pextlw(c->r[5], c->r[4]);
    
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 48), &c->vu0.vf[13]);
    c->r[4] = mmi_pcpyld(c->r[2], c->r[4]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 0), &c->vu0.vf[14]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 16), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 32), &c->vu0.vf[10]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 13, 0, 3, 0, 0);
    c->vu0.vf[13] = c->r[4];
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 4, 0xe, 10, 13, 2, 0, 0);
    c->r[2].d[0] = SX32(0x3f800000u);
    c->fpr[12].u = (uint32_t)c->r[2].d[0];
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)736);
    c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)720);
    c->r[6].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1128);
    c->r[7].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1112);
    c->r[8].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1144);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 704), &c->vu0.vf[4]);
    c->r[9].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1096);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 704));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 708));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 712));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 720), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 724), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 728), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[3].d[0] + 12));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 732), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[19].d[0] + 36));
    c->r[31].d[0] = 0x0012a934ull; rt_sw(c, (uint32_t)(c->r[29].d[0] + 1144), c->fpr[0].u); fn_003f6ff0(c);
    { int t_ = (c->r[2].d[0] == 0ull);  if (t_) goto L_0012aa58; }
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[19].d[0] + 36));
    fpu_cmp(c, F(c->fpr[1].u) < F(c->fpr[0].u));
    { int t_ = ((c->fcr31 & FCR31_C) == 0);  if (t_) goto L_0012aa58; }
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 36), c->fpr[1].u);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 240), &c->r[2]);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1096));
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1048);
    c->fpr[7].u = (uint32_t)0ull;
    c->r[22].d[0] = (0ull + (uint64_t)(int64_t)1);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 0), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1100));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 4), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1104));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 8), c->fpr[0].u);
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[21].d[0] + 0)));
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 16));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 32), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 17));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 33), c->r[2].d[0]);
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 0)));
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 224), &c->r[2]);
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 16));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 34), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 17));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 35), c->r[2].d[0]);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 28), c->r[16].d[0]);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 736));
    c->fpr[8].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144));
    c->fpr[4].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1128));
    c->acc.u = fpu_add(c->fpr[7].u, c->fpr[0].u);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 740));
    c->fpr[4].u = fpu_madd(c->acc.u, c->fpr[8].u, c->fpr[4].u);
    c->fpr[3].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1132));
    c->acc.u = fpu_add(c->fpr[7].u, c->fpr[1].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 744));
    c->fpr[6].u = fpu_madd(c->acc.u, c->fpr[8].u, c->fpr[3].u);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1136));
    c->acc.u = fpu_add(c->fpr[7].u, c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 720));
    c->fpr[5].u = fpu_madd(c->acc.u, c->fpr[8].u, c->fpr[2].u);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1112));
    c->acc.u = fpu_add(c->fpr[7].u, c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1048), c->fpr[4].u);
    c->fpr[0].u = fpu_madd(c->acc.u, c->fpr[8].u, c->fpr[1].u);
    c->fpr[4].u = fpu_sub(c->fpr[4].u, c->fpr[0].u);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 724));
    c->fpr[3].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1116));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 728));
    c->acc.u = fpu_add(c->fpr[7].u, c->fpr[2].u);
    c->fpr[2].u = fpu_madd(c->acc.u, c->fpr[8].u, c->fpr[3].u);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1120));
    c->acc.u = fpu_add(c->fpr[7].u, c->fpr[0].u);
    c->fpr[2].u = fpu_sub(c->fpr[6].u, c->fpr[2].u);
    c->fpr[0].u = fpu_madd(c->acc.u, c->fpr[8].u, c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1052), c->fpr[6].u);
    c->fpr[0].u = fpu_sub(c->fpr[5].u, c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1056), c->fpr[5].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1048), c->fpr[4].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1052), c->fpr[2].u);
    c->r[31].d[0] = 0x0012aa40ull; rt_sw(c, (uint32_t)(c->r[29].d[0] + 1056), c->fpr[0].u); fn_001860c0(c);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1048));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 16), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1052));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 20), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1056));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 24), c->fpr[0].u);
L_0012aa58:;
    c->r[23].d[0] = SX32((uint32_t)c->r[23].d[0] + (uint32_t)1);
L_0012aa5c:;
    c->r[2].d[0] = (uint64_t)(int64_t)(int8_t)rt_lb(c, (uint32_t)(c->r[17].d[0] + 30));
    c->r[2].d[0] = ((int64_t)c->r[23].d[0] < (int64_t)c->r[2].d[0]);
    if (c->r[2].d[0] != 0ull) { c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1176)); { RC_BACKEDGE_AT(c, 0x0012a860u); goto L_0012a860; } }
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1160));
    { int t_ = (c->r[2].d[0] == 0ull);  if (t_) goto L_0012aacc; }
    { int t_ = (c->r[22].d[0] == 0ull);  if (t_) goto L_0012aacc; }
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 892)));
    if (c->r[4].d[0] == 0ull) { c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1); goto L_0012b740; }
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[28].d[0] + -10812)));
    { int t_ = (c->r[4].d[0] != c->r[2].d[0]);  if (t_) goto L_0012aab0; }
    { int t_ = (c->r[4].d[0] == 0ull);  if (t_) goto L_0012aac0; }
    c->r[31].d[0] = 0x0012aaa8ull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)892); fn_0017ee10(c);
    {  goto L_0012aac0; }
L_0012aab0:;
    { int t_ = (c->r[4].d[0] == 0ull);  if (t_) goto L_0012aac0; }
    c->r[31].d[0] = 0x0012aac0ull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)892); fn_0017ee10(c);
L_0012aac0:;
    c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1);
    {  goto L_0012b740; }
L_0012aacc:;
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 800), &c->vu0.vf[16]);
L_0012aad0:;
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 752), &c->vu0.vf[14]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 768), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 784), &c->vu0.vf[10]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 640), &c->vu0.vf[13]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 16, 0, 3, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 3, 0xe, 10, 13, 2, 0, 0);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1128));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1112));
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 748));
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 672), &c->vu0.vf[3]);
    c->fpr[3].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1132));
    c->fpr[0].u = fpu_sub(c->fpr[1].u, c->fpr[0].u);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 816), &c->vu0.vf[14]);
    c->fpr[5].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 672));
    c->r[2].d[0] = SX32(c->fpr[0].u);
    c->fpr[4].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 676));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 592), c->fpr[5].u);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 832), &c->vu0.vf[12]);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 680));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 596), c->fpr[4].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1120));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 600), c->fpr[1].u);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 848), &c->vu0.vf[10]);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 604), c->fpr[2].u);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1116));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1136));
    c->fpr[2].u = fpu_sub(c->fpr[3].u, c->fpr[2].u);
    c->r[3].d[0] = SX32(c->fpr[2].u);
    c->fpr[0].u = fpu_sub(c->fpr[1].u, c->fpr[0].u);
    c->r[3] = mmi_pextlw(c->r[3], c->r[2]);
    c->r[2].d[0] = SX32(c->fpr[0].u);
    
    c->r[3] = mmi_pcpyld(c->r[2], c->r[3]);
    c->vu0.vf[13] = c->r[3];
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 13, 0xe, 10, 13, 2, 0, 0);
    vu0_fmac(c, VU0_MUL, 9, 0xe, 13, 13, -1, 0, 0);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 656), &c->vu0.vf[13]);
    vu0_fmac(c, VU0_ADD, 8, 0x8, 0, 0, 3, 0, 0);
    vu0_fmac(c, VU0_ADD, VU0_ACC, 0x8, 9, 9, 1, 0, 0);
    vu0_move(c, 0xf, 10, 9, 0, 0);
    vu0_fmac(c, VU0_MADD, 10, 0x8, 8, 9, 2, 0, 0);
    vu0_qop(c, VU0_SQRT, 0u, vu0_lane(c, 10, 0));
    ;
    rt_sb(c, (uint32_t)(c->r[29].d[0] + 1151), 0ull);
    vu0_fmac(c, VU0_ADD, 7, 0x8, 0, VU0_QREG, 0, 0, 0);
    c->r[2] = vu0_vf(c, 7);
    c->fpr[20].u = (uint32_t)c->r[2].d[0];
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 272), &c->r[2]);
    { int t_ = (c->r[2].d[0] == 0ull); rt_sw(c, (uint32_t)(c->r[29].d[0] + 1140), 0ull); if (t_) goto L_0012b01c; }
    { rt_sw(c, (uint32_t)(c->r[29].d[0] + 320), 0ull); goto L_0012afa8; }
L_0012abb0:;
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 320)));
    c->r[6].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)592);
    c->r[7].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)656);
    c->r[8].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1144);
    c->r[9].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1080);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1144), c->fpr[0].u);
    c->r[3].d[0] = SX32((uint32_t)c->r[2].d[0] << 1);
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 8)));
    c->r[2].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] << 4);
    c->r[3].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1140);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 208), &c->r[2]);
    c->r[10].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1064);
    c->r[4].d[0] = SX32((uint32_t)c->r[4].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[11].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1151);
    rt_sd(c, (uint32_t)(c->r[29].d[0] + 0), c->r[3].d[0]);
    c->r[31].d[0] = 0x0012abf8ull; c->r[5].d[0] = SX32((uint32_t)c->r[4].d[0] + (uint32_t)16); fn_004251b0(c);
    if (c->r[2].d[0] == 0ull) { c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1168)); goto L_0012adbc; }
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144));
    fpu_cmp(c, F(c->fpr[0].u) < F(c->fpr[20].u));
    { int t_ = ((c->fcr31 & FCR31_C) == 0);  if (t_) goto L_0012adb8; }
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1140)));
    c->r[1].d[0] = ((int64_t)c->r[2].d[0] < (int64_t)2);
    if (c->r[1].d[0] != 0ull) { c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144)); goto L_0012ac38; }
    { int t_ = (c->r[18].d[0] == 0ull);  if (t_) goto L_0012ac34; }
    c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1);
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 2), c->r[2].d[0]);
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 1), c->r[2].d[0]);
L_0012ac34:;
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144));
L_0012ac38:;
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[19].d[0] + 36));
    c->fpr[3].u = fpu_div(c->fpr[1].u, c->fpr[20].u);
    
    
    fpu_cmp(c, F(c->fpr[3].u) < F(c->fpr[0].u));
    if ((c->fcr31 & FCR31_C) == 0) { c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 320))); goto L_0012afa0; }
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1080)));
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1084)));
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1088)));
    
    
    c->r[5] = mmi_pextlw(c->r[4], c->r[3]);
    
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 0), &c->vu0.vf[14]);
    c->r[5] = mmi_pcpyld(c->r[2], c->r[5]);
    c->r[4].d[0] = SX32((uint32_t)c->r[20].d[0] + (uint32_t)16);
    c->r[3].d[0] = SX32((uint32_t)c->r[20].d[0] + (uint32_t)32);
    c->vu0.vf[13] = c->r[5];
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 16), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 32), &c->vu0.vf[10]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 13, 0xe, 10, 13, 2, 0, 0);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 688), &c->vu0.vf[13]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 688));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 692));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 696));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1080), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1084), c->fpr[1].u);
    { int t_ = (c->r[18].d[0] == 0ull); rt_sw(c, (uint32_t)(c->r[29].d[0] + 1088), c->fpr[0].u); if (t_) goto L_0012ace0; }
    c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1);
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 2), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1151));
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 0), c->r[2].d[0]);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1080));
    rt_sw(c, (uint32_t)(c->r[18].d[0] + 4), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1084));
    rt_sw(c, (uint32_t)(c->r[18].d[0] + 8), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1088));
    rt_sw(c, (uint32_t)(c->r[18].d[0] + 12), c->fpr[0].u);
L_0012ace0:;
    c->r[5].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1064)));
    c->r[6].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1068)));
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1072)));
    
    
    c->r[5] = mmi_pextlw(c->r[6], c->r[5]);
    
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 48), &c->vu0.vf[13]);
    c->r[5] = mmi_pcpyld(c->r[2], c->r[5]);
    rt_lq(c, (uint32_t)(c->r[4].d[0] + 0), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[3].d[0] + 0), &c->vu0.vf[10]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 0), &c->vu0.vf[14]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 13, 0, 3, 0, 0);
    c->vu0.vf[13] = c->r[5];
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 2, 0xe, 10, 13, 2, 0, 0);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 240), &c->r[2]);
    c->r[22].d[0] = (0ull + (uint64_t)(int64_t)1);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 688), &c->vu0.vf[2]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 688));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 692));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 696));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1064), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1068), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1072), c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 36), c->fpr[3].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1080));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 16), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1084));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 20), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1088));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 24), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1064));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 0), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1068));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 4), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1072));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 8), c->fpr[0].u);
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[21].d[0] + 0)));
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 16));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 32), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 17));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 33), c->r[2].d[0]);
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 8)));
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 208), &c->r[2]);
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 32));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 34), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 33));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 35), c->r[2].d[0]);
    { rt_sw(c, (uint32_t)(c->r[19].d[0] + 28), c->r[16].d[0]); goto L_0012af9c; }
L_0012adb8:;
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1168));
L_0012adbc:;
    { int t_ = (c->r[2].d[0] == 0ull);  if (t_) goto L_0012af9c; }
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 8)));
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)432);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 208), &c->r[2]);
    c->r[23].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[31].d[0] = 0x0012addcull; c->r[5].d[0] = (c->r[23].d[0] + 0ull); fn_0012b920(c);
    c->r[31].d[0] = 0x0012ade4ull; c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)432); fn_0012b910(c);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 672));
    fpu_cmp(c, F(c->fpr[1].u) <= F(c->fpr[0].u));
    { int t_ = ((c->fcr31 & FCR31_C) == 0); c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1); if (t_) goto L_0012adf8; }
    c->r[2].d[0] = (0ull + 0ull);
L_0012adf8:;
    { int t_ = (c->r[2].d[0] == 0ull);  if (t_) goto L_0012ae28; }
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)416);
    c->r[31].d[0] = 0x0012ae0cull; c->r[5].d[0] = (c->r[23].d[0] + 0ull); fn_0012b900(c);
    c->r[31].d[0] = 0x0012ae14ull; c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)416); fn_0012b8e0(c);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 676));
    fpu_cmp(c, F(c->fpr[1].u) <= F(c->fpr[0].u));
    { int t_ = ((c->fcr31 & FCR31_C) == 0); c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1); if (t_) goto L_0012ae28; }
    c->r[2].d[0] = (0ull + 0ull);
L_0012ae28:;
    { int t_ = (c->r[2].d[0] == 0ull);  if (t_) goto L_0012ae58; }
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)400);
    c->r[31].d[0] = 0x0012ae3cull; c->r[5].d[0] = (c->r[23].d[0] + 0ull); fn_0012b8d0(c);
    c->r[31].d[0] = 0x0012ae44ull; c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)400); fn_0012b8b0(c);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 680));
    fpu_cmp(c, F(c->fpr[1].u) <= F(c->fpr[0].u));
    { int t_ = ((c->fcr31 & FCR31_C) == 0); c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1); if (t_) goto L_0012ae58; }
    c->r[2].d[0] = (0ull + 0ull);
L_0012ae58:;
    { int t_ = (c->r[2].d[0] == 0ull);  if (t_) goto L_0012ae88; }
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)384);
    c->r[31].d[0] = 0x0012ae6cull; c->r[5].d[0] = SX32((uint32_t)c->r[23].d[0] + (uint32_t)16); fn_0012b920(c);
    c->r[31].d[0] = 0x0012ae74ull; c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)384); fn_0012b910(c);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 672));
    fpu_cmp(c, F(c->fpr[1].u) < F(c->fpr[0].u));
    { int t_ = ((c->fcr31 & FCR31_C) != 0); c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1); if (t_) goto L_0012ae88; }
    c->r[2].d[0] = (0ull + 0ull);
L_0012ae88:;
    { int t_ = (c->r[2].d[0] == 0ull);  if (t_) goto L_0012aeb8; }
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)368);
    c->r[31].d[0] = 0x0012ae9cull; c->r[5].d[0] = SX32((uint32_t)c->r[23].d[0] + (uint32_t)16); fn_0012b900(c);
    c->r[31].d[0] = 0x0012aea4ull; c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)368); fn_0012b8e0(c);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 676));
    fpu_cmp(c, F(c->fpr[1].u) < F(c->fpr[0].u));
    { int t_ = ((c->fcr31 & FCR31_C) != 0); c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1); if (t_) goto L_0012aeb8; }
    c->r[2].d[0] = (0ull + 0ull);
L_0012aeb8:;
    { int t_ = (c->r[2].d[0] == 0ull);  if (t_) goto L_0012aee8; }
    c->r[5].d[0] = SX32((uint32_t)c->r[23].d[0] + (uint32_t)16);
    c->r[31].d[0] = 0x0012aeccull; c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)352); fn_0012b8d0(c);
    c->r[31].d[0] = 0x0012aed4ull; c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)352); fn_0012b8b0(c);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 680));
    fpu_cmp(c, F(c->fpr[1].u) < F(c->fpr[0].u));
    { int t_ = ((c->fcr31 & FCR31_C) != 0); c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1); if (t_) goto L_0012aee8; }
    c->r[2].d[0] = (0ull + 0ull);
L_0012aee8:;
    { int t_ = (c->r[2].d[0] == 0ull);  if (t_) goto L_0012af9c; }
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 48), &c->vu0.vf[16]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 0), &c->vu0.vf[14]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 16), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 32), &c->vu0.vf[10]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 672), &c->vu0.vf[13]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 16, 0, 3, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 1, 0xe, 10, 13, 2, 0, 0);
    c->r[5].d[0] = SX32(0x3f800000u);
    c->r[4].d[0] = SX32(0x5c0000u);
    c->r[3].d[0] = SX32(0x5c0000u);
    c->r[2].d[0] = SX32(0x5c0000u);
    c->r[22].d[0] = (0ull + (uint64_t)(int64_t)1);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 688), &c->vu0.vf[1]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 688));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 692));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 696));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 0), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 4), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 8), c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 36), c->r[5].d[0]);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[4].d[0] + 11936));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 16), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[3].d[0] + 11940));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 20), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[2].d[0] + 11944));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 24), c->fpr[0].u);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 240), &c->r[2]);
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[21].d[0] + 0)));
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 16));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 32), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 17));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 33), c->r[2].d[0]);
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 8)));
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 208), &c->r[2]);
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 32));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 34), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 33));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 35), c->r[2].d[0]);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 28), c->r[16].d[0]);
L_0012af9c:;
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 320)));
L_0012afa0:;
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] + (uint32_t)1);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 320), c->r[2].d[0]);
L_0012afa8:;
    c->r[3].d[0] = (uint64_t)(int64_t)(int8_t)rt_lb(c, (uint32_t)(c->r[17].d[0] + 31));
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 320)));
    c->r[2].d[0] = ((int64_t)c->r[2].d[0] < (int64_t)c->r[3].d[0]);
    if (c->r[2].d[0] != 0ull) { c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[19].d[0] + 36)); { RC_BACKEDGE_AT(c, 0x0012abb0u); goto L_0012abb0; } }
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1160));
    if (c->r[2].d[0] == 0ull) { c->r[2].d[0] = (uint64_t)(int64_t)(int16_t)rt_lh(c, (uint32_t)(c->r[17].d[0] + 28)); goto L_0012b020; }
    { int t_ = (c->r[22].d[0] == 0ull);  if (t_) goto L_0012b01c; }
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 892)));
    if (c->r[4].d[0] == 0ull) { c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1); goto L_0012b740; }
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[28].d[0] + -10812)));
    { int t_ = (c->r[4].d[0] != c->r[2].d[0]);  if (t_) goto L_0012b000; }
    { int t_ = (c->r[4].d[0] == 0ull);  if (t_) goto L_0012b010; }
    c->r[31].d[0] = 0x0012aff8ull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)892); fn_0017ee10(c);
    {  goto L_0012b010; }
L_0012b000:;
    { int t_ = (c->r[4].d[0] == 0ull);  if (t_) goto L_0012b010; }
    c->r[31].d[0] = 0x0012b010ull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)892); fn_0017ee10(c);
L_0012b010:;
    c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1);
    {  goto L_0012b740; }
L_0012b01c:;
    c->r[2].d[0] = (uint64_t)(int64_t)(int16_t)rt_lh(c, (uint32_t)(c->r[17].d[0] + 28));
L_0012b020:;
    { int t_ = ((int64_t)c->r[2].d[0] <= 0);  if (t_) goto L_0012b6e8; }
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 256), &c->r[2]);
    { int t_ = (c->r[2].d[0] == 0ull);  if (t_) goto L_0012b6e8; }
    c->r[2].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)528);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 528), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1032), c->r[2].d[0]);
    c->r[2].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)540);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 532), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1036), c->r[2].d[0]);
    c->r[2].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)552);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 536), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1040), c->r[2].d[0]);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 540), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 544), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 548), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 552), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 556), 0ull);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 560), 0ull);
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 20)));
    if (c->r[4].d[0] == 0ull) { c->r[23].d[0] = (0ull + 0ull); goto L_0012b6d8; }
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 748));
    c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)672);
    c->r[6].d[0] = (0ull + 0ull);
    c->r[31].d[0] = 0x0012b090ull; c->fpr[12].u = fpu_add(c->fpr[0].u, c->fpr[20].u); fn_0037eb80(c);
    { c->r[4].d[0] = (c->r[2].d[0] & 0xffffull); goto L_0012b3ac; }
L_0012b098:;
    c->r[2].d[0] = (c->r[4].d[0] & 0xffffull);
    c->r[3].d[0] = SX32((uint32_t)c->r[2].d[0] << 3);
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 344)));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1144), c->fpr[0].u);
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 16)));
    c->r[23].d[0] = SX32((uint32_t)c->r[2].d[0] + (uint32_t)c->r[3].d[0]);
    c->r[6].d[0] = (uint64_t)rt_lh(c, (uint32_t)(c->r[23].d[0] + 0));
    c->r[31].d[0] = 0x0012b0bcull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)528); fn_00132030(c);
    c->r[6].d[0] = (uint64_t)rt_lh(c, (uint32_t)(c->r[23].d[0] + 2));
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 344)));
    c->r[31].d[0] = 0x0012b0ccull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)540); fn_00132030(c);
    c->r[6].d[0] = (uint64_t)rt_lh(c, (uint32_t)(c->r[23].d[0] + 4));
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 344)));
    c->r[31].d[0] = 0x0012b0dcull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)552); fn_00132030(c);
    c->fpr[7].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 528));
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1016);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 540));
    c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)984);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 552));
    c->r[6].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)968);
    c->fpr[6].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 532));
    c->fpr[5].u = fpu_sub(c->fpr[1].u, c->fpr[7].u);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 556));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 544));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 968), c->fpr[5].u);
    c->fpr[1].u = fpu_sub(c->fpr[1].u, c->fpr[6].u);
    c->fpr[5].u = fpu_sub(c->fpr[0].u, c->fpr[6].u);
    c->fpr[2].u = fpu_sub(c->fpr[2].u, c->fpr[7].u);
    c->fpr[4].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 536));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 560));
    c->fpr[3].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 548));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 988), c->fpr[1].u);
    c->fpr[0].u = fpu_sub(c->fpr[0].u, c->fpr[4].u);
    c->fpr[1].u = fpu_sub(c->fpr[3].u, c->fpr[4].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 972), c->fpr[5].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 984), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 976), c->fpr[1].u);
    c->r[31].d[0] = 0x0012b140ull; rt_sw(c, (uint32_t)(c->r[29].d[0] + 992), c->fpr[0].u); fn_00186240(c);
    c->r[31].d[0] = 0x0012b148ull; c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1016); fn_001860c0(c);
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1032);
    c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1016);
    c->r[6].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)592);
    c->r[7].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)656);
    c->r[8].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1144);
    c->r[9].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1080);
    c->r[10].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1064);
    c->r[31].d[0] = 0x0012b16cull; c->r[11].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1151); fn_00425ce0(c);
    if (c->r[2].d[0] == 0ull) { c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 20))); goto L_0012b3a0; }
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144));
    fpu_cmp(c, F(c->fpr[0].u) < F(c->fpr[20].u));
    { int t_ = ((c->fcr31 & FCR31_C) == 0);  if (t_) goto L_0012b39c; }
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1140)));
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] + (uint32_t)1);
    c->r[1].d[0] = ((int64_t)c->r[2].d[0] < (int64_t)2);
    { int t_ = (c->r[1].d[0] != 0ull); rt_sw(c, (uint32_t)(c->r[29].d[0] + 1140), c->r[2].d[0]); if (t_) goto L_0012b1ac; }
    if (c->r[18].d[0] == 0ull) { c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144)); goto L_0012b1b0; }
    c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1);
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 2), c->r[2].d[0]);
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 1), c->r[2].d[0]);
L_0012b1ac:;
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144));
L_0012b1b0:;
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[19].d[0] + 36));
    c->fpr[3].u = fpu_div(c->fpr[1].u, c->fpr[20].u);
    
    
    fpu_cmp(c, F(c->fpr[3].u) < F(c->fpr[0].u));
    { int t_ = ((c->fcr31 & FCR31_C) == 0);  if (t_) goto L_0012b39c; }
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1200));
    if (c->r[2].d[0] == 0ull) { c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1016))); goto L_0012b250; }
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1080)));
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1084)));
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1088)));
    
    
    c->r[5] = mmi_pextlw(c->r[4], c->r[3]);
    
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 0), &c->vu0.vf[14]);
    c->r[5] = mmi_pcpyld(c->r[2], c->r[5]);
    c->r[4].d[0] = SX32((uint32_t)c->r[20].d[0] + (uint32_t)16);
    c->r[3].d[0] = SX32((uint32_t)c->r[20].d[0] + (uint32_t)32);
    c->vu0.vf[13] = c->r[5];
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 16), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 32), &c->vu0.vf[10]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 13, 0xe, 10, 13, 2, 0, 0);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 688), &c->vu0.vf[13]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 688));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 692));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 696));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1080), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1084), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1088), c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 16), c->fpr[2].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1084));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 20), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1088));
    { rt_sw(c, (uint32_t)(c->r[19].d[0] + 24), c->fpr[0].u); goto L_0012b2c0; }
L_0012b250:;
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1020)));
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1024)));
    
    
    c->r[5] = mmi_pextlw(c->r[4], c->r[3]);
    
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 0), &c->vu0.vf[14]);
    c->r[5] = mmi_pcpyld(c->r[2], c->r[5]);
    c->r[4].d[0] = SX32((uint32_t)c->r[20].d[0] + (uint32_t)16);
    c->r[3].d[0] = SX32((uint32_t)c->r[20].d[0] + (uint32_t)32);
    c->vu0.vf[13] = c->r[5];
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 16), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 32), &c->vu0.vf[10]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 13, 0xe, 10, 13, 2, 0, 0);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 688), &c->vu0.vf[13]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 688));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 692));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 696));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1016), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1020), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1024), c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 16), c->fpr[2].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1020));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 20), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1024));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 24), c->fpr[0].u);
L_0012b2c0:;
    if (c->r[18].d[0] == 0ull) { c->r[5].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1064))); goto L_0012b2f4; }
    c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1);
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 2), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1151));
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 0), c->r[2].d[0]);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1016));
    rt_sw(c, (uint32_t)(c->r[18].d[0] + 4), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1020));
    rt_sw(c, (uint32_t)(c->r[18].d[0] + 8), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1024));
    rt_sw(c, (uint32_t)(c->r[18].d[0] + 12), c->fpr[0].u);
    c->r[5].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1064)));
L_0012b2f4:;
    c->r[6].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1068)));
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1072)));
    
    
    c->r[5] = mmi_pextlw(c->r[6], c->r[5]);
    
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 48), &c->vu0.vf[13]);
    c->r[5] = mmi_pcpyld(c->r[2], c->r[5]);
    rt_lq(c, (uint32_t)(c->r[4].d[0] + 0), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[3].d[0] + 0), &c->vu0.vf[10]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 0), &c->vu0.vf[14]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 13, 0, 3, 0, 0);
    c->vu0.vf[13] = c->r[5];
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 15, 0xe, 10, 13, 2, 0, 0);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 240), &c->r[2]);
    c->r[22].d[0] = (0ull + (uint64_t)(int64_t)1);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 688), &c->vu0.vf[15]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 688));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 692));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 696));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1064), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1068), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1072), c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 36), c->fpr[3].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1064));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 0), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1068));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 4), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1072));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 8), c->fpr[0].u);
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[21].d[0] + 0)));
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 16));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 32), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 17));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 33), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[23].d[0] + 6));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 34), c->r[2].d[0]);
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 35), 0ull);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 28), c->r[16].d[0]);
L_0012b39c:;
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 20)));
L_0012b3a0:;
    c->r[31].d[0] = 0x0012b3a8ull;  fn_0037ea80(c);
    c->r[4].d[0] = (c->r[2].d[0] & 0xffffull);
L_0012b3ac:;
    c->r[3].d[0] = (c->r[4].d[0] & 0xffffull);
    c->r[2].d[0] = (0ull | 0xffffull);
    if (c->r[3].d[0] != c->r[2].d[0]) { c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[19].d[0] + 36)); { RC_BACKEDGE_AT(c, 0x0012b098u); goto L_0012b098; } }
    {  goto L_0012b6e8; }
L_0012b3c4:;
    c->r[3].d[0] = SX32((uint32_t)c->r[23].d[0] << 3);
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 344)));
    c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)528);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1144), c->fpr[0].u);
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[17].d[0] + 16)));
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] + (uint32_t)c->r[3].d[0]);
    c->r[6].d[0] = (uint64_t)rt_lh(c, (uint32_t)(c->r[2].d[0] + 0));
    c->r[31].d[0] = 0x0012b3e8ull; rt_sq(c, (uint32_t)(c->r[29].d[0] + 192), &c->r[2]); fn_00132030(c);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 192), &c->r[2]);
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 344)));
    c->r[6].d[0] = (uint64_t)rt_lh(c, (uint32_t)(c->r[2].d[0] + 2));
    c->r[31].d[0] = 0x0012b3fcull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)540); fn_00132030(c);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 192), &c->r[2]);
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 344)));
    c->r[6].d[0] = (uint64_t)rt_lh(c, (uint32_t)(c->r[2].d[0] + 4));
    c->r[31].d[0] = 0x0012b410ull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)552); fn_00132030(c);
    c->fpr[7].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 528));
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1000);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 540));
    c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)952);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 552));
    c->r[6].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)936);
    c->fpr[6].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 532));
    c->fpr[5].u = fpu_sub(c->fpr[1].u, c->fpr[7].u);
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 556));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 544));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 936), c->fpr[5].u);
    c->fpr[1].u = fpu_sub(c->fpr[1].u, c->fpr[6].u);
    c->fpr[5].u = fpu_sub(c->fpr[0].u, c->fpr[6].u);
    c->fpr[2].u = fpu_sub(c->fpr[2].u, c->fpr[7].u);
    c->fpr[4].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 536));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 560));
    c->fpr[3].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 548));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 956), c->fpr[1].u);
    c->fpr[0].u = fpu_sub(c->fpr[0].u, c->fpr[4].u);
    c->fpr[1].u = fpu_sub(c->fpr[3].u, c->fpr[4].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 940), c->fpr[5].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 952), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 944), c->fpr[1].u);
    c->r[31].d[0] = 0x0012b474ull; rt_sw(c, (uint32_t)(c->r[29].d[0] + 960), c->fpr[0].u); fn_00186240(c);
    c->r[31].d[0] = 0x0012b47cull; c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1000); fn_001860c0(c);
    c->r[4].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1032);
    c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1000);
    c->r[6].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)592);
    c->r[7].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)656);
    c->r[8].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1144);
    c->r[9].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1080);
    c->r[10].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1064);
    c->r[31].d[0] = 0x0012b4a0ull; c->r[11].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1151); fn_00425ce0(c);
    if (c->r[2].d[0] == 0ull) { c->r[23].d[0] = SX32((uint32_t)c->r[23].d[0] + (uint32_t)1); goto L_0012b6d8; }
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144));
    fpu_cmp(c, F(c->fpr[0].u) < F(c->fpr[20].u));
    { int t_ = ((c->fcr31 & FCR31_C) == 0);  if (t_) goto L_0012b6d4; }
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1140)));
    c->r[2].d[0] = SX32((uint32_t)c->r[2].d[0] + (uint32_t)1);
    c->r[1].d[0] = ((int64_t)c->r[2].d[0] < (int64_t)2);
    { int t_ = (c->r[1].d[0] != 0ull); rt_sw(c, (uint32_t)(c->r[29].d[0] + 1140), c->r[2].d[0]); if (t_) goto L_0012b4e0; }
    if (c->r[18].d[0] == 0ull) { c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144)); goto L_0012b4e4; }
    c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1);
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 2), c->r[2].d[0]);
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 1), c->r[2].d[0]);
L_0012b4e0:;
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1144));
L_0012b4e4:;
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[19].d[0] + 36));
    c->fpr[3].u = fpu_div(c->fpr[1].u, c->fpr[20].u);
    
    
    fpu_cmp(c, F(c->fpr[3].u) < F(c->fpr[0].u));
    { int t_ = ((c->fcr31 & FCR31_C) == 0);  if (t_) goto L_0012b6d4; }
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1200));
    if (c->r[2].d[0] == 0ull) { c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1000))); goto L_0012b584; }
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1080)));
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1084)));
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1088)));
    
    
    c->r[5] = mmi_pextlw(c->r[4], c->r[3]);
    
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 0), &c->vu0.vf[14]);
    c->r[5] = mmi_pcpyld(c->r[2], c->r[5]);
    c->r[4].d[0] = SX32((uint32_t)c->r[20].d[0] + (uint32_t)16);
    c->r[3].d[0] = SX32((uint32_t)c->r[20].d[0] + (uint32_t)32);
    c->vu0.vf[13] = c->r[5];
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 16), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 32), &c->vu0.vf[10]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 13, 0xe, 10, 13, 2, 0, 0);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 688), &c->vu0.vf[13]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 688));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 692));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 696));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1080), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1084), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1088), c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 16), c->fpr[2].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1084));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 20), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1088));
    { rt_sw(c, (uint32_t)(c->r[19].d[0] + 24), c->fpr[0].u); goto L_0012b5f4; }
L_0012b584:;
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1004)));
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1008)));
    
    
    c->r[5] = mmi_pextlw(c->r[4], c->r[3]);
    
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 0), &c->vu0.vf[14]);
    c->r[5] = mmi_pcpyld(c->r[2], c->r[5]);
    c->r[4].d[0] = SX32((uint32_t)c->r[20].d[0] + (uint32_t)16);
    c->r[3].d[0] = SX32((uint32_t)c->r[20].d[0] + (uint32_t)32);
    c->vu0.vf[13] = c->r[5];
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 16), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 32), &c->vu0.vf[10]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 13, 0xe, 10, 13, 2, 0, 0);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 688), &c->vu0.vf[13]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 688));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 692));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 696));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1000), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1004), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1008), c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 16), c->fpr[2].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1004));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 20), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1008));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 24), c->fpr[0].u);
L_0012b5f4:;
    if (c->r[18].d[0] == 0ull) { c->r[5].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1064))); goto L_0012b628; }
    c->r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1);
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 2), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1151));
    rt_sb(c, (uint32_t)(c->r[18].d[0] + 0), c->r[2].d[0]);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1000));
    rt_sw(c, (uint32_t)(c->r[18].d[0] + 4), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1004));
    rt_sw(c, (uint32_t)(c->r[18].d[0] + 8), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1008));
    rt_sw(c, (uint32_t)(c->r[18].d[0] + 12), c->fpr[0].u);
    c->r[5].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1064)));
L_0012b628:;
    c->r[6].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1068)));
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 1072)));
    
    
    c->r[5] = mmi_pextlw(c->r[6], c->r[5]);
    
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 48), &c->vu0.vf[13]);
    c->r[5] = mmi_pcpyld(c->r[2], c->r[5]);
    rt_lq(c, (uint32_t)(c->r[4].d[0] + 0), &c->vu0.vf[12]);
    rt_lq(c, (uint32_t)(c->r[3].d[0] + 0), &c->vu0.vf[10]);
    rt_lq(c, (uint32_t)(c->r[20].d[0] + 0), &c->vu0.vf[14]);
    vu0_fmac(c, VU0_MUL, VU0_ACC, 0xe, 13, 0, 3, 0, 0);
    c->vu0.vf[13] = c->r[5];
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 14, 13, 0, 0, 0);
    vu0_fmac(c, VU0_MADD, VU0_ACC, 0xe, 12, 13, 1, 0, 0);
    vu0_fmac(c, VU0_MADD, 11, 0xe, 10, 13, 2, 0, 0);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 240), &c->r[2]);
    c->r[22].d[0] = (0ull + (uint64_t)(int64_t)1);
    rt_sq(c, (uint32_t)(c->r[29].d[0] + 688), &c->vu0.vf[11]);
    c->fpr[2].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 688));
    c->fpr[1].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 692));
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 696));
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1064), c->fpr[2].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1068), c->fpr[1].u);
    rt_sw(c, (uint32_t)(c->r[29].d[0] + 1072), c->fpr[0].u);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 36), c->fpr[3].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1064));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 0), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1068));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 4), c->fpr[0].u);
    c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 1072));
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 8), c->fpr[0].u);
    c->r[3].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[21].d[0] + 0)));
    c->r[3].d[0] = SX32((uint32_t)c->r[3].d[0] + (uint32_t)c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 16));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 32), c->r[2].d[0]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[3].d[0] + 17));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 33), c->r[2].d[0]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 192), &c->r[2]);
    c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[2].d[0] + 6));
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 34), c->r[2].d[0]);
    rt_sb(c, (uint32_t)(c->r[19].d[0] + 35), 0ull);
    rt_sw(c, (uint32_t)(c->r[19].d[0] + 28), c->r[16].d[0]);
L_0012b6d4:;
    c->r[23].d[0] = SX32((uint32_t)c->r[23].d[0] + (uint32_t)1);
L_0012b6d8:;
    c->r[2].d[0] = (uint64_t)(int64_t)(int16_t)rt_lh(c, (uint32_t)(c->r[17].d[0] + 28));
    c->r[2].d[0] = ((int64_t)c->r[23].d[0] < (int64_t)c->r[2].d[0]);
    if (c->r[2].d[0] != 0ull) { c->fpr[0].u = rt_lw(c, (uint32_t)(c->r[19].d[0] + 36)); { RC_BACKEDGE_AT(c, 0x0012b3c4u); goto L_0012b3c4; } }
L_0012b6e8:;
    c->r[16].d[0] = SX32((uint32_t)c->r[16].d[0] + (uint32_t)1);
L_0012b6ec:;
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 304), &c->r[2]);
    c->r[2].d[0] = ((int64_t)c->r[16].d[0] < (int64_t)c->r[2].d[0]);
    if (c->r[2].d[0] != 0ull) { c->r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(c->r[29].d[0] + 1176)); { RC_BACKEDGE_AT(c, 0x0012a74cu); goto L_0012a74c; } }
    c->r[4].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[29].d[0] + 892)));
    if (c->r[4].d[0] == 0ull) { c->r[2].d[0] = (c->r[22].d[0] + 0ull); goto L_0012b740; }
    c->r[2].d[0] = SX32(rt_lw(c, (uint32_t)(c->r[28].d[0] + -10812)));
    { int t_ = (c->r[4].d[0] != c->r[2].d[0]);  if (t_) goto L_0012b72c; }
    { int t_ = (c->r[4].d[0] == 0ull);  if (t_) goto L_0012b73c; }
    c->r[31].d[0] = 0x0012b724ull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)892); fn_0017ee10(c);
    {  goto L_0012b73c; }
L_0012b72c:;
    { int t_ = (c->r[4].d[0] == 0ull);  if (t_) goto L_0012b73c; }
    c->r[31].d[0] = 0x0012b73cull; c->r[5].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)892); fn_0017ee10(c);
L_0012b73c:;
    c->r[2].d[0] = (c->r[22].d[0] + 0ull);
L_0012b740:;
    c->r[31].d[0] = rt_ld(c, (uint32_t)(c->r[29].d[0] + 176));
    c->fpr[20].u = rt_lw(c, (uint32_t)(c->r[29].d[0] + 16));
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 160), &c->r[30]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 144), &c->r[23]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 128), &c->r[22]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 112), &c->r[21]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 96), &c->r[20]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 80), &c->r[19]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 64), &c->r[18]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 48), &c->r[17]);
    rt_lq(c, (uint32_t)(c->r[29].d[0] + 32), &c->r[16]);
    c->r[29].d[0] = SX32((uint32_t)c->r[29].d[0] + (uint32_t)1152); return;
}
