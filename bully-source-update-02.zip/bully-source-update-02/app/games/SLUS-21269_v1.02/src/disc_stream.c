/* Bully CDSTREAM.IRX RPC, verified against the SLUS-21269 v1.02 module.
 * Synchronous fixed-disc implementation; see docs/CDSTREAM.md for semantics.
 */
#include "hle.h"
#include <stdlib.h>

static uint32_t *channel_error;
static uint32_t channels, last_position;

static int disc_stream(R5900Ctx *c, uint32_t fno, uint32_t mode,
                       uint32_t send, uint32_t ssize, uint32_t recv, uint32_t rsize)
{
    (void)mode; /* The core handles SIF completion callbacks. */
    uint32_t args[4] = {0}, result = 0;
    uint32_t needed = fno == 1 ? 16 : (fno == 0 || fno == 2 || fno == 3 ? 4 : 0);
    if (fno > 5 || (needed && (!send || ssize < needed)) ||
        (rsize && (!recv || rsize < 4))) return -1;
    if (needed) memcpy(args, gptr(send, needed), needed);
    if (rsize) (void)gptr(recv, rsize);
    if (fno == 0) {
        /* The module initializes only once. Bound the allocation in this experimental pack. */
        if (!channels) {
            if (!args[0] || args[0] > 32) return -1;
            channel_error = calloc(args[0], sizeof *channel_error);
            if (!channel_error) hle_die(c, "Bully disc stream: channel allocation failed");
            channels = args[0];
            LOG("Bully disc stream: initialized %u channels\n", channels);
        }
    } else {
        if (!channels) return -1;
        if ((fno == 1 || fno == 2 || fno == 3) && args[0] >= channels) return -1;
        switch (fno) {
        case 1: {
            uint32_t ch = args[0], buf = args[1], lsn = args[2], n = args[3];
            if (!n) { channel_error[ch] = 254; break; }
            if (n > HLE_RAM_SIZE / 2048 || lsn > UINT32_MAX - n) return -1;
            void *dst = gptr(buf, n * 2048);
            channel_error[ch] = hle_disc_read_lsn(lsn, n, dst) == 0 ? 0 : 254;
            last_position = lsn + n;
            result = 1; /* Accepted; GetStatus/Sync supplies the read result. */
            VLOG("Bully disc stream: read ch=%u lsn=%u sectors=%u status=%u\n",
                 ch, lsn, n, channel_error[ch]);
            hle_safe_point(c, 4000 + (uint64_t)n * 256);
            break;
        }
        case 2:
            result = channel_error[args[0]];
            channel_error[args[0]] = 0; /* GetStatus consumes a completed error. */
            break;
        case 3: result = channel_error[args[0]]; break; /* Sync retains it. */
        case 4: result = last_position; break;
        case 5: result = 0; break; /* Fixed mounted disc: no media-change event. */
        }
    }
    if (rsize) {
        memset(gptr(recv, rsize), 0, rsize);
        sw_(recv, result);
    }
    return 0;
}

int bully_audio_probe(R5900Ctx*,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t);
int bully_scream_probe(R5900Ctx*,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t);
int bully_scream_load_probe(R5900Ctx*,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t);
void bully_ee_rpc_reset(void);

void hle_pack_iop_init(void)
{
    bully_ee_rpc_reset();
    hle_rpc_register(0xbcff,bully_audio_probe);
    hle_rpc_register(0x123456,bully_scream_probe);
    hle_rpc_register(0x123457,bully_scream_load_probe);
    free(channel_error);
    channel_error = NULL;
    channels = last_position = 0;
    hle_rpc_register(0x65686577u, disc_stream);
}

/* Private IOP import adapter: shares the same channels as EE CDSTREAM RPC. */
#include "iop_rt.h"
void probe_cd_read(IopCpu *c){uint32_t ch=c->r[4],dst=c->r[5],lsn=c->r[6],n=c->r[7];
 if(ch>=channels || !n || n>iop_rt_mem_size(c->rt)/2048 || dst>iop_rt_mem_size(c->rt)-n*2048 || lsn>UINT32_MAX-n){c->r[2]=0;return;}
 channel_error[ch]=hle_disc_read_lsn(lsn,n,c->mem+dst)==0?0:254;last_position=lsn+n;c->r[2]=1;}
void probe_cd_status(IopCpu *c){uint32_t ch=c->r[4];c->r[2]=ch<channels?channel_error[ch]:254;if(ch<channels)channel_error[ch]=0;}
void probe_cd_sync(IopCpu *c){uint32_t ch=c->r[4];c->r[2]=ch<channels?channel_error[ch]:254;}
void probe_cd_position(IopCpu *c){c->r[2]=last_position;}
