/* Conservative lower bound on converted single-level indexed texture alpha.
 * Scanning the stored index bytes includes padding, so the result can only be
 * lower than the visible image's minimum. Swizzle permutes these same bytes.
 * Unsupported formats/layouts return zero; original metadata is not changed. */
#ifndef BULLY_NATIVE_TEXTURE_ALPHA_H
#define BULLY_NATIVE_TEXTURE_ALPHA_H
#include "native_texture.h"
static inline unsigned bully_texture_alpha_minimum(const BullyNativeTexture *texture,
                                                    const uint8_t *data,size_t capacity) {
    if(!texture || !data)return 0;
    const TcPspTex *t=&texture->texture;
    if(t->swizzled>1 || t->nlevels!=1 || (t->psm!=TC_GU_T4 && t->psm!=TC_GU_T8) ||
       t->clut_psm!=TC_GU_8888 || t->clut_entries!=(t->psm==TC_GU_T4?16:256) ||
       t->total_bytes>capacity)return 0;
    const TcPspLevel *level=&t->level[0];
    size_t entries=t->clut_entries,total=t->total_bytes;
    if(!level->width || !level->height || level->bufw<level->width || level->rows<level->height ||
       !level->bytes || level->offset>total || level->bytes>total-level->offset ||
       t->clut_offset>total || t->clut_bytes>total-t->clut_offset || t->clut_bytes<entries*4)return 0;
    size_t pitch=((size_t)level->bufw*(t->psm==TC_GU_T4?4:8)+7)/8;
    if((uint64_t)pitch*level->rows>level->bytes ||
       (t->swizzled && ((pitch&15) || (level->rows&7))))return 0;
    const uint8_t *palette=data+t->clut_offset,*indices=data+level->offset;
    unsigned palette_minimum=255,minimum=255;
    for(size_t i=0;i<entries;i++)if(palette[i*4+3]<palette_minimum)palette_minimum=palette[i*4+3];
    if(palette_minimum==255)return 255;
    for(size_t i=0;i<level->bytes;i++) {
        unsigned index=indices[i],alpha;
        if(t->psm==TC_GU_T4) {
            alpha=palette[(index&15)*4+3];if(alpha<minimum)minimum=alpha;
            alpha=palette[(index>>4)*4+3];
        } else alpha=palette[index*4+3];
        if(alpha<minimum)minimum=alpha;
        if(minimum==palette_minimum)break;
    }
    return minimum;
}
#endif
