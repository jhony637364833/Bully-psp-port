#include "native_state.h"
static uint32_t word(const uint8_t *p) {
    return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static int range(size_t bytes,uint32_t at,size_t n) {
    return at>=4 && !(at&3) && at<=bytes && n<=bytes-at;
}
int bully_native_state(const uint8_t *ram,size_t bytes,uint32_t pipe,
                       uint32_t gp,BullyNativeState *out) {
    BullyNativeState s={0};
    if(!ram || !out || !range(bytes,pipe,72) || gp<25168 ||
       !range(bytes,gp-25168,80))return 0;
    uint32_t slot=word(ram+pipe+48),props=word(ram+pipe+60);
    if(!range(bytes,slot,4) || props<16 || !range(bytes,props-12,24))return 0;
    uint32_t entry=word(ram+slot);
    if(!range(bytes,entry,36))return 0;
    s.stream=word(ram+entry+32);s.material=props-12;
    if((s.stream&15) || !range(bytes,s.stream,16) ||
       (word(ram+s.stream)&0xffff0000u)!=0x10000000u)return 0;
    s.test=word(ram+gp-25152);s.alpha=word(ram+gp-25112)&255;
    s.alpha_fixed=word(ram+gp-25108)&255;
    s.zmask=word(ram+gp-25164)&1;
    s.blend=(word(ram+gp-25096)>>6)&1;
    /* DATE and ZB_ONLY/RGB_ONLY need additional GE passes, not approximation. */
    if(((s.test>>4)&255)>127 || (s.test&(1u<<14)) || ((s.test>>12)&3)>1 ||
       (s.blend && s.alpha!=0x44 && s.alpha!=0x88 &&
        !(s.alpha==0x68 && s.alpha_fixed==128)))return 0;
    *out=s;return 1;
}

/* The float sky pipeline uses the same driver shadow registers. Capture only
 * supported equations; the caller separately validates the observed materials. */
int bully_native_state_shadow(const uint8_t *ram,size_t bytes,uint32_t gp,BullyNativeState *out) {
    BullyNativeState s={0};
    if(!ram || !out || gp<25168 || !range(bytes,gp-25168,80))return 0;
    s.test=word(ram+gp-25152);s.alpha=word(ram+gp-25112)&255;
    s.alpha_fixed=word(ram+gp-25108)&255;s.zmask=word(ram+gp-25164)&1;
    s.blend=(word(ram+gp-25096)>>6)&1;
    if(((s.test>>4)&255)>127 || (s.test&(1u<<14)) || ((s.test>>12)&3)>1 ||
       (s.blend && s.alpha!=0x44 && s.alpha!=0x88 &&
        !(s.alpha==0x68 && s.alpha_fixed==128)))return 0;
    *out=s;return 1;
}
