/* EE-side synchronous RPC bridge. Keep guest SDK registration and execute each
 * handler on its registered EE thread. No game implementation is reproduced here.
 * Limits are explicit: one outstanding call per queue, no interrupt callers,
 * and no nested call from a queue's own server thread. */
#include "hle.h"

#define EE_RPC_QUEUES 4
#define EE_RPC_SERVERS 16
#define EE_RPC_WAIT_ID (-0x5349)
typedef struct {
    uint32_t addr;
    int tid, waiting, busy, done;
    uint32_t fn, buf, fno, ssize, rsize;
    void *recv;
    HleThread *caller;
} EeQueue;
typedef struct { uint32_t sd, sid, fn, buf, cbuf, queue; } EeServer;
static EeQueue queues[EE_RPC_QUEUES];
static EeServer servers[EE_RPC_SERVERS];

void bully_ee_rpc_reset(void)
{
    memset(queues, 0, sizeof queues);
    memset(servers, 0, sizeof servers);
}
static EeQueue *find_queue(uint32_t addr)
{
    for (int i=0;i<EE_RPC_QUEUES;i++) if (queues[i].addr == addr && addr) return &queues[i];
    return NULL;
}
static int span(uint32_t a, uint32_t n)
{
    return a && a < HLE_RAM_SIZE && n <= HLE_RAM_SIZE-a;
}
void GUEST(001186f0)(R5900Ctx *c);
void GUEST(00118788)(R5900Ctx *c);
HLE(001186f0) /* sceSifSetRpcQueue */
{
    uint32_t addr=ARG(0); int tid=(int)ARG(1);
    if (!span(addr,24) || !hle_thread(tid)) hle_die(c,"EE RPC: invalid queue/thread");
    EeQueue *q=find_queue(addr);
    if (q && q->busy) hle_die(c,"EE RPC: resetting busy queue");
    if (!q) for (int i=0;i<EE_RPC_QUEUES;i++) if (!queues[i].addr) {q=&queues[i];break;}
    if (!q) hle_die(c,"EE RPC: queue capacity exceeded");
    GUEST(001186f0)(c);
    memset(q,0,sizeof *q); q->addr=addr; q->tid=tid;
}
HLE(00118788) /* sceSifRegisterRpc */
{
    uint32_t sd=ARG(0),sid=ARG(1),fn=ARG(2),buf=ARG(3),cbuf=ARG(5),queue=ARG(6);
    if (!span(sd,68) || !fn || !span(buf,1) || !find_queue(queue))
        hle_die(c,"EE RPC: invalid server registration");
    EeServer *s=NULL;
    for (int i=0;i<EE_RPC_SERVERS;i++) if (servers[i].sd==sd) {s=&servers[i];break;}
    if (!s) for (int i=0;i<EE_RPC_SERVERS;i++) if (!servers[i].sd) {s=&servers[i];break;}
    if (!s) hle_die(c,"EE RPC: server capacity exceeded");
    if (find_queue(queue)->busy) hle_die(c,"EE RPC: registration on busy queue");
    GUEST(00118788)(c);
    *s=(EeServer){sd,sid,fn,buf,cbuf,queue};
    LOG("EE RPC: server %08x handler %08x on thread %d\n",sid,fn,find_queue(queue)->tid);
}
int bully_ee_rpc_bind(void *user,uint32_t sid,uint32_t *sd,uint32_t *buf,uint32_t *cbuf)
{
    (void)user; *sd=*buf=*cbuf=0;
    for (int i=0;i<EE_RPC_SERVERS;i++) if (servers[i].sd && servers[i].sid==sid) {
        *sd=servers[i].sd;*buf=servers[i].buf;*cbuf=servers[i].cbuf;break;
    }
    return 0;
}
int bully_ee_rpc_call(void *user,uint32_t sd,uint32_t fno,const void *send,uint32_t ssize,void *recv,uint32_t rsize)
{
    (void)user;
    EeServer *s=NULL;
    for (int i=0;i<EE_RPC_SERVERS;i++) if (servers[i].sd==sd && sd) {s=&servers[i];break;}
    if (!s || hle_in_intr || !hle_cur || (ssize && !send) || (rsize && !recv)) return -1;
    EeQueue *q=find_queue(s->queue);
    HleThread *t=q ? hle_thread(q->tid) : NULL;
    if (!q || !t || t==hle_cur || q->busy || !q->waiting || t->status!=TS_WAIT ||
        t->wait_kind!=WK_SLEEP || t->wait_id!=EE_RPC_WAIT_ID || !span(s->buf,ssize) || rsize>HLE_RAM_SIZE) return -1;
    if (ssize) memmove(gptr(s->buf,ssize),send,ssize);
    q->fn=s->fn;q->buf=s->buf;q->fno=fno;q->ssize=ssize;q->rsize=rsize;q->recv=recv;
    q->caller=hle_cur;q->busy=1;q->done=0;
    hle_make_ready(t); /* does not switch until the caller is blocked below */
    while (!q->done) hle_block(WK_SLEEP,EE_RPC_WAIT_ID);
    q->busy=0;q->caller=NULL;q->recv=NULL;
    return 0;
}
HLE(00118ba0) /* sceSifRpcLoop */
{
    EeQueue *q=find_queue(ARG(0));
    if (!q || !hle_cur || q->tid!=hle_cur->id || hle_in_intr) hle_die(c,"EE RPC: invalid server loop");
    for (;;) {
        while (!q->busy || q->done) {q->waiting=1;hle_block(WK_SLEEP,EE_RPC_WAIT_ID);q->waiting=0;}
        c->r[4].d[0]=q->fno;c->r[5].d[0]=q->buf;c->r[6].d[0]=q->ssize;
        rc_dispatch(c,q->fn);
        uint32_t reply=(uint32_t)c->r[2].d[0];
        if (q->rsize) {
            if (!span(reply,q->rsize)) hle_die(c,"EE RPC: invalid reply span");
            memmove(q->recv,gptr(reply,q->rsize),q->rsize);
        }
        q->done=1;
        hle_make_ready(q->caller);
        /* Block this server before the caller resumes; the caller owns busy. */
    }
}
