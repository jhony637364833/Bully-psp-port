/* Boot integration for the verified NTSC-U disc. Overlay selection is connected by overlay_load.c. */
#include "hle.h"

#if RC_MAX_OVERLAYS <= 17
#error "Apply the overlay capacity patch before building this pack."
#endif

extern rc_fn ov1_rc_lookup(uint32_t guest_addr);
extern rc_fn ov2_rc_lookup(uint32_t guest_addr);
extern rc_fn ov3_rc_lookup(uint32_t guest_addr);
extern rc_fn ov4_rc_lookup(uint32_t guest_addr);
extern rc_fn ov5_rc_lookup(uint32_t guest_addr);
extern rc_fn ov6_rc_lookup(uint32_t guest_addr);
extern rc_fn ov7_rc_lookup(uint32_t guest_addr);
extern rc_fn ov8_rc_lookup(uint32_t guest_addr);
extern rc_fn ov9_rc_lookup(uint32_t guest_addr);
extern rc_fn ov10_rc_lookup(uint32_t guest_addr);
extern rc_fn ov11_rc_lookup(uint32_t guest_addr);
extern rc_fn ov12_rc_lookup(uint32_t guest_addr);
extern rc_fn ov13_rc_lookup(uint32_t guest_addr);
extern rc_fn ov14_rc_lookup(uint32_t guest_addr);
extern rc_fn ov15_rc_lookup(uint32_t guest_addr);
extern rc_fn ov16_rc_lookup(uint32_t guest_addr);
extern rc_fn ov17_rc_lookup(uint32_t guest_addr);

void hle_pack_boot_init(void)
{
    hle_vblank_hz = 60; /* NTSC, before scheduler initialization. */
    rc_overlay_current = 0;
    rc_overlay_lo = 0x00756880u;
    rc_overlay_hi = 0x00769400u;
    rc_overlay_lookup[1] = ov1_rc_lookup;
    rc_overlay_lookup[2] = ov2_rc_lookup;
    rc_overlay_lookup[3] = ov3_rc_lookup;
    rc_overlay_lookup[4] = ov4_rc_lookup;
    rc_overlay_lookup[5] = ov5_rc_lookup;
    rc_overlay_lookup[6] = ov6_rc_lookup;
    rc_overlay_lookup[7] = ov7_rc_lookup;
    rc_overlay_lookup[8] = ov8_rc_lookup;
    rc_overlay_lookup[9] = ov9_rc_lookup;
    rc_overlay_lookup[10] = ov10_rc_lookup;
    rc_overlay_lookup[11] = ov11_rc_lookup;
    rc_overlay_lookup[12] = ov12_rc_lookup;
    rc_overlay_lookup[13] = ov13_rc_lookup;
    rc_overlay_lookup[14] = ov14_rc_lookup;
    rc_overlay_lookup[15] = ov15_rc_lookup;
    rc_overlay_lookup[16] = ov16_rc_lookup;
    rc_overlay_lookup[17] = ov17_rc_lookup;
    LOG("experimental SLUS-21269: NTSC timing, 17 overlay slots registered\n");
}
