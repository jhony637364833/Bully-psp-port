#include "native_texture.h"
#include <string.h>
#include <stddef.h>
#define TEXTURE_CACHE_BYTES (1536u*1024u)
#define TEXTURE_CACHE_ENTRIES 192u
#define TEXTURE_CACHE_MAGIC 0x54435832u
struct TextureCacheEntry {
    uint32_t valid,offset,bytes;
    TcPs2Info input;
    TcPolicy policy;
    TcPspTex plan,converted;
};
struct BullyNativeTextureCache {
    uint32_t magic,cursor,next,hits,misses;
    struct TextureCacheEntry entry[TEXTURE_CACHE_ENTRIES];
    uint8_t data[] __attribute__((aligned(16)));
};
size_t bully_native_texture_cache_bytes(void){return TEXTURE_CACHE_BYTES;}
void bully_native_texture_cache_init(BullyNativeTextureCache *cache) {
    if(!cache || ((uintptr_t)cache&15u))return;
    memset(cache,0,offsetof(BullyNativeTextureCache,data));cache->magic=TEXTURE_CACHE_MAGIC;
}
static int overlaps(const void *a,size_t an,const void *b,size_t bn) {
    uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
    if(!an || !bn)return 0;
    if(an>UINTPTR_MAX-x || bn>UINTPTR_MAX-y)return 1;
    return x<y+bn && y<x+an;
}
static BullyNativeTextureCache *usable_cache(BullyNativeTextureCache *c,const uint8_t *ram,size_t bytes,
                                             void *dst,size_t capacity,BullyNativeTexture *out,const TcPspTex *plan) {
    if(!c || ((uintptr_t)c&15u) || ((uintptr_t)dst&15u) ||
       (uint32_t)capacity<plan->total_bytes || plan->nlevels!=1 || plan->ngen ||
       overlaps(c,TEXTURE_CACHE_BYTES,ram,bytes) || overlaps(c,TEXTURE_CACHE_BYTES,dst,capacity) ||
       overlaps(c,TEXTURE_CACHE_BYTES,out,sizeof(*out)) ||
       overlaps(ram,bytes,dst,capacity) || overlaps(ram,bytes,out,sizeof(*out)))return NULL;
    return c->magic==TEXTURE_CACHE_MAGIC?c:NULL;
}
/* Parsing and planning precede every lookup. Level zero supplies alpha
 * classification; the selected level supplies pixels; CLUT bytes supply both.
 * A one-level, non-generated plan cannot consume any other pixel payload. */
static int cache_layout(const TcPs2Info *in,const TcPspTex *plan,uint32_t *source,uint32_t *total) {
    uint64_t n=(uint64_t)in->level[0].bytes+in->clut_bytes;
    if(plan->first)n+=in->level[plan->first].bytes;
    uint64_t all=n+plan->total_bytes;
    if(all>TEXTURE_CACHE_BYTES-(uint32_t)offsetof(BullyNativeTextureCache,data))return 0;
    *source=(uint32_t)n;*total=(uint32_t)((all+15u)&~15ull);
    return *total<=TEXTURE_CACHE_BYTES-(uint32_t)offsetof(BullyNativeTextureCache,data);
}
/* Equality only: scan aligned source snapshots four words at a time.
 * Never read beyond n; arbitrary alignments retain the library fallback. */
static int texture_bytes_equal(const void *left,const void *right,size_t n) {
    const unsigned char *a=left,*b=right;
    if(((uintptr_t)a|(uintptr_t)b)&3u)return !memcmp(a,b,n);
    while(n>=16) {
        uint32_t x[4],y[4];
        memcpy(x,__builtin_assume_aligned(a,4),16);
        memcpy(y,__builtin_assume_aligned(b,4),16);
        if((x[0]^y[0])|(x[1]^y[1])|(x[2]^y[2])|(x[3]^y[3]))return 0;
        a+=16;b+=16;n-=16;
    }
    return !memcmp(a,b,n);
}
static int cache_source_equal(const struct TextureCacheEntry *e,const uint8_t *p,const TcPs2Info *in,const TcPspTex *plan) {
    (void)e;
    if(!texture_bytes_equal(p,in->level[0].data,in->level[0].bytes)){return 0;}p+=in->level[0].bytes;
    if(plan->first){if(!texture_bytes_equal(p,in->level[plan->first].data,in->level[plan->first].bytes))return 0;p+=in->level[plan->first].bytes;}
    return !in->clut_bytes || texture_bytes_equal(p,in->clut,in->clut_bytes);
}
static int cache_load(BullyNativeTextureCache *c,const TcPs2Info *in,const TcPolicy *pol,TcPspTex *plan,void *dst,const void **view) {
    uint32_t source,total;if(!cache_layout(in,plan,&source,&total))return 0;
    for(unsigned i=0;i<TEXTURE_CACHE_ENTRIES;i++) {
        struct TextureCacheEntry *e=&c->entry[i];
        if(!e->valid || e->input.level[0].data!=in->level[0].data ||
           memcmp(&e->input,in,sizeof(*in)) || memcmp(&e->policy,pol,sizeof(*pol)) ||
           memcmp(&e->plan,plan,sizeof(*plan)) || !cache_source_equal(e,c->data+e->offset,in,plan))continue;
        if(view)*view=c->data+e->offset+source;else memcpy(dst,c->data+e->offset+source,plan->total_bytes);memcpy(plan,&e->converted,sizeof(*plan));c->hits++;return 1;
    }
    c->misses++;return 0;
}
static void cache_store(BullyNativeTextureCache *c,const TcPs2Info *in,const TcPolicy *pol,const TcPspTex *plan,const TcPspTex *converted,const void *dst) {
    uint32_t source,total;if(!cache_layout(in,plan,&source,&total))return;
    uint32_t limit=TEXTURE_CACHE_BYTES-(uint32_t)offsetof(BullyNativeTextureCache,data);
    uint32_t at=c->cursor;if(total>limit-at)at=0;
    for(unsigned i=0;i<TEXTURE_CACHE_ENTRIES;i++) {
        struct TextureCacheEntry *e=&c->entry[i];
        if(e->valid && e->offset<at+total && at<e->offset+e->bytes)e->valid=0;
    }
    struct TextureCacheEntry *e=&c->entry[c->next];e->valid=0;
    uint8_t *p=c->data+at;memcpy(p,in->level[0].data,in->level[0].bytes);p+=in->level[0].bytes;
    if(plan->first){memcpy(p,in->level[plan->first].data,in->level[plan->first].bytes);p+=in->level[plan->first].bytes;}
    if(in->clut_bytes){memcpy(p,in->clut,in->clut_bytes);p+=in->clut_bytes;}
    memcpy(p,dst,converted->total_bytes);
    memcpy(&e->input,in,sizeof(*in));memcpy(&e->policy,pol,sizeof(*pol));
    memcpy(&e->plan,plan,sizeof(*plan));memcpy(&e->converted,converted,sizeof(*converted));
    e->offset=at;e->bytes=total;e->valid=1;c->cursor=at+total;c->next=(c->next+1)%TEXTURE_CACHE_ENTRIES;
}

static uint32_t word(const uint8_t *p) {
    return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static int range(size_t bytes,uint32_t at,size_t n) {
    return at>=4 && !(at&3) && at<=bytes && n<=bytes-at;
}
static int texture_impl(const uint8_t *ram,size_t bytes,uint32_t material,
                         void *dst,size_t capacity,BullyNativeTexture *out,BullyNativeTextureCache *cache,const void **view) {
    if(!ram || !dst || !out || bytes>UINT32_MAX || !range(bytes,material,4))return 0;
    uint32_t tex=word(ram+material);
    if(!range(bytes,tex,84))return 0;
    uint32_t raster=word(ram+tex),fa=word(ram+tex+80);
    unsigned u=(fa>>8)&15,v=(fa>>12)&15,filter=fa&255;
    if(!range(bytes,raster,36) || (u!=1 && u!=3) || (v!=1 && v!=3) || filter<1 || filter>6)return 0;
    uint32_t pix=word(ram+raster+4),pal=word(ram+raster+8);
    unsigned format=(unsigned)ram[raster+35]<<8;
    if(pix<80 || !range(bytes,pix-80,80))return 0;
    TcPs2Raster input={0};TcPs2Info info;TcPolicy policy;
    BullyNativeTexture result={0};
    input.width=(int32_t)word(ram+raster+12);input.height=(int32_t)word(ram+raster+16);
    input.depth=(int32_t)word(ram+raster+20);input.format=format;input.version=2;
    input.nlevels=(format&TC_PF_MIPMAP)?0:1;
    input.pix=ram+pix-80;input.pix_size=(uint32_t)(bytes-(pix-80));
    /* Give the converter actual bounded RAM slices rather than the historical
     * helper's assumed palette length. The parser validates every GIF upload. */
    if(format&(TC_PF_PAL4|TC_PF_PAL8)) {
        if(pal<80 || !range(bytes,pal-80,80))return 0;
        input.pal=ram+pal-80;input.pal_size=(uint32_t)(bytes-(pal-80));
        if(pal>pix)input.pix_size=pal-pix;
    }
    if(tc_ps2_inspect(&input,&info))return 0;
    tc_policy_default(&policy);policy.max_dim=256;policy.max_levels=1;
    policy.cache_bytes=0;policy.decimate=1;
    if(tc_plan(&info,&policy,&result.texture))return 0;
    if(result.texture.total_bytes>capacity) {
        policy.max_dim=128;
        if(tc_plan(&info,&policy,&result.texture) || result.texture.total_bytes>capacity)return 0;
    }
    if(view && overlaps(dst,capacity,out,sizeof(*out)))cache=NULL;
    cache=usable_cache(cache,ram,bytes,dst,capacity,out,&result.texture);
    const void *pixels=dst;
    TcPspTex planned;if(cache)memcpy(&planned,&result.texture,sizeof planned);
    if(!cache || !cache_load(cache,&info,&policy,&result.texture,dst,view?&pixels:NULL)) {
        if(tc_convert(&info,&policy,&result.texture,dst,capacity))return 0;
        if(cache)cache_store(cache,&info,&policy,&planned,&result.texture,dst);
    }
    result.filter=filter;result.wrap_u=u;result.wrap_v=v;*out=result;if(view)*view=pixels;return 1;
}

int bully_native_texture(const uint8_t *ram,size_t bytes,uint32_t material,void *dst,size_t capacity,BullyNativeTexture *out) {
    return texture_impl(ram,bytes,material,dst,capacity,out,NULL,NULL);
}

int bully_native_texture_cached(const uint8_t *ram,size_t bytes,uint32_t material,void *dst,size_t capacity,BullyNativeTexture *out,BullyNativeTextureCache *cache) {
    return texture_impl(ram,bytes,material,dst,capacity,out,cache,NULL);
}
int bully_native_texture_view(const uint8_t *ram,size_t bytes,uint32_t material,void *dst,size_t capacity,BullyNativeTexture *out,BullyNativeTextureCache *cache,const void **view) {
    if(!view)return 0;
    return texture_impl(ram,bytes,material,dst,capacity,out,cache,view);
}
