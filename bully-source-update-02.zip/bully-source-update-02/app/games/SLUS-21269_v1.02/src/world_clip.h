#ifndef BULLY_WORLD_CLIP_H
#define BULLY_WORLD_CLIP_H
/* Camera space is the driver's (X,Y,Z), projecting to (X/Z,Y/Z).
 * Clip before division. At most 9 vertices result from 3 vertices / 6 planes. */
typedef struct { float p[3], color[3], uv[2], alpha; } BullyClipVertex;
/* Six plane bits, zero inside, -1 for non-finite input or invalid planes. */
int bully_clip_vertex_code(const BullyClipVertex *v,float near_plane,float far_plane);
int bully_clip_triangle(const BullyClipVertex input[3], float near_plane,
                        float far_plane, BullyClipVertex output[10]);
/* Exact ordered-edge reuse. Reset once per independent strip. Cached results
 * are keyed by all endpoint bits, plane index and both near/far bit patterns.
 * Keep floating-point control fixed while reusing a cache (as the renderer
 * does); reset it after any FPU mode change.
 * Two entries per plane retain the previous polygon's first two crossings.
 * Cache and polygon storage must be separate; use one cache per active strip. */
typedef struct { BullyClipVertex u,v,result; } BullyClipEdge;
typedef struct {
    BullyClipEdge edge[6][2];
    unsigned char count[6];
    unsigned initialized;
    unsigned near_bits,far_bits;
} BullyClipCache;
void bully_clip_cache_reset(BullyClipCache *cache);
int bully_clip_triangle_cached(const BullyClipVertex input[3],float near_plane,
                               float far_plane,BullyClipVertex output[10],
                               BullyClipCache *cache);
/* Optional persistent exact intersection reuse. NULL memo retains the original
 * path. See clip_memo.h for disjoint storage, FPU-state and lifetime contracts. */
typedef struct BullyClipMemo BullyClipMemo;
int bully_clip_triangle_memoized(const BullyClipVertex input[3],float near_plane,
    float far_plane,BullyClipVertex output[10],BullyClipCache *cache,BullyClipMemo *memo);
/* Internal renderer entry. Non-NULL codes must come from
 * bully_clip_vertex_code for these exact input bytes and planes; the caller
 * must not modify either between classification and this call. NULL retains
 * complete classification. Bounds, planes and negative codes remain checked. */
int bully_clip_triangle_classified(const BullyClipVertex input[3],float near,float far,
    const int codes[3],BullyClipVertex output[10],BullyClipCache *cache,BullyClipMemo *memo);
#endif
