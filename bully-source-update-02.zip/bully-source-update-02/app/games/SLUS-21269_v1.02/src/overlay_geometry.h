#ifndef BULLY_OVERLAY_GEOMETRY_H
#define BULLY_OVERLAY_GEOMETRY_H
#include <stdint.h>
typedef struct {float u,v;uint32_t color;float x,y,z;} BullyOverlayVertex;
typedef struct {
 uint64_t tex0,clamp,tex1,offset,scissor,alpha,test,frame,zbuf;
} BullyOverlayContext;
typedef struct {
 BullyOverlayContext ctx[2];
 uint64_t rgba,uv,prim,prmode,prmodecont;
 BullyOverlayVertex history[2];
 unsigned count;
 void (*state)(void*);
 void (*draw)(void*,unsigned,const BullyOverlayContext*,const BullyOverlayVertex*,unsigned);
 void *opaque;
} BullyOverlayGeometry;
void bully_overlay_geometry_init(BullyOverlayGeometry*,void(*)(void*),void(*)(void*,unsigned,const BullyOverlayContext*,const BullyOverlayVertex*,unsigned),void*);
void bully_overlay_geometry_reg(BullyOverlayGeometry*,unsigned,uint64_t);
#endif
