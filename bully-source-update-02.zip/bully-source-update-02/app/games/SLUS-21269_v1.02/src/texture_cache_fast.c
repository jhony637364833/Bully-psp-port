/* SLUS-21269 v1.02 texture residency hot path. Keep guest registers local
 * between observable boundaries; synchronize all 128 bits before/after every
 * guest call and scheduler slow path, and on return. Memory operations, guest
 * calls and backedge accounting preserve the prepared translation exactly.
 * See tests/check_texture_cache_body.py and the differential replay test. */
#include "main.h"
#define CACHE_CALL(call) do { memcpy(c->r,r,sizeof r); call; memcpy(r,c->r,sizeof r); } while(0)
#define CACHE_EDGE(at) do { hle_where=(at); if(__builtin_expect(++hle_backedge_count>=RC_BACKEDGE_PERIOD,0)) { CACHE_CALL(hle_backedge_slow(c)); } } while(0)
void y_nat_0024d848(R5900Ctx *c)
{
    R5900Reg128 r[32];
    memcpy(r,c->r,sizeof r);
    r[29].d[0] = SX32((uint32_t)r[29].d[0] + (uint32_t)-80);
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[28].d[0] + -7856)));
    rt_sq(c, (uint32_t)(r[29].d[0] + 16), &r[19]);
    rt_sq(c, (uint32_t)(r[29].d[0] + 64), &r[16]);
    r[19].d[0] = (r[4].d[0] + 0ull);
    rt_sq(c, (uint32_t)(r[29].d[0] + 48), &r[17]);
    r[16].d[0] = SX32((uint32_t)r[19].d[0] + (uint32_t)r[3].d[0]);
    rt_sq(c, (uint32_t)(r[29].d[0] + 32), &r[18]);
    rt_sd(c, (uint32_t)(r[29].d[0] + 0), r[31].d[0]);
    r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(r[16].d[0] + 54));
    r[2].d[0] = (r[2].d[0] & 0x1ull);
    { int t_ = (r[2].d[0] != 0ull); r[13].d[0] = (r[5].d[0] + 0ull); if (t_) goto L_0024d884; }
    if (r[13].d[0] != 0ull) { rt_lq(c, (uint32_t)(r[29].d[0] + 64), &r[16]); goto L_0024dd50; }
L_0024d884:;
    r[5].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 88)));
    { int t_ = (r[5].d[0] == 0ull); r[2].d[0] = SX32(0x580000u); if (t_) goto L_0024d8fc; }
    r[3].d[0] = SX32(0xaaaa0000u);
    r[17].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)-29056);
    r[3].d[0] = (r[3].d[0] | 0xaaabull);
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[17].d[0] + 20)));
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[17].d[0] + 4)));
    r[2].d[0] = SX32((uint32_t)r[5].d[0] - (uint32_t)r[2].d[0]);
    rt_mult(c, 0, r[2].d[0], r[3].d[0]); r[2].d[0] = c->lo.d[0];
    r[2].d[0] = (uint64_t)(int64_t)((int32_t)r[2].d[0] >> 2);
    if (r[4].d[0] != r[2].d[0]) { r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(r[16].d[0] + 23)); goto L_0024d900; }
    if (r[13].d[0] != 0ull) { rt_lq(c, (uint32_t)(r[29].d[0] + 64), &r[16]); goto L_0024dd50; }
    r[31].d[0] = 0x0024d8c8ull;  CACHE_CALL(fn_0011e620(c));
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 0)));
    r[3].d[0] = SX32((uint32_t)r[3].d[0] + (uint32_t)1);
    r[31].d[0] = 0x0024d8d8ull; rt_sw(c, (uint32_t)(r[16].d[0] + 0), r[3].d[0]); CACHE_CALL(fn_0011e670(c));
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 4)));
    r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)1);
    r[3].d[0] = SX32((uint32_t)r[3].d[0] + (uint32_t)1);
    { int t_ = (r[3].d[0] != r[2].d[0]); rt_sw(c, (uint32_t)(r[16].d[0] + 4), r[3].d[0]); if (t_) goto L_0024d8f4; }
    r[31].d[0] = 0x0024d8f4ull; r[4].d[0] = (r[16].d[0] + 0ull); CACHE_CALL(fn_002352d8(c));
L_0024d8f4:;
    { rt_sw(c, (uint32_t)(r[17].d[0] + 36), r[19].d[0]); goto L_0024dd4c; }
L_0024d8fc:;
    r[2].d[0] = (uint64_t)rt_lb(c, (uint32_t)(r[16].d[0] + 23));
L_0024d900:;
    if (r[2].d[0] != 0ull) { rt_lq(c, (uint32_t)(r[29].d[0] + 64), &r[16]); goto L_0024dd50; }
    r[2].d[0] = SX32(0x580000u);
    r[4].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)-29056);
    r[18].d[0] = (r[2].d[0] + 0ull);
    r[5].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 16)));
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 12)));
    { int t_ = (r[5].d[0] == r[2].d[0]); r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)12); if (t_) goto L_0024d938; }
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 20)));
    rt_mult(c, 0, r[5].d[0], r[2].d[0]); r[2].d[0] = c->lo.d[0];
    r[2].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)r[3].d[0]);
    { r[6].d[0] = SX32(rt_lw(c, (uint32_t)(r[2].d[0] + 4))); goto L_0024d944; }
L_0024d938:;
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 28)));
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 24)));
    r[6].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)r[3].d[0]);
L_0024d944:;
    r[3].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056);
    r[2].d[0] = SX32(0xffff0000u);
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[3].d[0] + 4)));
    r[2].d[0] = (r[2].d[0] | 0xffffull);
    { int t_ = (r[4].d[0] == r[2].d[0]); r[7].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 48))); if (t_) goto L_0024d988; }
    r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)12);
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[3].d[0] + 20)));
    rt_mult(c, 0, r[4].d[0], r[2].d[0]); r[2].d[0] = c->lo.d[0];
    r[2].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)r[3].d[0]);
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[2].d[0] + 8)));
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[2].d[0] + 4)));
    r[5].d[0] = SX32((uint32_t)r[3].d[0] + (uint32_t)r[4].d[0]);
    r[2].d[0] = SX32((uint32_t)r[6].d[0] - (uint32_t)r[5].d[0]);
    r[2].d[0] = ((uint64_t)r[2].d[0] < (uint64_t)r[7].d[0]);
    { int t_ = (r[2].d[0] == 0ull); r[3].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056); if (t_) goto L_0024d99c; }
L_0024d988:;
    r[5].d[0] = SX32(rt_lw(c, (uint32_t)(r[3].d[0] + 24)));
    r[2].d[0] = SX32((uint32_t)r[6].d[0] - (uint32_t)r[5].d[0]);
    r[2].d[0] = ((uint64_t)r[2].d[0] < (uint64_t)r[7].d[0]);
    if (r[2].d[0] != 0ull) { rt_lq(c, (uint32_t)(r[29].d[0] + 64), &r[16]); goto L_0024dd50; }
L_0024d99c:;
    { int t_ = (r[13].d[0] == 0ull); r[17].d[0] = (r[5].d[0] + 0ull); if (t_) goto L_0024db48; }
    r[6].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056);
    r[5].d[0] = SX32(0xffff0000u);
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 4)));
    r[5].d[0] = (r[5].d[0] | 0xffffull);
    if (r[2].d[0] == r[5].d[0]) { r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 88))); goto L_0024db4c; }
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 44)));
    { int t_ = (r[3].d[0] == r[5].d[0]); r[7].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 8))); if (t_) goto L_0024d9e8; }
    r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)12);
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 20)));
    rt_mult(c, 0, r[3].d[0], r[2].d[0]); r[2].d[0] = c->lo.d[0];
    r[2].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)r[4].d[0]);
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[2].d[0] + 0)));
    if (r[3].d[0] == 0ull) { rt_sw(c, (uint32_t)(r[6].d[0] + 44), r[5].d[0]); goto L_0024d9e8; }
    r[6].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056);
L_0024d9e8:;
    r[5].d[0] = SX32(0xffff0000u);
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 48)));
    r[5].d[0] = (r[5].d[0] | 0xffffull);
    { int t_ = (r[3].d[0] == r[5].d[0]); r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)12); if (t_) goto L_0024da14; }
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 20)));
    rt_mult(c, 0, r[3].d[0], r[2].d[0]); r[2].d[0] = c->lo.d[0];
    r[2].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)r[4].d[0]);
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[2].d[0] + 0)));
    if (r[3].d[0] == 0ull) { rt_sw(c, (uint32_t)(r[6].d[0] + 48), r[5].d[0]); goto L_0024da14; }
L_0024da14:;
    r[9].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056);
    r[2].d[0] = SX32(0xffff0000u);
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[9].d[0] + 4)));
    r[2].d[0] = (r[2].d[0] | 0xffffull);
    { int t_ = (r[4].d[0] == r[2].d[0]); r[8].d[0] = SX32((uint32_t)r[4].d[0] + (uint32_t)1); if (t_) goto L_0024db48; }
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[9].d[0] + 16)));
    r[2].d[0] = (r[8].d[0] ^ r[3].d[0]);
    { if (r[2].d[0] == 0) r[8].d[0] = 0ull; }
    if (r[8].d[0] != r[7].d[0]) { r[5].d[0] = SX32((uint32_t)0ull + (uint32_t)12); goto L_0024da64; }
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[9].d[0] + 44)));
    if (r[8].d[0] == r[2].d[0]) { rt_lq(c, (uint32_t)(r[29].d[0] + 64), &r[16]); goto L_0024dd50; }
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[9].d[0] + 48)));
    { int t_ = (r[8].d[0] == r[2].d[0]); r[7].d[0] = SX32((uint32_t)r[8].d[0] + (uint32_t)1); if (t_) goto L_0024dd4c; }
    r[2].d[0] = (r[7].d[0] ^ r[3].d[0]);
    { if (r[2].d[0] == 0) r[7].d[0] = 0ull; }
    r[5].d[0] = SX32((uint32_t)0ull + (uint32_t)12);
L_0024da64:;
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 48)));
    rt_mult(c, 0, r[4].d[0], r[5].d[0]); r[4].d[0] = c->lo.d[0];
    rt_mult(c, 0, r[7].d[0], r[5].d[0]); r[10].d[0] = c->lo.d[0];
    r[6].d[0] = SX32(rt_lw(c, (uint32_t)(r[9].d[0] + 20)));
    r[2].d[0] = SX32(0xffff0000u);
    r[2].d[0] = (r[2].d[0] | 0xf800ull);
    r[3].d[0] = SX32((uint32_t)r[3].d[0] + (uint32_t)2047);
    r[3].d[0] = (r[3].d[0] & r[2].d[0]);
    r[15].d[0] = (r[18].d[0] + 0ull);
    r[5].d[0] = SX32((uint32_t)r[10].d[0] + (uint32_t)r[6].d[0]);
    r[4].d[0] = SX32((uint32_t)r[4].d[0] + (uint32_t)r[6].d[0]);
    r[6].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 4)));
    r[10].d[0] = (r[9].d[0] + 0ull);
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 8)));
    r[9].d[0] = SX32((uint32_t)r[17].d[0] + (uint32_t)r[3].d[0]);
    r[14].d[0] = SX32((uint32_t)0ull + (uint32_t)12);
    r[12].d[0] = ((uint64_t)r[6].d[0] < (uint64_t)r[17].d[0]);
    r[2].d[0] = SX32((uint32_t)r[6].d[0] + (uint32_t)r[2].d[0]);
    { r[11].d[0] = ((uint64_t)r[17].d[0] < (uint64_t)r[2].d[0]); goto L_0024daf4; }
L_0024dab8:;
    { int t_ = (r[3].d[0] == 0ull); r[3].d[0] = SX32((uint32_t)r[15].d[0] + (uint32_t)-29056); if (t_) goto L_0024dad8; }
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[3].d[0] + 44)));
    if (r[7].d[0] == r[2].d[0]) { rt_lq(c, (uint32_t)(r[29].d[0] + 64), &r[16]); goto L_0024dd50; }
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[3].d[0] + 48)));
    if (r[7].d[0] == r[2].d[0]) { rt_lq(c, (uint32_t)(r[29].d[0] + 64), &r[16]); goto L_0024dd50; }
L_0024dad8:;
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[10].d[0] + 16)));
    r[7].d[0] = SX32((uint32_t)r[7].d[0] + (uint32_t)1);
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[10].d[0] + 20)));
    r[3].d[0] = (r[7].d[0] ^ r[3].d[0]);
    { if (r[3].d[0] == 0) r[7].d[0] = 0ull; }
    rt_mult(c, 0, r[7].d[0], r[14].d[0]); r[2].d[0] = c->lo.d[0];
    r[5].d[0] = SX32((uint32_t)r[4].d[0] + (uint32_t)r[2].d[0]);
L_0024daf4:;
    if (r[8].d[0] == r[7].d[0]) { r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 88))); goto L_0024db4c; }
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[5].d[0] + 0)));
    { int t_ = (r[2].d[0] == 0ull); r[3].d[0] = (r[2].d[0] + 0ull); if (t_) { CACHE_EDGE( 0x0024dad8u); goto L_0024dad8; } }
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[5].d[0] + 4)));
    r[2].d[0] = ((uint64_t)r[6].d[0] < (uint64_t)r[4].d[0]);
    { int t_ = (r[2].d[0] != 0ull); r[2].d[0] = ((uint64_t)r[4].d[0] < (uint64_t)r[9].d[0]); if (t_) goto L_0024db30; }
    { int t_ = (r[2].d[0] == 0ull); r[2].d[0] = ((uint64_t)r[4].d[0] < (uint64_t)r[17].d[0]); if (t_) goto L_0024db48; }
    { int t_ = (r[2].d[0] == 0ull);  if (t_) { CACHE_EDGE( 0x0024dab8u); goto L_0024dab8; } }
    { r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 88))); goto L_0024db4c; }
L_0024db30:;
    { int t_ = (r[11].d[0] != 0ull);  if (t_) goto L_0024db40; }
    { int t_ = (r[2].d[0] != 0ull);  if (t_) { CACHE_EDGE( 0x0024dab8u); goto L_0024dab8; } }
L_0024db40:;
    { int t_ = (r[12].d[0] == 0ull);  if (t_) { CACHE_EDGE( 0x0024dab8u); goto L_0024dab8; } }
L_0024db48:;
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 88)));
L_0024db4c:;
    { int t_ = (r[2].d[0] == 0ull); r[5].d[0] = (r[17].d[0] + 0ull); if (t_) goto L_0024db5c; }
    rt_sw(c, (uint32_t)(r[2].d[0] + 0), 0ull);
    rt_sw(c, (uint32_t)(r[16].d[0] + 88), 0ull);
L_0024db5c:;
    r[6].d[0] = (r[13].d[0] + 0ull);
    r[31].d[0] = 0x0024db68ull; r[4].d[0] = (r[19].d[0] + 0ull); CACHE_CALL(fn_0024cf38(c));
    r[5].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056);
    r[2].d[0] = SX32(0xffff0000u);
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[5].d[0] + 4)));
    r[2].d[0] = (r[2].d[0] | 0xffffull);
    { int t_ = (r[3].d[0] == r[2].d[0]); r[8].d[0] = SX32((uint32_t)r[3].d[0] + (uint32_t)1); if (t_) goto L_0024dd18; }
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[5].d[0] + 16)));
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[5].d[0] + 8)));
    r[2].d[0] = (r[8].d[0] ^ r[2].d[0]);
    { if (r[2].d[0] == 0) r[8].d[0] = 0ull; }
    { int t_ = (r[8].d[0] != r[3].d[0]); r[7].d[0] = SX32((uint32_t)0ull + (uint32_t)12); if (t_) goto L_0024dbe0; }
    r[2].d[0] = SX32((uint32_t)0ull + (uint32_t)12);
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[5].d[0] + 20)));
    rt_mult(c, 0, r[8].d[0], r[2].d[0]); r[2].d[0] = c->lo.d[0];
    r[2].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)r[3].d[0]);
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[2].d[0] + 0)));
    { int t_ = (r[3].d[0] == 0ull); r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[28].d[0] + -7856))); if (t_) goto L_0024dbc4; }
    r[4].d[0] = SX32((uint32_t)r[3].d[0] + (uint32_t)r[2].d[0]);
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 88)));
    rt_sw(c, (uint32_t)(r[4].d[0] + 88), 0ull);
    rt_sw(c, (uint32_t)(r[3].d[0] + 0), 0ull);
L_0024dbc4:;
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[5].d[0] + 8)));
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[5].d[0] + 16)));
    r[2].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)1);
    { int t_ = (r[2].d[0] != r[3].d[0]); rt_sw(c, (uint32_t)(r[5].d[0] + 8), r[2].d[0]); if (t_) goto L_0024dbdc; }
    rt_sw(c, (uint32_t)(r[5].d[0] + 8), 0ull);
L_0024dbdc:;
    r[7].d[0] = SX32((uint32_t)0ull + (uint32_t)12);
L_0024dbe0:;
    r[6].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056);
    rt_mult(c, 0, r[8].d[0], r[7].d[0]); r[3].d[0] = c->lo.d[0];
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 20)));
    r[13].d[0] = SX32(rt_lw(c, (uint32_t)(r[28].d[0] + -7856)));
    r[5].d[0] = SX32(0xffff0000u);
    r[5].d[0] = (r[5].d[0] | 0xf800ull);
    r[24].d[0] = (r[6].d[0] + 0ull);
    r[15].d[0] = (r[18].d[0] + 0ull);
    r[14].d[0] = SX32((uint32_t)0ull + (uint32_t)12);
    r[2].d[0] = SX32((uint32_t)r[3].d[0] + (uint32_t)r[2].d[0]);
    rt_sw(c, (uint32_t)(r[16].d[0] + 88), r[2].d[0]);
    rt_sw(c, (uint32_t)(r[2].d[0] + 0), r[19].d[0]);
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 20)));
    r[3].d[0] = SX32((uint32_t)r[3].d[0] + (uint32_t)r[4].d[0]);
    rt_sw(c, (uint32_t)(r[3].d[0] + 4), r[17].d[0]);
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 48)));
    r[2].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)2047);
    r[2].d[0] = (r[2].d[0] & r[5].d[0]);
    rt_sw(c, (uint32_t)(r[3].d[0] + 8), r[2].d[0]);
    r[10].d[0] = SX32((uint32_t)r[17].d[0] + (uint32_t)r[2].d[0]);
    r[9].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 8)));
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 4)));
    rt_mult(c, 0, r[9].d[0], r[7].d[0]); r[2].d[0] = c->lo.d[0];
    r[6].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)r[4].d[0]);
    rt_mult(c, 0, r[3].d[0], r[7].d[0]); r[2].d[0] = c->lo.d[0];
    r[5].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 0)));
    r[3].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)r[4].d[0]);
    r[7].d[0] = SX32(rt_lw(c, (uint32_t)(r[3].d[0] + 4)));
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[3].d[0] + 8)));
    r[12].d[0] = ((uint64_t)r[7].d[0] < (uint64_t)r[17].d[0]);
    r[2].d[0] = SX32((uint32_t)r[7].d[0] + (uint32_t)r[2].d[0]);
    { int t_ = (r[5].d[0] == 0ull); r[11].d[0] = ((uint64_t)r[17].d[0] < (uint64_t)r[2].d[0]); if (t_) goto L_0024dca8; }
    { int t_ = (r[8].d[0] == r[9].d[0]); r[2].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056); if (t_) goto L_0024dd10; }
    { r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 4))); goto L_0024dcf0; }
L_0024dc78:;
    { int t_ = (r[11].d[0] != 0ull);  if (t_) goto L_0024dc88; }
    if (r[2].d[0] != 0ull) { r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 0))); goto L_0024dc94; }
L_0024dc88:;
    { int t_ = (r[12].d[0] != 0ull); r[2].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056); if (t_) goto L_0024dd10; }
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 0)));
L_0024dc94:;
    { int t_ = (r[2].d[0] == 0ull); r[4].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)r[13].d[0]); if (t_) goto L_0024dca8; }
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 88)));
    rt_sw(c, (uint32_t)(r[4].d[0] + 88), 0ull);
    rt_sw(c, (uint32_t)(r[2].d[0] + 0), 0ull);
L_0024dca8:;
    r[4].d[0] = SX32((uint32_t)r[15].d[0] + (uint32_t)-29056);
L_0024dcac:;
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 8)));
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 16)));
    r[2].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)1);
    { int t_ = (r[2].d[0] != r[3].d[0]); rt_sw(c, (uint32_t)(r[4].d[0] + 8), r[2].d[0]); if (t_) goto L_0024dcc4; }
    rt_sw(c, (uint32_t)(r[4].d[0] + 8), 0ull);
L_0024dcc4:;
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 8)));
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[4].d[0] + 20)));
    rt_mult(c, 0, r[2].d[0], r[14].d[0]); r[2].d[0] = c->lo.d[0];
    r[6].d[0] = SX32((uint32_t)r[4].d[0] + (uint32_t)r[2].d[0]);
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 0)));
    if (r[3].d[0] == 0ull) { r[4].d[0] = SX32((uint32_t)r[15].d[0] + (uint32_t)-29056); { CACHE_EDGE( 0x0024dcacu); goto L_0024dcac; } }
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[24].d[0] + 8)));
    { int t_ = (r[8].d[0] == r[2].d[0]); r[2].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056); if (t_) goto L_0024dd10; }
    r[3].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 4)));
L_0024dcf0:;
    r[2].d[0] = ((uint64_t)r[7].d[0] < (uint64_t)r[3].d[0]);
    { int t_ = (r[2].d[0] != 0ull); r[2].d[0] = ((uint64_t)r[3].d[0] < (uint64_t)r[10].d[0]); if (t_) { CACHE_EDGE( 0x0024dc78u); goto L_0024dc78; } }
    { int t_ = (r[2].d[0] == 0ull); r[2].d[0] = ((uint64_t)r[3].d[0] < (uint64_t)r[17].d[0]); if (t_) goto L_0024dd0c; }
    if (r[2].d[0] == 0ull) { r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[6].d[0] + 0))); { CACHE_EDGE( 0x0024dc94u); goto L_0024dc94; } }
L_0024dd0c:;
    r[2].d[0] = SX32((uint32_t)r[18].d[0] + (uint32_t)-29056);
L_0024dd10:;
    { rt_sw(c, (uint32_t)(r[2].d[0] + 4), r[8].d[0]); goto L_0024dd4c; }
L_0024dd18:;
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[5].d[0] + 20)));
    r[3].d[0] = SX32(0xffff0000u);
    rt_sw(c, (uint32_t)(r[5].d[0] + 4), 0ull);
    r[3].d[0] = (r[3].d[0] | 0xf800ull);
    rt_sw(c, (uint32_t)(r[16].d[0] + 88), r[2].d[0]);
    rt_sw(c, (uint32_t)(r[5].d[0] + 8), 0ull);
    r[4].d[0] = SX32(rt_lw(c, (uint32_t)(r[5].d[0] + 20)));
    rt_sw(c, (uint32_t)(r[2].d[0] + 0), r[19].d[0]);
    rt_sw(c, (uint32_t)(r[4].d[0] + 4), r[17].d[0]);
    r[2].d[0] = SX32(rt_lw(c, (uint32_t)(r[16].d[0] + 48)));
    r[2].d[0] = SX32((uint32_t)r[2].d[0] + (uint32_t)2047);
    r[2].d[0] = (r[2].d[0] & r[3].d[0]);
    rt_sw(c, (uint32_t)(r[4].d[0] + 8), r[2].d[0]);
L_0024dd4c:;
    rt_lq(c, (uint32_t)(r[29].d[0] + 64), &r[16]);
L_0024dd50:;
    rt_lq(c, (uint32_t)(r[29].d[0] + 48), &r[17]);
    rt_lq(c, (uint32_t)(r[29].d[0] + 32), &r[18]);
    rt_lq(c, (uint32_t)(r[29].d[0] + 16), &r[19]);
    r[31].d[0] = rt_ld(c, (uint32_t)(r[29].d[0] + 0));
    r[29].d[0] = SX32((uint32_t)r[29].d[0] + (uint32_t)80); memcpy(c->r,r,sizeof r); return;
}

