#include "native_object.h"
#include "native_skin.h"
#include <math.h>
#include <string.h>

static int range(size_t bytes, uint32_t at, size_t n)
{
    return at >= 4 && !(at & 3) && at <= bytes && n <= bytes - at;
}
static uint32_t word(const uint8_t *p)
{
    return (uint32_t)p[0] | (uint32_t)p[1]<<8 | (uint32_t)p[2]<<16 | (uint32_t)p[3]<<24;
}
static float scalar(const uint8_t *p)
{
    uint32_t bits=word(p);
    float f;
    memcpy(&f,&bits,4);
    return f;
}
static int matrix(const uint8_t *ram, size_t bytes, uint32_t at, float m[4][3])
{
    if (!range(bytes,at,64)) return 0;
    for (unsigned i=0;i<4;i++) for (unsigned j=0;j<3;j++) {
        m[i][j]=scalar(ram+at+i*16+j*4);
        if (!isfinite(m[i][j])) return 0;
    }
    return 1;
}
typedef struct { BullyNativeSkinCache *cache;unsigned mesh; } SkinCollect;
static void collect_skin(const BullyNativeVertex *v,const uint8_t *skip,size_t n,void *context)
{
    SkinCollect *c=context;BullyNativeSkinCache *cache=c->cache;
    if(!cache->recording)return;
    if(cache->batches==BULLY_SKIN_CACHE_BATCHES ||
       n>BULLY_SKIN_CACHE_VERTICES-cache->used) {cache->recording=0;return;}
    BullySkinCachedBatch *batch=&cache->batch[cache->batches++];
    batch->first=cache->used;batch->count=(unsigned)n;
    memcpy(cache->vertex+cache->used,v,n*sizeof(*v));
    memcpy(cache->skip+cache->used,skip,n);
    cache->used+=(unsigned)n;cache->count[c->mesh]++;
}
int bully_native_object_cached(const uint8_t *ram, size_t bytes, uint32_t object,
                        uint32_t camera, BullyNativeVertex *scratch,
                        BullyNativeObject *out,BullyNativeSkinCache *skin_cache)
{
    if(skin_cache) {
        skin_cache->complete=0;skin_cache->recording=1;
        skin_cache->used=skin_cache->batches=skin_cache->meshes=0;
    }
    BullyNativeObject candidate={0};
    float local[4][3], view[4][3];
    if (!ram || !scratch || !out || bytes>UINT32_MAX ||
        !range(bytes,object,28) || !range(bytes,camera,136)) return 0;
    /* Atomic and perspective camera types observed by the original setup callback. */
    if (ram[object]!=1 || word(ram+camera)!=4 || word(ram+camera+20)!=1) return 0;
    uint32_t frame=word(ram+object+4), geo=word(ram+object+24);
    if (!range(bytes,frame,144) || !range(bytes,geo,100)) return 0;
    /* Keep this first adapter restricted to the exact static native flags observed.
     * Additional pipelines/morph targets need independent validation. */
    uint32_t flags=word(ram+geo+8);
    int skinned=flags==0x01000037u;
    if (flags!=0x0100006fu && flags!=0x0100002fu && !skinned) return 0;
    if(skinned) {
        if(!range(bytes,0x58a5f4,12) || word(ram+geo+24)!=1)return 0;
        uint32_t go=word(ram+0x58a5f8),ao=word(ram+0x58a5f4);
        if(go>bytes-geo || ao>bytes-object ||
           !range(bytes,geo+go,4) || !range(bytes,object+ao,4))return 0;
        uint32_t skin=word(ram+geo+go),hier=word(ram+object+ao);
        if(!range(bytes,skin,16) || !range(bytes,hier,20))return 0;
        candidate.bones=word(ram+skin);candidate.palette=word(ram+0x58a5fc);
        if(!candidate.bones || candidate.bones>64 || word(ram+hier+4)!=candidate.bones)return 0;
    }
    uint32_t header=word(ram+geo+84), cache=word(ram+geo+96);
    if (!range(bytes,header,16) || !range(bytes,cache,4)) return 0;
    uint32_t count=word(ram+header+4)&65535;
    if (!count || count>BULLY_NATIVE_MAX_MESHES || word(ram+header)!=1 ||
        word(ram+cache)!=count || !range(bytes,header,16+count*12) ||
        !range(bytes,cache,4+count*4)) return 0;
    if (!matrix(ram,bytes,frame+80,local) || !matrix(ram,bytes,camera+32,view)) return 0;
    candidate.near_plane=scalar(ram+camera+128);
    candidate.far_plane=scalar(ram+camera+132);
    if (!isfinite(candidate.near_plane) || !isfinite(candidate.far_plane) ||
        candidate.near_plane<=0 || candidate.near_plane>=candidate.far_plane) return 0;
    for (unsigned r=0;r<4;r++) for (unsigned k=0;k<3;k++) {
        float sum=r==3 ? view[3][k] : 0;
        for (unsigned j=0;j<3;j++) sum+=local[r][j]*view[j][k];
        if (!isfinite(sum)) return 0;
        candidate.view[r][k]=sum;
    }
    if(skinned && skin_cache) {
        memset(skin_cache->first,0,sizeof(skin_cache->first));
        memset(skin_cache->count,0,sizeof(skin_cache->count));
    }
    uint32_t total=0;size_t skin_triangles=0;
    for (uint32_t i=0;i<count;i++) {
        uint32_t entry=word(ram+cache+4+i*4);
        if (!range(bytes,entry,36)) return 0;
        uint32_t chain=word(ram+entry+32);
        if ((chain&15) || !range(bytes,chain,16)) return 0;
        BullyNativeMeshView *m=&candidate.mesh[i];
        m->vertices=word(ram+header+20+i*12);
        m->material=word(ram+header+24+i*12);
        size_t decoded=0;
        /* The original0x29ccc0 setup can set bit0x40 on compressed
         * geometry at render time. That material flag is not a vertex format.
         * Select the compressed decoder by its validated CNT chain shape. */
        if(skinned) {
            size_t used=0,tris=0;
            SkinCollect collector={skin_cache,i};
            if(skin_cache)skin_cache->first[i]=skin_cache->batches;
            if(!bully_skin_chain(ram,bytes,chain,candidate.palette,candidate.bones,
                                 scratch,skin_cache?collect_skin:0,&collector,&decoded,&used,&tris) ||
               decoded!=m->vertices || used>UINT32_MAX)return 0;
            m->stream=chain;m->bytes=(uint32_t)used;m->compressed=2;
            skin_triangles+=tris;
        } else if(flags==0x0100002fu || (word(ram+chain)&0xffff0000u)==0x10000000u) {
            size_t used=0;
            if(!bully_compressed_chain(ram,bytes,chain,scratch,0,0,&decoded,&used) ||
               decoded!=m->vertices || used>UINT32_MAX)return 0;
            m->stream=chain;m->bytes=(uint32_t)used;m->compressed=1;
        } else {
            uint32_t tag=word(ram+chain), qwords=tag&65535;
            /* Preserve the float pipeline's exact inline RET contract. */
            if ((tag&0xffff0000u)!=0x60000000u || word(ram+chain+4) ||
                !range(bytes,chain,16+(size_t)qwords*16)) return 0;
            m->stream=chain+8; m->bytes=8+qwords*16;
            if (!bully_native_decode(ram+m->stream,m->bytes,scratch,256,&decoded) ||
                decoded!=m->vertices) return 0;
        }
        total+=m->vertices; /* <=64*2048*256 by decoder bounds */
    }
    if (total!=word(ram+header+8)) return 0;
    candidate.triangles=word(ram+geo+16);
    /* Keep unverified skin topology out of the draw path. */
    if(skinned && skin_triangles!=candidate.triangles)return 0;
    candidate.meshes=count;
    *out=candidate;
    if(skinned && skin_cache && skin_cache->recording) {
        skin_cache->meshes=count;skin_cache->complete=1;
    }
    return 1;
}

int bully_native_object(const uint8_t *ram,size_t bytes,uint32_t object,
                        uint32_t camera,BullyNativeVertex *scratch,BullyNativeObject *out)
{
    return bully_native_object_cached(ram,bytes,object,camera,scratch,out,0);
}
int bully_native_skin_replay(const BullyNativeSkinCache *cache,unsigned mesh,
                            BullySkinVisit visit,void *context)
{
    if(!cache || !cache->complete || mesh>=cache->meshes ||
       mesh>=BULLY_NATIVE_MAX_MESHES || !visit || !cache->count[mesh])return 0;
    unsigned first=cache->first[mesh],count=cache->count[mesh];
    if(first>cache->batches || count>cache->batches-first ||
       cache->batches>BULLY_SKIN_CACHE_BATCHES || cache->used>BULLY_SKIN_CACHE_VERTICES)return 0;
    /* Check the whole mesh before invoking any visitor. */
    for(unsigned i=first;i<first+count;i++) {
        const BullySkinCachedBatch *batch=&cache->batch[i];
        if(batch->first>cache->used || batch->count>cache->used-batch->first)return 0;
    }
    for(unsigned i=first;i<first+count;i++) {
        const BullySkinCachedBatch *batch=&cache->batch[i];
        visit(cache->vertex+batch->first,cache->skip+batch->first,batch->count,context);
    }
    return 1;
}
